import { RUNNING_RELEASE } from './version.js';
import { getHost } from './host.js';

// Page-lifetime only. Do not reload modules or persist update state in a chat.
export function createUpdateTracker(runningRelease, readInstalled) {
  let current = { pending: false, installed: '', dismissed: false }, checking;
  const listeners = new Set();
  const notify = () => { for (const fn of listeners) fn({ ...current }); };
  return {
    state: () => ({ ...current }),
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    updated(installed = '') {
      if (installed && installed === runningRelease) return;
      if (current.pending && (!installed || installed === current.installed)) return;
      current = { pending: true, installed, dismissed: false }; notify();
    },
    dismiss() { current.dismissed = true; notify(); },
    async check() {
      if (checking) return checking;
      checking = (async () => {
        try {
          const manifest = await readInstalled();
          const installed = manifest?.shiju_build || manifest?.version;
          if (typeof installed === 'string' && installed && installed !== (manifest.shiju_build ? runningRelease : runningRelease.split('+')[0])) this.updated(installed);
        } catch { /* An offline version check is not an update failure or a model error. */ }
      })().finally(() => { checking = null; });
      return checking;
    },
  };
}
export const updates = createUpdateTracker(RUNNING_RELEASE, () => getHost().readInstalledManifest?.());
export function onExtensionUpdate() { updates.updated(); }
