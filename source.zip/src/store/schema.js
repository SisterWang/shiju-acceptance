import { cloneJson, isPlainObject } from '../plain.js';
import { DEFAULT_MODEL_SETTINGS, effectivePreferences, normalizeAppliedPreferences, normalizeModelSettings } from '../preferences.js';

/** Version 7 adds physical input boundaries and durable visibility exclusions. */
export const SCHEMA_VERSION = 8;

export const THEME_OPTIONS = [
  { id: 'day', label: '日间' },
  { id: 'night', label: '夜间' },
  { id: 'pastel', label: '粉彩' },
  { id: 'green', label: '木白' },
  { id: 'st', label: '跟随ST' },
];

export const THEME_IDS = THEME_OPTIONS.map((item) => item.id);

const TIME_SOURCE_MODES = ['auto', 'shiju', 'custom', 'baibai'];

export const DEFAULT_SETTINGS = {
  model: { ...DEFAULT_MODEL_SETTINGS },
  ui: {
    theme: 'st',
    fab: { x: null, y: null },
  },
  // auto = not chosen by hand. The settings page shows ① without 柏宝书, ③ when it is present.
  timeSource: {
    mode: 'auto',
    customTag: '',
  },
  // Off switch for shiju_macro. Missing means on.
  inject: {
    enabled: true,
  },
  // Book-level only. Empty means blue light + rotated green scan. UI may leave this unset.
  worldbook: {
    forceInclude: [],
    exclude: [],
  },
};

export function createEmptyWorld() {
  return {
    schemaVersion: SCHEMA_VERSION,
    plugin: {
      name: '世局',
      package: 'shiju',
      enabled: false,
      frozenAt: null,
    },
    storyClock: {
      dateLabel: '',
      dayIndex: 0,
      source: '',
      lastConfirmedAtFloor: null,
    },
    protagonistFocus: {
      locationGuess: null,
    },
    regions: [],
    orgs: [],
    factions: [],
    events: [],
    facts: [],
    todayChanges: [],
    timeline: [],
    dayBuffer: { items: [] },
    processedInput: null,
    appliedPreferences: effectivePreferences(),
    userCorrections: [],
    worldbookDiscovery:{cursor:0,seen:{}},
    lastEvolutionCheckpoint: null,
    evolutionLog: [],
    worldbookRotateCursor: 0,
    meta: {
      builtFingerprint: null,
      evolutionCallCount: 0,
      lastEvolvedDayIndex: null,
      errorCount: 0,
      modelCallCount: 0,
      sources: {
        memory: null,
        mvu: false,
        truncated: false,
        softWarn: false,
      },
      usage: null,
    },
  };
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function finiteOrNull(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function finiteNumber(value, fallback) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function normalizeBuffer(value) {
  if (Array.isArray(value)) return { items: value };
  if (isPlainObject(value)) {
    return { ...value, items: Array.isArray(value.items) ? value.items : [] };
  }
  return { items: [] };
}

/**
 * Fill missing fields without evolving, discarding or auto-archiving old data.
 * Future schema versions are kept. `preferences` is stripped (D8).
 */
export function migrateWorld(raw) {
  if (!isPlainObject(raw)) return createEmptyWorld();
  const base = createEmptyWorld();
  const incomingVersion = Number(raw.schemaVersion);
  const focus = { ...asObject(raw.protagonistFocus) };
  delete focus.locationCorrection;
  delete focus.locationOverride;
  delete focus.correction;
  focus.locationGuess = typeof focus.locationGuess === 'string' ? focus.locationGuess : null;

  const sources = { ...base.meta.sources, ...asObject(raw.meta?.sources) };
  const meta = {
    ...base.meta,
    ...asObject(raw.meta),
    sources: {
      memory: typeof sources.memory === 'string' ? sources.memory : null,
      mvu: Boolean(sources.mvu),
      truncated: Boolean(sources.truncated),
      softWarn: Boolean(sources.softWarn),
    },
    usage: normalizeUsage(raw.meta?.usage),
    builtFingerprint: typeof raw.meta?.builtFingerprint === 'string' ? raw.meta.builtFingerprint : null,
    evolutionCallCount: finiteNumber(raw.meta?.evolutionCallCount, 0),
    modelCallCount: finiteNumber(raw.meta?.modelCallCount, 0),
    errorCount: finiteNumber(raw.meta?.errorCount, 0),
    lastEvolvedDayIndex: finiteOrNull(raw.meta?.lastEvolvedDayIndex),
  };
  delete meta.generatingTip;

  const clockIn = asObject(raw.storyClock);
  const world = {
    ...base,
    ...raw,
    appliedPreferences: normalizeAppliedPreferences(raw.appliedPreferences),
    schemaVersion: Number.isFinite(incomingVersion) && incomingVersion > SCHEMA_VERSION
      ? incomingVersion
      : SCHEMA_VERSION,
    plugin: {
      ...base.plugin,
      ...asObject(raw.plugin),
      name: '世局',
      package: 'shiju',
      enabled: Boolean(raw.plugin?.enabled),
      frozenAt: finiteOrNull(raw.plugin?.frozenAt),
    },
    storyClock: {
      ...clockIn,
      dateLabel: typeof clockIn.dateLabel === 'string' ? clockIn.dateLabel : '',
      dayIndex: finiteNumber(clockIn.dayIndex, 0),
      source: typeof clockIn.source === 'string' ? clockIn.source : '',
      lastConfirmedAtFloor: finiteOrNull(clockIn.lastConfirmedAtFloor),
    },
    protagonistFocus: focus,
    regions: asArray(raw.regions),
    orgs: asArray(raw.orgs),
    factions: asArray(raw.factions),
    events: asArray(raw.events),
    facts: asArray(raw.facts),
    todayChanges: asArray(raw.todayChanges),
    timeline: asArray(raw.timeline),
    dayBuffer: normalizeBuffer(raw.dayBuffer),
    processedInput: isPlainObject(raw.processedInput) ? raw.processedInput : null,
    userCorrections: asArray(raw.userCorrections),
    evolutionLog: asArray(raw.evolutionLog),
    lastEvolutionCheckpoint: isPlainObject(raw.lastEvolutionCheckpoint) ? raw.lastEvolutionCheckpoint : null,
    worldbookRotateCursor: nonNegInt(raw.worldbookRotateCursor),
    worldbookDiscovery:{cursor:nonNegInt(raw.worldbookDiscovery?.cursor),seen:Object.fromEntries(Object.entries(asObject(raw.worldbookDiscovery?.seen)).filter(([,value])=>typeof value==='string'))},
    meta,
  };
  delete world.preferences;
  for(const kind of ['regions','orgs','factions','events','todayChanges']) {
    world[kind]=world[kind].map(item=>({...item,aliases:Array.isArray(item.aliases) ? item.aliases.filter(v=>typeof v==='string') : [],
      manualMaintained:item.manualMaintained===true || item.evidence==='用户修正' || world.userCorrections.some(c=>c.id===item.id && (c.kind===kind || ({event:'events',todayChange:'todayChanges',region:'regions',org:'orgs',faction:'factions'})[c.kind]===kind) && c.origin!=='generated')}));
  }
  return world;
}

function asObject(value) {
  return isPlainObject(value) ? value : {};
}

/** Merge onto defaults. Unknown keys survive so later waves can add fields. */
export function mergeSettings(raw) {
  const defaults = cloneJson(DEFAULT_SETTINGS);
  const source = isPlainObject(raw) ? raw : {};
  const merged = mergePlain(defaults, source);
  merged.model = normalizeModelSettings(merged.model);
  if (!isPlainObject(merged.ui)) merged.ui = cloneJson(defaults.ui);
  if (!THEME_IDS.includes(merged.ui.theme)) merged.ui.theme = defaults.ui.theme;
  const fab = isPlainObject(merged.ui?.fab) ? merged.ui.fab : {};
  merged.ui.fab = {
    x: finiteOrNull(fab.x),
    y: finiteOrNull(fab.y),
  };
  if (!isPlainObject(merged.timeSource)) merged.timeSource = { ...defaults.timeSource };
  if (!TIME_SOURCE_MODES.includes(merged.timeSource.mode)) merged.timeSource.mode = 'auto';
  if (typeof merged.timeSource.customTag !== 'string') merged.timeSource.customTag = '';
  if (merged.inject === false) merged.inject = { enabled: false };
  else if (!isPlainObject(merged.inject)) merged.inject = { enabled: true };
  if (typeof merged.inject.enabled !== 'boolean') merged.inject.enabled = true;
  const book = isPlainObject(merged.worldbook) ? merged.worldbook : {};
  merged.worldbook = {
    ...book,
    forceInclude: normalizeBookRefs(book.forceInclude),
    exclude: normalizeBookRefs(book.exclude),
  };
  return merged;
}

function nonNegInt(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return 0;
  return Math.floor(value);
}

function nonNegNumber(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? Math.round(value) : 0;
}

/** Estimated tokens for one assembled round. Null when this chat has not reported any. */
export function normalizeUsage(value) {
  if (!isPlainObject(value)) return null;
  const worldbook = nonNegNumber(value.worldbook);
  const mvu = nonNegNumber(value.mvu);
  const recent = nonNegNumber(value.recent);
  return {
    worldbook,
    mvu,
    recent,
    total: worldbook + mvu + recent,
    unit: 'token',
  };
}

function normalizeBookRefs(value) {
  if (!Array.isArray(value)) return [];
  const out = [];
  for (const item of value) {
    if (typeof item === 'string') {
      const text = item.trim();
      if (text) out.push(text);
      continue;
    }
    if (!isPlainObject(item)) continue;
    const uid = typeof item.uid === 'string' ? item.uid.trim() : '';
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    if (!uid && !name) continue;
    const next = {};
    if (uid) next.uid = uid;
    if (name) next.name = name;
    out.push(next);
  }
  return out;
}

function mergePlain(base, patch) {
  const out = { ...base };
  for (const [key, value] of Object.entries(patch)) {
    if (isPlainObject(value) && isPlainObject(out[key])) out[key] = mergePlain(out[key], value);
    else out[key] = value;
  }
  return out;
}
