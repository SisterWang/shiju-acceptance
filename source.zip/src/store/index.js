import { shijuError } from '../errors.js';
import { assertChatScope, captureChatScope } from '../chatScope.js';
import { getHost } from '../host.js';
import { cloneJson, deepMerge, isPlainObject } from '../plain.js';
import { createEmptyWorld, mergeSettings, migrateWorld, SCHEMA_VERSION, THEME_OPTIONS } from './schema.js';
import { normalizePreferences, validateModelSettings } from '../preferences.js';

export { createEmptyWorld, migrateWorld, SCHEMA_VERSION, THEME_OPTIONS };

const listeners = new Set();

function emit(kind) {
  for (const listener of [...listeners]) {
    try {
      listener(kind);
    } catch (error) {
      console.error('[shiju]', error);
    }
  }
}

/** @returns {() => void} unsubscribe */
export function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function context() {
  return getHost().getContext();
}

function settingsBag() {
  const bag = getHost().getExtensionSettings();
  if (!isPlainObject(bag)) {
    throw shijuError('SHIJU_NO_SETTINGS', '世局：读不到 extension_settings');
  }
  return bag;
}

/** Read extension_settings.shiju. Missing keys are filled; nothing is written. */
export function loadSettings() {
  return cloneJson(mergeSettings(settingsBag().shiju));
}

/**
 * Merge a full or partial settings object and ask the host to persist it.
 * 设置走酒馆后端的 settings.json，不进浏览器数据库。
 */
export function saveSettings(patch) {
  const bag = settingsBag();
  const current = isPlainObject(bag.shiju) ? bag.shiju : {};
  const candidate = deepMerge(current, isPlainObject(patch) ? patch : {});
  if (patch?.model) validateModelSettings({ ...loadSettings().model, ...patch.model });
  const merged = mergeSettings(candidate);
  bag.shiju = cloneJson(merged);
  const persist = getHost().saveSettingsDebounced;
  if (typeof persist === 'function') persist();
  emit('settings');
  return cloneJson(merged);
}

/** Write defaults once when the namespace is missing or older than the merge. */
export function ensureSettings() {
  const bag = settingsBag();
  const merged = mergeSettings(bag.shiju);
  if (JSON.stringify(bag.shiju) !== JSON.stringify(merged)) {
    bag.shiju = cloneJson(merged);
    const persist = getHost().saveSettingsDebounced;
    if (typeof persist === 'function') persist();
    emit('settings');
  }
  return cloneJson(merged);
}

/**
 * Read chatMetadata.shiju. Always calls getContext() again.
 * Returns null when this chat has no world yet. Does not create one.
 */
export function loadWorld() {
  const ctx = context();
  const raw = ctx?.chatMetadata?.shiju;
  if (!isPlainObject(raw)) return null;
  return cloneJson(migrateWorld(raw));
}

export function loadPreferences() {
  return normalizePreferences(context()?.chatMetadata?.shijuPreferences);
}

/** Merge metadata without resetting another extension's fields. */
export async function saveChatMetadata(patch, scope = captureChatScope(), kind = 'world') {
  assertChatScope(scope);
  const ctx = context();
  if (!ctx?.chatMetadata || typeof ctx.chatMetadata !== 'object') {
    throw shijuError('SHIJU_NO_CHAT', '世局：当前没有聊天，无法保存');
  }
  const stored = cloneJson(patch);
  if (typeof ctx.updateChatMetadata === 'function') {
    await ctx.updateChatMetadata(stored, false);
  } else Object.assign(ctx.chatMetadata, stored);
  assertChatScope(scope);
  if (typeof ctx.saveMetadata === 'function') await ctx.saveMetadata();
  assertChatScope(scope);
  emit(kind);
}

/**
 * Replace chatMetadata.shiju and ask the host to save chat metadata.
 * 世界账跟聊天走。调用方拿到的是副本，改完必须再 saveWorld。
 */
export async function saveWorld(world, chatScope) {
  if (!isPlainObject(world)) {
    throw shijuError('SHIJU_INVALID_WORLD', '世局：saveWorld 需要世界状态对象');
  }
  const scope = chatScope ?? captureChatScope();
  const stored = cloneJson(migrateWorld(world));
  await saveChatMetadata({ shiju: stored }, scope);
  return cloneJson(stored);
}
