import { ensureSettings, loadSettings, loadWorld, saveSettings, saveWorld, subscribe } from './store/index.js';
import { getHost } from './host.js';
import { mountShell } from './ui/shell.js';
import * as model from './modules/model/index.js';
import * as source from './modules/source/index.js';
import * as bootstrap from './modules/bootstrap/index.js';
import * as timetag from './modules/timetag/index.js';
import * as timeGate from './modules/timeGate/index.js';
import * as evolve from './modules/evolve/index.js';
import * as commit from './modules/commit/index.js';
import * as reconcile from './modules/reconcile/index.js';
import * as inject from './modules/inject/index.js';
import * as lifecycle from './modules/lifecycle/index.js';
import * as intervene from './modules/intervene/index.js';

const MODULES = [model, source, bootstrap, timetag, timeGate, evolve, commit, reconcile, inject, lifecycle, intervene];

function registerModules() {
  const api = { loadWorld, saveWorld, loadSettings, saveSettings, subscribe };
  for (const mod of MODULES) {
    if (typeof mod.register !== 'function') continue;
    try {
      mod.register(api);
    } catch (error) {
      console.error('[shiju] 模块注册失败', error);
    }
  }
}

function bindHostEvents(api) {
  const host = getHost();
  const type = host.event_types?.CHAT_CHANGED;
  if (!type || typeof host.eventSource?.on !== 'function') return;
  host.eventSource.on(type, () => {
    try {
      api.refresh();
    } catch (error) {
      console.error('[shiju]', error);
    }
  });
}

/** Idempotent boot. A second import (cache-bust) must not stack a second FAB. */
export function start() {
  try {
    if (typeof document === 'undefined') return null;
    if (document.getElementById('shiju-chrome')) return null;
    ensureSettings();
    const api = mountShell();
    bindHostEvents(api);
    registerModules();
    console.info('[shiju] 世局已挂上');
    return api;
  } catch (error) {
    console.error('[shiju] 启动失败', error);
    return null;
  }
}
