import { readChatStream } from './stream.js';
import { prepareTokens } from './tokens.js';
import { cloneJson } from '../plain.js';
import { shijuError } from '../errors.js';
import { createGenerationParameters, createTextGenGenerationData, getKoboldGenerationData, textgen_types, chat_completion_sources } from './native-builders.js';

export function normalizeEndpoint(value) {
  let url;
  try { url = new URL(String(value).trim()); } catch { throw shijuError('SHIJU_MODEL_SETTINGS','请填写有效的 API 地址'); }
  if (!['http:','https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw shijuError('SHIJU_MODEL_SETTINGS','API 地址须为 HTTP(S)，不包含账号、查询参数或片段');
  url.pathname = url.pathname.replace(/\/chat\/completions\/?$/, '').replace(/\/+$/, '');
  return url.toString().replace(/\/$/,'');
}
export function expandNames(value, snapshot, name = '') {
  return String(value || '').replace(/{{(user|char|name|name1|name2)}}/gi, (_, key) => ({user:snapshot.name1,name1:snapshot.name1,char:snapshot.name2,name2:snapshot.name2,name})[key.toLowerCase()] || '');
}
export function textPrompt(messages, snapshot) {
  const ins = snapshot.instruct || {}, wrap = ins.wrap ? '\n' : '';
  const nameOf = m => m.name ?? (m.role === 'user' ? snapshot.name1 : m.role === 'assistant' ? snapshot.name2 : '');
  const macro = (v,name) => ins.macro ? expandNames(v,snapshot,name) : (v || '');
  if (!ins.enabled) return messages.map(m => `${nameOf(m) ? nameOf(m)+': ' : ''}${m.content}`).join('\n')+'\n';
  const text = messages.map(m => {
    const role = m.role === 'system' ? (ins.system_same_as_user ? 'input' : 'system') : m.role === 'user' ? 'input' : 'output';
    const name=nameOf(m), prefix=macro(ins[`${role}_sequence`],name || 'System');
    const suffix=macro(ins[`${role}_suffix`],name || 'System') || wrap;
    const includeName=m.role !== 'system' && (ins.names_behavior === 'always' || ins.names_behavior === 'force' && snapshot.groupId != null && name !== snapshot.name1);
    const content=includeName && name ? `${name}: ${m.content}` : m.content;
    return [prefix,content + suffix].filter(Boolean).join(wrap);
  }).join('');
  const ending=macro(ins.last_system_sequence || ins.output_sequence,snapshot.name2 || 'System');
  return text + (ins.wrap ? ending.trimEnd() : ending) + wrap;
}
function lengthOf(request,snapshot) {
  const value = request.responseLength ?? snapshot.responseLength;
  if (!Number.isSafeInteger(value) || value <= 0) throw shijuError('SHIJU_MODEL_SETTINGS','当前接口的回复长度无效，请指定正整数');
  return value;
}
export async function buildRequest(request) {
  const s = request.connection ? cloneJson(request.connection) : null;
  if (!s) throw shijuError('SHIJU_NO_BACKEND','没有捕获到当前连接配置');
  const length = lengthOf(request,s), messages = cloneJson(request.messages);
  const path = '/api/backends/chat-completions/generate';
  if (s.mode === 'custom') return {path, api:'openai', body:{type:'quiet',chat_completion_source:'openai',model:s.customModel,
    reverse_proxy:normalizeEndpoint(s.endpoint),proxy_password:s.apiKey,messages,max_tokens:length,stream:s.stream === true,tool_choice:'none'}};
  const env = {...s, macro:v=>expandNames(v,s)};
  if (s.api === 'openai') {
    if (!Object.values(chat_completion_sources).includes(s.settings.chat_completion_source)) throw shijuError('SHIJU_UNSUPPORTED_API','当前 Chat Completion 服务商尚未适配');
    const settings = {...s.settings,stream_openai:false,openai_max_tokens:length,function_calling:false,enable_web_search:false,request_images:false};
    const {generate_data} = await createGenerationParameters(settings,s.model,'quiet',messages,{env});
    delete generate_data.tools; delete generate_data.functions;
    return {path,api:s.api,body:generate_data};
  }
  const prompt = textPrompt(messages,s);
  if (s.api === 'textgenerationwebui') {
    if (!Object.values(textgen_types).includes(s.settings.type)) throw shijuError('SHIJU_UNSUPPORTED_API','当前 Text Completion 类型尚未适配');
    return {path:'/api/backends/text-completions/generate',api:s.api,body:{...createTextGenGenerationData(s.settings,s.model,prompt,length,false,false,null,'quiet',env),type:'quiet',stream:false}};
  }
  if (s.api === 'kobold' || s.api === 'koboldhorde') {
    if(s.api === 'kobold' && s.settings.preset_settings === 'gui') return {path:'/api/backends/kobold/generate',api:s.api,body:{prompt,gui_settings:true,max_length:length,max_context_length:s.maxContext,api_server:s.settings.api_server,type:'quiet'}};
    const body = getKoboldGenerationData(prompt,s.settings,length,s.maxContext,s.api === 'koboldhorde','quiet',env);
    if (s.api === 'kobold') return {path:'/api/backends/kobold/generate',api:s.api,body:{...body,type:'quiet'}};
    delete body.prompt;
    if (!s.horde?.models?.length) throw shijuError('SHIJU_MODEL_SETTINGS','请选择 AI Horde 模型');
    return {path:'/api/horde/generate-text',api:s.api,body:{prompt,params:{...body,n:1,frmtadsnsp:false,frmtrmblln:false,frmtrmspch:false,frmttriminc:false},trusted_workers:s.horde.trusted_workers_only,models:s.horde.models}};
  }
  if (s.api === 'novel') {
    const n = s.settings;
    const body = {input:n.model_novel?.includes('erato') ? '<|startoftext|><|reserved_special_token81|>'+prompt : prompt,
      model:n.model_novel,use_string:true,max_length:length,stop_sequences:s.stopSequences,bad_words_ids:s.badWordIds,logit_bias_exp:s.novelBias,
      order:n.order,phrase_rep_pen:n.phrase_rep_pen,prefix:/clio|kayra|erato/.test(n.model_novel) ? prompt.slice(-1500).includes('}') ? 'special_instruct' : n.prefix : 'vanilla',
      generate_until_sentence:true,use_cache:false,return_full_text:false};
    for (const key of ['temperature','min_length','tail_free_sampling','repetition_penalty','repetition_penalty_range','repetition_penalty_slope','repetition_penalty_frequency','repetition_penalty_presence','top_a','top_p','top_k','min_p','math1_temp','math1_quad','math1_quad_entropy_scale','typical_p','mirostat_lr','mirostat_tau']) if(n[key] != null) body[key]=Number(n[key]);
    return {path:'/api/novelai/generate',api:s.api,body};
  }
  throw shijuError('SHIJU_UNSUPPORTED_API','当前接口或酒馆版本不兼容，请选择自定义渠道');
}
export function responseText(data, api) {
  if (data?.error) throw shijuError('SHIJU_MODEL_FAILED','模型后端返回错误；请检查连接与参数');
  const content = data?.choices?.[0]?.message?.content;
  const text = typeof content === 'string' ? content : Array.isArray(content) ? content.filter(p => p.type === 'text').map(p=>p.text).join('')
    : data?.choices?.[0]?.text ?? data?.results?.[0]?.text ?? data?.output ?? data?.content?.filter?.(p=>p.type === 'text').map(p=>p.text).join('') ?? data?.candidates?.[0]?.content?.parts?.filter(p=>p.text && !p.thought).map(p=>p.text).join('');
  if (typeof text !== 'string' || !text.trim()) throw shijuError('SHIJU_MODEL_FAILED',`模型后端没有返回文本（${api}）`);
  return text;
}
// Stop reading oversized error bodies instead of retaining an entire upstream page.
async function errorExcerpt(response, limit = 4000) {
  if (!response.body?.getReader) return '';
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let text = '', length = 0;
  try {
    while (length < limit) {
      const {value, done} = await reader.read();
      if (done) break;
      const part = value.subarray(0, limit - length);
      length += part.length; text += decoder.decode(part, {stream:true});
    }
    return (text + decoder.decode()).slice(0,2000);
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
export async function sendRequest(request, {fetchImpl = globalThis.fetch, headers, signal, assertCurrent = () => {}, pollDelay = 1000, detailed = false, onProgress = () => {}} = {}) {
  const post = async (path, body, abort = signal) => {
    assertCurrent();
    const response = await fetchImpl(path,{method:'POST',headers,body:JSON.stringify(body),signal:abort});
    if (!response.ok) throw shijuError('SHIJU_MODEL_FAILED',`模型后端请求失败（HTTP ${response.status}），未自动重试`);
    return response.json();
  };
  const connection=cloneJson(request.connection);
  await prepareTokens(connection,post);
  const built = await buildRequest({...request,connection});
  if (built.api !== 'koboldhorde') {
    if (!detailed && !built.body.stream && connection.mode !== 'custom') return responseText(await post(built.path,built.body),built.api);
    assertCurrent();
    const start = Date.now();
    const response = await fetchImpl(built.path,{method:'POST',headers,body:JSON.stringify(built.body),signal});
    if (!response.ok) {
      const detail = await errorExcerpt(response);
      const error = shijuError('SHIJU_MODEL_FAILED', `模型后端请求失败（HTTP ${response.status}）：${detail || '无错误详情'}`);
      error.httpStatus = response.status; throw error;
    }
    let result;
    if (built.body.stream) {
      try { result = await readChatStream(response,onProgress,start); }
      catch (error) { error.httpStatus = response.status; throw error; }
    }
    else {
      try {
      const data = await response.json();
      if (data?.error) { const error = shijuError('SHIJU_MODEL_FAILED', `模型后端返回错误：${String(data.error.message || data.error).slice(0, 2000)}`); error.httpStatus = response.status; throw error; }
      const finishReason = data?.choices?.[0]?.finish_reason || null;
      if (finishReason === 'length' || finishReason === 'content_filter') {
        const error = shijuError('SHIJU_MODEL_FAILED',`模型输出不完整（${finishReason}）`);
        try { error.partialText = responseText(data,built.api); } catch { error.partialText = ''; }
        error.httpStatus=response.status; error.finishReason=finishReason; throw error;
      }
      result = {text:responseText(data,built.api),usage:data?.usage || null,finishReason,actualStream:false};
      } catch (error) { error.httpStatus = response.status; throw error; }
    }
    result.httpStatus = response.status; result.elapsedMs = Date.now() - start;
    return detailed ? result : result.text;
  }
  let taskId, completed = false;
  try {
    // Keep the creation response even if switching chats, so an allocated job
    // can be explicitly cancelled instead of becoming an orphaned Horde task.
    const job = await post(built.path,built.body,null); taskId=job.id;
    if (!taskId || job.error) throw shijuError('SHIJU_MODEL_FAILED','AI Horde 未创建任务');
    const deadline=Date.now()+10*60*1000;
    while(Date.now()<deadline) {
      signal?.throwIfAborted(); assertCurrent();
      const status = await post('/api/horde/task-status',{taskId});
      if (status.faulted || status.is_possible === false) throw shijuError('SHIJU_MODEL_FAILED','AI Horde 无法完成当前任务');
      if (status.done) { completed=true; return responseText({output:status.generations?.[0]?.text},built.api); }
      await new Promise((resolve,reject)=>{const abort=()=>{clearTimeout(timer);reject(new DOMException('取消','AbortError'));}; const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},pollDelay); signal?.addEventListener('abort',abort,{once:true});});
    }
    throw shijuError('SHIJU_MODEL_FAILED','AI Horde 等待超时');
  } finally {
    if(taskId && !completed) await fetchImpl('/api/horde/cancel-task',{method:'POST',headers,body:JSON.stringify({taskId})}).catch(()=>{});
  }
}

/** Fetch models through SillyTavern; a failed status endpoint can hide the upstream status. */
export async function fetchCustomModels(settings, {fetchImpl = globalThis.fetch, headers, signal} = {}) {
  const response = await fetchImpl('/api/backends/chat-completions/status', {method:'POST',headers,signal,body:JSON.stringify({chat_completion_source:'openai',reverse_proxy:normalizeEndpoint(settings.endpoint),proxy_password:settings.apiKey || ''})});
  if (!response.ok) throw shijuError('SHIJU_MODEL_FAILED', `获取模型失败（HTTP ${response.status}）`);
  const data = await response.json();
  if (data?.error) throw shijuError('SHIJU_MODEL_FAILED','获取模型失败；酒馆未提供上游错误详情，请检查地址、密钥或渠道是否支持模型列表');
  if (!Array.isArray(data?.data)) throw shijuError('SHIJU_MODEL_FAILED','渠道不支持标准模型列表，请手动填写模型名称');
  return [...new Set(data.data.map(item => item?.id).filter(id => typeof id === 'string' && id.trim()))].sort((a,b)=>a.localeCompare(b));
}
