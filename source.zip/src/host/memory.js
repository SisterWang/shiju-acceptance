/**
 * In-memory host for smoke tests and the local preview.
 * 内存宿主：不写 IndexedDB，也不碰酒馆。
 */
export function createMemoryHost(initial = {}) {
  const listeners = new Map();
  const state = {
    extensionSettings: {},
    chatMetadata: initial.chatMetadata === undefined ? {} : initial.chatMetadata,
    chat: Array.isArray(initial.chat) ? initial.chat : [],
    worldInfoEntries: Array.isArray(initial.worldInfoEntries) ? initial.worldInfoEntries : [],
    mvu: initial.mvu ?? null,
    prompts: {},
    savedMetadata: 0,
    savedSettings: 0,
    requestHistory: null,
    hasBaibai: Boolean(initial.hasBaibai),
    chatId: initial.chatId || 'preview',
  };
  if (initial.settings) state.extensionSettings.shiju = initial.settings;

  return {
    state,
    extension_prompt_types: { NONE: -1, IN_PROMPT: 0, IN_CHAT: 1, BEFORE_PROMPT: 2 },
    extension_prompt_roles: { SYSTEM: 0, USER: 1, ASSISTANT: 2 },
    getContext() {
      return {
        chat: state.chat,
        chatId: state.chatId,
        chatMetadata: state.chatMetadata,
        worldInfoEntries: state.worldInfoEntries,
        getCurrentChatId: () => state.chatId,
        updateChatMetadata(patch, reset) {
          if (!state.chatMetadata || typeof state.chatMetadata !== 'object') {
            const error = new Error('世局：当前没有聊天');
            error.code = 'SHIJU_NO_CHAT';
            throw error;
          }
          // Match SillyTavern: reset replaces metadata; persistence is separate.
          state.chatMetadata = reset ? { ...patch } : { ...state.chatMetadata, ...patch };
        },
        async saveMetadata() {
          state.savedMetadata += 1;
        },
        setExtensionPrompt(key, value, position, depth, scan, role) {
          state.prompts[key] = { value, position, depth, scan, role };
        },
      };
    },
    getExtensionSettings() {
      return state.extensionSettings;
    },
    async loadRequestHistory() { return state.requestHistory; },
    async persistRequestHistory(data) { state.requestHistory = data; },
    saveSettingsDebounced() {
      state.savedSettings += 1;
    },
    hasBaibaiBook() {
      return Boolean(state.hasBaibai);
    },
    readChat() {
      return state.chat;
    },
    readMvu() {
      return state.mvu;
    },
    readWorldbook() {
      return { entries: state.worldInfoEntries };
    },
    setExtensionPrompt(key, value, position, depth, scan, role) {
      state.prompts[key] = { value, position, depth, scan, role };
    },
    eventSource: {
      on(type, fn) {
        const list = listeners.get(type) || [];
        list.push(fn);
        listeners.set(type, list);
      },
      emit(type, ...args) {
        for (const fn of listeners.get(type) || []) fn(...args);
      },
    },
    event_types: {
      CHAT_CHANGED: 'chat_changed',
      GENERATION_STARTED: 'generation_started',
      GENERATION_ENDED: 'generation_ended',
      GENERATION_STOPPED: 'generation_stopped',
      CHARACTER_MESSAGE_RENDERED: 'character_message_rendered',
      MESSAGE_SWIPED: 'message_swiped',
      MESSAGE_DELETED: 'message_deleted',
      MESSAGE_EDITED: 'message_edited',
    },
  };
}
