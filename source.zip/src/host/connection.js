import { cloneJson } from '../plain.js';
import { expandNames } from './transport.js';
import { shijuError } from '../errors.js';

// Native custom-provider YAML is merged by the server *after* the main body.
// Keep sampling extras, but do not let it replace this operation's protocol.
function captureCustomBody(settings, yaml) {
  const reserved = new Set(['messages','prompt','model','stream','max_tokens','max_completion_tokens','tools','tool_choice','functions','function_call','n']);
  if (!settings.custom_include_body && !settings.custom_exclude_body) return;
  if (!yaml?.parse) throw shijuError('SHIJU_UNSUPPORTED_API','无法读取当前自定义服务商的附加参数');
  try {
    const included = yaml.parse(settings.custom_include_body || '{}');
    const merged = Array.isArray(included) ? Object.assign({},...included.filter(v=>v && typeof v === 'object' && !Array.isArray(v))) : included;
    settings.custom_include_body = JSON.stringify(Object.fromEntries(Object.entries(merged && typeof merged === 'object' ? merged : {}).filter(([key])=>!reserved.has(key))));
    const excluded = yaml.parse(settings.custom_exclude_body || '[]');
    const keys = Array.isArray(excluded) ? excluded : typeof excluded === 'string' ? [excluded] : Object.keys(excluded || {});
    settings.custom_exclude_body = JSON.stringify(keys.filter(key=>!reserved.has(String(key))));
  } catch {
    throw shijuError('SHIJU_MODEL_SETTINGS','酒馆自定义服务商的附加参数格式无效');
  }
}

/** Read-only capture. No generation helper, tokenizer cache or template API. */
export function captureConnection(ctx, script, modules, modelSettings) {
  const version=String(script.CLIENT_VERSION || '').split(':')[1];
  if(!/^1\.(16|17)\./.test(version || '')) throw shijuError('SHIJU_UNSUPPORTED_API','仅适配酒馆 1.16 / 1.17；当前版本未知或不兼容');
  const api = ctx.mainApi;
  const oai = ctx.chatCompletionSettings || {};
  const settings = api === 'openai' ? oai : api === 'textgenerationwebui' ? ctx.textCompletionSettings
    : api === 'novel' ? modules.novel?.nai_settings : modules.kobold?.kai_settings;
  const snapshot = cloneJson({mode:modelSettings.channelMode || 'follow', endpoint:modelSettings.endpoint || '', customModel:modelSettings.customModel || '', apiKey:modelSettings.apiKey || '', stream:modelSettings.stream === true,
    api,version,settings:settings || {},name1:ctx.name1 || '',name2:ctx.name2 || '',groupId:ctx.groupId,
    responseLength:api === 'openai' ? oai.openai_max_tokens : Number(script.amount_gen),maxContext:Number(ctx.maxContext),
    instruct:ctx.powerUserSettings?.instruct || {},context:ctx.powerUserSettings?.context || {}, flags:modules.kobold?.kai_flags || {},horde:modules.horde?.horde_settings || {}});
  if (snapshot.mode === 'custom') return snapshot;
  if (!['openai','textgenerationwebui','novel','kobold','koboldhorde'].includes(api) || !settings) throw shijuError('SHIJU_UNSUPPORTED_API','当前酒馆接口不兼容，请选择自定义渠道');
  const expand = value => expandNames(value,snapshot);
  try {snapshot.stop=JSON.parse(ctx.powerUserSettings?.custom_stopping_strings || '[]').filter(v=>typeof v === 'string').map(expand);} catch {snapshot.stop=[];}
  const ins = snapshot.instruct;
  if (api !== 'openai') {
    const sequences = ins.enabled ? [ins.stop_sequence] : [];
    if(ins.enabled && ins.sequences_as_stop_strings) for(const field of ['input_sequence','output_sequence','first_output_sequence','last_output_sequence','system_sequence','last_system_sequence']) {
      sequences.push(String(ins[field] || '').replace(/{{name}}/gi,field.startsWith('input') ? snapshot.name1 : field.includes('system') ? 'System' : snapshot.name2));
    }
    for(const line of new Set(sequences.filter(Boolean).join('\n').split('\n').filter(s=>s.trim()))) {
      const stop=(ins.wrap ? '\n' : '')+line;snapshot.stop.push(ins.macro ? expand(stop) : stop);
    }
    if(snapshot.context.use_stop_strings) for(const field of ['chat_start','example_separator']) if(snapshot.context[field]) snapshot.stop.push('\n'+expand(snapshot.context[field]));
  }
  if (api === 'openai') {
    if (snapshot.settings.chat_completion_source === 'custom') captureCustomBody(snapshot.settings,modules.lib?.yaml);
    const fields={makersuite:'google_model',azure_openai:'azure_openai_model'};
    snapshot.model = oai[fields[oai.chat_completion_source] || `${oai.chat_completion_source}_model`];
    if (snapshot.model === 'OR_Website') snapshot.model=null;
    snapshot.biasPreset=cloneJson(oai.bias_presets?.[oai.bias_preset_selected] || []);
    snapshot.tokenizerModel=ctx.getTokenizerModel?.() || snapshot.model;
  }
  if (api === 'textgenerationwebui') {
    snapshot.model=modules.text?.getTextGenModel?.(snapshot.settings);
    snapshot.server=modules.text?.getTextGenServer?.(snapshot.settings.type);
    if (!snapshot.server) throw shijuError('SHIJU_UNSUPPORTED_API','无法读取当前 Text Completion 连接地址');
  }
  if(api === 'novel') snapshot.tokenizer=/erato/.test(settings.model_novel) ? 12 : /kayra/.test(settings.model_novel) ? 5 : /clio/.test(settings.model_novel) ? 4 : 1;
  if(api === 'textgenerationwebui') {
    const best=modules.tokenizers?.getTokenizerBestMatch?.('textgenerationwebui');
    const chosen=ctx.powerUserSettings?.tokenizer;
    snapshot.tokenizer=best === 9 ? 9 : chosen === 6 && modules.tokenizers?.TEXTGEN_TOKENIZERS?.includes(settings.type) ? 6 : modules.tokenizers?.ENCODE_TOKENIZERS?.includes(chosen) ? chosen : ['openrouter','dreamgen'].includes(settings.type) ? best : 3;
  }
  // Token IDs can be captured directly; textual bias is tokenized by our own
  // same-origin backend request using this captured model, never host caches.
  return snapshot;
}
