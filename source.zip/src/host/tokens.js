import { shijuError } from '../errors.js';
import { expandNames } from './transport.js';
const paths={1:'gpt2',2:'openai',3:'llama',4:'nerdstash',5:'nerdstash_v2',7:'mistral',8:'yi',11:'claude',12:'llama3',13:'gemma',14:'jamba',15:'qwen2',16:'command-r',17:'nemo',18:'deepseek',19:'command-a'};

/** Tokenize captured bias/ban/stop settings through ST, without shared caches. */
export async function prepareTokens(snapshot, post) {
  if (snapshot.mode === 'custom') return;
  const s=snapshot.settings;
  if(snapshot.api === 'openai') {
    if(snapshot.biasPreset?.length) snapshot.logitBias=await post(`/api/backends/chat-completions/bias?model=${encodeURIComponent(snapshot.tokenizerModel || snapshot.model || '')}`,snapshot.biasPreset);
    return;
  }
  const memo=new Map();
  async function encode(text) {
    if(memo.has(text)) return memo.get(text);
    let path,body;
    if(snapshot.tokenizer === 9 || snapshot.tokenizer === 6) {
      path='/api/tokenizers/remote/textgenerationwebui/encode';
      body={text,api_type:s.type,url:snapshot.server,vllm_model:s.vllm_model,aphrodite_model:s.aphrodite_model};
    } else {
      const name=paths[snapshot.tokenizer];
      if(!name) throw shijuError('SHIJU_UNSUPPORTED_API','当前分词器不兼容，无法转换停止串或采样词条');
      path=`/api/tokenizers/${name}/encode`;body={text};
    }
    const result=await post(path,body);
    if(!Array.isArray(result.ids)) throw shijuError('SHIJU_MODEL_FAILED','分词后端没有返回 token ID');
    memo.set(text,result.ids);return result.ids;
  }
  async function sequence(text,bias=false) {
    text=expandNames(text,snapshot).trim();
    if(text.startsWith('[') && text.endsWith(']')) {
      const ids=JSON.parse(text);
      if(!Array.isArray(ids) || ids.some(n=>!Number.isSafeInteger(n))) throw shijuError('SHIJU_MODEL_SETTINGS','采样 token 列表无效');
      return ids;
    }
    return encode(text.startsWith('{') && text.endsWith('}') ? text.slice(1,-1) : (bias ? ' ' : '')+text);
  }
  if(snapshot.api === 'textgenerationwebui') {
    snapshot.logitBias={};
    for(const entry of s.logit_bias || []) if(entry.text?.trim()) for(const id of await sequence(entry.text,true)) snapshot.logitBias[id]=entry.value;
    snapshot.tokenBans={banned_tokens:'',banned_strings:[]};
    if(s.send_banned_tokens) {
      const tokens=[];
      for(const line of new Set(`${s.banned_tokens || ''}\n${s.global_banned_tokens || ''}`.split('\n').filter(Boolean))) {
        if(line.startsWith('"') && line.endsWith('"')) snapshot.tokenBans.banned_strings.push(line.slice(1,-1));
        else tokens.push(...await sequence(line));
      }
      snapshot.tokenBans.banned_tokens=[...new Set(tokens)].join(',');
    }
  }
  if(snapshot.api === 'novel') {
    snapshot.stopSequences=[]; snapshot.badWordIds=[]; snapshot.novelBias=[];
    let stops=[...(snapshot.stop || [])];
    if(s.model_novel?.includes('erato')) for(const stop of snapshot.stop || []) if(stop.startsWith('\n')) for(const prefix of ['.','!','?','*','"','_','...','."','?"','!"','.*',')']) stops.push(prefix+stop);
    for(const stop of stops.slice(0,1024)) snapshot.stopSequences.push(await encode(stop));
    for(const line of String(s.banned_tokens || '').split('\n').map(t=>t.trim()).filter(Boolean)) {
      const variants=/^[{[]/.test(line) ? [line] : [...new Set([line,line[0].toUpperCase()+line.slice(1),line[0].toLowerCase()+line.slice(1),line.toUpperCase(),line.toLowerCase()].flatMap(t=>[t,' '+t]))];
      for(const text of variants) snapshot.badWordIds.push(/^[{[]/.test(text) ? await sequence(text) : await encode(text));
    }
    for(const entry of s.logit_bias || []) if(entry.text?.trim()) snapshot.novelBias.push({sequence:await sequence(entry.text,true),bias:entry.value,ensure_sequence_finish:false,generate_once:false});
  }
}
