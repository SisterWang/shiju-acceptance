// Account-scoped SillyTavern file storage. Never saves the host settings document.
export const HISTORY_FILE_NAME = 'shiju-request-history-v1.json';
export const HISTORY_FILE_PATH = `/user/files/${HISTORY_FILE_NAME}`;
const MAX_FILE_BYTES = 2 * 1024 * 1024 + 256;

async function readLimited(response) {
  const reader = response.body.getReader();
  const chunks = []; let size = 0;
  try {
    while (true) {
      const {value, done} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_FILE_BYTES) throw new Error('历史文件超过容量限制');
      chunks.push(value);
    }
  } catch (error) { await reader.cancel().catch(() => {}); throw error; }
  finally { reader.releaseLock(); }
  return new Blob(chunks).text();
}

export function createHistoryFileStore({getHeaders, fetchImpl = (...args) => globalThis.fetch(...args), timeoutMs = 15000}) {
  async function operation(action) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try { return await action({headers:getHeaders(), signal:controller.signal, cache:'no-store'}); }
    finally { clearTimeout(timer); }
  }
  async function read(options) {
    const response = await fetchImpl(HISTORY_FILE_PATH, options);
    if (response.status === 404) return null;
    if (!response.ok) throw new Error(`历史文件读取失败（HTTP ${response.status}）`);
    const file = JSON.parse(await readLimited(response));
    if (file?.format !== 'shiju-request-history' || file.version !== 1 || typeof file.data !== 'string' || file.data.length > 2 * 1024 * 1024) {
      throw new Error('历史文件格式无效');
    }
    return file.data;
  }
  return {
    loadRequestHistory: () => operation(read),
    persistRequestHistory: expected => operation(async options => {
      // Envelope contains ASCII only; gzip payload is already base64 encoded.
      const text = JSON.stringify({format:'shiju-request-history', version:1, data:expected});
      if (text.length > MAX_FILE_BYTES) throw new Error('历史文件超过容量限制');
      const response = await fetchImpl('/api/files/upload', {...options, method:'POST', body:JSON.stringify({name:HISTORY_FILE_NAME, data:btoa(text)})});
      if (!response.ok) throw new Error(`历史文件保存失败（HTTP ${response.status}）`);
      const result = await response.json();
      if (`/${String(result?.path || '').replace(/^\//,'')}` !== HISTORY_FILE_PATH) throw new Error('历史文件保存位置未确认');
      if (await read(options) !== expected) throw new Error('历史文件保存未确认');
    }),
  };
}
