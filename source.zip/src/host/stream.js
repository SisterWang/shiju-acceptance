import { shijuError } from '../errors.js';

/** Parse SSE without exposing reasoning as response text. */
export async function readChatStream(response, onProgress = () => {}, started = Date.now()) {
  if (!response.body?.getReader) throw shijuError('SHIJU_MODEL_FAILED', '渠道未提供可读取的流式响应');
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let buffer = '', text = '', characters = 0, done = false, finishReason = null, usage = null, firstTextMs = null, format = null;
  const failure = message => { const error = shijuError('SHIJU_MODEL_FAILED', message); error.partialText = text; error.finishReason = finishReason; throw error; };
  function event(raw) {
    const data = raw.split(/\r\n|\r|\n/).filter(line => line.startsWith('data:')).map(line => line.slice(5).replace(/^ /, '')).join('\n');
    if (/^event:\s*error\s*$/m.test(raw)) failure(`流式错误事件：${data.slice(0, 1000) || '无错误详情'}`);
    if (!data) return;
    if (data.trim() === '[DONE]') { done = true; return; }
    let part; try { part = JSON.parse(data); } catch { failure('流式响应包含无效数据'); }
    if (part.error) failure(`流式响应错误：${String(part.error.message || part.error).slice(0, 1000)}`);
    const choice = part.choices?.[0];
    const content = choice?.delta?.content ?? choice?.text ?? '';
    if (typeof content === 'string' && content) {
      if (firstTextMs == null) firstTextMs = Date.now() - started;
      text += content; characters += Array.from(content).length; onProgress({ characters, elapsedMs: Date.now() - started });
    }
    if (choice?.finish_reason) finishReason = choice.finish_reason;
    if (part.usage) usage = part.usage;
  }
  try {
    while (true) {
      const chunk = await reader.read();
      buffer += decoder.decode(chunk.value || new Uint8Array(), { stream: !chunk.done });
      if (!format && buffer.trimStart()) format = buffer.trimStart().startsWith('{') ? 'json' : 'sse';
      let match;
      while (format === 'sse' && (match = /\r\n\r\n|\n\n|\r\r/.exec(buffer))) {
        event(buffer.slice(0, match.index)); buffer = buffer.slice(match.index + match[0].length);
      }
      if (done) { await reader.cancel(); break; }
      if (chunk.done) break;
    }
    if (format === 'json') {
      let data; try { data = JSON.parse(buffer); } catch { failure('渠道返回无效 JSON'); }
      if (data.error) failure(`模型后端返回错误：${String(data.error.message || data.error).slice(0, 1000)}`);
      const choice = data.choices?.[0];
      text = choice?.message?.content ?? choice?.text ?? '';
      finishReason = choice?.finish_reason || null;
      if (finishReason === 'length' || finishReason === 'content_filter') failure(`模型输出不完整（${finishReason}）`);
      if (typeof text !== 'string' || !text.trim()) failure('模型后端没有返回文本');
      return {text, usage:data.usage || null, finishReason, firstTextMs:null, actualStream:false};
    }
    if (buffer.trim()) event(buffer);
    if (!done) failure('流式响应意外结束，未收到结束标记');
    if (finishReason === 'length' || finishReason === 'content_filter') failure(`模型输出不完整（${finishReason}）`);
    if (!text.trim()) failure('模型后端没有返回文本');
    return { text, usage, finishReason, firstTextMs, actualStream: true };
  } catch (error) {
    if (!error.partialText) error.partialText = text;
    throw error;
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
