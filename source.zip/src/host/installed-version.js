/** Read only this installed extension's manifest; never query its remote repository. */
export async function readInstalledManifest(entryUrl, fetcher = globalThis.fetch) {
  const url = new URL('./manifest.json', entryUrl);
  const response = await fetcher(url, { cache: 'no-store' });
  if (!response.ok) throw new Error('无法检查本地版本');
  return response.json();
}
