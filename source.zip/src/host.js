import { shijuError } from './errors.js';

let current = null;

/**
 * Bind the SillyTavern host once. Tests and the preview pass a fake host.
 * 绑定酒馆宿主。预览和冒烟传入替身，业务代码不要缓存 chatMetadata。
 */
export function setHost(host) {
  current = host;
}

export function getHost() {
  if (!current) {
    throw shijuError('SHIJU_NO_HOST', '世局：宿主尚未绑定');
  }
  return current;
}

/** Depth only controls placement with IN_CHAT, not IN_PROMPT. */
export function writeInChatPrompt(key, value, depth) {
  const host = getHost();
  // Official values also support lightweight hosts without exported enums.
  const position = host.extension_prompt_types?.IN_CHAT ?? 1;
  const role = host.extension_prompt_roles?.SYSTEM ?? 0;
  if (typeof host.setExtensionPrompt === 'function') {
    host.setExtensionPrompt(key, value, position, depth, false, role);
    return;
  }
  const ctx = host.getContext?.();
  if (typeof ctx?.setExtensionPrompt === 'function') {
    ctx.setExtensionPrompt(key, value, position, depth, false, role);
  }
}
