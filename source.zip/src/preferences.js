import { normalizeEndpoint } from './host/transport.js';
import { shijuError } from './errors.js';

export const EVOLUTION_PRESETS = [
  { id: 'natural', label: '自然演进', text: '按已有因果和势力动机推进，允许平静，不为了产生输出而制造事件。' },
  { id: 'steady', label: '平稳经营', text: '偏向生产、贸易、建设、合作与修复；变化渐进，危机有缓冲，但不抹去既有冲突。' },
  { id: 'intrigue', label: '暗流博弈', text: '偏向外交、利益交换、势力竞争和隐秘布局；先积累条件，再形成明显后果。' },
  { id: 'upheaval', label: '动荡变局', text: '条件成熟时积极推进权力更替、资源危机和公开冲突；后果明显，但不凭空制造灾难。' },
];
export const PREFERENCE_MODES = [...EVOLUTION_PRESETS.map((item) => item.id), 'custom'];
export const DEFAULT_PREFERENCES = { mode: 'natural', customText: '' };
export const DEFAULT_MODEL_SETTINGS = { jailbreakMode: 'builtin', customText: '', responseLength: null, channelMode: 'follow', endpoint: '', customModel: '', apiKey: '', stream: false };

export function normalizePreferences(raw) {
  return {
    mode: PREFERENCE_MODES.includes(raw?.mode) ? raw.mode : 'natural',
    customText: typeof raw?.customText === 'string' ? raw.customText : '',
  };
}
export function validatePreferences(raw) {
  if (!PREFERENCE_MODES.includes(raw?.mode)) throw shijuError('SHIJU_PREFERENCES_INVALID', '请选择一种演进偏好');
  if (raw.mode === 'custom' && (typeof raw.customText !== 'string' || !raw.customText.trim())) {
    throw shijuError('SHIJU_PREFERENCES_INVALID', '请填写自定义演进偏好，或选择一个内置方向');
  }
}
export function effectivePreferences(raw = DEFAULT_PREFERENCES) {
  const preference = normalizePreferences(raw);
  validatePreferences(preference);
  return { mode: preference.mode, text: preference.mode === 'custom'
    ? preference.customText : EVOLUTION_PRESETS.find((item) => item.id === preference.mode).text };
}
export function normalizeAppliedPreferences(raw) {
  return PREFERENCE_MODES.includes(raw?.mode) && typeof raw?.text === 'string' && raw.text.trim()
    ? { mode: raw.mode, text: raw.text } : effectivePreferences();
}
export function preferencesPending(world, current) {
  if (!world?.meta?.builtFingerprint) return false;
  const applied = normalizeAppliedPreferences(world.appliedPreferences);
  return applied.mode !== current.mode || applied.text !== current.text;
}
export function normalizeModelSettings(raw) {
  return {
    jailbreakMode: ['builtin', 'custom', 'off'].includes(raw?.jailbreakMode) ? raw.jailbreakMode : 'builtin',
    customText: typeof raw?.customText === 'string' ? raw.customText : '',
    responseLength: raw?.responseLength ?? null,
    channelMode: raw?.channelMode === 'custom' ? 'custom' : 'follow',
    endpoint: typeof raw?.endpoint === 'string' ? raw.endpoint : '',
    customModel: typeof raw?.customModel === 'string' ? raw.customModel : '',
    apiKey: typeof raw?.apiKey === 'string' ? raw.apiKey : '',
    stream: raw?.stream === true,
  };
}
export function validateModelSettings(raw) {
  if (raw.channelMode === 'custom') {
    normalizeEndpoint(raw.endpoint);
    if (!raw.customModel?.trim()) throw shijuError('SHIJU_MODEL_SETTINGS','请填写自定义渠道的模型名称');
  }
  if (!['builtin', 'custom', 'off'].includes(raw?.jailbreakMode)) throw shijuError('SHIJU_MODEL_SETTINGS', '请选择破限提示词模式');
  if (raw.jailbreakMode === 'custom' && (typeof raw.customText !== 'string' || !raw.customText.trim())) {
    throw shijuError('SHIJU_MODEL_SETTINGS', '自定义提示词不能为空，请填写内容或选择内置、关闭');
  }
  if (raw.responseLength != null && (!Number.isSafeInteger(raw.responseLength) || raw.responseLength <= 0)) {
    throw shijuError('SHIJU_MODEL_SETTINGS', '回复上限必须是正的安全整数');
  }
}
