/** Typed error. code is stable for callers. 带 code 的错误，调用方靠 code 分支。 */
export function shijuError(code, message) {
  const error = new Error(message);
  error.name = 'ShijuError';
  error.code = code;
  return error;
}
