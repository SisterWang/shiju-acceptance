import { getHost } from '../host.js';

/** 柏宝书挂上公共接口时派发。只用来刷新探测，不读楼。 */
export const BAIBAI_READY_EVENT = 'st-baibai-book:ready';

function markerPresent(value) {
  return Boolean(value) && (typeof value === 'object' || typeof value === 'function');
}

/**
 * Live page markers from ST-BaiBai-Book.
 * Leftover extension_settings are not treated as "the book is here".
 * 只认已经挂上的运行时标记。
 */
export function detectBaibaiInPage() {
  const root = globalThis;
  if (markerPresent(root.STBaiBaiBook)) return true;
  if (typeof root.bbs_generateInterceptor === 'function') return true;
  if (typeof document !== 'undefined' && document.getElementById('bbs-app-host')) return true;
  return false;
}

/** Host hook wins when present (preview and smoke). Otherwise look at the page. */
export function detectBaibaiBook() {
  try {
    const host = getHost();
    if (typeof host.hasBaibaiBook === 'function') return Boolean(host.hasBaibaiBook());
  } catch {
    /* Host not bound yet. */
  }
  return detectBaibaiInPage();
}

export function watchBaibaiReady(listener) {
  if (typeof window === 'undefined' || typeof listener !== 'function') return () => {};
  const onReady = () => {
    try {
      listener();
    } catch (error) {
      console.error('[shiju]', error);
    }
  };
  window.addEventListener(BAIBAI_READY_EVENT, onReady);
  return () => window.removeEventListener(BAIBAI_READY_EVENT, onReady);
}
