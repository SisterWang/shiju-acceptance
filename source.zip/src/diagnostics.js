import { assertChatScope } from './chatScope.js';
let latest = [], owner = null;
const listeners = new Set();
export function publishDiagnostics(items, scope) {
  assertChatScope(scope); latest = items; owner = scope;
  for (const fn of listeners) fn();
}
export function readDiagnostics() {
  try { assertChatScope(owner); return latest; } catch { return []; }
}
export function subscribeDiagnostics(fn) { listeners.add(fn); return () => listeners.delete(fn); }
