/** Knowledge belongs to the protagonist; visibility belongs to the reader. */
export function isSecret(item) {
  return item?.kind === 'secret' || item?.secret === true || item?.veil === true;
}
export function isKnown(item) {
  if (item?.knowledgeOverride === 'known') return true;
  if (item?.knowledgeOverride === 'unknown') return false;
  return Boolean(item?.autoKnown ?? item?.knownMarked);
}
export function isFactVisible(item) {
  if (!isSecret(item)) return true;
  if (item?.viewMode === 'hidden') return false;
  return Boolean(item?.revealed || isKnown(item));
}
export function synchronizeKnowledge(world) {
  for (const change of world.todayChanges || []) {
    const event = (world.events || []).find((item) => item.id === change.linkedEventId);
    if (!event) continue;
    for (const key of ['autoKnown', 'knowledgeOverride', 'knownMarked', 'knowledgeEvidence', 'viewMode', 'revealed']) {
      if (key in event) change[key] = event[key];
      else delete change[key];
    }
    if (isSecret(event)) change.kind = 'secret';
  }
}

export const EVENT_MODEL_RULES = [
  '事件以 8～12 条进行中为软目标，不为凑数删除仍在发展的事件。优先按已有 id 更新，同一事态不要重复新建。',
  'events 项的 lifecycle 可为 active 或 archived。归档必须给出 outcome（长期后果；确无变化时明确写无持久变化）；全文保留。',
  '重复事件可归档并用 mergedInto 指向保留的事件 id；重新发展时复用原 id 并设 lifecycle=active。',
  '隐秘只有主角从剧情中获知才可自动判为已知，不能因为世界书、世界账或用户查看就判已知。',
  '自动知情使用 knowledge:[{kind:"event"或"todayChange",id,known:true,evidenceQuote:"给定剧情或记忆中的原句"}]；无依据则不输出。不得修改用户的手动知情覆盖。',
  'todayChanges 关联事件时填写 linkedEventId；隐秘知情状态沿用关联事件。',
].join('\n');

/** Include full active records but only identity information for archived ones. */
export function eventContext(world) {
  const active = (world?.events || []).filter((item) => item.lifecycle !== 'archived').map((item) => ({
    id: item.id, kind: item.kind, title: item.title, body: item.body, phase: item.phase,
    lifecycle: 'active', protagonistKnows: isKnown(item), relatedRefs: item.relatedRefs || [],
  }));
  const archived = (world?.events || []).filter((item) => item.lifecycle === 'archived')
    .map(({ id, title, mergedInto }) => ({ id, title, mergedInto }));
  return `当前进行中事件（更新时复用 id）：\n${JSON.stringify(active)}\n\n归档索引（仅供识别旧事复发，不重新演进历史）：\n${JSON.stringify(archived)}`;
}

export function applyKnowledgeEvidence(world, proposals, evidenceText) {
  const evidence = String(evidenceText || '');
  for (const proposal of Array.isArray(proposals) ? proposals : []) {
    const quote = typeof proposal?.evidenceQuote === 'string' ? proposal.evidenceQuote.trim() : '';
    // Only accept quotes actually present in supplied prose/memory, never worldbook text.
    if (proposal?.known !== true || quote.length < 6 || !evidence.includes(quote)) continue;
    const list = proposal.kind === 'event' ? world.events : proposal.kind === 'todayChange' ? world.todayChanges : [];
    let item = (list || []).find((entry) => entry.id === proposal.id);
    if (item?.linkedEventId) item = world.events.find((entry) => entry.id === item.linkedEventId) || item;
    if (!item || !isSecret(item)) continue;
    item.autoKnown = true;
    item.knowledgeEvidence = quote;
    item.knownMarked = isKnown(item);
  }
  synchronizeKnowledge(world);
}
