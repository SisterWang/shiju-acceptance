/** Knowledge belongs to the protagonist; visibility belongs to the reader. */
export function isSecret(item) {
  return item?.kind === 'secret' || item?.secret === true || item?.veil === true;
}
export function isKnown(item) {
  if (item?.knowledgeOverride === 'known') return true;
  if (item?.knowledgeOverride === 'unknown') return false;
  return Boolean(item?.autoKnown ?? item?.knownMarked);
}
export function isFactVisible(item) {
  if (!isSecret(item)) return true;
  if (item?.viewMode === 'hidden') return false;
  return Boolean(item?.revealed || isKnown(item));
}
export function synchronizeKnowledge(world) {
  for (const change of world.todayChanges || []) {
    const event = (world.events || []).find((item) => item.id === change.linkedEventId);
    if (!event) continue;
    for (const key of ['autoKnown', 'knowledgeOverride', 'knownMarked', 'knowledgeEvidence', 'viewMode', 'revealed']) {
      if (key in event) change[key] = event[key];
      else delete change[key];
    }
    if (isSecret(event)) change.kind = 'secret';
  }
}

export const EVENT_MODEL_RULES = [
  '新增实体必须包含非空 name、summary；新增事件必须包含非空 title、body。现有条目可按 id 更新，省略的字段保持不变。',
  '输出字段规范：regions、orgs、factions、events、facts、todayChanges、knowledge 如有输出，必须是对象数组，不是字符串数组或以 id 为键的对象。locationGuess、note 如有输出，必须是字符串。只输出当前任务允许的字段。',
  'regions、orgs、factions 的实体使用 name（名称）、summary（完整概况）；可选 id、aliases（字符串数组）、status（active/dormant/resolved）、regionRef（地区 id）、secret（布尔值）。',
  'events 的事件使用 title（标题）、body（完整正文）；kind 为 macro/news/secret，phase 为萌芽/发展/高潮/消退/稳定，lifecycle 为 active/archived；relatedRefs 是实体 id 的字符串数组。',
  'todayChanges 每项必须明确输出非空字符串 title（这条今日变更的标题）和 body（这条今日变更的完整内容），以及 kind（macro/news/secret）；可选 id、linkedEventId。即使关联了事件，也不能省略 title 或 body，插件不会自动从关联事件补齐。不要用 text、name、summary、description 替代 title 或 body，也不要只输出事件 id。',
  'todayChanges 的 linkedEventId 必须引用世界账中已有或本次 events 中输出的事件 id；没有对应事件时省略该字段。提供 todayChanges 表示替换本日变更完整列表，不是只追加新条目；本日没有变更时输出 []。建世界和重新初始化仍按任务要求输出 todayChanges:[]；分类补全不得输出 todayChanges。',
  'facts 每项使用非空字符串 text（持久事实），可选 id、evidence；text 是 facts 的字段，不是 events 或 todayChanges 的正文替代字段。',
  'id 如有输出必须是非空字符串；更新已有记录沿用原 id，同一数组不要重复 id 或名称／标题。省略必填字段仅适用于可按原 id 确定已有完整内容的实体／事件更新，不适用于 todayChanges。',
  '以下只是演进响应的格式示例，不是世界资料；不要照抄示例剧情或 id，其他任务仍遵守各自允许的字段与空数组要求。',
  JSON.stringify({ events: [{ id: 'event-example-bridge', kind: 'macro', title: '渡口木桥恢复通行', body: '修缮完成后，商队可以重新使用渡口木桥。', lifecycle: 'active' }], todayChanges: [{ id: 'change-example-bridge', kind: 'macro', title: '渡口恢复通行', body: '木桥完成修缮，沿岸货运恢复。', linkedEventId: 'event-example-bridge' }] }),
  '事件以 8～12 条进行中为软目标，不为凑数删除仍在发展的事件。优先按已有 id 更新，同一事态不要重复新建。',
  'events 项的 lifecycle 可为 active 或 archived。归档必须给出 outcome（长期后果；确无变化时明确写无持久变化）；全文保留。',
  '重复事件可归档并用 mergedInto 指向保留的事件 id；重新发展时复用原 id 并设 lifecycle=active。',
  '隐秘只有主角从剧情中获知才可自动判为已知，不能因为世界书、世界账或用户查看就判已知。',
  '自动知情使用 knowledge:[{kind:"event"或"todayChange",id,known:true,evidenceQuote:"给定剧情或记忆中的原句"}]；无依据则不输出。不得修改用户的手动知情覆盖。',
  'todayChanges 关联事件时填写 linkedEventId；隐秘知情状态沿用关联事件。',
].join('\n');

/** Include full active records but only identity information for archived ones. */
export function eventContext(world) {
  const active = (world?.events || []).filter((item) => item.lifecycle !== 'archived').map((item) => ({
    ...item,
    lifecycle: 'active', protagonistKnows: isKnown(item), relatedRefs: item.relatedRefs || [],
  }));
  const archived = (world?.events || []).filter((item) => item.lifecycle === 'archived')
    .map(({ id, title, mergedInto }) => ({ id, title, mergedInto }));
  return `当前进行中事件（更新时复用 id）：\n${JSON.stringify(active)}\n\n归档索引（仅供识别旧事复发，不重新演进历史）：\n${JSON.stringify(archived)}`;
}

export function applyKnowledgeEvidence(world, proposals, evidenceText) {
  const evidence = String(evidenceText || '');
  for (const proposal of Array.isArray(proposals) ? proposals : []) {
    const quote = typeof proposal?.evidenceQuote === 'string' ? proposal.evidenceQuote.trim() : '';
    // Only accept quotes actually present in supplied prose/memory, never worldbook text.
    if (proposal?.known !== true || quote.length < 6 || !evidence.includes(quote)) continue;
    const list = proposal.kind === 'event' ? world.events : proposal.kind === 'todayChange' ? world.todayChanges : [];
    let item = (list || []).find((entry) => entry.id === proposal.id);
    if (item?.linkedEventId) item = world.events.find((entry) => entry.id === item.linkedEventId) || item;
    if (!item || !isSecret(item)) continue;
    item.autoKnown = true;
    item.knowledgeEvidence = quote;
    item.knownMarked = isKnown(item);
  }
  synchronizeKnowledge(world);
}
