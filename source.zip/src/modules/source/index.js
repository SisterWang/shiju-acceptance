import { captureChatScope, assertChatScope } from '../../chatScope.js';
import { shijuError } from '../../errors.js';
import { loadWorld } from '../../store/index.js';
import { manualHidden, memoryHidden, hiddenMessage, summaryNodes } from '../visibility.js';
import { cloneJson } from '../../plain.js';
import { getHost } from '../../host.js';
import { collectKeys } from '../worldbook/select.js';

/**
 * M-Source. Read-only pack for world building and evolution.
 * `{ worldbook, floorsTail, baibai?, mvu? }`. Never writes the world ledger.
 */



export function register() {}

function enabledEntry(entry) {
  if (!entry || typeof entry !== 'object') return false;
  if (entry.disable === true || entry.disabled === true || entry.enabled === false) return false;
  return true;
}

function bookMetaOf(book, fallbackName = '') {
  const name = typeof book?.name === 'string' && book.name.trim()
    ? book.name.trim()
    : (typeof book?.bookName === 'string' && book.bookName.trim() ? book.bookName.trim() : String(fallbackName || '').trim());
  const uid = typeof book?.uid === 'string' && book.uid.trim()
    ? book.uid.trim()
    : (typeof book?.bookUid === 'string' ? book.bookUid.trim() : '');
  return { bookName: name, bookUid: uid };
}

export function normalizeEntries(raw, bookMeta = {}) {
  const list = Array.isArray(raw) ? raw : (raw && typeof raw === 'object' ? Object.values(raw) : []);
  const entries = [];
  const seen = new Set();
  const fallback = bookMetaOf(bookMeta);
  for (const entry of list) {
    if (!enabledEntry(entry)) continue;
    const title = String(entry.comment || entry.name || entry.title || '未命名').trim() || '未命名';
    const content = String(entry.content || entry.text || '');
    if (!content && title === '未命名') continue;
    const bookName = String(entry.bookName || entry.world || fallback.bookName || '').trim();
    const bookUid = String(entry.bookUid || fallback.bookUid || '').trim();
    const constant = entry.constant === true || entry.constant === 1 || entry.constant === 'true';
    const keys = collectKeys(entry);
    const key = `${bookUid}\n${bookName}\n${title}\n${content}`;
    if (seen.has(key)) continue;
    seen.add(key);
    entries.push({
      ...entry,
      uid: entry.uid ?? entry.id,
      title,
      content,
      constant,
      keys,
      bookName,
      bookUid,
      enabled: true,
    });
  }
  return entries;
}

function entriesFromBook(book, fallbackName = '') {
  if (!book) return [];
  if (Array.isArray(book)) return normalizeEntries(book, { bookName: fallbackName });
  const meta = bookMetaOf(book, fallbackName);
  if (Array.isArray(book.entries)) return normalizeEntries(book.entries, meta);
  if (book.entries && typeof book.entries === 'object') return normalizeEntries(Object.values(book.entries), meta);
  return [];
}

function inlineWorldbook(ctx) {
  const buckets = [];
  if (Array.isArray(ctx?.worldInfoEntries)) buckets.push(...normalizeEntries(ctx.worldInfoEntries));
  buckets.push(...entriesFromBook(ctx?.worldInfo));
  const character = ctx?.characters?.[ctx?.characterId];
  const card = character?.data?.character_book || character?.character_book;
  buckets.push(...entriesFromBook(card));
  return normalizeEntries(buckets);
}

function entriesFromRead(read) {
  if (Array.isArray(read)) return normalizeEntries(read);
  if (!read || typeof read !== 'object') return null;
  if (Array.isArray(read.books)) {
    const all = [];
    for (const book of read.books) all.push(...entriesFromBook(book));
    return normalizeEntries(all);
  }
  if (Array.isArray(read.entries) || (read.entries && typeof read.entries === 'object')) {
    return entriesFromBook(read);
  }
  return null;
}

async function loadWorldbook(ctx) {
  const host = getHost();
  if (typeof host.readWorldbook === 'function') {
    try {
      const read = await host.readWorldbook();
      const entries = entriesFromRead(read);
      if (entries) return { entries };
    } catch (error) {
      console.error('[shiju] 世界书读取失败', error);
    }
  }
  return { entries: inlineWorldbook(ctx) };
}

/** All permitted physical messages, without text or floor-count clipping. */
export function readFloorsTail(chat) {
  return (chat || []).flatMap((message, floor) => !message || manualHidden(message) || typeof message.mes !== 'string' || !message.mes.trim() ? [] : [{floor,swipeId:message.swipe_id ?? 0,isUser:!!message.is_user,text:message.mes}]);
}

function textOf(value) {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (typeof value.relativeText === 'string' && value.relativeText) return value.relativeText;
  if (typeof value.text === 'string') return value.text;
  return '';
}

export function probeBaibai(before) {
  let api;
  try {
    api = globalThis.STBaiBaiBook;
  } catch {
    return undefined;
  }
  if (!api || typeof api.getSnapshot !== 'function') return undefined;
  const pack = { present: true };
  try {
    pack.snapshot = api.getSnapshot();
  } catch {
    pack.snapshot = null;
  }
  try {
    pack.history = typeof api.getHistory === 'function' ? api.getHistory(Number.isInteger(before) ? {before} : undefined) : null;
  } catch {
    pack.history = null;
  }
  try {
    pack.injectedHistory = typeof api.getInjectedHistory === 'function' ? api.getInjectedHistory() : null;
  } catch {
    pack.injectedHistory = null;
  }
  pack.coverage = pack.snapshot?.coverage || pack.injectedHistory?.coverage || null;
  pack.historyText = textOf(pack.history);
  pack.injectedText = textOf(pack.injectedHistory);
  return pack;
}

function readMvu() {
  const host = getHost();
  if (typeof host.readMvu !== 'function') return undefined;
  try {
    const value = host.readMvu();
    if (value && typeof value === 'object') return value;
  } catch {
    return undefined;
  }
  return undefined;
}

export function readChat() {
  const host = getHost();
  if (typeof host.readChat === 'function') {
    const chat = host.readChat();
    return Array.isArray(chat) ? chat : [];
  }
  const ctx = host.getContext?.();
  return Array.isArray(ctx?.chat) ? ctx.chat : [];
}

/**
 * Background: complete reliable memories plus uncovered permitted prose.
 * snapshot.state.time is not the clock and is intentionally left out.
 */
export function narrativeText(pack) {
  const floors = pack?.floorsTail || [];
  const memories = [...(pack?.baibai?.history?.nodes || []), ...(pack?.baibai?.injectedHistory?.nodes || []), ...(pack?.baibai?.floorMemories || [])];
  const valid = memories.filter(n => n?.valid !== false && typeof n?.text === 'string' && n.text.trim() && Number.isInteger(n.floorStart) && Number.isInteger(n.floorEnd) && n.floorStart >= 0 && n.floorEnd >= n.floorStart && (!pack?.chat || n.floorEnd < pack.chat.length));
  // Prefer broad valid summaries; never include overlapping levels twice.
  const selected = [];
  for (const node of valid.sort((a,b)=>(b.floorEnd-b.floorStart)-(a.floorEnd-a.floorStart) || a.floorStart-b.floorStart)) {
    let low=0,high=selected.length;
    while(low<high){const mid=(low+high)>>>1;if(selected[mid].floorStart<node.floorStart)low=mid+1;else high=mid;}
    if((low>0&&selected[low-1].floorEnd>=node.floorStart)||(low<selected.length&&selected[low].floorStart<=node.floorEnd))continue;
    selected.splice(low,0,node);
  }
  selected.sort((a,b)=>a.floorStart-b.floorStart);
  let position=0;
  const uncovered=[...floors].sort((a,b)=>a.floor-b.floor).filter(f=>{while(position<selected.length&&selected[position].floorEnd<f.floor)position++;return position>=selected.length||selected[position].floorStart>f.floor;});
  const unknown=memories.filter(n=>n?.valid!==false && typeof n?.text==='string' && (!Number.isInteger(n.floorStart) || !Number.isInteger(n.floorEnd))).map(n=>n.text);
  if(!Array.isArray(pack?.baibai?.history?.nodes)) unknown.push(pack?.baibai?.historyText);
  if(!Array.isArray(pack?.baibai?.injectedHistory?.nodes)) unknown.push(pack?.baibai?.injectedText);
  const blocks=[...selected.map(n=>({floor:n.floorStart,text:`柏宝书记忆楼${n.floorStart}–${n.floorEnd}（背景）：${n.text}`})),
    ...uncovered.map(f=>({floor:f.floor,text:`楼${f.floor}（未被记忆覆盖的背景）：${f.text}`}))].sort((a,b)=>a.floor-b.floor);
  return [...new Set(unknown.filter(Boolean))].map(t=>`柏宝书背景（覆盖未知，可能与原文重复）：\n${t}`).concat(blocks.map(b=>b.text)).join('\n');
}

function chatStamp(chat) {
  return JSON.stringify(chat.map(m => [m?.mes, m?.swipe_id, m?.send_date, m?.is_system, m?.hidden, m?.extra?.hidden, m?.extra?.bbs_hidden]));
}

/** Capture once; retry only the READ when a memory revision changes. */
export async function readSourcePack(options = {}) {
  const host = getHost(), scope = captureChatScope();
  for (let attempt = 0; attempt < 2; attempt++) {
    assertChatScope(scope); options.signal?.throwIfAborted();
    const ctx = host.getContext?.() || {};
    const chat = cloneJson(readChat()), stamp = chatStamp(chat);
    const baibai = cloneJson(probeBaibai() || null);
    const previous = loadWorld()?.processedInput;
    const excluded = new Set([...(previous?.excluded || []).map(r=>r.floor), ...(previous?.rows || []).filter(r=>r.status === 'excluded').map(r=>r.floor)]);
    chat.forEach((m,i)=>{if(manualHidden(m)) excluded.add(i);});
    let memoryConsistent = true, omittedMixed = false;
    if (baibai) {
      baibai.floorMemories = [];
      for (const [floor,message] of chat.entries()) {
        if(floor%100===99){await new Promise(resolve=>setTimeout(resolve,0));assertChatScope(scope);options.signal?.throwIfAborted();}
        if (!memoryHidden(message) || excluded.has(floor)) continue;
        try {
          const leaf = globalThis.STBaiBaiBook.getFloor?.(floor);
          if (leaf && (leaf.chat?.id !== baibai.snapshot?.chat?.id || leaf.revision !== baibai.snapshot?.revision)) memoryConsistent=false;
          if (leaf?.memory?.valid && leaf.memory.summary) baibai.floorMemories.push({floorStart:floor,floorEnd:floor,text:leaf.memory.summary});
        } catch { /* aggregate nodes and effective prose remain available */ }
      }
      for (const history of [baibai.history,baibai.injectedHistory]) {
        if (history?.revision != null && history.revision !== baibai.snapshot?.revision || history?.chat?.id != null && history.chat.id !== baibai.snapshot?.chat?.id) memoryConsistent=false;
        if (history?.nodes) history.nodes = history.nodes.filter(n=>{const blocked=excluded.size && (!Number.isInteger(n.floorStart) || !Number.isInteger(n.floorEnd)) || [...excluded].some(f=>f>=n.floorStart && f<=n.floorEnd);omittedMixed ||= blocked;return !blocked;});
      }
      // Unknown coverage cannot safely distinguish excluded new prose.
      if (excluded.size) {baibai.historyText=''; baibai.injectedText='';}
    }
    const character = ctx.characters?.[ctx.characterId] || {};
    const templateData = cloneJson({ global: host.getExtensionSettings?.()?.variables?.global || {},
        initial: globalThis.EjsTemplate?.initialVariables || {},
        local: ctx.chatMetadata?.variables || {}, chat:chat.map((m,i) => hiddenMessage(m) || excluded.has(i) ? {...m,mes:''} : m), user: ctx.name1 || '', char: ctx.name2 || character.name || '', character, persona:ctx.powerUserSettings?.persona_description || '' });
    const mvu = cloneJson(readMvu() || null);
    const worldbook = await loadWorldbook(ctx);
    assertChatScope(scope);
    const after = probeBaibai();
    const beforeId = baibai?.snapshot?.chat?.id, afterId = after?.snapshot?.chat?.id;
    if (!memoryConsistent || stamp !== chatStamp(readChat()) || baibai?.snapshot?.revision !== after?.snapshot?.revision
      || beforeId !== afterId || (beforeId != null && String(beforeId) !== String(scope.chatId))) continue;
    const diagnostics = [{kind:'memory',title:'记忆替代',reason:baibai ? '可靠覆盖使用完整记忆，未覆盖楼层提供完整原文；覆盖未知时保守拼接。' : '无可靠记忆，使用全部允许读取的原文。'}];
    if(omittedMixed) diagnostics.push({title:'记忆替代',reason:'摘要混入隐藏或排除楼层，已跳过该摘要并回退到允许读取的原文'});
    if (baibai && !Array.isArray(baibai.history?.nodes)) diagnostics.push({title:'背景资料',reason:'摘要覆盖范围不足，按来源保守拼接；不作为新增剧情'});
    if (baibai && !baibai.historyText && !baibai.injectedText && !summaryNodes(baibai).length) diagnostics.push({ reason: '柏宝书摘要不可用，已使用全部有效原文', title: '背景资料' });
    return { chat, worldbook, floorsTail: readFloorsTail(chat).filter(f=>!excluded.has(f.floor)), baibai: baibai || undefined,
      ...(mvu ? {mvu} : {}), diagnostics,
      templateData };
  }
  throw shijuError('SHIJU_SOURCE_CHANGED', '聊天或柏宝书摘要在读取期间发生变化，请重试；本次未消耗增量');
}
