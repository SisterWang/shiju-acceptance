import { shijuError } from '../errors.js';

/** W0 stub guard. Importing a module must stay safe; calling it throws. */
export function notImplemented(moduleName, fnName) {
  throw shijuError(
    'SHIJU_NOT_IMPLEMENTED',
    `世局 ${moduleName}.${fnName} 尚未实现（W0 只交付骨架）`,
  );
}
