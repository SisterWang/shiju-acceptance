import { getHost } from '../../host.js';
import { cloneJson } from '../../plain.js';
import { captureChatScope, assertChatScope } from '../../chatScope.js';
import { loadWorld, loadSettings, saveWorld, saveChatMetadata, createEmptyWorld } from '../../store/index.js';
import { assertEditable, isWorldBusy, enqueueEdit, enqueueTurn } from '../turn.js';
import { assembleRenderedInput, summarizeWorld } from '../evolve/index.js';
import { applyEvolutionPatch } from '../evolve/patch.js';
import { validateWorldPatch } from '../evolve/validate.js';
import { parseModelJson } from '../evolve/json.js';
import { eventContext, EVENT_MODEL_RULES, isSecret, isFactVisible, synchronizeKnowledge } from '../events.js';
import { captureModelConfig, generateViaST } from '../model/index.js';
import { updateHistory, recordBusinessResult } from '../model/history.js';
import { readSourcePack, readChat, narrativeText } from '../source/index.js';
import { captureInputBoundary } from '../incremental.js';
import { minSubset } from '../commit/subset.js';
import { currentTipCursor, resolveTimeSourceMode } from '../timetag/index.js';
import { refreshInject } from '../inject/index.js';

export const ENTITY_KINDS = ['regions','factions','orgs'];
const ALL_KINDS = [...ENTITY_KINDS,'events','facts','todayChanges'];
const sessions = new WeakMap();
const version = world => JSON.stringify(world);
const text = (value, label) => { if (typeof value !== 'string' || !value.trim()) throw new Error(`${label}不能为空`); return value; };
const names = item => [item.name || item.title || item.text, ...(item.aliases || [])].filter(Boolean);
const newId = kind => `${kind}-${(globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).substring(2)}`)}`;
function requireWorld() { const world=loadWorld(); if (!world?.meta?.builtFingerprint) throw new Error('请先建立世界'); return world; }
function category(kind) { if (!ENTITY_KINDS.includes(kind)) throw new Error('未知资料分类'); }
function session(data) { const token={}; sessions.set(token,data); return token; }
function rebuildBoundary(pack, previous) {
  const exclusions=new Map((previous?.excluded || []).map(row=>[row.floor,row.identity]));
  for(const row of previous?.rows || []) if(row.status==='excluded') exclusions.set(row.floor,row.identity);
  const prior={...previous,excluded:[...exclusions].map(([floor,identity])=>({floor,identity}))};
  // Full background covers these floors as reliable memory or allowed raw prose.
  const boundary=captureInputBoundary(pack.chat,Infinity,prior,pack.floorsTail.map(row=>row.floor));
  for(const row of boundary.rows) if(row.status==='excluded') exclusions.set(row.floor,row.identity);
  boundary.excluded=[...exclusions].map(([floor,identity])=>({floor,identity}));
  return boundary;
}
function current(token, type) {
  const data=sessions.get(token);
  if (!data || (type && data.type!==type)) throw new Error('编辑会话已失效，请重新打开');
  assertChatScope(data.scope);
  if (version(requireWorld())!==data.version) {
    if(data.requestId) updateHistory(data.requestId,{business:'预览已过期'});
    throw new Error('世界账已变化，请重新生成或打开编辑');
  }
  return data;
}
export function beginEntityEdit(kind, id = null, viewed = false) {
  category(kind); assertEditable(); const world=requireWorld();
  const item=id ? world[kind].find(row=>row.id===id) : null;
  if(id && !item) throw new Error('条目已不存在');
  if(item && isSecret(item) && !isFactVisible(item) && !viewed) throw new Error('请先显式查看隐秘内容，再编辑');
  const token=session({type:'edit',scope:captureChatScope(),version:version(world),kind,id});
  return {token,item:cloneJson({name:'',summary:'',status:'active',regionRef:'',secret:false,...item})};
}
function addCorrection(world, kind, item, origin) {
  world.userCorrections=(world.userCorrections || []).filter(row=>!(row.kind===kind && row.id===item.id));
  world.userCorrections.push({kind,id:item.id,title:item.name || item.title,body:item.summary || item.body,consumed:false,origin});
}
/** Convert only unambiguous old references, never prose or arbitrary strings. */
function remapReferences(world, mapping) {
  for(const kind of ALL_KINDS) for(const item of world[kind] || []) {
    for(const key of ['regionRef','linkedEventId','mergedInto','sourceEventId']) if(mapping.has(item[key])) item[key]=mapping.get(item[key]);
    if(Array.isArray(item.relatedRefs)) item.relatedRefs=item.relatedRefs.map(ref=>mapping.get(ref) || ref);
  }
}
export function saveEntity(token, input) {
  const data=current(token,'edit');
  return enqueueEdit(async scope=>{
    current(token,'edit'); const world=requireWorld(), list=world[data.kind];
    const name=text(input.name,'名称'), summary=text(input.summary,'概况');
    const duplicate=list.find(row=>row.id!==data.id && names(row).includes(name));
    if(duplicate) throw Object.assign(new Error(`名称已存在：${isSecret(duplicate) && !isFactVisible(duplicate) ? '未揭晓的隐秘' : duplicate.name}，请编辑已有记录`),{code:'SHIJU_DUPLICATE_ENTITY',entityId:duplicate.id,kind:data.kind});
    const old=list.find(row=>row.id===data.id);
    const status=input.status ?? old?.status ?? 'active';
    if(!['active','dormant','resolved'].includes(status)) throw new Error('请选择有效状态');
    if(input.regionRef && !world.regions.some(row=>row.id===input.regionRef)) throw new Error('所属地区不存在');
    if(input.secret!=null && typeof input.secret!=='boolean') throw new Error('隐秘标记必须为开或关');
    const item={...old,id:old?.id || newId(data.kind),name,summary,status,secret:input.secret ?? Boolean(old?.secret),
      aliases:[...new Set([...(old?.aliases || []),...(old && old.name!==name ? [old.name] : [])])],
      manualMaintained:true,evidence:'用户修正',updatedAtDay:world.storyClock.dayIndex};
    if(data.kind!=='regions') item.regionRef=input.regionRef || '';
    if(old) list[list.indexOf(old)]=item; else list.push(item);
    if(old && old.name!==name) {
      const matching=ALL_KINDS.flatMap(k=>world[k] || []).filter(row=>names(row).includes(old.name));
      if(matching.length===1) remapReferences(world,new Map([[old.name,item.id]]));
    }
    addCorrection(world,data.kind,item,'manual');
    const saved=await saveWorld(world,scope); sessions.delete(token); refreshInject(); return saved;
  },data.scope);
}
function match(old, item) {
  const byId=item.id && old.find(row=>row.id===item.id); if(byId) return byId;
  const found=old.filter(row=>names(row).some(name=>names(item).includes(name)));
  if(found.length>1) throw new Error('名称或别名存在歧义，请先查看并整理重复记录');
  return found[0];
}
/** Stable IDs, explicit manual provenance, and knowledge overrides survive replacement. */
export function mergeGenerated(before, generated, kind = null) {
  const generatedIds=new Set();
  for(const key of kind ? [kind] : ALL_KINDS) for(const row of generated[key] || []) if(row.id) {
    if(generatedIds.has(row.id)) throw new Error('模型返回了重复 ID，无法可靠保留关联');
    generatedIds.add(row.id);
  }
  const next=kind ? cloneJson(before) : cloneJson(generated), mapping=new Map(), changes=[];
  for(const key of kind ? [kind] : ALL_KINDS) {
    const old=before[key] || [], rows=[], used=new Set();
    for(const incoming of generated[key] || []) {
      if(incoming.id && ALL_KINDS.some(other=>other!==key && (before[other] || []).some(row=>row.id===incoming.id))) throw new Error('返回的 ID 与其他分类冲突，请重新生成');
      const previous=match(old,incoming);
      if(previous && used.has(previous.id)) throw new Error('模型返回了重复实体或事件');
      const id=previous?.id || newId(key); used.add(id);
      if(incoming.id) mapping.set(incoming.id,id);
      const item=previous?.manualMaintained ? cloneJson(previous) : {...incoming,id,
        aliases:[...new Set([...(previous?.aliases || []),...(incoming.aliases || []),...(previous?.name && previous.name!==incoming.name ? [previous.name] : [])])]};
      if(previous) for(const field of ['knowledgeOverride','viewMode','revealed','knownMarked','autoKnown','knowledgeEvidence']) {
        if(field in previous) item[field]=previous[field];
      }
      // Missing/default model fields cannot declassify an existing secret.
      if(isSecret(previous)) {
        if(key==='events' || key==='todayChanges') item.kind='secret';
        else item.secret=true;
        if(previous.veil===true) item.veil=true;
      }
      rows.push(item);
      changes.push({kind:key,id,type:previous?.manualMaintained ? 'preserved' : previous ? 'updated' : 'added',before:previous || null,after:item});
    }
    for(const item of old) if(!used.has(item.id) && (kind || item.manualMaintained || item.knowledgeOverride || item.lifecycle==='archived')) {
      rows.push(cloneJson(item)); changes.push({kind:key,id:item.id,type:'preserved',before:item,after:item});
    }
    next[key]=rows;
  }
  if(!kind) {
    // Retain referents of protected records, transitively, so a rebuild cannot sever their links.
    let changed=true;
    while(changed) {
      changed=false;
      const ids=new Set(ALL_KINDS.flatMap(k=>(next[k] || []).map(row=>row.id)));
      const refs=ALL_KINDS.flatMap(k=>(next[k] || []).flatMap(row=>[row.regionRef,row.linkedEventId,row.mergedInto,row.sourceEventId,...(row.relatedRefs || [])]));
      for(const ref of refs.filter(Boolean)) if(!ids.has(mapping.get(ref) || ref)) {
        const candidates=ALL_KINDS.flatMap(k=>(before[k] || []).filter(row=>row.id===ref || names(row).includes(ref)).map(row=>({k,row})));
        if(candidates.length===1) { const {k,row}=candidates[0]; mapping.set(ref,row.id); if(!ids.has(row.id)){next[k].push(cloneJson(row)); ids.add(row.id); changed=true;} }
      }
    }
  }
  if(!kind) remapReferences(next,mapping);
  else if(kind!=='regions') for(const item of next[kind]) if(!item.manualMaintained && item.regionRef) {
    const regions=before.regions.filter(row=>row.id===item.regionRef || names(row).includes(item.regionRef));
    if(regions.length!==1) throw new Error('所属地区不存在或有歧义，请检查资料关联');
    item.regionRef=regions[0].id;
  }
  if(!kind) for(const event of next.events) if(event.lifecycle==='archived' && event.outcome && !next.facts.some(fact=>fact.sourceEventId===event.id)) {
    const previous=before.facts.find(fact=>fact.sourceEventId===event.id);
    next.facts.push(previous ? cloneJson(previous) : {id:`outcome-${event.id}`,text:event.outcome,evidence:'事件归档',sourceEventId:event.id});
  }
  if(!kind) synchronizeKnowledge(next);
  return {world:next,changes};
}
export function generateManagementPreview(kind = null, options = {}) {
  if(kind) category(kind);
  if(isWorldBusy()) return Promise.reject(new Error('正在演进，请等待完成'));
  return enqueueTurn(async scope=>{
    const before=requireWorld(), fingerprint=version(before);
    const config=captureModelConfig(kind ? `regenerate-${kind}` : 'reinitialize');
    const pack=await readSourcePack({signal:options.signal}); assertChatScope(scope); options.signal?.throwIfAborted();
    const assembled=await assembleRenderedInput({world:cloneJson(before),pack,mode:'full',advanceCursor:false,
      summary:summarizeWorld(before),p1:narrativeText(pack),signal:options.signal,onProgress:options.onProgress});
    if(!assembled.selected.bodies.length && !narrativeText(pack).trim() && !Object.keys(pack.mvu || {}).length) throw new Error('有效资料不足，请查看资料诊断');
    const purpose=kind ? `regenerate-${kind}` : 'reinitialize';
    const response=await generateViaST({purpose,inputBreakdown:assembled.inputBreakdown,modelConfig:config,signal:options.signal,
      systemPrompt:`你是宏观世界资料整理器。只返回 JSON。实体需要非空 name、summary；事件需要非空 title、body。优先复用已有 id，不修改人工记录。\n${EVENT_MODEL_RULES}`,
      prompt:[kind ? `只补全并更新 ${kind}，输出仅可有 ${kind} 数组及 note，不输出其他分类。` : '重新整理当前世界实体、提取已有宏观事态、计划和冲突。不要跨日，不只复述主角当前动作。资料不足可少量事件，在 note 说明。输出 regions、factions、orgs、events、facts，todayChanges 为空。',assembled.budget.text,eventContext(before)].join('\n\n')},scope);
    try {
      validateWorldPatch(parseModelJson(response.text),{},kind);
      const parsed=parseModelJson(response.text);
      if(kind && !Array.isArray(parsed[kind])) throw new Error('响应缺少目标分类');
      const generated=createEmptyWorld(); applyEvolutionPatch(generated,parsed,{dayIndex:before.storyClock.dayIndex,evidence:kind ? '分类补全' : '重新初始化',evidenceText:assembled.budget.p1});
      if(!kind && !ENTITY_KINDS.some(k=>generated[k].length)) throw new Error('重新初始化没有返回有效实体');
      if(version(requireWorld())!==fingerprint) throw new Error('世界账已变化，预览已失效');
      const merged=mergeGenerated(before,generated,kind);
      const token=session({type:'preview',scope,version:fingerprint,kind,before,world:merged.world,requestId:response.requestId,
        preferences:response.preferencesSnapshot,chat:JSON.stringify(pack.chat),
        boundary:rebuildBoundary(pack,before.processedInput),usage:assembled.usage});
      updateHistory(response.requestId,{business:'草稿已生成，等待采用'});
      return {token,kind,changes:cloneJson(merged.changes),note:typeof parsed.note==='string' ? parsed.note : ''};
    } catch(error) { updateHistory(response.requestId,{status:'failed',business:'响应校验失败',errorStage:'响应校验',error:error.message}); throw error; }
  });
}
export function adoptManagementPreview(token) {
  const data=current(token,'preview');
  return enqueueEdit(async scope=>{
    current(token,'preview');
    if(JSON.stringify(readChat())!==data.chat) { updateHistory(data.requestId,{business:'预览已过期'}); throw new Error('聊天正文已变化，请重新生成预览'); }
    const next=cloneJson(data.world);
    if(data.kind) {
      for(const item of next[data.kind]) {
        const old=data.before[data.kind].find(row=>row.id===item.id);
        if(!item.manualMaintained && JSON.stringify(old)!==JSON.stringify(item)) addCorrection(next,data.kind,item,'generated');
      }
      await recordBusinessResult(data.requestId,()=>saveWorld(next,scope),'分类补全已采用');
    } else {
      next.plugin=cloneJson(data.before.plugin); next.storyClock=cloneJson(data.before.storyClock);
      next.appliedPreferences=cloneJson(data.preferences); next.processedInput=data.boundary;
      next.userCorrections=cloneJson(data.before.userCorrections || []);
      next.meta={...next.meta,builtFingerprint:`rebuild-${Date.now()}`,lastEvolvedDayIndex:next.storyClock.dayIndex,
        modelCallCount:(data.before.meta.modelCallCount || 0)+1,usage:data.usage};
      next.lastEvolutionCheckpoint=null; next.evolutionLog=[]; next.dayBuffer={items:[]};
      const settings=loadSettings(), tip=currentTipCursor(readChat(),resolveTimeSourceMode(settings),settings.timeSource?.customTag || '');
      next.meta.initialSnapshot={dayIndexAfter:next.storyClock.dayIndex,tipFloor:tip.floor,tipSwipeId:tip.swipeId,tipTimeFingerprint:tip.fingerprint,worldAfter:minSubset(next)};
      await recordBusinessResult(data.requestId,()=>saveChatMetadata({shiju:next,shijuRebuildBackup:{createdAt:new Date().toISOString(),world:data.before}},scope),'重新初始化已采用');
    }
    sessions.delete(token); refreshInject(); return next;
  },data.scope);
}
export function readRebuildBackup() { return cloneJson(getHost().getContext()?.chatMetadata?.shijuRebuildBackup || null); }
export function beginBackupRestore() { const world=requireWorld(),backup=readRebuildBackup(); if(!backup?.world) throw new Error('没有重建备份'); return session({type:'restore',scope:captureChatScope(),version:version(world),backup:JSON.stringify(backup)}); }
export function restoreRebuildBackup(token) {
  const data=current(token,'restore'); return enqueueEdit(async scope=>{
    current(token,'restore'); const backup=readRebuildBackup(); if(JSON.stringify(backup)!==data.backup) throw new Error('备份已变化，请重新确认');
    // The old boundary is restored, never replaced with the current tip: later prose stays pending.
    const saved=await saveWorld(backup.world,scope); sessions.delete(token); refreshInject(); return saved;
  },data.scope);
}
export function discardManagementSession(token) { const data=sessions.get(token); if(data?.requestId) updateHistory(data.requestId,{business:'草稿未采用'}); sessions.delete(token); }
