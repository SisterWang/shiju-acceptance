import { isKnown } from '../events.js';
import { getHost, writeInChatPrompt } from '../../host.js';
import { cloneJson } from '../../plain.js';
import { loadSettings, loadWorld, subscribe } from '../../store/index.js';

/**
 * M-Inject. Macro background only, on its own key.
 * shiju_timetag stays with the time-tag module and is never written here.
 * Message text is never rewritten.
 */

export const MACRO_KEY = 'shiju_macro';
export const MACRO_DEPTH = 4;
export const MACRO_CHAR_BUDGET = 1500;
/** D17, exact sentence. */
export const MACRO_DISCLAIMER = '背景参考，不必强行写入正文';

const EMPTY_PREVIEW = {
  key: MACRO_KEY,
  depth: MACRO_DEPTH,
  enabled: false,
  active: false,
  cleared: false,
  text: '',
  previewText: '',
  disclaimer: MACRO_DISCLAIMER,
  items: [],
  omittedSecrets: 0,
  truncated: false,
};

let lastPreview = { ...EMPTY_PREVIEW, items: [] };
let subscribed = false;
const boundHosts = new WeakSet();

function chars(value) {
  return Array.from(String(value || '')).length;
}

function clip(value, max) {
  const text = String(value || '').replace(/\s+/g, ' ').trim();
  const list = Array.from(text);
  if (list.length <= max) return text;
  return list.slice(0, max).join('');
}

function worldRunning(world) {
  return Boolean(world?.plugin?.enabled) && world?.plugin?.frozenAt == null && world?.meta?.builtFingerprint;
}

function injectSwitchOn(settings) {
  if (!settings || typeof settings !== 'object') return true;
  if (settings.inject === false) return false;
  if (settings.inject && typeof settings.inject === 'object' && settings.inject.enabled === false) return false;
  return true;
}

function isVeiled(item) {
  if (!item || typeof item !== 'object') return false;
  const secret = item.kind === 'secret' || item.secret === true || item.veil === true;
  if (!secret) return false;
  return !isKnown(item);
}

function asItem(raw, source) {
  if (!raw || typeof raw !== 'object') return null;
  const title = clip(raw.title || raw.name, 40);
  if (!title) return null;
  const kind = raw.kind === 'news' || raw.kind === 'secret' ? raw.kind : 'macro';
  const farAway = kind === 'news' || raw.farAway === true;
  const resolvedKind = farAway && kind !== 'secret' ? 'news' : kind;
  const base = resolvedKind === 'secret' ? 5 : resolvedKind === 'news' ? 3 : 1;
  return {
    id: typeof raw.id === 'string' ? raw.id : '',
    source,
    kind: resolvedKind,
    title,
    summary: clip(raw.body || raw.summary, 80),
    farAway,
    revealed: Boolean(raw.revealed),
    knownMarked: Boolean(raw.knownMarked),
    rank: source === 'today' ? base + 1 : base,
  };
}

function collect(world) {
  const items = [];
  let omittedSecrets = 0;
  const take = (list, source) => {
    if (!Array.isArray(list)) return;
    list.forEach((raw, index) => {
      if (raw?.lifecycle === 'archived') return;
      const linked = raw?.linkedEventId && (world.events || []).find((event) => event.id === raw.linkedEventId);
      if (linked?.lifecycle === 'archived') return;
      if (isVeiled(raw)) {
        omittedSecrets += 1;
        return;
      }
      const item = asItem(raw, source);
      if (!item) return;
      if (!item.id) item.id = `${source}-${index}`;
      items.push(item);
    });
  };
  take(world?.events, 'event');
  take(world?.todayChanges, 'today');
  return { items, omittedSecrets };
}

function lineOf(item) {
  const summary = item.summary ? `：${item.summary}` : '';
  if (item.farAway || item.kind === 'news') return `- 发生于远方。${item.title}${summary}`;
  if (item.kind === 'secret') return `- 已揭晓。${item.title}${summary}`;
  return `- ${item.title}${summary}`;
}

function compose(items) {
  const head = [
    '【世局 · 背景参考】',
    MACRO_DISCLAIMER,
    '勿强迫主角介入。远方见闻发生于远方，不当作眼前戏。',
  ];
  const groups = [
    ['宏观事态', (item) => item.kind === 'macro'],
    ['远方见闻', (item) => item.kind === 'news'],
    ['已揭晓', (item) => item.kind === 'secret'],
  ];
  const parts = [head.join('\n')];
  for (const [label, match] of groups) {
    const rows = items.filter(match);
    if (!rows.length) continue;
    parts.push(`${label}\n${rows.map(lineOf).join('\n')}`);
  }
  return parts.join('\n\n');
}

function fit(items) {
  let kept = items.slice();
  let truncated = false;
  let text = compose(kept);
  while (chars(text) > MACRO_CHAR_BUDGET && kept.length) {
    truncated = true;
    let dropAt = 0;
    let rank = kept[0].rank;
    for (let index = 1; index < kept.length; index += 1) {
      if (kept[index].rank >= rank) {
        rank = kept[index].rank;
        dropAt = index;
      }
    }
    kept.splice(dropAt, 1);
    text = compose(kept);
  }
  if (chars(text) > MACRO_CHAR_BUDGET) {
    text = Array.from(text).slice(0, MACRO_CHAR_BUDGET).join('');
    truncated = true;
  }
  return { text, items: kept, truncated };
}

function writePrompt(value) {
  writeInChatPrompt(MACRO_KEY, value, MACRO_DEPTH);
}

function remember(preview) {
  lastPreview = preview;
  return cloneJson(preview);
}

function ensureSubscribed() {
  if (subscribed) return;
  subscribed = true;
  subscribe(() => {
    try {
      refreshInject();
    } catch (error) {
      console.error('[shiju] 注入刷新失败', error);
    }
  });
}

function bindHost() {
  let host;
  try {
    host = getHost();
  } catch {
    return;
  }
  if (!host || boundHosts.has(host)) return;
  boundHosts.add(host);
  const source = host.eventSource;
  const types = host.event_types || {};
  if (!source || typeof source.on !== 'function') return;
  const refresh = () => {
    try {
      refreshInject();
    } catch (error) {
      console.error('[shiju] 注入刷新失败', error);
    }
  };
  for (const name of [types.GENERATION_STARTED, types.GENERATION_AFTER_COMMANDS, types.CHAT_CHANGED]) {
    if (name) source.on(name, refresh);
  }
}

/** Read-only snapshot for the panel. Does not write a prompt. */
export function getInjectPreview() {
  return cloneJson(lastPreview);
}

/**
 * Rebuild shiju_macro at depth 4.
 * Macro and far-away items are included. Far-away lines carry 「发生于远方」.
 * Secret / veil stays out until the protagonist knows; reader visibility is separate.
 * An off switch, a frozen world, or a disabled world clears the key.
 */
export function refreshInject() {
  ensureSubscribed();
  const settings = loadSettings();
  const world = loadWorld();
  const running = worldRunning(world);
  const enabled = injectSwitchOn(settings);
  const collected = world ? collect(world) : { items: [], omittedSecrets: 0 };
  const fitted = world ? fit(collected.items) : { text: '', items: [], truncated: false };
  const write = running && enabled;
  const value = write ? fitted.text : '';
  writePrompt(value);
  return remember({
    key: MACRO_KEY,
    depth: MACRO_DEPTH,
    enabled: write,
    active: Boolean(value),
    cleared: !value,
    text: value,
    previewText: fitted.text,
    disclaimer: MACRO_DISCLAIMER,
    items: fitted.items.map((item) => ({
      id: item.id,
      source: item.source,
      kind: item.kind,
      title: item.title,
      summary: item.summary,
      farAway: item.farAway,
      revealed: item.revealed,
      knownMarked: item.knownMarked,
    })),
    omittedSecrets: collected.omittedSecrets,
    truncated: fitted.truncated,
  });
}

/** Clear shiju_macro only. The time-tag key is left untouched. */
export function clearInject() {
  writePrompt('');
  return remember({
    ...lastPreview,
    items: Array.isArray(lastPreview.items) ? lastPreview.items : [],
    enabled: false,
    active: false,
    cleared: true,
    text: '',
  });
}

export function register() {
  ensureSubscribed();
  bindHost();
  try {
    refreshInject();
  } catch (error) {
    console.error('[shiju] 注入刷新失败', error);
  }
}
