import { summarizeWorld } from '../evolve/index.js';
import { validateWorldPatch } from '../evolve/validate.js';
import { EVENT_MODEL_RULES, eventContext } from '../events.js';
import { captureInputBoundary, correctionText } from '../incremental.js';
import { cloneJson } from '../../plain.js';
import { assertChatScope } from '../../chatScope.js';
import { loadSettings, loadWorld, saveWorld } from '../../store/index.js';
import { runBootstrap } from '../bootstrap/index.js';
import { assembleRenderedInput } from '../evolve/index.js';
import { parseModelJson } from '../evolve/json.js';
import { updateHistory, recordBusinessResult } from '../model/history.js';
import { applyEvolutionPatch } from '../evolve/patch.js';
import { clearInject, refreshInject } from '../inject/index.js';
import { captureModelConfig, generateViaST } from '../model/index.js';
import { narrativeText, readChat, readSourcePack } from '../source/index.js';
import { refreshTimeTag, resolveTimeSourceMode } from '../timetag/index.js';
import { absoluteSerial, applyClock, interpretStoryTime } from '../timetag/read.js';
import { enqueueTurn, isWorldBusy } from '../turn.js';

/**
 * M-Lifecycle. Freeze stops evolution and injection. Reopen continues
 * from the current story day and does not backfill the frozen gap.
 * Story-day correction never deletes chat floors and never appends evolutionLog.
 */

const REALIGN_SYSTEM = [
  '你是世局的重对齐器。只根据给定资料，把宏观世界调整到正文当前这一日。',
  '这不是跨日推演，不要把故事日往前再推一天，不要写眼前戏。',
  '只输出一个 JSON 对象，不要 Markdown。',
  '字段可以有：regions、orgs、factions、events、facts、todayChanges、locationGuess、note。',
  'todayChanges 只保留校正后这一日的变更，允许空数组。',
  '不要要求把这些内容写进正文。',
  EVENT_MODEL_RULES,
].join('\n');

export function register() {}

function armed(world) {
  return Boolean(world?.plugin?.enabled) && world?.plugin?.frozenAt == null && world?.meta?.builtFingerprint;
}

function refreshSurface() {
  refreshTimeTag();
  try {
    refreshInject();
  } catch (error) {
    console.error('[shiju] 注入刷新失败', error);
  }
}

function modeOf() {
  const settings = loadSettings();
  return {
    mode: resolveTimeSourceMode(settings),
    customTag: settings.timeSource?.customTag || '',
  };
}

function proseReading(world, chat, mode, customTag) {
  return interpretStoryTime(world, chat, mode, customTag, { allowClockRewind: true });
}

function conflictKey(prose) {
  return `${prose?.status || ''}:${prose?.dayIndex ?? ''}:${prose?.dateLabel || ''}:${prose?.fingerprint || ''}:${JSON.stringify(prose?.diagnostic || null)}`;
}

function clockSnapshot(reading) {
  if (!reading) return null;
  return {
    status: reading.status,
    dayIndex: reading.dayIndex,
    dateLabel: reading.dateLabel || '',
    fingerprint: reading.fingerprint || '',
    source: reading.source || null,
    diagnostic: reading.diagnostic || null,
  };
}

/**
 * Read the plugin clock against the current floors.
 * Does not write, does not evolve, does not touch messages.
 */
export function inspectStoryDay() {
  const world = loadWorld();
  if (!world?.meta?.builtFingerprint) {
    return {
      status: 'disabled',
      prompt: null,
      promptRequired: false,
      choices: [],
      canRealign: false,
      plugin: null,
      prose: null,
    };
  }
  const { mode, customTag } = modeOf();
  const chat = readChat();
  const prose = interpretStoryTime(world, chat, mode, customTag);
  const pluginDay = world.storyClock?.dayIndex ?? 0;
  const plugin = {
    dayIndex: pluginDay,
    dateLabel: world.storyClock?.dateLabel || '',
  };
  const acked = world.meta?.clockChoice === 'keep' && world.meta?.conflictAck === conflictKey(prose);
  let status = 'aligned';
  let prompt = null;
  let choices = [];
  let canRealign = false;
  let promptRequired = false;

  const diagnostic = prose.diagnostic;
  if (prose.status === 'missing' || diagnostic?.reason === 'unrecognized') {
    status = diagnostic?.reason === 'unrecognized' ? 'unrecognized' : 'missing';
    choices = ['set'];
    prompt = status === 'missing' ? '当前来源没有提供日期，世界保持当前故事日。' : '当前日期文字无法识别，世界保持当前故事日。请检查时间来源或校正日期。';
  } else if (prose.status === 'conflict') {
    status = 'conflict';
    const internal = ['range-reversed', 'timeline-reversed'].includes(diagnostic?.reason);
    canRealign = !internal && proseReading(world, chat, mode, customTag).status !== 'conflict';
    choices = internal ? ['keep'] : ['set', ...(canRealign ? ['realign'] : []), 'keep'];
    prompt = internal
      ? '来源中的日期互相矛盾，不能代为取值。请检查下列楼层的日期字段，修正来源后重新检查；仅修改世界账日期不能消除来源矛盾。'
      : '世界账日期或故事日起点与当前来源不一致。可手动校正日期，或以正文为准重对齐（调用模型）。';
    promptRequired = true;
  } else if (prose.dayIndex !== pluginDay) {
    status = 'drift';
    choices = ['set'];
  }

  const historyChanged = world.meta?.inputHint === 'history-changed';
  if (historyChanged) {
    status = 'history-changed';
    canRealign = proseReading(world, chat, mode, customTag).status !== 'conflict' && prose.status !== 'missing';
    choices = canRealign ? ['realign', 'keep'] : ['keep'];
    prompt = '已处理的正文有修改。可重新对齐（调用模型），或保留世界账、从当前正文继续。' + (prose.conflict ? ' 当前还存在日期矛盾，请先修正来源日期。' : '');
    promptRequired = true;
  }

  if (acked && world.meta?.inputHint !== 'history-changed') {
    prompt = null;
    promptRequired = false;
  }

  return {
    status,
    prompt,
    promptRequired,
    choices,
    canRealign,
    blocked: prose.conflict || historyChanged,
    reason: historyChanged ? 'history-changed' : diagnostic?.reason || '',
    diagnostic,
    source: prose.source,
    mode,
    plugin,
    prose: clockSnapshot(prose),
  };
}

export function getLifecycleStatus() {
  const world = loadWorld();
  const settings = loadSettings();
  const inspection = world ? inspectStoryDay() : {
    status: 'disabled',
    prompt: null,
    promptRequired: false,
    choices: [],
    canRealign: false,
    plugin: null,
    prose: null,
  };
  const enabled = Boolean(world?.plugin?.enabled) && world?.plugin?.frozenAt == null;
  return {
    enabled,
    frozen: Boolean(world?.meta?.builtFingerprint) && !enabled,
    frozenAt: world?.plugin?.frozenAt ?? null,
    hasWorld: Boolean(world?.meta?.builtFingerprint),
    injectEnabled: settings.inject?.enabled !== false,
    ...inspection,
  };
}

/**
 * Rebuild today's changes for one story day.
 * Prefers the log anchor for that day, then same-day changes, then same-day events.
 * Does not remove events, facts, or chat floors.
 */
export function recalculateTodayChanges(world, dayIndex, options = {}) {
  const day = Number(dayIndex);
  if (options.preferLog !== false) {
    const log = Array.isArray(world.evolutionLog) ? world.evolutionLog : [];
    for (let index = log.length - 1; index >= 0; index -= 1) {
      const entry = log[index];
      if (entry?.dayIndexAfter === day && Array.isArray(entry.worldAfter?.todayChanges)) {
        world.todayChanges = cloneJson(entry.worldAfter.todayChanges);
        return world.todayChanges;
      }
    }
  }
  const current = Array.isArray(world.todayChanges) ? world.todayChanges : [];
  const kept = current.filter((item) => item && item.updatedAtDay === day);
  if (kept.length) {
    world.todayChanges = cloneJson(kept);
    return world.todayChanges;
  }
  const derived = [];
  for (const event of world.events || []) {
    if (!event || event.updatedAtDay !== day || !event.title) continue;
    derived.push({
      id: `day-${event.id}`,
      kind: event.kind === 'news' || event.kind === 'secret' ? event.kind : 'macro',
      title: event.title,
      body: event.body || '',
      revealed: Boolean(event.revealed),
      knownMarked: Boolean(event.knownMarked),
      updatedAtDay: day,
      linkedEventId: event.id,
      farAway: event.kind === 'news' || event.farAway === true,
    });
  }
  world.todayChanges = derived;
  return world.todayChanges;
}

async function freezeBody(chatScope) {
  const world = loadWorld();
  if (world?.meta?.builtFingerprint) {
    world.plugin.enabled = false;
    if (world.plugin.frozenAt == null) world.plugin.frozenAt = Date.now();
    await saveWorld(world, chatScope);
  }
  assertChatScope(chatScope);
  clearInject();
  refreshTimeTag();
  return { ok: true, frozen: Boolean(world?.meta?.builtFingerprint), evolved: false };
}

async function skipFrozenGap(chatScope) {
  assertChatScope(chatScope);
  const world = loadWorld();
  if (!world?.meta?.builtFingerprint) return;
  const { mode, customTag } = modeOf();
  const reading = interpretStoryTime(world, readChat(), mode, customTag);
  const previousDay = world.storyClock?.dayIndex ?? 0;
  if (reading.status === 'advance' || reading.status === 'same') {
    applyClock(world, reading);
    if (world.storyClock.dayIndex !== previousDay) {
      recalculateTodayChanges(world, world.storyClock.dayIndex, { preferLog: true });
    }
    world.meta.lastEvolvedDayIndex = world.storyClock.dayIndex;
    world.meta.clockChoice = '';
    world.meta.conflictAck = '';
  } else {
    applyClock(world, reading);
  }
  world.processedInput = captureInputBoundary(readChat());
  world.meta.inputHint = '';
  await saveWorld(world, chatScope);
  assertChatScope(chatScope);
  refreshTimeTag();
}

async function reopenBody(chatScope,options = {}) {
  const before = loadWorld();
  const wasFrozenLedger = Boolean(before?.meta?.builtFingerprint)
    && (before.plugin?.enabled !== true || before.plugin?.frozenAt != null);
  const result = await runBootstrap(chatScope,options);
  assertChatScope(chatScope);
  if (!result?.ok) return { ...result, evolved: false };
  if (wasFrozenLedger) await skipFrozenGap(chatScope);
  assertChatScope(chatScope);
  refreshSurface();
  return { ...result, evolved: false };
}

async function realignBody(chatScope) {
  const world = loadWorld();
  if (!armed(world)) return { ok: false, evolved: false, reason: 'disabled' };
  const modelConfig = captureModelConfig('realign');
  const { mode, customTag } = modeOf();

  let pack;
  try {
    pack = await readSourcePack();
  } catch (error) {
    assertChatScope(chatScope);
    return { ok: false, evolved: false, reason: 'source', message: error?.message || '' };
  }
  assertChatScope(chatScope);
  const chat = pack.chat || cloneJson(readChat());
  const prose = proseReading(world, chat, mode, customTag);
  if (prose.status === 'conflict') return { ok: false, evolved: false, reason: 'conflict' };
  if (prose.status === 'missing') return { ok: false, evolved: false, reason: 'missing' };
  const fromDay = typeof world.meta?.lastEvolvedDayIndex === 'number'
    ? world.meta.lastEvolvedDayIndex
    : (world.storyClock?.dayIndex || 0);
  const dayDelta = Math.max(1, (prose.dayIndex || 0) - fromDay);
  const assembled = await assembleRenderedInput({
    world,
    pack,
    dayDelta,
    summary: summarizeWorld(world),
    bufferText: '',
    p1: narrativeText(pack),
  });
  const budget = assembled.budget;
  const prompt = [
    '任务：以正文为准重对齐。把世界账拨到正文当前故事日，并重算这一日的今日变更。',
    '不要再往前推一天。不要删改聊天楼层。',
    `正文故事日:${prose.dateLabel || '未定'}#${prose.dayIndex}`,
    budget.text || '（没有更多资料。）',
    eventContext(world),
    correctionText(world),
    '只输出 JSON。',
  ].join('\n\n');

  let generated;
  try {
    generated = await generateViaST({
      purpose: 'realign', inputBreakdown:assembled.inputBreakdown,
      modelConfig,
      systemPrompt: REALIGN_SYSTEM,
      prompt,
    }, chatScope);
  } catch (error) {
    assertChatScope(chatScope);
    return { ok: false, evolved: false, reason: 'model', message: error?.message || '' };
  }
  assertChatScope(chatScope);
  const parsed = parseModelJson(generated.text);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    updateHistory(generated.requestId, { business:'响应校验失败', status:'failed', errorStage:'响应校验' });
    return { ok: false, evolved: false, reason: 'parse' };
  }

  try { validateWorldPatch(parsed,world); } catch(error) {
    updateHistory(generated.requestId,{status:'failed',business:'响应校验失败',errorStage:'响应校验',error:error.message}); return {ok:false,reason:'parse',message:error.message};
  }
  const next = loadWorld();
  next.appliedPreferences = cloneJson(generated.preferencesSnapshot);
  applyClock(next, prose);
  applyEvolutionPatch(next, { ...parsed, todayChanges: Array.isArray(parsed.todayChanges) ? parsed.todayChanges : [] }, {
    dayIndex: next.storyClock.dayIndex,
    evolutionId: null,
    evidence: '以正文为准重对齐',
    evidenceText: budget.p1,
  });
  recalculateTodayChanges(next, next.storyClock.dayIndex, { preferLog: false });
  next.processedInput = captureInputBoundary(chat);
  next.meta.inputHint = '';
  next.userCorrections = (next.userCorrections || []).map((item) => ({ ...item, consumed: true }));
  next.meta.lastEvolvedDayIndex = next.storyClock.dayIndex;
  next.meta.modelCallCount = (next.meta.modelCallCount || 0) + 1;
  next.meta.clockHint = '';
  next.meta.clockChoice = 'realign';
  next.meta.conflictAck = '';
  next.worldbookRotateCursor = world.worldbookRotateCursor;
  next.meta.usage = assembled.usage;
  next.meta.sources.truncated = Boolean(budget.truncated);
  next.meta.sources.softWarn = Boolean(budget.softWarn);
  await recordBusinessResult(generated.requestId, () => saveWorld(next, chatScope), '世界已重对齐');
  assertChatScope(chatScope);
  refreshSurface();
  return {
    ok: true,
    evolved: false,
    choice: 'realign',
    dayIndex: next.storyClock.dayIndex,
    modelCalled: true,
    usage: assembled.usage,
  };
}

async function keepBody(chatScope) {
  const world = loadWorld();
  if (!armed(world)) return { ok: false, evolved: false, reason: 'disabled' };
  const { mode, customTag } = modeOf();
  const prose = interpretStoryTime(world, readChat(), mode, customTag);
  const dayIndex = world.storyClock?.dayIndex ?? 0;
  if (world.meta.inputHint === 'history-changed') {
    world.processedInput = captureInputBoundary(readChat());
    world.meta.inputHint = '';
  }
  world.meta.clockChoice = 'keep';
  world.meta.conflictAck = conflictKey(prose);
  await saveWorld(world, chatScope);
  assertChatScope(chatScope);
  refreshInject();
  return { ok: true, evolved: false, choice: 'keep', dayIndex };
}

async function setDayBody(input, chatScope) {
  const world = loadWorld();
  if (!armed(world)) return { ok: false, evolved: false, reason: 'disabled' };
  const rawDay = typeof input?.dayIndex === 'number' ? input.dayIndex : Number(input?.dayIndex);
  if (!Number.isInteger(rawDay) || rawDay < 0 || rawDay > 100000) {
    return { ok: false, evolved: false, reason: 'bad-day' };
  }
  const previousLabel = world.storyClock?.dateLabel || '';
  const label = typeof input?.dateLabel === 'string' ? input.dateLabel.trim() : previousLabel;
  world.storyClock.dayIndex = rawDay;
  world.storyClock.dateLabel = label || previousLabel;
  world.storyClock.source = modeOf().mode;
  const serial = absoluteSerial(world.storyClock.dateLabel);
  if (serial != null) {
    world.storyClock.serial = serial;
    world.storyClock.originSerial = serial - rawDay;
  } else {
    world.storyClock.serial = null;
    world.storyClock.originSerial = null;
  }
  world.meta.lastEvolvedDayIndex = rawDay;
  world.meta.clockHint = '';
  world.meta.clockChoice = 'set';
  world.meta.conflictAck = '';
  recalculateTodayChanges(world, rawDay, { preferLog: true });
  await saveWorld(world, chatScope);
  assertChatScope(chatScope);
  refreshSurface();
  return { ok: true, evolved: false, choice: 'set', dayIndex: rawDay };
}

async function correctBody(input, chatScope) {
  const choice = input?.choice;
  if (choice === 'keep') return keepBody(chatScope);
  if (choice === 'realign') return realignBody(chatScope);
  if (choice === 'set') return setDayBody(input, chatScope);
  return { ok: false, evolved: false, reason: 'choice' };
}

/** Stop evolution and clear both injection keys. Chat floors stay. */
export function freezeWorld() {
  return enqueueTurn(freezeBody);
}

/**
 * Resume a frozen ledger, or build once when this chat has none.
 * Days that passed while frozen are not evolved.
 */
export function reopenWorld(options = {}) {
  return enqueueTurn(scope=>reopenBody(scope,options));
}

export function setPluginEnabled(enabled, options = {}) {
  return enabled ? reopenWorld(options) : freezeWorld();
}

/**
 * Confirm a story-day correction.
 * choice `keep` leaves the plugin clock. `realign` spends one model call
 * when the prose has a single day. `set` writes an explicit day and
 * recalculates today's changes. None of these delete floors or append the log.
 */
export function correctStoryDay(input) {
  if (isWorldBusy()) return Promise.resolve({ ok:false, reason:'busy', message:'正在演进或保存，完成后可校正' });
  return enqueueTurn((chatScope) => correctBody(input, chatScope));
}
