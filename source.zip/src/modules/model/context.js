import { estimateTokens } from '../evolve/budget.js';
import { normalizeEndpoint } from '../../host/transport.js';
/** No credentials or sampling settings in the binding. A different destination/model invalidates it. */
export function contextBinding(connection = {}) {
  if(connection.mode==='custom') return JSON.stringify(['custom',normalizeEndpoint(connection.endpoint),connection.customModel]);
  const s=connection.settings || {};
  return JSON.stringify(['follow',connection.api,connection.model || s.model_novel || s.model || '',s.chat_completion_source || s.type || '',
    connection.server || s.api_server || '',connection.horde?.models || [],s.reverse_proxy || '',s.custom_url || '',s.azure_base_url || '',s.azure_deployment_name || '']);
}
export function checkContext(request, limit) {
  const parts=(request.messages || []).map((message,index)=>({label:`${message.role} ${index+1}`,tokens:estimateTokens(message.content)+4}));
  const output=Number(request.responseLength ?? request.connection?.responseLength) || 0;
  const input=parts.reduce((sum,p)=>sum+p.tokens,0)+3;
  const breakdown=request.inputBreakdown ? Object.entries(request.inputBreakdown).map(([label,tokens])=>({label,tokens})) : parts;
  const attributed=breakdown.reduce((sum,p)=>sum+p.tokens,0);
  if(request.inputBreakdown) breakdown.push({label:'协议、偏好、事件与其他消息',tokens:Math.max(0,input-attributed)});
  const applicable=limit && limit.binding===contextBinding(request.connection);
  const result={input,output,total:input+output,parts:breakdown,limit:applicable ? limit.tokens : null};
  if(applicable && result.total>limit.tokens) {
    const error=new Error(`世局上下文估算超出上限：输入约 ${input} + 输出预留 ${output} = ${result.total} token，上限 ${limit.tokens}。${breakdown.map(p=>`${p.label} ≈${p.tokens}`).join('；')}。请到模型设置调整上限或回复长度，资料没有被裁剪。`);
    Object.assign(error,{code:'SHIJU_CONTEXT_LIMIT',stage:'上下文检查',context:result}); throw error;
  }
  return result;
}
