import { getHost } from '../../host.js';

const MAX_COUNT = 30, MAX_PACKED = 2 * 1024 * 1024, MAX_RAW = 16 * 1024 * 1024;
let records = [], ready, pending = Promise.resolve(), failure = '', revision = 0, readBlocked = false;
const listeners = new Set();
const notify = () => { for (const fn of listeners) { try { fn(); } catch {} } };
export const subscribeHistory = fn => { listeners.add(fn); return () => listeners.delete(fn); };
export const historyStatus = () => failure;
export const getHistory = () => records.map(r => ({...r}));
const bytes = text => new TextEncoder().encode(text);
async function gzip(text) {
  const stream = new Blob([bytes(text)]).stream().pipeThrough(new CompressionStream('gzip'));
  const data = new Uint8Array(await new Response(stream).arrayBuffer());
  let binary = ''; for (let i=0;i<data.length;i+=8192) binary += String.fromCharCode(...data.subarray(i,i+8192));
  return btoa(binary);
}
async function gunzip(encoded) {
  const bin = atob(encoded), data = Uint8Array.from(bin, c => c.charCodeAt(0));
  const reader = new Blob([data]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
  let chunks=[], length=0;
  while (true) { const x=await reader.read(); if(x.done) break; length+=x.value.length; if(length>MAX_RAW) { await reader.cancel(); throw new Error('历史内容超过大小限制'); } chunks.push(x.value); }
  return await new Blob(chunks).text();
}
function setFailure(message) {
  const firstFailure = !failure;
  failure = message;
  notify();
  if (message && firstFailure) {
    try { getHost().notifyHistoryFailure?.(`${message}。模型任务不受影响，可在设置的请求历史中重试或导出本页记录。`); } catch { /* Notification must not affect requests. */ }
  }
}
async function readRecords() {
  const encoded = await getHost().loadRequestHistory();
  if (encoded == null) return [];
  if (typeof encoded !== 'string' || encoded.length > MAX_PACKED) throw new Error('历史数据超过大小限制');
  const parsed = JSON.parse(await gunzip(encoded));
  if (!Array.isArray(parsed) || parsed.some(r => !r || typeof r !== 'object' || typeof r.id !== 'string' || (r.messages != null && (!Array.isArray(r.messages) || r.messages.some(m => !m || typeof m.content !== 'string'))) )) throw new Error('历史格式无效');
  return parsed.slice(0, MAX_COUNT).map(r => r.status === 'running' ? {...r,status:'interrupted',business:'结果未知／页面中断'} : r);
}
export async function initHistory() {
  if (ready) return ready;
  ready = (async () => {
    try { records = await readRecords(); }
    catch { readBlocked = true; setFailure('历史读取失败；原有文件未覆盖，请重试读取并保存'); }
    notify();
  })(); return ready;
}
function sanitize(value, secret) {
  if (typeof value === 'string') return (Array.isArray(secret) ? secret : [secret]).filter(Boolean).flatMap(key => [key, JSON.stringify(key).slice(1,-1), encodeURIComponent(key)]).sort((a,b)=>b.length-a.length).reduce((text,key) => text.split(key).join('[已隐藏]'),value);
  if (Array.isArray(value)) return value.map(v => sanitize(v,secret));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k,v]) => [k,sanitize(v,secret)]));
  return value;
}
// Identity and protocol fields must remain usable even for short placeholder keys.
// Only redact content that can contain credentials echoed by the user/upstream.
function sanitizeRecord(record, secret) {
  const result = {...record};
  for (const field of ['response', 'error', 'endpoint', 'model', 'provider']) {
    if (field in result) result[field] = sanitize(result[field], secret);
  }
  if (Array.isArray(result.messages)) result.messages = result.messages.map(message => ({
    ...message, content: sanitize(message.content, secret),
  }));
  return result;
}
async function saveSnapshot(snapshot, currentRevision) {
  if (readBlocked) return;
  let list = snapshot.slice(0,MAX_COUNT).map(r => {
    const {notPersisted,...saved} = r;
    if (r.status !== 'running') return saved;
    const {messages,response,...summary} = r;
    return {...summary,summaryOnly:true};
  }), json, packed;
  while (true) {
    json = JSON.stringify(list); packed = bytes(json).length <= MAX_RAW ? await gzip(json) : '';
    if (packed && packed.length <= MAX_PACKED) break;
    if (list.length > 1) { list.pop(); continue; }
    if (list.length === 1 && ('messages' in list[0] || 'response' in list[0])) { const {messages,response,...summary} = list[0]; list[0] = {...summary,bodyOmitted:true}; continue; }
    throw new Error('历史摘要超过容量上限');
  }
  await getHost().persistRequestHistory(packed);
  if (currentRevision === revision) {
    const persisted = new Map(list.map(r => [r.id,r]));
    for (const record of records) {
      record.notPersisted = !persisted.has(record.id);
      if (persisted.get(record.id)?.bodyOmitted) record.bodyOmitted = true;
    }
    failure = ''; notify();
  }
}
function queueSave() {
  const snapshot = JSON.parse(JSON.stringify(records)), currentRevision = ++revision;
  pending = pending.catch(()=>{}).then(()=>saveSnapshot(snapshot,currentRevision)).catch(() => { setFailure('历史未保存，请重试保存'); });
  return pending;
}
export async function retryHistory() {
  await initHistory();
  await pending;
  if (readBlocked) {
    try {
      const saved = await readRecords();
      if (readBlocked) {
        const ids = new Set(records.map(r => r.id));
        records = [...records, ...saved.filter(r => !ids.has(r.id))].sort((a,b) => Date.parse(b.startedAt) - Date.parse(a.startedAt)).slice(0, MAX_COUNT);
        readBlocked = false;
      }
    } catch { setFailure('历史读取失败；原有文件未覆盖，请重试读取并保存'); return; }
  }
  return queueSave();
}
export async function clearHistory() { await initHistory(); records=[]; readBlocked=false; failure=''; notify(); return queueSave(); }
export async function beginHistory(request, scope) {
  const ctx=getHost().getContext?.() || {};
  const origin={chatId:ctx.getCurrentChatId?.() ?? ctx.chatId ?? '',characterId:ctx.characterId ?? null,groupId:ctx.groupId ?? null};
  await initHistory();
  const conn=request.connection || {}, secret=[conn.apiKey,conn.settings?.proxy_password].filter(key => typeof key === 'string' && key.length);
  const id=globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
  const record=sanitizeRecord({ id, startedAt:new Date().toISOString(), purpose:request.historyPurpose || request.purpose,
    chatId:scope?.chatId ?? origin.chatId, characterId:scope?.characterId ?? origin.characterId, groupId:scope?.groupId ?? origin.groupId,
    channel:conn.mode === 'custom' ? '自定义' : '跟随酒馆', provider:conn.mode === 'custom' ? 'OpenAI 兼容' : conn.settings?.chat_completion_source || conn.api || '', model:conn.mode === 'custom' ? conn.customModel : conn.model || conn.settings?.model_novel || conn.horde?.models?.join(', ') || '',
    endpoint:conn.mode === 'custom' ? conn.endpoint : ({openai:'/api/backends/chat-completions/generate',textgenerationwebui:'/api/backends/text-completions/generate',kobold:'/api/backends/kobold/generate',novel:'/api/novelai/generate',koboldhorde:'/api/horde/generate-text'})[conn.api] || '', length:request.responseLength ?? conn.responseLength ?? null,
    requestedStream:conn.mode === 'custom' && conn.stream === true, status:'running', business:'等待响应', messages:request.messages, inputCharacters:Array.from((request.messages || []).map(m => m.content || '').join('\n')).length, characters:0 }, secret);
  records.unshift(record); records=records.slice(0,MAX_COUNT); notify(); queueSave();
  return {id, secret, started:Date.now()};
}
export function updateHistory(id, patch, secret = '', persist = true) {
  const record=records.find(r => r.id === id); if(!record) return;
  Object.assign(record,sanitizeRecord(patch,secret)); notify(); if(persist) queueSave();
}
export function finishHistory(ref, result, error) {
  const elapsedMs=Date.now()-ref.started;
  if (error) updateHistory(ref.id,{status:error.name === 'AbortError' || error.code === 'SHIJU_CHAT_CHANGED' ? 'cancelled':'failed',transportStatus:error.name === 'AbortError' || error.code === 'SHIJU_CHAT_CHANGED' ? 'cancelled' : 'failed',business:error.code === 'SHIJU_TIMEOUT' ? '连接测试超时' : error.name === 'AbortError' || error.code === 'SHIJU_CHAT_CHANGED' ? '请求已取消' : '请求失败',errorStage:error.stage || (error.httpStatus ? '接收响应' : '连接／请求'),error:String(error.message || '请求失败'),errorCode:error.code || '',httpStatus:error.httpStatus || null,finishReason:error.finishReason || null,response:error.partialText || '',elapsedMs},ref.secret);
  else {
    const details=typeof result === 'string' ? {text:result} : result;
    updateHistory(ref.id,{status:'success',transportStatus:'success',business:'响应完成，等待处理',characters:Array.from(details.text || '').length,response:details.text,elapsedMs,httpStatus:details.httpStatus ?? null,actualStream:details.actualStream ?? false,firstTextMs:details.firstTextMs ?? null,finishReason:details.finishReason ?? null,usage:details.usage ?? null},ref.secret);
  }
}

export const redactHistoryText = (text, secret) => sanitize(text, secret);

export async function recordBusinessResult(requestId, action, success) {
  try {
    const result = await action();
    updateHistory(requestId, {business:success});
    return result;
  } catch (error) {
    const cancelled = error.code === 'SHIJU_CHAT_CHANGED';
    updateHistory(requestId, {status:cancelled ? 'cancelled' : 'failed', business:cancelled ? '聊天已切换，结果未采用' : '世界账保存失败', errorStage:'提交世界账'});
    throw error;
  }
}
