import { shijuError } from '../../errors.js';
import { getHost } from '../../host.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { loadSettings, loadPreferences } from '../../store/index.js';
import { effectivePreferences, validateModelSettings } from '../../preferences.js';
import { BAIBAI_JAILBREAK } from '../../prompts/baibai-jailbreak.js';

const WORLD_TASKS = new Set(['bootstrap', 'evolve', 'realign']);

/** Capture before asynchronous source reads, not when the model finally starts. */
export function captureModelConfig(purpose) {
  const settings = loadSettings().model;
  validateModelSettings(settings);
  return {
    ...settings,
    connection: getHost().captureModelConnection?.(settings),
    preferences: WORLD_TASKS.has(purpose) ? effectivePreferences(loadPreferences()) : null,
  };
}

function dispatch(backend, request, scope) {
  assertChatScope(scope);
  return backend(request, () => assertChatScope(scope));
}

/**
 * M-Model. Every world-building and evolution call leaves through here.
 * The host method must use SillyTavern's backend (independent request). No browser fetch.
 * 统一出口。禁止浏览器直连上游。
 */
export function register() {}

export async function generateViaST(request, chatScope = captureChatScope()) {
  assertChatScope(chatScope);
  const config = request.modelConfig ?? captureModelConfig(request.purpose);
  validateModelSettings(config);
  const prompt = typeof request?.prompt === 'string' ? request.prompt : '';
  if (!prompt.trim()) {
    throw shijuError('SHIJU_MODEL_INPUT', '世局：模型请求是空的');
  }
  const host = getHost();
  const backend = host.generateViaBackend;
  if (typeof backend !== 'function') {
    throw shijuError('SHIJU_NO_BACKEND', '世局：没有接到酒馆后端转发');
  }
  let text;
  try {
    const jailbreak = config.jailbreakMode === 'off' ? ''
      : config.jailbreakMode === 'custom' ? config.customText : BAIBAI_JAILBREAK;
    const systemPrompt = typeof request.systemPrompt === 'string' ? request.systemPrompt : '';
    const preferences = WORLD_TASKS.has(request.purpose) ? config.preferences : null;
    const messages = [
      ...(jailbreak ? [{ role: 'system', content: jailbreak }] : []),
      ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
      ...(preferences ? [{ role: 'system', content: `【当前演进偏好】\n${preferences.text}\n\n此偏好只影响未来的发展方向，不改写既有事实和用户修正；不替主角行动、不强迫介入。仍遵守任务的结构化输出、事件 ID、归档与隐秘证据规则。` }] : []),
      { role: 'user', content: prompt },
    ];
    text = await dispatch(backend, {
      purpose: typeof request.purpose === 'string' ? request.purpose : 'unknown',
      systemPrompt,
      prompt,
      messages,
      ...(config.connection ? { connection: config.connection } : {}),
      ...(config.responseLength == null ? {} : { responseLength: config.responseLength }),
    }, chatScope);
  } catch (error) {
    assertChatScope(chatScope);
    if (typeof error?.code === 'string' && error.code.startsWith('SHIJU_')) throw error;
    throw shijuError('SHIJU_MODEL_FAILED', error?.message || '世局：模型调用失败');
  }
  assertChatScope(chatScope);
  if (typeof text !== 'string' || !text.trim()) {
    throw shijuError('SHIJU_MODEL_FAILED', '世局：酒馆后端没有返回文本');
  }
  return { text, purpose: typeof request.purpose === 'string' ? request.purpose : 'unknown',
    preferencesSnapshot: WORLD_TASKS.has(request.purpose) ? config.preferences : null };
}
