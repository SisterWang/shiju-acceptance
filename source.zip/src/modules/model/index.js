import { shijuError } from '../../errors.js';
import { getHost } from '../../host.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { loadSettings, loadPreferences } from '../../store/index.js';
import { effectivePreferences, validateModelSettings } from '../../preferences.js';
import { BAIBAI_JAILBREAK } from '../../prompts/baibai-jailbreak.js';
import { beginHistory, updateHistory, finishHistory, redactHistoryText } from './history.js';

const WORLD_TASKS = new Set(['bootstrap', 'evolve', 'realign']);

/** Capture before asynchronous source reads, not when the model finally starts. */
export function captureModelConfig(purpose) {
  const settings = loadSettings().model;
  validateModelSettings(settings);
  return {
    ...settings,
    connection: getHost().captureModelConnection?.(settings),
    preferences: WORLD_TASKS.has(purpose) ? effectivePreferences(loadPreferences()) : null,
  };
}

/**
 * M-Model. Every world-building and evolution call leaves through here.
 * The host method must use SillyTavern's backend (independent request). No browser fetch.
 * 统一出口。禁止浏览器直连上游。
 */
export function register() {}

/** A connection test is isolated from world prompts and does not need a chat. */
export async function testCustomConnection(model, options = {}) {
  if (model?.channelMode !== 'custom') throw shijuError('SHIJU_MODEL_SETTINGS','连接测试仅用于自定义渠道');
  validateModelSettings({ ...model, jailbreakMode: 'off' });
  const host = getHost();
  const connection = host.captureModelConnection(model);
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (options.signal?.aborted) abort(); else options.signal?.addEventListener('abort', abort, {once:true});
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, 120000);
  try {
    const result = await recorded(host.generateViaBackend, {purpose:'connection-test', connection,
      messages:[{role:'user',content:'回复"ok"两个字符即可。'}],
      ...(model.responseLength == null ? {} : {responseLength:model.responseLength})}, null, () => {}, {...options,signal:controller.signal,isTimedOut:()=>timedOut});
    updateHistory(result.requestId,{business:result.text.trim() === 'ok' ? '连接测试通过' : '已连通，但回复未按测试要求'});
    return result.text;
  } finally { clearTimeout(timer); options.signal?.removeEventListener('abort',abort); }
}

async function recorded(backend, request, scope, assertCurrent, options = {}) {
  const ref = await beginHistory(request, scope);
  let received;
  try {
    const result = await backend(request, assertCurrent, {...options,detailed:true,onProgress: progress => {
      updateHistory(ref.id, {business:'正在接收',characters:progress.characters,elapsedMs:progress.elapsedMs},ref.secret,false);
      options.onProgress?.(progress);
    }});
    received = result;
    assertCurrent();
    const text = typeof result === 'string' ? result : result?.text;
    if (typeof text !== 'string' || !text.trim()) throw shijuError('SHIJU_MODEL_FAILED','模型后端没有返回文本');
    finishHistory(ref,result,null);
    return {text:typeof result === 'string' ? result : result.text, requestId:ref.id};
  } catch (error) {
    if (options.isTimedOut?.()) { error = Object.assign(shijuError('SHIJU_TIMEOUT','连接测试超时'), {partialText:error.partialText, httpStatus:error.httpStatus}); }
    if (received && !error.partialText) error.partialText = typeof received === 'string' ? received : received.text;
    finishHistory(ref,null,error);
    if (typeof error?.message === 'string') {
      try { error.message = redactHistoryText(error.message, ref.secret); } catch { /* immutable error */ }
    }
    throw error;
  }
}

export async function generateViaST(request, chatScope = captureChatScope()) {
  assertChatScope(chatScope);
  const config = request.modelConfig ?? captureModelConfig(request.purpose);
  validateModelSettings(config);
  const prompt = typeof request?.prompt === 'string' ? request.prompt : '';
  if (!prompt.trim()) {
    throw shijuError('SHIJU_MODEL_INPUT', '世局：模型请求是空的');
  }
  const host = getHost();
  const backend = host.generateViaBackend;
  if (typeof backend !== 'function') {
    throw shijuError('SHIJU_NO_BACKEND', '世局：没有接到酒馆后端转发');
  }
  let text, requestId;
  try {
    const jailbreak = config.jailbreakMode === 'off' ? ''
      : config.jailbreakMode === 'custom' ? config.customText : BAIBAI_JAILBREAK;
    const systemPrompt = typeof request.systemPrompt === 'string' ? request.systemPrompt : '';
    const preferences = WORLD_TASKS.has(request.purpose) ? config.preferences : null;
    const messages = [
      ...(jailbreak ? [{ role: 'system', content: jailbreak }] : []),
      ...(systemPrompt ? [{ role: 'system', content: systemPrompt }] : []),
      ...(preferences ? [{ role: 'system', content: `【当前演进偏好】\n${preferences.text}\n\n此偏好只影响未来的发展方向，不改写既有事实和用户修正；不替主角行动、不强迫介入。仍遵守任务的结构化输出、事件 ID、归档与隐秘证据规则。` }] : []),
      { role: 'user', content: prompt },
    ];
    const result = await recorded(backend, {
      purpose: typeof request.purpose === 'string' ? request.purpose : 'unknown',
      historyPurpose: request.historyPurpose,
      systemPrompt,
      prompt,
      messages,
      ...(config.connection ? { connection: config.connection } : {}),
      ...(config.responseLength == null ? {} : { responseLength: config.responseLength }),
    }, chatScope, () => assertChatScope(chatScope));
    text = result.text; requestId = result.requestId;
  } catch (error) {
    assertChatScope(chatScope);
    if (typeof error?.code === 'string' && error.code.startsWith('SHIJU_')) throw error;
    throw shijuError('SHIJU_MODEL_FAILED', error?.message || '世局：模型调用失败');
  }
  assertChatScope(chatScope);
  if (typeof text !== 'string' || !text.trim()) {
    throw shijuError('SHIJU_MODEL_FAILED', '世局：酒馆后端没有返回文本');
  }
  return { text, requestId, purpose: typeof request.purpose === 'string' ? request.purpose : 'unknown',
    preferencesSnapshot: WORLD_TASKS.has(request.purpose) ? config.preferences : null };
}
