import { reconcileTextEdits } from '../incremental.js';
import { getHost } from '../../host.js';
import { assertChatScope, watchChatChanges } from '../../chatScope.js';
import { loadSettings, loadWorld, saveWorld } from '../../store/index.js';
import { applySubset } from '../commit/subset.js';
import { isGeneratingTip, setGeneratingTip } from '../generatingTip.js';
import { refreshInject } from '../inject/index.js';
import { readChat } from '../source/index.js';
import { clearEvolutionHold, rebuildDayBuffer, runAutomaticGateBody } from '../timeGate/index.js';
import { fingerprintOfMessage, interpretStoryTime, resolveTimeSourceMode } from '../timetag/index.js';
import { enqueueTurn } from '../turn.js';

/**
 * M-Reconcile. Drop invalid anchors, restore that anchor's worldAfter,
 * rebuild the day buffer, then call the gate again.
 * Valid anchors are left in place. This module does not append the log.
 * 冻结或未启用时只刷新注入，不推演。
 */

let boundHost = null;

function floorArg(value) {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 0) return value;
  if (typeof value === 'string' && /^\d+$/.test(value)) return Number(value);
  if (value && typeof value === 'object') {
    if (Number.isInteger(value.floor)) return value.floor;
    if (Number.isInteger(value.mesId)) return value.mesId;
  }
  return null;
}

function generationKind(type, options) {
  if (typeof type === 'string') return type.toLowerCase();
  if (type && typeof type === 'object') {
    return String(type.type || type.kind || options?.type || '').toLowerCase();
  }
  if (typeof options === 'string') return options.toLowerCase();
  return String(options?.type || '').toLowerCase();
}

function anchorHolds(entry, chat, mode, customTag, hint) {
  // A swipe invalidates later anchors. The swiped floor itself is judged by
  // swipe id and fingerprint, so a second notice of the same swipe does not push again.
  if (hint?.cause === 'swipe' && Number.isInteger(hint.floor) && entry.tipFloor > hint.floor) return false;
  if (entry.tipFloor < 0) return chat.length === 0;
  if (typeof entry.tipFloor !== 'number' || entry.tipFloor >= chat.length) return false;
  const message = chat[entry.tipFloor];
  if (!message) return false;
  const swipeId = typeof message.swipe_id === 'number' ? message.swipe_id : 0;
  if (swipeId !== (entry.tipSwipeId ?? 0)) return false;
  return fingerprintOfMessage(message, mode, customTag) === (entry.tipTimeFingerprint ?? '');
}

async function reconcileBody(hint, chatScope) {
  assertChatScope(chatScope);
  if (isGeneratingTip()) return { ok: true, dropped: 0, evolved: false, reason: 'generating' };
  const world = loadWorld();
  if (!world?.plugin?.enabled || world.plugin.frozenAt != null || !world.meta?.builtFingerprint) {
    try {
      refreshInject();
    } catch (error) {
      console.error('[shiju] 注入刷新失败', error);
    }
    return { ok: true, dropped: 0, evolved: false, reason: 'disabled' };
  }
  const chat = readChat();
  const settings = loadSettings();
  const mode = resolveTimeSourceMode(settings);
  const customTag = settings.timeSource?.customTag || '';
  // Contradictory dates are a temporary input error, not evidence that the
  // ledger should be rolled back. Check prose alone before touching anchors.
  if (interpretStoryTime(null, chat, mode, customTag).status === 'conflict') {
    world.meta.clockHint = 'conflict';
    await saveWorld(world, chatScope);
    return { ok: true, dropped: 0, evolved: false, reason: 'conflict' };
  }
  const log = Array.isArray(world.evolutionLog) ? world.evolutionLog : [];
  let keepCount = log.length;
  for (let index = 0; index < log.length; index += 1) {
    if (!anchorHolds(log[index], chat, mode, customTag, hint)) {
      keepCount = index;
      break;
    }
  }
  const dropped = log.length - keepCount;
  if (dropped > 0) {
    const kept = log.slice(0, keepCount);
    const base = kept.length ? kept[kept.length - 1] : world.meta.initialSnapshot;
    if (base?.worldAfter) {
      applySubset(world, base.worldAfter);
      if (typeof base.dayIndexAfter === 'number') world.meta.lastEvolvedDayIndex = base.dayIndexAfter;
    }
    world.evolutionLog = kept;
    const latestId = kept.length ? kept[kept.length - 1].id : null;
    if (world.lastEvolutionCheckpoint && world.lastEvolutionCheckpoint.evolutionId !== latestId) {
      world.lastEvolutionCheckpoint = null;
    }
    rebuildDayBuffer(world, chat, typeof base?.tipFloor === 'number' ? base.tipFloor : -1);
    await saveWorld(world, chatScope);
  }
  if (!dropped && hint?.cause === 'edit' && reconcileTextEdits(world, chat)) {
    world.meta.inputHint = '';
    await saveWorld(world, chatScope);
  }
  assertChatScope(chatScope);
  const gated = await runAutomaticGateBody(chatScope);
  assertChatScope(chatScope);
  try {
    refreshInject();
  } catch (error) {
    console.error('[shiju] 注入刷新失败', error);
  }
  return {
    ok: gated.ok !== false,
    dropped,
    evolved: Boolean(gated.evolved),
    reason: gated.reason || 'reconciled',
  };
}

export function reconcileOnChatMutation(hint) {
  return enqueueTurn((chatScope) => reconcileBody(hint, chatScope));
}

function listen(source, name, fn) {
  if (!name || !source || typeof source.on !== 'function') return;
  source.on(name, (...args) => {
    try {
      fn(...args);
    } catch (error) {
      console.error('[shiju]', error);
    }
  });
}

export function register() {
  const host = getHost();
  if (boundHost === host) return;
  boundHost = host;
  watchChatChanges(host);
  const types = host.event_types || {};
  const source = host.eventSource;
  listen(source, types.GENERATION_STARTED, (type, options, dryRun) => {
    if (dryRun === true || options?.dryRun === true) return;
    const kind = generationKind(type, options);
    if (kind === 'regenerate' || kind === 'swipe' || kind === 'regen') setGeneratingTip(true);
  });
  const settle = () => {
    setGeneratingTip(false);
    reconcileOnChatMutation().catch((error) => console.error('[shiju]', error));
  };
  listen(source, types.GENERATION_ENDED, settle);
  listen(source, types.GENERATION_STOPPED, settle);
  listen(source, types.CHARACTER_MESSAGE_RENDERED, settle);
  listen(source, types.MESSAGE_SWIPED, (id) => {
    reconcileOnChatMutation({ cause: 'swipe', floor: floorArg(id) }).catch((error) => console.error('[shiju]', error));
  });
  listen(source, types.MESSAGE_DELETED, () => {
    reconcileOnChatMutation({ cause: 'delete' }).catch((error) => console.error('[shiju]', error));
  });
  listen(source, types.MESSAGE_EDITED, () => {
    reconcileOnChatMutation({ cause: 'edit' }).catch((error) => console.error('[shiju]', error));
  });
  listen(source, types.CHAT_CHANGED, () => {
    setGeneratingTip(false);
    clearEvolutionHold();
    reconcileOnChatMutation({ cause: 'chat' }).catch((error) => console.error('[shiju]', error));
  });
}
