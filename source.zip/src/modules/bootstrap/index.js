import { captureInputBoundary } from '../incremental.js';
import { EVENT_MODEL_RULES } from '../events.js';
import { cloneJson } from '../../plain.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { createEmptyWorld, loadSettings, loadWorld, saveWorld } from '../../store/index.js';
import { minSubset } from '../commit/subset.js';
import { assembleRenderedInput } from '../evolve/index.js';
import { parseModelJson } from '../evolve/json.js';
import { applyEvolutionPatch, countEntities, makeId } from '../evolve/patch.js';
import { captureModelConfig, generateViaST } from '../model/index.js';
import { narrativeText, readChat, readSourcePack } from '../source/index.js';
import { refreshInject } from '../inject/index.js';
import { applyClock, currentTipCursor, interpretStoryTime, refreshTimeTag, resolveTimeSourceMode } from '../timetag/index.js';
import { enqueueTurn } from '../turn.js';

/**
 * M-Bootstrap. One world-building model call, then stop.
 * Historical dates are written onto the clock so the gate does not evolve them.
 * Message text is never rewritten.
 */

const SYSTEM = [
  '你是世局的建世界器。只根据给定资料建立宏观世界，不要推演后续日子，不要写眼前戏。',
  '只输出一个 JSON 对象，不要 Markdown。',
  '至少给出一个地区、组织或势力。字段：regions、orgs、factions，每项含 name 与 summary。',
  '可以带少量 events。todayChanges 必须是空数组。',
  '不要要求把这些内容写进正文。',
  EVENT_MODEL_RULES,
].join('\n');

export function register() {}

function refreshSurface() {
  refreshTimeTag();
  try {
    refreshInject();
  } catch (error) {
    console.error('[shiju] 注入刷新失败', error);
  }
}

function summarize(pack) {
  const titles = (pack.worldbook?.entries || []).map((entry) => entry.title).join(',');
  return makeId('boot', `${titles}:${pack.floorsTail?.length || 0}:${pack.baibai ? 1 : 0}`, pack.floorsTail?.length || 0);
}

async function bootstrapBody(chatScope) {
  assertChatScope(chatScope);
  const existing = loadWorld();
  if (existing?.meta?.builtFingerprint) {
    if (existing.plugin.enabled && existing.plugin.frozenAt == null) {
      refreshSurface();
      return { ok: true, created: false, evolved: false, world: existing };
    }
    existing.plugin.enabled = true;
    existing.plugin.frozenAt = null;
    const saved = await saveWorld(existing, chatScope);
    assertChatScope(chatScope);
    refreshSurface();
    return { ok: true, created: false, resumed: true, evolved: false, world: saved };
  }

  const inputChat = cloneJson(readChat());
  const modelConfig = captureModelConfig('bootstrap');
  const pack = await readSourcePack();
  assertChatScope(chatScope);
  const assembled = await assembleRenderedInput({
    world: null,
    pack,
    dayDelta: 1,
    summary: '新建世界，尚无世局账。',
    bufferText: '',
    p1: narrativeText(pack),
  });
  if (!assembled.selected.bodies.length && !narrativeText(pack).trim() && !Object.keys(pack.mvu || {}).length) return {ok:false, created:false, reason:'source', message:'有效资料不足；请查看资料诊断'};
  const budget = assembled.budget;
  const prompt = [
    '任务：建世界。只建立当前时点的实体，不要跨日推演。',
    budget.text || '（没有世界书，也没有楼层。请仍给出至少一个地点或势力。）',
    '只输出 JSON。todayChanges 用空数组。',
  ].join('\n\n');

  let generated;
  try {
    generated = await generateViaST({
      purpose: 'bootstrap',
      modelConfig,
      systemPrompt: SYSTEM,
      prompt,
    }, chatScope);
  } catch (error) {
    assertChatScope(chatScope);
    return { ok: false, created: false, evolved: false, reason: 'model', message: error?.message || '建世界失败' };
  }
  assertChatScope(chatScope);
  const parsed = parseModelJson(generated.text);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, created: false, evolved: false, reason: 'parse' };
  }

  const world = createEmptyWorld();
  world.appliedPreferences = cloneJson(generated.preferencesSnapshot);
  applyEvolutionPatch(world, { ...parsed, todayChanges: [] }, {
    dayIndex: 0,
    evolutionId: null,
    evidence: '建世界',
    evidenceText: budget.p1,
  });
  world.todayChanges = [];
  if (countEntities(world) < 1) {
    return { ok: false, created: false, evolved: false, reason: 'empty' };
  }

  const settings = loadSettings();
  const mode = resolveTimeSourceMode(settings);
  const chat = pack.chat || inputChat;
  const reading = interpretStoryTime(world, chat, mode, settings.timeSource?.customTag || '');
  applyClock(world, reading);
  world.plugin.enabled = true;
  world.plugin.frozenAt = null;
  world.meta.builtFingerprint = summarize(pack);
  world.meta.modelCallCount = 1;
  world.meta.evolutionCallCount = 0;
  world.meta.lastEvolvedDayIndex = world.storyClock.dayIndex;
  world.worldbookRotateCursor = assembled.selected.nextCursor;
  world.meta.usage = assembled.usage;
  world.meta.sources = {
    memory: pack.baibai ? 'baibai' : 'native',
    mvu: Boolean(pack.mvu),
    truncated: Boolean(budget.truncated),
    softWarn: Boolean(budget.softWarn),
  };
  world.lastEvolutionCheckpoint = null;
  world.evolutionLog = [];
  const tip = currentTipCursor(chat, mode, settings.timeSource?.customTag || '');
  world.processedInput = captureInputBoundary(chat);
  world.meta.initialSnapshot = {
    dayIndexAfter: world.storyClock.dayIndex,
    tipFloor: tip.floor,
    tipSwipeId: tip.swipeId,
    tipTimeFingerprint: tip.fingerprint,
    worldAfter: minSubset(world),
  };

  const saved = await saveWorld(cloneJson(world), chatScope);
  assertChatScope(chatScope);
  refreshSurface();
  return { ok: true, created: true, evolved: false, world: saved, usage: assembled.usage };
}

/** Enable the current chat without taking another turn slot. Never evolves. */
export function runBootstrap(chatScope = captureChatScope()) {
  return bootstrapBody(chatScope);
}

/** Enable the current chat: build once, or resume a frozen ledger. Never evolves. */
export function bootstrapWorld() {
  return enqueueTurn(bootstrapBody);
}
