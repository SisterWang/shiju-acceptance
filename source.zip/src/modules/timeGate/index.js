import { captureModelConfig } from '../model/index.js';
import { captureInputBoundary, ensureInputBoundary, readIncrement, pendingCorrections } from '../incremental.js';
import { cloneJson } from '../../plain.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { loadSettings, loadWorld, saveWorld, loadPreferences } from '../../store/index.js';
import { effectivePreferences, preferencesPending } from '../../preferences.js';
import { applySubset, minSubset } from '../commit/subset.js';
import { commitEvolutionSuccess } from '../commit/index.js';
import { makeEvolutionId } from '../evolve/patch.js';
import { runEvolutionOnce } from '../evolve/index.js';
import { isGeneratingTip } from '../generatingTip.js';
import { refreshInject } from '../inject/index.js';
import { readChat, readSourcePack } from '../source/index.js';
import {
  applyClock,
  currentTipCursor,
  interpretStoryTime,
  resolveTimeSourceMode,
} from '../timetag/index.js';
import { enqueueTurn } from '../turn.js';

/**
 * M-TimeGate. Same-day automatic evolution is zero.
 * A missing time tag stays on the same day.
 * While the tip is regenerating or swiping, the automatic gate returns without evolving.
 * Success goes through commitEvolutionSuccess only.
 */

let failedAutoKey = '';

export function register() {}

export function clearEvolutionHold() {
  failedAutoKey = '';
}

function clipMes(mes) {
  if (typeof mes !== 'string') return '';
  return mes.replace(/<[^>\n]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
}

export function updateDayBuffer(world, chat) {
  const items = Array.isArray(world.dayBuffer?.items) ? world.dayBuffer.items.slice() : [];
  const seen = new Set(items.map((item) => `${item.floor}:${item.swipeId}:${item.text}`));
  const list = Array.isArray(chat) ? chat : [];
  for (let index = 0; index < list.length; index += 1) {
    const message = list[index];
    if (!message || message.is_system || message.extra?.bbs_omit) continue;
    const text = clipMes(message.mes);
    if (!text) continue;
    const swipeId = typeof message.swipe_id === 'number' ? message.swipe_id : 0;
    const key = `${index}:${swipeId}:${text}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push({ floor: index, swipeId, text });
  }
  world.dayBuffer = { items: items.slice(-12) };
  return world.dayBuffer;
}

export function rebuildDayBuffer(world, chat, afterFloor) {
  const items = [];
  const list = Array.isArray(chat) ? chat : [];
  const floor = typeof afterFloor === 'number' ? afterFloor : -1;
  for (let index = 0; index < list.length; index += 1) {
    if (index <= floor) continue;
    const message = list[index];
    if (!message || message.is_system || message.extra?.bbs_omit) continue;
    const text = clipMes(message.mes);
    if (!text) continue;
    items.push({
      floor: index,
      swipeId: typeof message.swipe_id === 'number' ? message.swipe_id : 0,
      text,
    });
  }
  world.dayBuffer = { items: items.slice(-12) };
}

function modeOf() {
  const settings = loadSettings();
  return {
    mode: resolveTimeSourceMode(settings),
    customTag: settings.timeSource?.customTag || '',
  };
}

function armed(world) {
  return Boolean(world?.plugin?.enabled) && world?.plugin?.frozenAt == null && world?.meta?.builtFingerprint;
}

function skipReason(reading, world) {
  if (reading.status === 'missing') return 'missing-tag';
  if (reading.status === 'conflict') return 'conflict';
  const last = world.meta?.lastEvolvedDayIndex;
  if (reading.status !== 'advance') return 'same-day';
  if (typeof last === 'number' && reading.dayIndex <= last) return 'same-day';
  return '';
}

async function noteFailure(world, result, chatScope) {
  world.meta.errorCount = (world.meta.errorCount || 0) + 1;
  if (result?.modelCalled) world.meta.modelCallCount = (world.meta.modelCallCount || 0) + 1;
  if (result?.truncated) world.meta.sources.truncated = true;
  world.meta.clockHint = 'evolve-failed';
  await saveWorld(world, chatScope);
}

async function commitIfOk(fields, result) {
  if (!result?.ok) return false;
  await commitEvolutionSuccess({
    ok: true,
    ...fields,
    patch: result.patch,
    evidenceText: result.evidenceText || '',
    preferencesSnapshot: result.preferencesSnapshot,
    truncated: Boolean(result.truncated),
    softWarn: Boolean(result.softWarn),
    digest: result.digest || '',
    memory: result.memory,
    mvu: result.mvu,
    usage: result.usage || null,
    worldbookScan: result.worldbookScan || null,
  });
  return true;
}

function pendingFrom(world, draft, tip, id, chatScope, inputBoundary) {
  const checkpoint = minSubset(draft);
  return {
    chatScope,
    inputBoundary,
    baseWorld: draft,
    checkpoint,
    storyClock: cloneJson(draft.storyClock),
    lastEvolvedDayIndex: draft.storyClock.dayIndex,
    callCount: world.meta.evolutionCallCount || 0,
    modelCount: world.meta.modelCallCount || 0,
    entry: {
      id,
      dayIndexAfter: draft.storyClock.dayIndex,
      tipFloor: tip.floor,
      tipSwipeId: tip.swipeId,
      tipTimeFingerprint: tip.fingerprint,
    },
  };
}

export async function runAutomaticGateBody(chatScope = captureChatScope()) {
  assertChatScope(chatScope);
  if (isGeneratingTip()) return { ok: true, evolved: false, reason: 'generating' };
  const world = loadWorld();
  if (!armed(world)) {
    try {
      refreshInject();
    } catch (error) {
      console.error('[shiju] 注入刷新失败', error);
    }
    return { ok: true, evolved: false, reason: 'disabled' };
  }
  const modelConfig = captureModelConfig('evolve');
  const pack = await readSourcePack();
  assertChatScope(chatScope);
  const chat = pack.chat;
  const { mode, customTag } = modeOf();
  ensureInputBoundary(world, chat, mode, customTag);
  const exclusionsBefore = world.processedInput.excluded?.length || 0;
  const increment = readIncrement(world, chat, pack.baibai);
  if (!increment.changed && world.meta.inputHint === 'history-changed') world.meta.inputHint = '';
  world.dayBuffer = { items: increment.items.map((item) => ({ floor: item.floor, swipeId: item.swipeId, text: clipMes(item.text) })).slice(-12) };
  const reading = interpretStoryTime(world, chat, mode, customTag);
  if (increment.changed && reading.status !== 'conflict') {
    world.meta.inputHint = 'history-changed';
    await saveWorld(world, chatScope);
    return { ok: false, evolved: false, reason: 'history-changed' };
  }
  const reason = skipReason(reading, world);
  if (reason) {
    applyClock(world, reading);
    await saveWorld(world, chatScope);
    return { ok: true, evolved: false, reason, time: reading };
  }
  const tip = currentTipCursor(chat, mode, customTag);
  const key = `${tip.floor}:${tip.swipeId}:${tip.fingerprint}:${reading.dayIndex}`;
  if (failedAutoKey === key) {
    await saveWorld(world, chatScope);
    return { ok: true, evolved: false, reason: 'held', time: reading };
  }
  if ((world.processedInput.excluded?.length || 0) !== exclusionsBefore) await saveWorld(world, chatScope);
  const inputBoundary = captureInputBoundary(chat, Infinity, world.processedInput, increment.accepted);
  const draft = cloneJson(world);
  applyClock(draft, reading);
  const id = makeEvolutionId(draft.storyClock.dayIndex, tip.floor);
  const result = await runEvolutionOnce({
    chatScope,
    world: draft,
    purpose: 'auto', pack, modelConfig,
    incrementText: increment.text || '',
    span: { from: world.storyClock.dayIndex, to: reading.dayIndex },
  });
  assertChatScope(chatScope);
  if (!result.ok) {
    failedAutoKey = key;
    await noteFailure(world, result, chatScope);
    return { ok: false, evolved: false, reason: result.reason || 'model', message: result.message, time: reading };
  }
  failedAutoKey = '';
  await commitIfOk(pendingFrom(world, draft, tip, id, chatScope, inputBoundary), result);
  return { ok: true, evolved: true, reason: 'advance', time: reading, usage: result.usage || null };
}

async function immediateBody(chatScope) {
  assertChatScope(chatScope);
  if (isGeneratingTip()) return { ok: false, evolved: false, reason: 'generating' };
  const world = loadWorld();
  if (!armed(world)) return { ok: false, evolved: false, reason: 'no-world' };
  failedAutoKey = '';
  const modelConfig = captureModelConfig('evolve');
  const pack = await readSourcePack();
  assertChatScope(chatScope);
  const chat = pack.chat;
  const { mode, customTag } = modeOf();
  ensureInputBoundary(world, chat, mode, customTag);
  const exclusionsBefore = world.processedInput.excluded?.length || 0;
  const increment = readIncrement(world, chat, pack.baibai);
  if (!increment.changed && world.meta.inputHint === 'history-changed') world.meta.inputHint = '';
  world.dayBuffer = { items: increment.items.map((item) => ({ floor: item.floor, swipeId: item.swipeId, text: clipMes(item.text) })).slice(-12) };
  const reading = interpretStoryTime(world, chat, mode, customTag);
  if (increment.changed) {
    world.meta.inputHint = 'history-changed';
    await saveWorld(world, chatScope);
    return { ok: false, evolved: false, reason: 'history-changed' };
  }
  const noOtherIncrement = !increment.items.length && !pendingCorrections(world).length && reading.status !== 'advance';
  if (noOtherIncrement && !preferencesPending(world, effectivePreferences(loadPreferences()))) {
    await saveWorld(world, chatScope);
    return { ok: true, evolved: false, reason: 'no-increment' };
  }
  if ((world.processedInput.excluded?.length || 0) !== exclusionsBefore) await saveWorld(world, chatScope);
  const inputBoundary = captureInputBoundary(chat, Infinity, world.processedInput, increment.accepted);
  const draft = cloneJson(world);
  if (reading.status === 'advance') applyClock(draft, reading);
  const tip = currentTipCursor(chat, mode, customTag);
  const id = makeEvolutionId(draft.storyClock.dayIndex, tip.floor);
  const result = await runEvolutionOnce({ world: draft, purpose: 'immediate', chatScope, pack, modelConfig,
    incrementText: increment.text || '', preferenceOnly: noOtherIncrement });
  assertChatScope(chatScope);
  if (!result.ok) {
    await noteFailure(world, result, chatScope);
    return { ok: false, evolved: false, reason: result.reason || 'model', message: result.message };
  }
  await commitIfOk(pendingFrom(world, draft, tip, id, chatScope, inputBoundary), result);
  return { ok: true, evolved: true, reason: 'immediate', usage: result.usage || null };
}

function restoredDraft(world, checkpoint) {
  const draft = cloneJson(world);
  const clock = cloneJson(world.storyClock);
  const log = cloneJson(world.evolutionLog || []);
  const plugin = cloneJson(world.plugin);
  const initial = world.meta.initialSnapshot ? cloneJson(world.meta.initialSnapshot) : null;
  const fingerprint = world.meta.builtFingerprint;
  const checkpointSlot = cloneJson(world.lastEvolutionCheckpoint);
  applySubset(draft, checkpoint);
  draft.storyClock = clock;
  draft.evolutionLog = log;
  draft.plugin = plugin;
  draft.lastEvolutionCheckpoint = checkpointSlot;
  // Corrections are current user intent, not part of the old model input window.
  draft.userCorrections = cloneJson(world.userCorrections || []);
  if (initial) draft.meta.initialSnapshot = initial;
  if (fingerprint) draft.meta.builtFingerprint = fingerprint;
  return draft;
}

async function rerunBody(chatScope) {
  assertChatScope(chatScope);
  if (isGeneratingTip()) return { ok: false, evolved: false, reason: 'generating' };
  const world = loadWorld();
  if (!armed(world)) return { ok: false, evolved: false, reason: 'no-world' };
  if (!world.lastEvolutionCheckpoint) return { ok: false, evolved: false, reason: 'no-checkpoint' };
  const checkpoint = world.lastEvolutionCheckpoint;
  const draft = restoredDraft(world, checkpoint);
  const chat = readChat();
  const { mode, customTag } = modeOf();
  const tip = currentTipCursor(chat, mode, customTag);
  const id = makeEvolutionId(draft.storyClock.dayIndex, tip.floor);
  const digest = typeof checkpoint.evolutionInputDigest === 'string' ? checkpoint.evolutionInputDigest : null;
  const scan = checkpoint.worldbookScan && typeof checkpoint.worldbookScan === 'object'
    ? checkpoint.worldbookScan
    : null;
  const result = await runEvolutionOnce({
    chatScope,
    world: draft,
    purpose: 'rerun',
    inputDigest: digest,
    advanceCursor: false,
    ...(scan ? {
      cursor: scan.cursor,
      dayDelta: scan.dayDelta,
      scanWords: scan.scanWords,
    } : {}),
  });
  assertChatScope(chatScope);
  if (!result.ok) {
    await noteFailure(world, result, chatScope);
    return { ok: false, evolved: false, reason: result.reason || 'model', message: result.message };
  }
  await commitIfOk(pendingFrom(world, draft, tip, id, chatScope, world.processedInput), result);
  return { ok: true, evolved: true, reason: 'rerun', usage: result.usage || null };
}

export function runAutomaticGate() {
  return enqueueTurn(runAutomaticGateBody);
}

export function runImmediateEvolution() {
  return enqueueTurn(immediateBody);
}

export function rerunLastEvolution() {
  return enqueueTurn(rerunBody);
}
