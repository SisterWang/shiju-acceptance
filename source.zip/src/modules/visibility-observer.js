import { captureChatScope, assertChatScope } from '../chatScope.js';
import { loadWorld, saveWorld } from '../store/index.js';
import { enqueueTurn } from './turn.js';
import { manualHidden, messageIdentity } from './visibility.js';

/** Called with physical floor IDs from ST's visibility-only DOM updates. Capture
 * the observation now; persist in the existing writer queue without evolving. */
export function observeHiddenFloors(chat, floors) {
  const scope=captureChatScope(), world=loadWorld();
  if(!world?.meta?.builtFingerprint || !world.processedInput?.rows) return Promise.resolve();
  const previous=new Map(world.processedInput.rows.map(r=>[r.floor,r]));
  const excluded=new Set((world.processedInput.excluded || []).map(r=>`${r.floor}:${r.identity}`));
  const observations=[];
  for(const floor of new Set(floors)) {
    const message=chat[floor];
    if(!manualHidden(message)) continue;
    const row=previous.get(floor), identity=messageIdentity(message);
    if(row && row.status !== 'pending') continue;
    if(!excluded.has(`${floor}:${identity}`)) observations.push({floor,identity});
  }
  if(!observations.length)return Promise.resolve();
  return enqueueTurn(async()=>{
    assertChatScope(scope);
    const latest=loadWorld();if(!latest?.processedInput)return;
    latest.processedInput.excluded ||= [];
    for(const row of observations) {
      if(!latest.processedInput.excluded.some(e=>e.floor===row.floor&&e.identity===row.identity)) latest.processedInput.excluded.push(row);
    }
    await saveWorld(latest,scope);
  },{scope});
}
