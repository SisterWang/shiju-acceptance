import { physicalMessage, manualHidden, memoryHidden, messageIdentity, summaryNodes } from './visibility.js';
import { loadSettings } from '../store/index.js';
import { fingerprintOfMessage, resolveTimeSourceMode } from './timetag/read.js';

function hash(text) {
  let a = 2166136261;
  for (let i = 0; i < text.length; i++) a = Math.imul(a ^ text.charCodeAt(i), 16777619);
  return `${text.length}:${a >>> 0}`;
}
function rows(chat) {
  return (chat || []).flatMap((message, floor) => physicalMessage(message)
    ? [{ floor, identity: messageIdentity(message), swipeId: message.swipe_id ?? 0, text: message.mes, hash: hash(message.mes) }] : []);
}
export function captureInputBoundary(chat, through = Infinity, previous = null, accepted = []) {
  const list = rows(chat).filter((row) => row.floor <= through);
  const settings = loadSettings();
  const mode = resolveTimeSourceMode(settings), customTag = settings.timeSource?.customTag || '';
  const prior = new Map((previous?.rows || []).map(r => [r.floor, r]));
  const excluded = new Map((previous?.excluded || []).map(r => [r.floor,r.identity]));
  const included = new Set(accepted);
  return {
    version: 2, mode, customTag, excluded: previous?.excluded || [],
    rows: list.map(({ text, ...row }) => {
      const old = prior.get(row.floor);
      const already = old?.identity === row.identity && old.status === 'processed';
      const omit = manualHidden(chat[row.floor]) || excluded.get(row.floor) === row.identity;
      const pending = previous && memoryHidden(chat[row.floor]) && !included.has(row.floor);
      return {...row, status:already ? 'processed' : omit ? 'excluded' : pending ? 'pending' : 'processed',
        timeFingerprint:already && excluded.get(row.floor) === row.identity ? old.timeFingerprint : fingerprintOfMessage(chat[row.floor],mode,customTag)};
    }),
    tipText: list.at(-1)?.text ?? '',
  };
}

/** Old ledgers recover their last valid anchor; otherwise establish a safe baseline. */
export function ensureInputBoundary(world, chat, mode, customTag) {
  if (world.processedInput?.version === 2) return false;
  if (Array.isArray(world.processedInput?.rows)) {
    const old = world.processedInput;
    const valid = old.rows.every(r => chat[r.floor] && (chat[r.floor].swipe_id ?? 0) === r.swipeId && hash(chat[r.floor].mes) === r.hash);
    const through = valid ? (old.rows.at(-1)?.floor ?? -1) : Infinity;
    world.processedInput = captureInputBoundary(chat, through);
    // Existing hidden floors form a baseline; never replay them on upgrade.
    for (const r of world.processedInput.rows) if (r.status === 'pending') r.status = 'processed';
    world.meta.inputHint = valid ? '' : 'baseline-established';
    return true;
  }
  const anchors = [...(world.evolutionLog || [])].reverse();
  if (world.meta.initialSnapshot) anchors.push(world.meta.initialSnapshot);
  const anchor = anchors.find((entry) => Number.isInteger(entry.tipFloor)
    && entry.tipFloor >= -1 && entry.tipFloor < chat.length
    && (entry.tipFloor < 0 || ((chat[entry.tipFloor]?.swipe_id ?? 0) === (entry.tipSwipeId ?? 0)
      && (entry.tipTimeFingerprint == null || fingerprintOfMessage(chat[entry.tipFloor], mode, customTag) === entry.tipTimeFingerprint))));
  world.processedInput = captureInputBoundary(chat, anchor ? anchor.tipFloor : Infinity);
  world.meta.inputHint = anchor ? '' : 'baseline-established';
  return true;
}

export function readIncrement(world, chat, baibai) {
  const current = rows(chat), boundary = world.processedInput || {};
  const previous = boundary.rows || [];
  boundary.excluded ||= [];
  const changes = [], pendingMemory = [];
  const exclusions = new Map(boundary.excluded.map(e => [e.floor,e.identity]));
  const excluded = r => exclusions.get(r.floor) === r.identity;
  const include = (now, text = now.text) => {
    if (excluded(now)) return;
    if (manualHidden(chat[now.floor])) {
      boundary.excluded.push({ floor: now.floor, identity: now.identity });
      exclusions.set(now.floor,now.identity);
      return;
    }
    if (memoryHidden(chat[now.floor])) { pendingMemory.push(now); return; }
    if (text.trim()) changes.push({ ...now, text });
  };
  for (let i = 0; i < previous.length; i++) {
    const before = previous[i], now = current[i];
    if (!now || before.floor !== now.floor || before.swipeId !== now.swipeId
      || (before.identity != null && before.identity !== now.identity)) return { changed: true, items: [] };
    if (before.hash !== now.hash) {
      const oldText = boundary.tipText;
      if (i !== previous.length - 1 || typeof oldText !== 'string' || !now.text.startsWith(oldText)) return { changed: true, items: [] };
      if (before.status !== 'excluded') include(now, now.text.slice(oldText.length));
    } else if (before.status === 'pending') include(now);
  }
  current.slice(previous.length).forEach(r => include(r));
  // Only wholly unconsumed, non-excluded ranges may become NEW input. Mixed
  // summaries remain background; they cannot smuggle excluded prose back in.
  const pending = new Set(pendingMemory.map(r => r.floor));
  const accepted = new Set();
  for (const node of [...(baibai?.floorMemories || []), ...summaryNodes(baibai)]) {
    if (!Number.isInteger(node.floorStart) || !Number.isInteger(node.floorEnd) || !node.text) continue;
    const covered = current.filter(r => r.floor >= node.floorStart && r.floor <= node.floorEnd);
    if (!covered.length || covered.some(r => !pending.has(r.floor) || accepted.has(r.floor) || excluded(r))) continue;
    covered.forEach(r => accepted.add(r.floor));
    changes.push({ floor: node.floorEnd, swipeId: chat[node.floorEnd]?.swipe_id ?? 0,
      text: `柏宝书摘要（楼${node.floorStart}–${node.floorEnd}）：${node.text}` });
  }
  return { changed: false, items: changes, accepted: [...accepted], text: changes.map(r => `楼${r.floor}:${r.text}`).join('\n') };
}

export function pendingCorrections(world) {
  return (world.userCorrections || []).filter((item) => !item.consumed);
}
export function correctionText(world) {
  return pendingCorrections(world).map((item) => `${item.kind}:${item.id}\n标题:${item.title}\n用户修正:${item.body}`).join('\n\n');
}
