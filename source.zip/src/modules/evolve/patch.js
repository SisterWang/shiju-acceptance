import { applyKnowledgeEvidence, synchronizeKnowledge, isSecret } from '../events.js';
const PHASES = new Set(['萌芽', '发展', '高潮', '消退', '稳定']);
const KINDS = new Set(['macro', 'news', 'secret']);
const STATUSES = new Set(['active', 'dormant', 'resolved']);

export function makeId(prefix, name, index) {
  let hash = 2166136261;
  const text = `${prefix}:${name}:${index}`;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `${prefix}-${(hash >>> 0).toString(36)}`;
}

export function makeEvolutionId(dayIndex, floor) {
  const stamp = Date.now().toString(36);
  const noise = Math.floor(Math.random() * 46656).toString(36);
  return `evo-${dayIndex}-${floor}-${stamp}-${noise}`;
}

function clean(value, max) {
  return String(value || '').trim().slice(0, max);
}

function normalizeEntity(raw, kind, index, day, evidenceFallback) {
  if (!raw || typeof raw !== 'object') return null;
  const name = clean(raw.name || raw.title, 40);
  if (!name) return null;
  const secret = Boolean(raw.secret);
  const entity = {
    id: typeof raw.id === 'string' && raw.id.trim() ? raw.id.trim() : makeId(kind, name, index),
    name,
    summary: clean(raw.summary || raw.body, 400),
    status: STATUSES.has(raw.status) ? raw.status : 'active',
    secret,
    revealed: secret ? false : Boolean(raw.revealed),
    knownMarked: false,
    updatedAtDay: day,
    evidence: clean(raw.evidence, 80) || evidenceFallback,
  };
  if (typeof raw.regionRef === 'string' && raw.regionRef.trim()) {
    entity.regionRef = clean(raw.regionRef, 40);
  }
  return entity;
}

/** Match a real id, name, title, or fact text. Missing fields must not collapse the list. */
function sameIdentity(item, entity) {
  if (item?.id && entity?.id && item.id === entity.id) return true;
  if (item?.name && entity?.name && item.name === entity.name) return true;
  if (item?.title && entity?.title && item.title === entity.title) return true;
  if (item?.text && entity?.text && item.text === entity.text) return true;
  return false;
}

function identityIndex(list, entity) {
  const byId = entity?.id ? list.findIndex((item) => item.id === entity.id) : -1;
  return byId >= 0 ? byId : list.findIndex((item) => sameIdentity(item, entity));
}

function mergeList(current, incoming, map) {
  const next = Array.isArray(current) ? current.map((item) => ({ ...item })) : [];
  if (!Array.isArray(incoming)) return next;
  for (const raw of incoming) {
    const entity = map(raw);
    if (!entity) continue;
    const index = identityIndex(next, entity);
    if (index < 0) {
      next.push(entity);
      continue;
    }
    const prev = next[index];
    const merged = { ...prev, ...entity, id: prev.id };
    if (prev.revealed) merged.revealed = true;
    if (prev.knownMarked) merged.knownMarked = true;
    if (merged.secret && !prev.revealed) merged.revealed = false;
    next[index] = merged;
  }
  return next;
}

function eventKind(raw) {
  return KINDS.has(raw?.kind) ? raw.kind : 'macro';
}

function normalizeEvent(raw, index, day) {
  if (!raw || typeof raw !== 'object') return null;
  const title = clean(raw.title || raw.name, 40);
  if (!title) return null;
  const kind = eventKind(raw);
  const event = {
    id: typeof raw.id === 'string' && raw.id.trim() ? raw.id.trim() : makeId('event', title, index),
    kind,
    phase: PHASES.has(raw.phase) ? raw.phase : '萌芽',
    title,
    body: clean(raw.body || raw.summary, 500),
    revealed: kind === 'secret' ? false : Boolean(raw.revealed),
    knownMarked: false,
    relatedRefs: Array.isArray(raw.relatedRefs) ? raw.relatedRefs.map((item) => clean(item, 40)).filter(Boolean).slice(0, 8) : [],
    farAway: kind === 'news',
    updatedAtDay: day,
  };
  event.lifecycle = raw.lifecycle === 'archived' ? 'archived' : 'active';
  if (raw.outcome) event.outcome = clean(raw.outcome, 500);
  if (raw.mergedInto) event.mergedInto = clean(raw.mergedInto, 100);
  if (event.lifecycle === 'archived' && !event.outcome) event.lifecycle = 'active';
  for (const key of ['autoKnown', 'knowledgeOverride', 'knowledgeEvidence', 'viewMode']) {
    if (key in raw) event[key] = raw[key];
  }
  if (kind !== 'secret' && raw.farAway === true) event.farAway = true;
  if (typeof raw.playerRipple === 'string' && raw.playerRipple.trim()) {
    event.playerRipple = clean(raw.playerRipple, 200);
  }
  return event;
}

function normalizeFact(raw, index) {
  if (!raw || typeof raw !== 'object') return null;
  const text = clean(raw.text || raw.body || raw.summary, 400);
  if (!text) return null;
  return {
    id: typeof raw.id === 'string' && raw.id.trim() ? raw.id.trim() : makeId('fact', text, index),
    text,
    evidence: clean(raw.evidence, 80) || '推演',
  };
}

function normalizeChange(raw, index, evolutionId, day) {
  if (!raw || typeof raw !== 'object') return null;
  const title = clean(raw.title || raw.name, 40);
  if (!title) return null;
  const kind = eventKind(raw);
  const change = {
    id: typeof raw.id === 'string' && raw.id.trim() ? raw.id.trim() : makeId('change', title, index),
    kind,
    title,
    body: clean(raw.body || raw.summary, 500),
    revealed: kind === 'secret' ? false : Boolean(raw.revealed),
    updatedAtDay: day,
  };
  if (kind === 'news') change.farAway = true;
  if (typeof raw.linkedEventId === 'string' && raw.linkedEventId) change.linkedEventId = raw.linkedEventId;
  if (evolutionId) change.producedByEvolutionId = evolutionId;
  return change;
}

/**
 * Merge a structured model patch into a world clone.
 * Today-changes replace the list. Entities and events merge by id or name.
 * Secrets produced here stay unrevealed.
 */
export function applyEvolutionPatch(world, patch, ctx = {}) {
  const day = Number.isFinite(ctx.dayIndex) ? ctx.dayIndex : (world.storyClock?.dayIndex || 0);
  const evidence = ctx.evidence || '推演';
  const source = patch && typeof patch === 'object' ? patch : {};
  let entityIndex = 0;
  const mapEntity = (kind) => (raw) => normalizeEntity(raw, kind, entityIndex++, day, evidence);
  world.regions = mergeList(world.regions, source.regions, mapEntity('region'));
  world.orgs = mergeList(world.orgs, source.orgs, mapEntity('org'));
  world.factions = mergeList(world.factions, source.factions, mapEntity('faction'));
  if (Array.isArray(source.events)) {
    let eventIndex = 0;
    world.events = mergeList(world.events, source.events, (raw) => {
      const previous = world.events[identityIndex(world.events, raw)];
      const input = { ...previous, ...raw };
      if (previous && isSecret(previous)) input.kind = 'secret';
      const next = normalizeEvent(input, eventIndex++, day);
      if (next) {
        // Archival changes lifecycle, not the original event's full text.
        if (previous && next.lifecycle === 'archived') {
          next.body = previous.body;
          next.title = previous.title;
          next.relatedRefs = [...new Set([...(previous.relatedRefs || []), ...next.relatedRefs])];
        }
        for (const key of ['autoKnown', 'knowledgeOverride', 'knowledgeEvidence', 'viewMode']) {
          if (previous && key in previous) next[key] = previous[key];
          else delete next[key];
        }
      }
      return next;
    });
  }
  if (Array.isArray(source.facts)) {
    let factIndex = 0;
    world.facts = mergeList(world.facts, source.facts, (raw) => normalizeFact(raw, factIndex++));
  }
  if (Array.isArray(source.todayChanges)) {
    const previousChanges = world.todayChanges || [];
    world.todayChanges = source.todayChanges
      .map((raw, index) => {
        const next = normalizeChange(raw, index, ctx.evolutionId, day);
        const prev = previousChanges[identityIndex(previousChanges, next)];
        if (next && isSecret(prev)) next.kind = 'secret';
        if (next && prev) for (const key of ['revealed', 'knownMarked', 'autoKnown', 'knowledgeOverride', 'knowledgeEvidence', 'viewMode']) {
          if (key in prev) next[key] = prev[key];
        }
        return next;
      })
      .filter(Boolean);
  }
  if (typeof source.locationGuess === 'string' && source.locationGuess.trim()) {
    world.protagonistFocus = { locationGuess: clean(source.locationGuess, 80) };
  }
  if (typeof source.note === 'string' && source.note.trim()) {
    const timeline = Array.isArray(world.timeline) ? world.timeline.slice() : [];
    timeline.push({ dayIndex: day, text: clean(source.note, 200) });
    world.timeline = timeline.slice(-20);
  }
  for (const event of world.events || []) {
    if (event.lifecycle !== 'archived') continue;
    if (event.mergedInto && !world.events.some((target) => target.id === event.mergedInto && target.id !== event.id && target.lifecycle !== 'archived')) {
      event.lifecycle = 'active';
      delete event.mergedInto;
      continue;
    }
    if (event.archivedAtDay == null) event.archivedAtDay = day;
    const id = `outcome-${event.id}`;
    const fact = { id, text: event.outcome, evidence: '事件归档', sourceEventId: event.id };
    const index = world.facts.findIndex((item) => item.id === id);
    if (index < 0) world.facts.push(fact);
    else world.facts[index] = fact;
  }
  applyKnowledgeEvidence(world, source.knowledge, ctx.evidenceText);
  synchronizeKnowledge(world);
  return world;
}

export function countEntities(world) {
  return (world.regions?.length || 0) + (world.orgs?.length || 0) + (world.factions?.length || 0);
}
