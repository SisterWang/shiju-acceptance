/** Validate required content before touching a draft. Existing records may be patched by ID. */
export function validateWorldPatch(patch, world = {}, category) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('响应必须是 JSON 对象');
  if (category && Object.keys(patch).some(key => key !== category && key !== 'note')) throw new Error('分类补全返回了其他分类，未采用');
  for (const key of ['regions','orgs','factions','events','todayChanges']) {
    if (!(key in patch)) continue;
    if (!Array.isArray(patch[key])) throw new Error(`${key} 必须是数组`);
    const ids=new Set(), titles=new Set();
    for (const item of patch[key]) {
      if (!item || typeof item !== 'object' || Array.isArray(item)) throw new Error(`${key} 包含无效条目`);
      const entity = ['regions','orgs','factions'].includes(key);
      const title = entity ? 'name' : 'title', body = entity ? 'summary' : 'body';
      if((item.id && ids.has(item.id)) || (item[title] && titles.has(item[title]))) throw new Error(`${key} 返回重复 ID 或名称`);
      if(item.id)ids.add(item.id); if(item[title])titles.add(item[title]);
      if('aliases' in item && (!Array.isArray(item.aliases)||item.aliases.some(v=>typeof v!=='string'))) throw new Error('别名必须是文本数组');
      if('relatedRefs' in item && (!Array.isArray(item.relatedRefs)||item.relatedRefs.some(v=>typeof v!=='string'))) throw new Error('关联必须是 ID 数组');
      const old = (world[key] || []).find(row => (item.id && row.id === item.id) || (item[title] && row[title] === item[title]));
      for (const field of [title,body]) {
        const value = field in item ? item[field] : old?.[field];
        if (typeof value !== 'string' || !value.trim()) throw new Error(`${key} 的${field === title ? '名称／标题' : '概况／正文'}不能为空`);
      }
    }
  }
  if('facts' in patch && (!Array.isArray(patch.facts) || patch.facts.some(item=>!item || typeof item.text!=='string' || !item.text.trim()))) throw new Error('facts 必须包含非空 text');
  return patch;
}
