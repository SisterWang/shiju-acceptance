/** Complete input assembly. Selection is explicit; content is never clipped. */
import { WORLD_ENTRY_SOFT_CHARS } from '../worldbook/select.js';
export { WORLD_ENTRY_SOFT_CHARS };
// Kept for callers importing the old API; these are no longer limits.
export const INPUT_BUDGET = Object.freeze({p0:Infinity,p1:Infinity,p3:Infinity});
/** Rough estimate: CJK and other wide characters count as 1, the rest as 1/4. */
export function estimateTokens(text) {
  let wide = 0;
  let other = 0;
  for (const ch of String(text || '')) {
    const code = ch.codePointAt(0);
    if (code >= 0x3000) wide += 1;
    else other += 1;
  }
  return Math.ceil(wide + other / 4);
}


export function applyHardBudget(input = {}) {
  const p0 = [input.summary || '', input.bufferText || ''].filter(Boolean).join('\n');
  const p1 = input.p1 || '';
  const p2 = typeof input.worldbookText === 'string' ? input.worldbookText : (input.entries || []).map(e => `${e.title || e.comment || '未命名'}: ${e.content || ''}`).join('\n');
  const p3 = input.mvu == null ? '' : typeof input.mvu === 'string' ? input.mvu : JSON.stringify(input.mvu);
  const text = [['P0',p0],['P1',p1],['P2',p2],['P3',p3]].filter(([,v])=>v).map(([k,v])=>`${k}\n${v}`).join('\n');
  return {text,p0,p1,p2,p3,truncated:false,softWarn:false};
}
