/**
 * D18′ input budget.
 * P0 / P1 / P3 keep suggestion caps and may set a soft warning.
 * Worldbook text is passed through whole. There is no 12k total gate
 * and no mid-entry cut.
 */

import { WORLD_ENTRY_SOFT_CHARS } from '../worldbook/select.js';

export const INPUT_BUDGET = Object.freeze({
  p0: 3000,
  p1: 5000,
  p3: 2000,
});

export { WORLD_ENTRY_SOFT_CHARS };

function chars(text) {
  return Array.from(text || '').length;
}

function takeHead(text, count) {
  if (!text || count <= 0) return '';
  return Array.from(text).slice(0, count).join('');
}

function takeTail(text, count) {
  if (!text || count <= 0) return '';
  const all = Array.from(text);
  if (all.length <= count) return text;
  return all.slice(all.length - count).join('');
}

function fitP0(summary, bufferText, limit) {
  let summaryText = summary || '';
  let buffer = bufferText || '';
  let truncated = false;
  if (chars(buffer) > limit) {
    buffer = takeTail(buffer, limit);
    summaryText = '';
    truncated = true;
  } else if (chars(summaryText) + chars(buffer) > limit) {
    summaryText = takeHead(summaryText, limit - chars(buffer));
    truncated = true;
  }
  const text = [summaryText, buffer].filter(Boolean).join('\n');
  return { text: takeHead(text, limit), truncated };
}

function fitP1(text, limit) {
  const source = text || '';
  if (chars(source) <= limit) return { text: source, truncated: false };
  return { text: takeTail(source, limit), truncated: true };
}

function entriesText(entries) {
  return (Array.isArray(entries) ? entries : [])
    .map((entry) => {
      const title = String(entry?.title || entry?.comment || '未命名');
      const content = String(entry?.content || '');
      return `${title}: ${content}`;
    })
    .filter((line) => line !== '未命名: ')
    .join('\n');
}

function fitP3(value, limit) {
  if (value == null || value === '') return { text: '', truncated: false };
  if (typeof value === 'string') {
    if (chars(value) <= limit) return { text: value, truncated: false };
    return { text: takeHead(value, limit), truncated: true };
  }
  if (typeof value !== 'object') {
    const text = String(value);
    return chars(text) <= limit
      ? { text, truncated: false }
      : { text: takeHead(text, limit), truncated: true };
  }
  if (Array.isArray(value)) {
    const text = JSON.stringify(value);
    if (chars(text) <= limit) return { text, truncated: false };
    return { text: takeHead(text, limit), truncated: true };
  }
  const kept = {};
  let truncated = false;
  for (const key of Object.keys(value)) {
    const next = { ...kept, [key]: value[key] };
    if (chars(JSON.stringify(next)) > limit) {
      truncated = true;
      break;
    }
    kept[key] = value[key];
  }
  let text = JSON.stringify(kept);
  if (chars(text) > limit) {
    text = takeHead(text, limit);
    truncated = true;
  }
  if (chars(JSON.stringify(value)) > limit) truncated = true;
  return { text, truncated };
}

function assemble(parts) {
  const chunks = [];
  if (parts.p0) chunks.push(`P0\n${parts.p0}`);
  if (parts.p1) chunks.push(`P1\n${parts.p1}`);
  if (parts.p2) chunks.push(`P2\n${parts.p2}`);
  if (parts.p3) chunks.push(`P3\n${parts.p3}`);
  return chunks.join('\n');
}

/** Rough estimate: CJK and other wide characters count as 1, the rest as 1/4. */
export function estimateTokens(text) {
  let wide = 0;
  let other = 0;
  for (const ch of String(text || '')) {
    const code = ch.codePointAt(0);
    if (code >= 0x3000) wide += 1;
    else other += 1;
  }
  return Math.ceil(wide + other / 4);
}

/**
 * @param {{ summary?: string, bufferText?: string, p1?: string, worldbookText?: string, entries?: Array, worldbookOversized?: boolean, mvu?: unknown }} input
 * @returns {{ text: string, truncated: boolean, softWarn: boolean, p0: string, p1: string, p2: string, p3: string }}
 */
export function applyHardBudget(input, limits = INPUT_BUDGET) {
  const p0Fit = fitP0(input?.summary || '', input?.bufferText || '', limits.p0);
  const p1Fit = fitP1(input?.p1 || '', limits.p1);
  const p2Text = typeof input?.worldbookText === 'string'
    ? input.worldbookText
    : entriesText(input?.entries);
  const legacyOversized = typeof input?.worldbookText !== 'string'
    && (Array.isArray(input?.entries) ? input.entries : []).some((entry) => chars(entry?.content) > WORLD_ENTRY_SOFT_CHARS);
  const p3Fit = fitP3(input?.mvu, limits.p3);
  const parts = {
    p0: p0Fit.text,
    p1: p1Fit.text,
    p2: p2Text || '',
    p3: p3Fit.text,
  };
  const truncated = p0Fit.truncated || p1Fit.truncated || p3Fit.truncated;
  const softWarn = truncated || Boolean(input?.worldbookOversized) || legacyOversized;
  return {
    text: assemble(parts),
    truncated,
    softWarn,
    p0: parts.p0,
    p1: parts.p1,
    p2: parts.p2,
    p3: parts.p3,
  };
}
