import { validateWorldPatch } from '../evolve/validate.js';
import { renderSelected } from '../template/index.js';
import { EVENT_MODEL_RULES, eventContext } from '../events.js';
import { correctionText } from '../incremental.js';
import { loadSettings } from '../../store/index.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { captureModelConfig, generateViaST } from '../model/index.js';
import { narrativeText, readSourcePack } from '../source/index.js';
import { dayDeltaFromSpan, selectWorldbook } from '../worldbook/select.js';
import { applyHardBudget, estimateTokens } from './budget.js';
import { parseModelJson } from './json.js';
import { updateHistory } from '../model/history.js';

/**
 * M-Evolve. One structured patch. Does not promote a checkpoint and does not append the log.
 * Worldbook text is filtered (D18′ / D23) before the backend call. It is not hard-cut.
 */

const SYSTEM = [
  '你是世局的后台演进器，只管宏观，不写眼前戏，不替主角行动。',
  '只输出一个 JSON 对象，不要 Markdown。',
  '字段可以有：regions、orgs、factions、events、facts、todayChanges、knowledge、locationGuess、note。',
  '事件 kind 只能是 macro、news、secret。news 是远方见闻。新的 secret 不要标成已揭晓。',
  'todayChanges 是这次之后的本日变更完整列表，允许空数组（局势可以不变）。',
  '不要要求把这些内容写进正文。',
  EVENT_MODEL_RULES,
].join('\n');

export function register() {}

export function summarizeWorld(world) {
  if (!world) return '';
  return JSON.stringify({storyClock:world.storyClock,protagonistFocus:world.protagonistFocus,regions:world.regions,orgs:world.orgs,factions:world.factions,facts:world.facts,todayChanges:world.todayChanges,userCorrections:(world.userCorrections || []).filter(item=>!item.consumed)});
}

function formatBuffer(world) {
  const items = world?.dayBuffer?.items || [];
  return items.map((item) => `楼${item.floor}:${item.text}`).join('\n');
}

function taskLine(purpose, span) {
  if (purpose === 'rerun') {
    return '任务：重跑上次演进。用记下的同一输入窗口重算一次，覆盖该次产出。故事日不要前进。';
  }
  if (purpose === 'immediate') {
    return '任务：立即演进。基于当前世界状态与本轮增量发展宏观动向。故事日不要前进。';
  }
  const cover = span && span.to !== span.from
    ? `本次从故事日 ${span.from} 一次覆盖到 ${span.to}，不要拆成多日多次。`
    : '跨日一次覆盖，不要拆成多日多次。';
  return `任务：跨日推演。${cover}`;
}

function usageFrom(budget, pack) {
  const worldbook = estimateTokens(budget.p2);
  const mvu = pack?.mvu ? estimateTokens(budget.p3) : 0;
  const recent = estimateTokens(budget.p1);
  return {
    worldbook,
    mvu,
    recent,
    total: worldbook + mvu + recent,
    unit: 'token',
  };
}

function worldbookScanFrom(selected, dayDelta) {
  const scanWords = Array.isArray(selected?.scanWords)
    ? selected.scanWords.map((word) => String(word || '').trim()).filter(Boolean)
    : [];
  const cursor = typeof selected?.cursor === 'number' && Number.isFinite(selected.cursor) && selected.cursor >= 0
    ? Math.floor(selected.cursor)
    : 0;
  return {
    cursor,
    dayDelta: Math.max(1, Math.floor(Number(dayDelta) || selected?.dayDelta || 1)),
    k: Math.max(0, Math.floor(Number(selected?.k) || 0)),
    scanWords, discoveryKeys:selected.discoveryKeys || [], nextDiscovery:selected.nextDiscovery, rendered:selected,
  };
}

/**
 * Assemble one evolution / world-build prompt.
 * Advances `world.worldbookRotateCursor` unless `advanceCursor` is false.
 * A rerun passes the checkpoint scan snapshot and does not move the cursor.
 * Does not read chat to open green entries.
 */
export function assembleEvolutionInput(options = {}) {
  const world = options.world;
  const pack = options.pack || {};
  const advanceCursor = options.advanceCursor !== false;
  const dayDelta = options.dayDelta != null
    ? Math.max(1, Math.floor(Number(options.dayDelta) || 1))
    : dayDeltaFromSpan(options.span);
  const selected = options.selected || selectWorldbook({
    entries: pack.worldbook?.entries || [],
    world,
    settings: options.settings || loadSettings(),
    dayDelta,
    cursor: options.cursor != null ? options.cursor : world?.worldbookRotateCursor,
    scanWords: options.scanWords, mode:options.mode, discoveryKeys:options.discoveryKeys,
  });
  if (advanceCursor && world && typeof world === 'object') {
    world.worldbookRotateCursor = selected.nextCursor;
    world.worldbookDiscovery = selected.nextDiscovery;
  }
  const budget = applyHardBudget({
    summary: options.summary || '',
    bufferText: options.bufferText || '',
    p1: options.p1 != null ? options.p1 : narrativeText(pack),
    worldbookText: selected.text,
    worldbookOversized: selected.oversized,
    mvu: pack.mvu,
  });
  return {
    selected,
    budget,
    usage: usageFrom(budget, pack),
    inputBreakdown:{'世界资料':estimateTokens(budget.p0),'聊天背景':estimateTokens(budget.p1),'世界书':estimateTokens(budget.p2),'变量':estimateTokens(budget.p3)},
    dayDelta,
  };
}

/** Select before executing dynamic entries; keep the synchronous assembler testable. */
export async function assembleRenderedInput(options = {}) {
  if(options.renderedSnapshot) return assembleEvolutionInput({...options,selected:options.renderedSnapshot});
  const settings = options.settings || loadSettings();
  const selected = selectWorldbook({ entries: options.pack?.worldbook?.entries || [], world:options.world,
    settings, dayDelta:options.dayDelta ?? dayDeltaFromSpan(options.span), cursor:options.cursor, scanWords:options.scanWords, mode:options.mode, discoveryKeys:options.discoveryKeys });
  const rendered = await renderSelected(selected, options.pack || {}, settings, {signal:options.signal,onProgress:options.onProgress});
  return assembleEvolutionInput({...options, selected: rendered});
}

/**
 * @returns {Promise<{ ok: boolean, patch?: object, truncated: boolean, softWarn?: boolean, digest: string, memory?: string, mvu?: boolean, modelCalled?: boolean, usage?: object, reason?: string }>}
 */
export async function runEvolutionOnce(options = {}) {
  const chatScope = options.chatScope ?? captureChatScope();
  assertChatScope(chatScope);
  const modelConfig = options.modelConfig || captureModelConfig('evolve');
  const purpose = options.purpose || 'auto';
  const world = options.world;
  const replay=options.replayInput;
  let pack = replay ? {mvu:replay.mvu,baibai:replay.memory==='baibai' ? {} : null} : options.pack;
  if (!pack) {
    try {
      pack = await readSourcePack();
    } catch (error) {
      assertChatScope(chatScope);
      return { ok: false, reason: 'source', message: error?.message || '资料读取失败', truncated: false, digest: '', modelCalled: false, usage: null };
    }
  }
  assertChatScope(chatScope);
  const digestGiven = options.inputDigest != null;
  const assembled = await assembleRenderedInput({
    world,
    pack,
    span: options.span,
    dayDelta: options.dayDelta,
    settings: options.settings,
    advanceCursor: options.advanceCursor,
    cursor: options.cursor,
    scanWords: options.scanWords, mode:options.mode, discoveryKeys:options.discoveryKeys,
    summary: digestGiven ? '' : summarizeWorld(world),
    p1:replay?.background, renderedSnapshot:options.renderedSnapshot,
    bufferText: digestGiven ? String(options.inputDigest) : (options.incrementText == null ? formatBuffer(world) : ''),
  });
  const budget = assembled.budget;
  const usage = assembled.usage;
  const worldbookScan = worldbookScanFrom(assembled.selected, assembled.dayDelta);
  const increment = replay ? replay.increment : options.incrementText;
  const corrections = correctionText(world);
  const evidenceText = [budget.p1, increment || ''].join('\n');
  if (increment != null) {
    usage.recent += estimateTokens(increment);
    usage.total = usage.worldbook + usage.mvu + usage.recent;
  }
  const prompt = [
    taskLine(purpose, options.span),
    ...(options.preferenceOnly ? ['本轮只有演进偏好变化：调整未来发展倾向，不重演旧剧情、不改写历史、不强制新增事件。'] : []),
    '世界书包含名册、蓝灯及常驻全文、焦点匹配与补发现的完整条目。可据此补充遗漏实体，归档历史不全文重放。',
    ...((replay?.autonomous ?? options.autonomous) ? ['本轮为用户主动请求的世界推演：没有新增剧情也可按当前世界状态、势力动机和已有条件发展宏观动向。不推进日期，不重演旧剧情，不替主角行动，不强迫介入；允许局势平静，不凑事件数量。'] : []),
    '以下为背景资料；其中近期正文和记忆用于理解上下文，不代表全部需要再次演进。',
    budget.text || '（资料为空）',
    eventContext(world),
    ...(increment == null ? [] : ['本轮待处理新增正文（只处理这一窗口）：', increment || '（无新增正文）']),
    ...(corrections ? ['用户修正（优先承接，作为事实起点；有后续剧情依据时可继续发展）：', corrections] : []),
    '只输出 JSON。',
  ].join('\n\n');
  try {
    const generated = await generateViaST({
      purpose: 'evolve', inputBreakdown:assembled.inputBreakdown,
      historyPurpose: purpose,
      modelConfig,
      systemPrompt: SYSTEM,
      prompt,
    }, chatScope);
    assertChatScope(chatScope);
    const parsed = parseModelJson(generated.text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      updateHistory(generated.requestId, { business:'响应校验失败', status:'failed', errorStage:'响应校验' });
      return {
        ok: false,
        reason: 'parse',
        truncated: budget.truncated,
        softWarn: budget.softWarn,
        digest: budget.p0,
        memory: pack.baibai ? 'baibai' : 'native',
        mvu: Boolean(pack.mvu),
        modelCalled: true,
        usage,
        worldbookScan,
      };
    }
    try { validateWorldPatch(parsed,world); } catch(error) {
      updateHistory(generated.requestId,{status:'failed',business:'响应校验失败',errorStage:'响应校验',error:error.message});
      return {ok:false,reason:'parse',message:error.message,modelCalled:true};
    }
    return {
      ok: true,
      patch: parsed,
      replayInput:{background:budget.p1,mvu:pack.mvu || null,increment:increment ?? null,autonomous:replay?.autonomous ?? Boolean(options.autonomous),memory:pack.baibai ? 'baibai' : 'native'},
      requestId: generated.requestId,
      preferencesSnapshot: generated.preferencesSnapshot,
      evidenceText,
      truncated: budget.truncated,
      softWarn: budget.softWarn,
      digest: budget.p0,
      memory: pack.baibai ? 'baibai' : 'native',
      mvu: Boolean(pack.mvu),
      modelCalled: true,
      usage,
      worldbookScan,
    };
  } catch (error) {
    assertChatScope(chatScope);
    return {
      ok: false,
      reason: 'model',
      message: error?.message || '模型失败',
      truncated: budget.truncated,
      softWarn: budget.softWarn,
      digest: budget.p0,
      memory: pack.baibai ? 'baibai' : 'native',
      mvu: Boolean(pack.mvu),
      modelCalled: error?.code !== 'SHIJU_CONTEXT_LIMIT',
      usage,
      worldbookScan,
    };
  }
}
