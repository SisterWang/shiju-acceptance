import { renderSelected } from '../template/index.js';
import { EVENT_MODEL_RULES, eventContext } from '../events.js';
import { correctionText } from '../incremental.js';
import { loadSettings } from '../../store/index.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { captureModelConfig, generateViaST } from '../model/index.js';
import { narrativeText, readSourcePack } from '../source/index.js';
import { dayDeltaFromSpan, selectWorldbook } from '../worldbook/select.js';
import { applyHardBudget, estimateTokens } from './budget.js';
import { parseModelJson } from './json.js';

/**
 * M-Evolve. One structured patch. Does not promote a checkpoint and does not append the log.
 * Worldbook text is filtered (D18′ / D23) before the backend call. It is not hard-cut.
 */

const SYSTEM = [
  '你是世局的后台演进器，只管宏观，不写眼前戏，不替主角行动。',
  '只输出一个 JSON 对象，不要 Markdown。',
  '字段可以有：regions、orgs、factions、events、facts、todayChanges、locationGuess、note。',
  '事件 kind 只能是 macro、news、secret。news 是远方见闻。新的 secret 不要标成已揭晓。',
  'todayChanges 是这次之后的本日变更完整列表，允许空数组（局势可以不变）。',
  '不要要求把这些内容写进正文。',
  EVENT_MODEL_RULES,
].join('\n');

export function register() {}

function summarizeWorld(world) {
  if (!world) return '';
  const lines = [];
  const label = world.storyClock?.dateLabel || '未定';
  lines.push(`故事日:${label}#${world.storyClock?.dayIndex ?? 0}`);
  const guess = world.protagonistFocus?.locationGuess;
  if (guess) lines.push(`位置推断:${guess}`);
  for (const kind of ['regions', 'orgs', 'factions']) {
    for (const entity of world[kind] || []) {
      lines.push(`${kind}:${entity.name}:${entity.summary || ''}`);
    }
  }
  for (const fact of world.facts || []) {
    lines.push(`事实:${fact.text || ''}`);
  }
  return lines.join('\n');
}

function formatBuffer(world) {
  const items = world?.dayBuffer?.items || [];
  return items.map((item) => `楼${item.floor}:${item.text}`).join('\n');
}

function taskLine(purpose, span) {
  if (purpose === 'rerun') {
    return '任务：重跑上次演进。用记下的同一输入窗口重算一次，覆盖该次产出。故事日不要前进。';
  }
  if (purpose === 'immediate') {
    return '任务：立即演进。只根据自上次以来的增量写出新变更。故事日不要前进。';
  }
  const cover = span && span.to !== span.from
    ? `本次从故事日 ${span.from} 一次覆盖到 ${span.to}，不要拆成多日多次。`
    : '跨日一次覆盖，不要拆成多日多次。';
  return `任务：跨日推演。${cover}`;
}

function usageFrom(budget, pack) {
  const worldbook = estimateTokens(budget.p2);
  const mvu = pack?.mvu ? estimateTokens(budget.p3) : 0;
  const recent = estimateTokens(budget.p1);
  return {
    worldbook,
    mvu,
    recent,
    total: worldbook + mvu + recent,
    unit: 'token',
  };
}

function worldbookScanFrom(selected, dayDelta) {
  const scanWords = Array.isArray(selected?.scanWords)
    ? selected.scanWords.map((word) => String(word || '').trim()).filter(Boolean)
    : [];
  const cursor = typeof selected?.cursor === 'number' && Number.isFinite(selected.cursor) && selected.cursor >= 0
    ? Math.floor(selected.cursor)
    : 0;
  return {
    cursor,
    dayDelta: Math.max(1, Math.floor(Number(dayDelta) || selected?.dayDelta || 1)),
    k: Math.max(0, Math.floor(Number(selected?.k) || 0)),
    scanWords,
  };
}

/**
 * Assemble one evolution / world-build prompt.
 * Advances `world.worldbookRotateCursor` unless `advanceCursor` is false.
 * A rerun passes the checkpoint scan snapshot and does not move the cursor.
 * Does not read chat to open green entries.
 */
export function assembleEvolutionInput(options = {}) {
  const world = options.world;
  const pack = options.pack || {};
  const advanceCursor = options.advanceCursor !== false;
  const dayDelta = options.dayDelta != null
    ? Math.max(1, Math.floor(Number(options.dayDelta) || 1))
    : dayDeltaFromSpan(options.span);
  const selected = options.selected || selectWorldbook({
    entries: pack.worldbook?.entries || [],
    world,
    settings: options.settings || loadSettings(),
    dayDelta,
    cursor: options.cursor != null ? options.cursor : world?.worldbookRotateCursor,
    scanWords: options.scanWords,
  });
  if (advanceCursor && world && typeof world === 'object') {
    world.worldbookRotateCursor = selected.nextCursor;
  }
  const budget = applyHardBudget({
    summary: options.summary || '',
    bufferText: options.bufferText || '',
    p1: options.p1 != null ? options.p1 : narrativeText(pack),
    worldbookText: selected.text,
    worldbookOversized: selected.oversized,
    mvu: pack.mvu,
  });
  return {
    selected,
    budget,
    usage: usageFrom(budget, pack),
    dayDelta,
  };
}

/** Select before executing dynamic entries; keep the synchronous assembler testable. */
export async function assembleRenderedInput(options = {}) {
  const settings = options.settings || loadSettings();
  const selected = selectWorldbook({ entries: options.pack?.worldbook?.entries || [], world:options.world,
    settings, dayDelta:options.dayDelta ?? dayDeltaFromSpan(options.span), cursor:options.cursor, scanWords:options.scanWords });
  const rendered = await renderSelected(selected, options.pack || {}, settings);
  return assembleEvolutionInput({...options, selected: rendered});
}

/**
 * @returns {Promise<{ ok: boolean, patch?: object, truncated: boolean, softWarn?: boolean, digest: string, memory?: string, mvu?: boolean, modelCalled?: boolean, usage?: object, reason?: string }>}
 */
export async function runEvolutionOnce(options = {}) {
  const chatScope = options.chatScope ?? captureChatScope();
  assertChatScope(chatScope);
  const modelConfig = options.modelConfig || captureModelConfig('evolve');
  const purpose = options.purpose || 'auto';
  const world = options.world;
  let pack = options.pack;
  if (!pack) {
    try {
      pack = await readSourcePack();
    } catch (error) {
      assertChatScope(chatScope);
      return { ok: false, reason: 'source', message: error?.message || '资料读取失败', truncated: false, digest: '', modelCalled: false, usage: null };
    }
  }
  assertChatScope(chatScope);
  const digestGiven = options.inputDigest != null;
  const assembled = await assembleRenderedInput({
    world,
    pack,
    span: options.span,
    dayDelta: options.dayDelta,
    settings: options.settings,
    advanceCursor: options.advanceCursor,
    cursor: options.cursor,
    scanWords: options.scanWords,
    summary: digestGiven ? '' : summarizeWorld(world),
    bufferText: digestGiven ? String(options.inputDigest) : (options.incrementText == null ? formatBuffer(world) : ''),
  });
  const budget = assembled.budget;
  const usage = assembled.usage;
  const worldbookScan = worldbookScanFrom(assembled.selected, assembled.dayDelta);
  const increment = options.incrementText;
  const corrections = correctionText(world);
  const evidenceText = [budget.p1, increment || ''].join('\n');
  if (increment != null) {
    usage.recent += estimateTokens(increment);
    usage.total = usage.worldbook + usage.mvu + usage.recent;
  }
  const prompt = [
    taskLine(purpose, options.span),
    ...(options.preferenceOnly ? ['本轮只有演进偏好变化：调整未来发展倾向，不重演旧剧情、不改写历史、不强制新增事件。'] : []),
    '世界书只带名册，以及蓝灯全文、书级常驻全文、本轮焦点扫词命中的全文。这些正文是整条，没有从中间砍掉。',
    '以下为背景资料；其中近期正文和记忆用于理解上下文，不代表全部需要再次演进。',
    budget.text || '（资料为空）',
    eventContext(world),
    ...(increment == null ? [] : ['本轮待处理新增正文（只处理这一窗口）：', increment || '（无新增正文）']),
    ...(corrections ? ['用户修正（优先承接，作为事实起点；有后续剧情依据时可继续发展）：', corrections] : []),
    '只输出 JSON。',
  ].join('\n\n');
  try {
    const generated = await generateViaST({
      purpose: 'evolve',
      modelConfig,
      systemPrompt: SYSTEM,
      prompt,
    }, chatScope);
    assertChatScope(chatScope);
    const parsed = parseModelJson(generated.text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {
        ok: false,
        reason: 'parse',
        truncated: budget.truncated,
        softWarn: budget.softWarn,
        digest: budget.p0,
        memory: pack.baibai ? 'baibai' : 'native',
        mvu: Boolean(pack.mvu),
        modelCalled: true,
        usage,
        worldbookScan,
      };
    }
    return {
      ok: true,
      patch: parsed,
      preferencesSnapshot: generated.preferencesSnapshot,
      evidenceText,
      truncated: budget.truncated,
      softWarn: budget.softWarn,
      digest: budget.p0,
      memory: pack.baibai ? 'baibai' : 'native',
      mvu: Boolean(pack.mvu),
      modelCalled: true,
      usage,
      worldbookScan,
    };
  } catch (error) {
    assertChatScope(chatScope);
    return {
      ok: false,
      reason: 'model',
      message: error?.message || '模型失败',
      truncated: budget.truncated,
      softWarn: budget.softWarn,
      digest: budget.p0,
      memory: pack.baibai ? 'baibai' : 'native',
      mvu: Boolean(pack.mvu),
      modelCalled: true,
      usage,
      worldbookScan,
    };
  }
}
