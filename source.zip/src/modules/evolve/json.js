/** Pull one JSON object out of a model reply. Markdown fences are allowed. */
export function parseModelJson(text) {
  const source = String(text || '').trim();
  if (!source) return null;
  const fenced = source.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = (fenced ? fenced[1] : source).trim();
  try {
    return JSON.parse(body);
  } catch {
    // fall through to the outermost braces
  }
  const start = body.indexOf('{');
  const end = body.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(body.slice(start, end + 1));
  } catch {
    return null;
  }
}
