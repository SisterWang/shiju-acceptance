import { isSecret, isKnown, isFactVisible, synchronizeKnowledge } from '../events.js';
import { shijuError } from '../../errors.js';
import { assertChatScope, captureChatScope } from '../../chatScope.js';
import { loadWorld, saveWorld } from '../../store/index.js';
import { refreshInject } from '../inject/index.js';
import { enqueueEdit, assertEditable } from '../turn.js';
import { generateViaST } from '../model/index.js';

/**
 * M-Intervene. Hard-edit one event or one today-change.
 * Preview calls generateViaST and does not write. Apply and manual save do.
 * This module does not evolve, does not commit, and does not append the evolution log.
 */

/** Shown before previewAiCorrection. Apply itself spends nothing. */
export const AI_CORRECTION_CONFIRM = '消耗 1 次调用。只改这一条，不是重跑上次演进，也不是立即演进。';

const TITLE_MAX = 40;
const BODY_MAX = 500;
const LIST_KEY = {
  event: 'events',
  todayChange: 'todayChanges',
};

const CORRECT_SYSTEM = [
  '你是世局的单条修正。只改用户给出的这一条事实正文。',
  '不要重跑整次演进，不要新增条目，不要推进故事日，不要写眼前戏。',
  '只输出修订后的正文，不要 JSON，不要标题，不要解释。',
].join('\n');

export function register() {}

function clip(value, max) {
  return String(value ?? '').trim().slice(0, max);
}

function refuse(message) {
  throw shijuError('SHIJU_INTERVENE_REFUSED', message);
}

function isUnrevealedSecret(item) {
  if (!item || typeof item !== 'object') return false;
  return isSecret(item) && !isFactVisible(item);
}

function loadEditable(kind, id, allowSecret = false) {
  const key = LIST_KEY[kind];
  if (!key) refuse('世局：只能修正事件或今日变更');
  if (typeof id !== 'string' || !id.trim()) refuse('世局：缺少条目 id');
  const world = loadWorld();
  if (!world) refuse('世局：还没有世界账');
  const list = Array.isArray(world[key]) ? world[key] : [];
  const index = list.findIndex((item) => item && item.id === id);
  if (index < 0) refuse('世局：找不到这一条');
  const item = list[index];
  if (!allowSecret && isUnrevealedSecret(item)) refuse('世局：隐秘未揭晓，不能修正这一条');
  return { world, key, kind, index, item };
}

function noteUserEdit(world) {
  const day = Number.isFinite(world.storyClock?.dayIndex) ? world.storyClock.dayIndex : 0;
  const timeline = Array.isArray(world.timeline) ? world.timeline.slice() : [];
  timeline.push({ dayIndex: day, text: '用户修正' });
  world.timeline = timeline.slice(-20);
}

async function storeItem(found, next, scope) {
  next.evidence = '用户修正';
  const list = found.world[found.key].slice();
  list[found.index] = next;
  found.world[found.key] = list;
  found.world.userCorrections = (found.world.userCorrections || []).filter((item) => item.kind !== found.kind || item.id !== next.id);
  found.world.userCorrections.push({ kind: found.kind, id: next.id, title: next.title, body: next.body, consumed: false });
  noteUserEdit(found.world);
  const saved = await saveWorld(found.world, scope);
  try {
    refreshInject();
  } catch (error) {
    console.error('[shiju] 注入刷新失败', error);
  }
  const written = (saved[found.key] || []).find((entry) => entry && entry.id === next.id) || next;
  return {
    ok: true,
    kind: found.kind,
    id: next.id,
    title: typeof written.title === 'string' ? written.title : '',
    body: typeof written.body === 'string' ? written.body : '',
    modelCalls: 0,
  };
}

/**
 * Hard-write one event or todayChange. patch accepts title and body only.
 * Unrevealed secrets are refused and the ledger is left untouched.
 */
async function saveManualBody(request, scope) {
  const found = loadEditable(request.kind, request.id);
  const patch = request.patch;
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
    refuse('世局：没有要保存的标题或正文');
  }
  const hasTitle = Object.prototype.hasOwnProperty.call(patch, 'title');
  const hasBody = Object.prototype.hasOwnProperty.call(patch, 'body');
  if (!hasTitle && !hasBody) refuse('世局：没有要保存的标题或正文');
  const title = hasTitle ? clip(patch.title, TITLE_MAX) : null;
  const body = hasBody ? clip(patch.body, BODY_MAX) : null;
  if (hasTitle && !title) refuse('世局：标题不能是空的');
  const next = { ...found.item };
  if (title != null) next.title = title;
  if (body != null) next.body = body;
  return storeItem(found, next, scope);
}

function correctionPrompt(kind, item, instruction) {
  const label = kind === 'todayChange' ? '今日变更' : '事件';
  const lines = [
    '只修订下面这一条的正文。',
    `种类:${label}`,
    `标题:${item.title || ''}`,
    `正文:${item.body || ''}`,
  ];
  if (instruction) lines.push(`短指令:${instruction}`);
  lines.push('只输出修订后的正文。');
  return lines.join('\n');
}

function previewFromModel(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';
  const fenced = text.match(/^```(?:json|text)?\s*([\s\S]*?)\s*```$/i);
  const body = (fenced ? fenced[1] : text).trim();
  if (body.startsWith('{') && body.endsWith('}')) {
    try {
      const parsed = JSON.parse(body);
      const picked = parsed && (parsed.body || parsed.text || parsed.previewText);
      if (typeof picked === 'string' && picked.trim()) return clip(picked, BODY_MAX);
      return '';
    } catch {
      // braces around ordinary prose
    }
  }
  return clip(body, BODY_MAX);
}

/**
 * One lightweight correction call. Does not write the ledger.
 * @returns {Promise<{ previewText: string, modelCalls: 1, confirm: string }>}
 */
export async function previewAiCorrection(request = {}) {
  const chatScope = request.chatScope ?? captureChatScope();
  assertEditable(chatScope);
  const found = loadEditable(request.kind, request.id);
  const before = JSON.stringify(loadWorld());
  const instruction = typeof request.instruction === 'string' ? clip(request.instruction, 200) : '';
  const generated = await generateViaST({
    purpose: 'correct',
    systemPrompt: CORRECT_SYSTEM,
    prompt: correctionPrompt(request.kind, found.item, instruction),
  }, chatScope);
  assertChatScope(chatScope);
  const previewText = previewFromModel(generated.text);
  if (JSON.stringify(loadWorld()) !== before) {
    // Other operations may legitimately update the ledger while the model runs.
    // Reject this stale draft without undoing their writes.
    refuse('世局：生成修订稿期间世界账已更新，请重新生成');
  }
  if (!previewText) refuse('世局：修订稿是空的');
  return {
    ok: true,
    kind: found.kind,
    id: found.item.id,
    title: typeof found.item.title === 'string' ? found.item.title : '',
    body: typeof found.item.body === 'string' ? found.item.body : '',
    previewText,
    modelCalls: 1,
    confirm: AI_CORRECTION_CONFIRM,
  };
}

/** Write an adopted revision, including one the user edited in the preview. Zero model calls. */
async function applyAiBody(request, scope) {
  const found = loadEditable(request.kind, request.id);
  const body = clip(request.text, BODY_MAX);
  if (!body) refuse('世局：修订稿是空的');
  const next = { ...found.item, body };
  return storeItem(found, next, scope);
}

export function saveFactManual(request = {}) {
  return enqueueEdit((scope) => saveManualBody(request, scope), request.chatScope);
}
export function applyAiCorrection(request = {}) {
  return enqueueEdit((scope) => applyAiBody(request, scope), request.chatScope);
}

/** Viewing never grants protagonist knowledge. Explicit overrides survive model patches. */
export function setFactVisibility(request = {}) {
  return enqueueEdit(async (scope) => {
    const found = loadEditable(request.kind, request.id, true);
    let item = found.item;
    if (item.linkedEventId) item = found.world.events.find((event) => event.id === item.linkedEventId) || item;
    if (!isSecret(item)) refuse('这一条不是隐秘');
    if (request.action === 'view' || request.action === 'hide') {
      item.viewMode = request.action === 'hide' ? 'hidden' : 'shown';
      item.revealed = request.action === 'view';
    } else if (request.action === 'knowledge' && ['auto', 'known', 'unknown'].includes(request.value)) {
      if (item.autoKnown == null) item.autoKnown = Boolean(item.knownMarked);
      item.knowledgeOverride = request.value;
      item.knownMarked = isKnown(item);
    } else refuse('无效的隐秘操作');
    synchronizeKnowledge(found.world);
    await saveWorld(found.world, scope);
    return { ok: true };
  }, request.chatScope);
}
