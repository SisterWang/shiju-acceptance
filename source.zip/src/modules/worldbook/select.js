/**
 * D18′ / D23 世界书筛选。演进和建世界共用。
 * 扫描词只来自本轮 K 个轮转焦点，不读聊天，不调用 checkWorldInfo。
 * 正文整条进或整条不进，这里不截断。
 */

export const ONGOING_PHASES = Object.freeze(['萌芽', '发展', '高潮']);
export const WORLD_ENTRY_SOFT_CHARS = 8000;

const ONGOING = new Set(ONGOING_PHASES);
const KEY_FIELDS = ['keys', 'key', 'keysecondary', 'keySecondary', 'secondary_keys'];

function chars(text) {
  return Array.from(text || '').length;
}

function clean(value) {
  return String(value || '').trim();
}

export function normalizeCursor(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return 0;
  return Math.floor(value);
}

/** dayDelta = max(1, 本轮前进的故事日数)。缺省按 1。 */
export function dayDeltaFromSpan(span) {
  if (!span || typeof span.from !== 'number' || typeof span.to !== 'number') return 1;
  if (!Number.isFinite(span.from) || !Number.isFinite(span.to)) return 1;
  return Math.max(1, Math.floor(span.to - span.from));
}

/** K = min(12, 3 + floor(log2(dayDelta)) * 2)。 */
export function focusCount(dayDelta) {
  const delta = Math.max(1, Math.floor(Number(dayDelta) || 1));
  return Math.min(12, 3 + Math.floor(Math.log2(delta)) * 2);
}

function pushKey(list, seen, value) {
  if (Array.isArray(value)) {
    for (const item of value) pushKey(list, seen, item);
    return;
  }
  if (typeof value !== 'string') return;
  const parts = value.split(/[,，]/).map((part) => part.trim()).filter(Boolean);
  const tokens = parts.length > 1 ? parts : (value.trim() ? [value.trim()] : []);
  for (const token of tokens) {
    if (seen.has(token)) continue;
    seen.add(token);
    list.push(token);
  }
}

/** 主关键词和次关键词。字符串里的逗号拆开，供中文子串匹配。 */
export function collectKeys(entry) {
  const list = [];
  const seen = new Set();
  for (const field of KEY_FIELDS) pushKey(list, seen, entry?.[field]);
  return list;
}

export function bookIdentity(entry) {
  const uid = clean(entry?.bookUid || entry?.book?.uid);
  const name = clean(entry?.bookName || entry?.book?.name || entry?.world);
  return { uid, name };
}

function refToken(item) {
  if (typeof item === 'string') {
    const text = item.trim();
    return text ? { uid: text, name: text } : null;
  }
  if (!item || typeof item !== 'object') return null;
  const uid = typeof item.uid === 'string' ? item.uid.trim() : '';
  const name = typeof item.name === 'string' ? item.name.trim() : '';
  if (!uid && !name) return null;
  return { uid, name };
}

/**
 * 书级名单。书有 uid 时只认 uid；没有 uid 才用 name。
 * @param {Array} list
 * @param {{ uid?: string, name?: string }} book
 */
export function bookListed(list, book) {
  const uid = clean(book?.uid);
  const name = clean(book?.name);
  for (const item of Array.isArray(list) ? list : []) {
    const token = refToken(item);
    if (!token) continue;
    if (uid) {
      if (token.uid && token.uid === uid) return true;
      continue;
    }
    if (name && (token.name === name || token.uid === name)) return true;
  }
  return false;
}

function phaseOngoing(phase) {
  if (phase == null) return true;
  const text = String(phase).trim();
  if (!text) return true;
  return ONGOING.has(text);
}

function eventTitle(event) {
  return clean(event?.title || event?.name);
}

/** 轮转池：地区 / 组织 / 势力名 + 进行中宏观事件标题。不当扫描词全集。 */
export function rotationPool(world) {
  const names = [];
  const seen = new Set();
  const push = (name) => {
    const text = clean(name);
    if (!text || seen.has(text)) return;
    seen.add(text);
    names.push(text);
  };
  for (const key of ['regions', 'orgs', 'factions']) {
    const list = world?.[key];
    if (!Array.isArray(list)) continue;
    for (const entity of list) { push(entity?.name); for (const alias of entity?.aliases || []) push(alias); }
  }
  const events = Array.isArray(world?.events) ? world.events : [];
  for (const event of events) {
    if (!event || event.kind !== 'macro' || event.lifecycle === 'archived') continue;
    if (!phaseOngoing(event.phase)) continue;
    push(eventTitle(event));
  }
  return names;
}

/** 重放某一轮已经取出的扫描词。游标停在起点，不另取下一批。 */
function focusFromSnapshot(scanWords, cursor) {
  const names = [];
  const seen = new Set();
  for (const word of scanWords) {
    const text = clean(word);
    if (!text || seen.has(text)) continue;
    seen.add(text);
    names.push(text);
  }
  return { names, scanWords: names, nextCursor: cursor };
}

/** 从游标起环状取 K 个焦点。扫描词是去重后的这 K 个名字。 */
export function takeFocus(pool, cursor, k) {
  const list = Array.isArray(pool) ? pool : [];
  const startCursor = normalizeCursor(cursor);
  const count = Math.max(0, Math.floor(Number(k) || 0));
  if (!list.length || count === 0) {
    return { names: [], scanWords: [], nextCursor: startCursor };
  }
  const start = startCursor % list.length;
  const names = [];
  for (let index = 0; index < count; index += 1) {
    names.push(list[(start + index) % list.length]);
  }
  const scanWords = [];
  const seen = new Set();
  for (const name of names) {
    if (seen.has(name)) continue;
    seen.add(name);
    scanWords.push(name);
  }
  return { names, scanWords, nextCursor: startCursor + count };
}

/** 扫描词子串命中关键词。中文不要求整词边界，两边互相包含都算。 */
export function keywordHit(keys, scanWords) {
  const words = (Array.isArray(scanWords) ? scanWords : []).map(clean).filter(Boolean);
  const tags = (Array.isArray(keys) ? keys : []).map(clean).filter(Boolean);
  for (const word of words) {
    const foldedWord = word.toLowerCase();
    for (const key of tags) {
      const foldedKey = key.toLowerCase();
      if (!foldedKey || !foldedWord) continue;
      if (foldedKey.includes(foldedWord) || foldedWord.includes(foldedKey)) return true;
    }
  }
  return false;
}

function isConstant(entry) {
  return entry?.constant === true || entry?.constant === 1 || entry?.constant === 'true';
}

function isDisabled(entry) {
  return entry?.disable === true || entry?.disabled === true || entry?.enabled === false;
}

function bookLists(settings) {
  const book = settings?.worldbook || settings?.shiju?.worldbook || {};
  return {
    forceInclude: Array.isArray(book.forceInclude) ? book.forceInclude : [],
    exclude: Array.isArray(book.exclude) ? book.exclude : [],
  };
}

export function renderBlock(roster, bodies) {
  if (!roster.length) return '';
  const lines = ['世界书名册'];
  for (const item of roster) lines.push(`- ${item.label}`);
  if (bodies.length) {
    lines.push('');
    lines.push('世界书正文');
    for (const body of bodies) {
      lines.push(`【${body.label}】`);
      lines.push(body.content);
    }
  }
  return lines.join('\n');
}

/**
 * @param {{ entries?: Array, world?: object, settings?: object, dayDelta?: number, cursor?: number, scanWords?: string[] }} input
 * 忽略 chat / floors。绿灯不看聊天。传入 scanWords 时按这份快照命中，不再从游标另取一批。
 */
function stamp(value) {
  let hash=2166136261; for(const c of String(value)) hash=Math.imul(hash ^ c.charCodeAt(0),16777619);
  return (hash>>>0).toString(36);
}
export function worldbookEntryKey(entry) {
  const book=bookIdentity(entry);
  return JSON.stringify([book.uid || book.name, entry.uid ?? entry.id ?? entry.title ?? entry.comment ?? entry.name ?? '', entry.uid == null && entry.id == null ? collectKeys(entry) : []]);
}
function eligible(entry, exclude) {
  return entry && typeof entry === 'object' && !isDisabled(entry) && !bookListed(exclude,bookIdentity(entry)) && !/\[(?:GENERATE|RENDER):|@INJECT|@@(?:generate|render)_(?:before|after)/i.test(`${entry.title || entry.comment || ''}\n${entry.content || entry.text || ''}`);
}
export function selectWorldbook(input = {}) {
  const entries = Array.isArray(input.entries) ? input.entries : [];
  const world = input.world || null;
  const dayDelta = Math.max(1, Math.floor(Number(input.dayDelta) || 1));
  const k = focusCount(dayDelta);
  const pool = rotationPool(world);
  const cursor = normalizeCursor(input.cursor != null ? input.cursor : world?.worldbookRotateCursor);
  const focus = Array.isArray(input.scanWords)
    ? focusFromSnapshot(input.scanWords, cursor)
    : takeFocus(pool, cursor, k);
  const { forceInclude, exclude } = bookLists(input.settings);
  const mode = input.mode || 'focus';
  const previous = world?.worldbookDiscovery || {cursor:0,seen:{}};
  const candidates = entries.filter(e=>eligible(e,exclude) && !isConstant(e) && !bookListed(forceInclude,bookIdentity(e)));
  const unique = [...new Map(candidates.map(e=>[worldbookEntryKey(e),e])).values()];
  const versions = Object.fromEntries(unique.map(e=>[worldbookEntryKey(e),stamp(JSON.stringify([e.content || e.text,collectKeys(e)]))]));
  const remaining = unique.filter(e=>!keywordHit(collectKeys(e),focus.scanWords));
  const changed = remaining.filter(e=>previous.seen?.[worldbookEntryKey(e)] !== versions[worldbookEntryKey(e)]);
  const start=normalizeCursor(previous.cursor);
  const rotated=remaining.map((_,i)=>remaining[(start+i)%remaining.length]);
  const discovered = mode === 'full' ? [] : Array.isArray(input.discoveryKeys) ? input.discoveryKeys
    : [...new Set([...changed,...rotated].map(worldbookEntryKey))].slice(0,k);
  const nextDiscovery = mode === 'full' ? previous : {cursor:start+k,seen:{...(previous.seen || {})}};
  if(mode !== 'full') for(const key of discovered) nextDiscovery.seen[key]=versions[key];
  const roster = [];
  const bodies = [];
  const oversizedTitles = [];
  const included=new Set();

  for (const entry of entries) {
    if (!entry || typeof entry !== 'object' || isDisabled(entry)) continue;
    const identity=worldbookEntryKey(entry); if(included.has(identity))continue; included.add(identity);
    const title = clean(entry.comment || entry.name || entry.title) || '未命名';
    const content = String(entry.content || entry.text || '');
    if (/\[(?:GENERATE|RENDER):|@INJECT|@@(?:generate|render)_(?:before|after)/i.test(`${title}\n${content}`)) continue;
    if (!content.trim() && title === '未命名') continue;
    const book = bookIdentity(entry);
    if (bookListed(exclude, book)) continue;
    const shaped = {
      title,
      bookName: book.name,
      bookUid: book.uid,
      label: book.name ? `${book.name} · ${title}` : title,
    };
    roster.push(shaped);
    const constant = isConstant(entry);
    const forced = bookListed(forceInclude, book);
    const hit = keywordHit(collectKeys(entry), focus.scanWords);
    if (mode !== 'full' && !constant && !forced && !hit && !discovered.includes(worldbookEntryKey(entry))) continue;
    const body = content;
    if (!body.trim()) continue;
    const reason = mode === 'full' ? 'full' : constant ? 'constant' : forced ? 'forceInclude' : hit ? 'keyword' : 'discovery';
    bodies.push({ ...entry, ...shaped, content: body, reason });
    if (chars(body) > WORLD_ENTRY_SOFT_CHARS) oversizedTitles.push(shaped.label);
  }


  return {
    mode, discoveryKeys: discovered, nextDiscovery,
    roster,
    bodies,
    text: renderBlock(roster, bodies),
    pool,
    focusNames: focus.names,
    scanWords: focus.scanWords,
    k,
    dayDelta,
    cursor,
    nextCursor: focus.nextCursor,
    oversized: oversizedTitles.length > 0,
    oversizedTitles,
  };
}
