import { assertChatScope, captureChatScope } from '../chatScope.js';
import { shijuError } from '../errors.js';

const queues = new WeakMap();
const operations = new Set();
const listeners = new Set();

export function subscribeOperations(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
function notify() {
  for (const listener of listeners) {
    try { listener(); } catch (error) { console.error('[shiju]', error); }
  }
}
export function isWorldBusy() {
  for (const scope of operations) {
    try { assertChatScope(scope); return true; } catch { operations.delete(scope); }
  }
  return false;
}
export function assertEditable(scope = captureChatScope()) {
  assertChatScope(scope);
  if (isWorldBusy()) throw shijuError('SHIJU_WORLD_BUSY', '正在演进，完成后可修改');
}

/** All world writers share the queue; pending world turns already block editing. */
export function enqueueTurn(task, options = {}) {
  const scope = options.scope ?? captureChatScope();
  try { assertChatScope(scope); } catch (error) {
    return options.edit ? Promise.reject(error)
      : Promise.resolve({ ok: false, evolved: false, reason: 'chat-changed', message: error.message });
  }
  // A pending model call in an abandoned chat must not stall the new chat.
  let session = queues.get(scope.host);
  if (!session || session.epoch !== scope.epoch) {
    session = { epoch: scope.epoch, tails: new Map() };
    queues.set(scope.host, session);
  }
  const key = scope.fallback || JSON.stringify([scope.chatId, scope.characterId, scope.groupId]);
  const tail = session.tails.get(key) || Promise.resolve();
  if (options.edit) {
    try { assertEditable(scope); } catch (error) { return Promise.reject(error); }
  } else {
    operations.add(scope);
    notify();
  }
  const run = tail.then(async () => {
    assertChatScope(scope);
    const result = await task(scope);
    assertChatScope(scope);
    return result;
  }).catch((error) => {
    if (!options.edit && error?.code === 'SHIJU_CHAT_CHANGED') {
      return { ok: false, evolved: false, reason: 'chat-changed', message: error.message };
    }
    throw error;
  }).finally(() => {
    operations.delete(scope);
    notify();
  });
  const settled = run.then(() => undefined, () => undefined);
  session.tails.set(key, settled);
  settled.then(() => {
    if (session.tails.get(key) === settled) session.tails.delete(key);
  });
  return run;
}

export function enqueueEdit(task, scope = captureChatScope()) {
  return enqueueTurn(task, { edit: true, scope });
}
