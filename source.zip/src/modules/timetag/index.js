import { getHost, writeInChatPrompt } from '../../host.js';
import { watchBaibaiReady } from '../../source/baibai.js';
import { loadSettings, loadWorld, subscribe } from '../../store/index.js';
import {
  SHIJU_END_TAG,
  SHIJU_START_TAG,
  activeMode,
  applyClock,
  baibaiPresent,
  currentTipCursor,
  fingerprintOfMessage,
  interpretStoryTime,
  parseCustomTags,
  readTaggedStoryTime,
  resolveTimeSourceMode,
  tagPair,
} from './read.js';

/**
 * M-TimeTag. Mode ① injects shiju_timetag at depth 0.
 * shiju_macro is a different key and is not written here.
 * Hide-regex is display-only, same idea as 柏宝书: tags stay in the message text.
 */

export const TIMETAG_PROMPT_KEY = 'shiju_timetag';
export const TIMETAG_DEPTH = 0;
export const HIDE_REGEX_ID = 'shiju-time-tag-hide';

export {
  SHIJU_END_TAG,
  SHIJU_START_TAG,
  applyClock,
  baibaiPresent,
  currentTipCursor,
  fingerprintOfMessage,
  interpretStoryTime,
  readTaggedStoryTime,
  resolveTimeSourceMode,
};

export const TIME_TAG_PROMPT = `【时间锚点要求】
在每次正文的最前面和最后面各放一个时间标签，标明本段开始与结束时刻：

<${SHIJU_START_TAG}>1988/9/29 21:30</${SHIJU_START_TAG}>
（正文）
<${SHIJU_END_TAG}>1988/9/29 21:45</${SHIJU_END_TAG}>

规则：
- 时间必须能定位到某一刻。现代题材写成带完整年份的 YYYY/M/D HH:mm。古风或奇幻写成完整纪年与时辰，不要只写季节或「某天」。
- 禁止「稍后」「不久」「某天」「同一天」这类无法定位的说法。
- 以上一段的结束时间为基准，按本段实际跨度推进。跨日、跨月要写进结束标签。
- 两个标签各出现一次，紧贴正文首尾，标签里只有时间。
- 这是时间锚点，不是要求把世界局势写进正文。`;

const boundHosts = new WeakSet();
let subscribed = false;
let listening = false;

function worldEnabled(world) {
  return Boolean(world?.plugin?.enabled) && world?.plugin?.frozenAt == null;
}

function activePrompt(settings) {
  const custom = settings?.timeSource?.prompt;
  if (typeof custom === 'string' && custom.trim()) return custom.trim();
  return TIME_TAG_PROMPT;
}

function writePrompt(key, value) {
  writeInChatPrompt(key, value, TIMETAG_DEPTH);
}

function hideScript(pair) {
  const piece = (tag) => `<${tag}\\b[^>\\r\\n]*>[^<\\r\\n]*<\\/${tag}>`;
  const start = piece(pair.start);
  const body = pair.single || pair.start === pair.end ? start : `${start}|${piece(pair.end)}`;
  return {
    id: HIDE_REGEX_ID,
    scriptName: '世局 · 隐藏时间标签',
    findRegex: `/${body}/gi`,
    replaceString: '',
    trimStrings: [],
    placement: [0, 1, 2],
    disabled: false,
    markdownOnly: true,
    promptOnly: false,
    runOnEdit: true,
    substituteRegex: 0,
    minDepth: null,
    maxDepth: null,
  };
}

/** Idempotent upsert or removal of the display-only hide script. */
export function syncHideRegex() {
  const settings = loadSettings();
  const world = loadWorld();
  const mode = resolveTimeSourceMode(settings, baibaiPresent());
  const pair = tagPair(mode, settings.timeSource?.customTag || '');
  const shouldHide = worldEnabled(world) && pair && mode !== 'baibai';
  const host = getHost();
  const bag = host.getExtensionSettings?.();
  if (!bag || typeof bag !== 'object') return { synced: false, present: false };
  const list = Array.isArray(bag.regex) ? bag.regex : [];
  const exists = list.some((script) => script?.id === HIDE_REGEX_ID);
  if (!shouldHide) {
    if (exists) {
      bag.regex = list.filter((script) => script?.id !== HIDE_REGEX_ID);
      host.saveSettingsDebounced?.();
    }
    return { synced: true, present: false };
  }
  const script = hideScript(pair);
  if (!Array.isArray(bag.regex)) bag.regex = [];
  const index = bag.regex.findIndex((item) => item?.id === HIDE_REGEX_ID);
  if (index >= 0) {
    const updated = { ...bag.regex[index], ...script };
    if (JSON.stringify(updated) === JSON.stringify(bag.regex[index])) {
      return { synced: true, present: true };
    }
    bag.regex[index] = updated;
  } else bag.regex.push(script);
  host.saveSettingsDebounced?.();
  return { synced: true, present: true };
}

/** Mode ① writes shiju_timetag. Modes ② and ③ clear that key. */
export function refreshTimeTag() {
  const settings = loadSettings();
  const world = loadWorld();
  const mode = resolveTimeSourceMode(settings, baibaiPresent());
  const prompt = worldEnabled(world) && mode === 'shiju' ? activePrompt(settings) : '';
  writePrompt(TIMETAG_PROMPT_KEY, prompt);
  const hidden = syncHideRegex();
  return { mode, prompt, hidden: hidden.present };
}

function refreshSafely() {
  try {
    refreshTimeTag();
  } catch (error) {
    console.error('[shiju] 时间标签刷新失败', error);
  }
}

export function register() {
  const host = getHost();
  if (!subscribed) {
    subscribed = true;
    subscribe((kind) => {
      if (kind === 'settings' || kind === 'world') refreshSafely();
    });
  }
  const chatChanged = host.event_types?.CHAT_CHANGED;
  if (!boundHosts.has(host) && chatChanged && typeof host.eventSource?.on === 'function') {
    boundHosts.add(host);
    host.eventSource.on(chatChanged, () => {
      if (getHost() === host) refreshSafely();
    });
  }
  refreshSafely();
  if (listening || typeof window === 'undefined') return;
  listening = true;
  watchBaibaiReady(refreshSafely);
}

export function currentMode() {
  return activeMode();
}

export { parseCustomTags };
