import { physicalMessage, manualHidden } from '../visibility.js';
import { getHost } from '../../host.js';
import { detectBaibaiBook } from '../../source/baibai.js';
import { loadSettings, loadWorld } from '../../store/index.js';

export const SHIJU_START_TAG = 'shiju_start';
export const SHIJU_END_TAG = 'shiju_end';

const CN_DIGIT = {
  零: 0, 〇: 0, 一: 1, 二: 2, 两: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9,
};

/** Host hook wins, including an explicit false. Same probe the settings page uses. */
export function baibaiPresent() {
  return detectBaibaiBook();
}

/**
 * Effective time source. Does not write settings.
 * 手选的世局标签 / 自定义标签保持不动。
 * auto，以及存着的柏宝书在书不在时，都落到世局标签；书在才用柏宝书。
 */
export function resolveTimeSourceMode(settings, present = baibaiPresent()) {
  const mode = settings?.timeSource?.mode || 'auto';
  if (mode === 'shiju' || mode === 'custom') return mode;
  return present ? 'baibai' : 'shiju';
}

function sanitizeTag(tag) {
  const name = String(tag || '').trim().replace(/[<>/\s]/g, '');
  if (!name || !/^[\w\-\u4e00-\u9fff]+$/u.test(name)) return '';
  return name;
}

export function parseCustomTags(customTag) {
  return String(customTag || '')
    .split(/[|,/]/)
    .map(sanitizeTag)
    .filter(Boolean);
}

export function tagPair(mode, customTag) {
  if (mode === 'shiju') return { start: SHIJU_START_TAG, end: SHIJU_END_TAG, single: false };
  if (mode === 'baibai') return { start: 'bbs_start', end: 'bbs_end', single: false };
  const tags = parseCustomTags(customTag);
  if (!tags.length) return null;
  if (tags.length === 1) return { start: tags[0], end: tags[0], single: true };
  return { start: tags[0], end: tags[1], single: false };
}

function matchTag(text, tag) {
  const found = text.match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
  if (!found) return null;
  return { raw: found[0], inner: found[1].trim() };
}

export function absoluteSerial(label) {
  const match = String(label || '').match(/(\d{3,4})\s*[\/\-.年]\s*(\d{1,2})\s*[\/\-.月]\s*(\d{1,2})/);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  const utc = Date.UTC(year, month - 1, day);
  const check = new Date(utc);
  if (check.getUTCFullYear() !== year || check.getUTCMonth() !== month - 1 || check.getUTCDate() !== day) return null;
  return Math.floor(utc / 86400000);
}

function parseChineseNumber(raw) {
  const text = String(raw || '').replace(/[个之\s]/g, '');
  if (!text) return null;
  if (/^\d+$/.test(text)) return Number(text);
  if (text === '半') return 0.5;
  if (text === '十') return 10;
  const ten = text.indexOf('十');
  if (ten >= 0) {
    const hi = ten === 0 ? 1 : CN_DIGIT[text[ten - 1]];
    const lo = ten === text.length - 1 ? 0 : CN_DIGIT[text[ten + 1]];
    if (hi == null || lo == null) return null;
    return hi * 10 + lo;
  }
  if (text.length === 1 && CN_DIGIT[text] != null) return CN_DIGIT[text];
  return null;
}

/** Explicit advances only. A bare date is handled by absoluteSerial, not here. */
export function relativeDelta(label) {
  const text = String(label || '');
  if (!text) return null;
  let days = 0;
  let hit = false;
  const rules = [
    { re: /(\d+|[零〇一二两三四五六七八九十]+)\s*年\s*后/g, scale: 365 },
    { re: /(\d+|[零〇一二两三四五六七八九十]+)\s*个\s*月\s*后/g, scale: 30 },
    { re: /(\d+|[零〇一二两三四五六七八九十]+)\s*月\s*后/g, scale: 30 },
    { re: /(\d+|[零〇一二两三四五六七八九十]+)\s*(?:周|星期)\s*后/g, scale: 7 },
    { re: /(\d+|[零〇一二两三四五六七八九十]+)\s*(?:天|日)\s*后/g, scale: 1 },
  ];
  for (const rule of rules) {
    for (const match of text.matchAll(rule.re)) {
      const count = parseChineseNumber(match[1]);
      if (count == null) continue;
      days += count * rule.scale;
      hit = true;
    }
  }
  if (/半月后/.test(text)) {
    days += 15;
    hit = true;
  }
  if (/次日|翌日|第二天|隔日|隔天|过了一夜|一夜之后|过夜/.test(text)) {
    days += 1;
    hit = true;
  }
  if (!hit || days <= 0) return null;
  return Math.round(days);
}

function classifyLabel(label) {
  const serial = absoluteSerial(label);
  if (serial != null) return { serial, delta: null };
  return { serial: null, delta: relativeDelta(label) };
}

function leafLabel(message) {
  const leaf = message?.extra?.bbs_leaf;
  if (!leaf || typeof leaf !== 'object' || !leaf.id) return null;
  const leafSwipe = typeof leaf.swipe === 'number' ? leaf.swipe : 0;
  const msgSwipe = typeof message.swipe_id === 'number' ? message.swipe_id : 0;
  if (leafSwipe !== msgSwipe) return null;
  const label = String(leaf.timeEnd || leaf.timeStart || '').trim();
  return label || null;
}

function extractFromMessage(message, mode, customTag) {
  const text = typeof message?.mes === 'string' ? message.mes : '';
  const pair = tagPair(mode, customTag);
  if (!pair || !text) return null;
  if (pair.single) {
    const one = matchTag(text, pair.start);
    if (!one) return null;
    const kind = classifyLabel(one.inner);
    return {
      label: one.inner,
      raw: one.raw,
      conflict: false,
      serial: kind.serial,
      delta: kind.delta,
      startSerial: kind.serial,
      endSerial: kind.serial,
    };
  }
  const start = matchTag(text, pair.start);
  const end = matchTag(text, pair.end);
  if (!start && !end) {
    if (mode !== 'baibai') return null;
    const leaf = leafLabel(message);
    if (!leaf) return null;
    const kind = classifyLabel(leaf);
    return {
      label: leaf,
      raw: `leaf:${leaf}`,
      conflict: false,
      serial: kind.serial,
      delta: kind.delta,
      startSerial: kind.serial,
      endSerial: kind.serial,
      fromLeaf: true,
    };
  }
  const startKind = start ? classifyLabel(start.inner) : { serial: null, delta: null };
  const endKind = end ? classifyLabel(end.inner) : { serial: null, delta: null };
  if (startKind.serial != null && endKind.serial != null && endKind.serial < startKind.serial) {
    return {
      label: (end || start).inner,
      raw: (end || start).raw,
      conflict: true,
      serial: null,
      delta: null,
      startSerial: startKind.serial,
      endSerial: endKind.serial,
    };
  }
  if (end && endKind.serial == null && endKind.delta && startKind.serial != null) {
    return {
      label: end.inner,
      raw: end.raw,
      conflict: false,
      serial: startKind.serial + endKind.delta,
      delta: null,
      startSerial: startKind.serial,
      endSerial: startKind.serial + endKind.delta,
    };
  }
  const chosen = end || start;
  const chosenKind = end ? endKind : startKind;
  return {
    label: chosen.inner,
    raw: chosen.raw,
    conflict: false,
    serial: chosenKind.serial ?? startKind.serial,
    delta: chosenKind.serial == null && startKind.serial == null ? (chosenKind.delta || startKind.delta) : null,
    startSerial: startKind.serial,
    endSerial: endKind.serial ?? chosenKind.serial,
  };
}

export function fingerprintOfMessage(message, mode, customTag) {
  return extractFromMessage(message, mode, customTag)?.raw || '';
}

function relevant(message) {
  if (!physicalMessage(message)) return false;
  return typeof message.mes === 'string';
}

export function currentTipCursor(chat, mode, customTag) {
  const list = Array.isArray(chat) ? chat : [];
  for (let index = list.length - 1; index >= 0; index -= 1) {
    if (!relevant(list[index])) continue;
    return {
      floor: index,
      swipeId: typeof list[index].swipe_id === 'number' ? list[index].swipe_id : 0,
      fingerprint: fingerprintOfMessage(list[index], mode, customTag),
    };
  }
  return { floor: -1, swipeId: 0, fingerprint: '' };
}

function clockOf(world) {
  const clock = world?.storyClock || {};
  return {
    dayIndex: typeof clock.dayIndex === 'number' && Number.isFinite(clock.dayIndex) ? clock.dayIndex : 0,
    dateLabel: typeof clock.dateLabel === 'string' ? clock.dateLabel : '',
    originSerial: typeof clock.originSerial === 'number' ? clock.originSerial : null,
    serial: typeof clock.serial === 'number' ? clock.serial : null,
    relativeTimeAnchor: clock.relativeTimeAnchor || null,
  };
}

function sameRelativeAnchor(previous, next) {
  return previous && next && previous.mode === next.mode
    && previous.customTag === next.customTag && previous.floor === next.floor
    && previous.swipeId === next.swipeId && previous.fingerprint === next.fingerprint;
}

function finish(reading) {
  return {
    ...reading,
    advanced: reading.status === 'advance',
    missing: reading.status === 'missing',
    conflict: reading.status === 'conflict',
  };
}

function baseReading(mode, clock, extra = {}) {
  return finish({
    mode,
    status: 'missing',
    dayIndex: clock.dayIndex,
    dateLabel: clock.dateLabel,
    originSerial: clock.originSerial,
    serial: clock.serial,
    fingerprint: '',
    floor: -1,
    swipeId: 0,
    ...extra,
  });
}

function baibaiApiLabel(chat) {
  try {
    const api = globalThis.STBaiBaiBook;
    if (!api || typeof api.latestStoryTime !== 'function') return '';
    const value = api.latestStoryTime(chat);
    return typeof value === 'string' ? value.trim() : '';
  } catch {
    return '';
  }
}

function pointOf(item) {
  return item.endSerial ?? item.serial;
}

/**
 * Read the active time-source mode.
 * Missing or unparseable tags stay on the same day.
 * Baibai mode scans bbs tags / leaf time / latestStoryTime. It does not trust snapshot.state.time.
 */
export function interpretStoryTime(world, chat, mode, customTag) {
  const clock = clockOf(world);
  const list = Array.isArray(chat) ? chat : [];
  const known = world?.processedInput?.rows ? new Set(world.processedInput.rows.filter(r => r.status !== 'excluded' && r.status !== 'pending').map(r => r.floor)) : null;
  const excluded = new Set([...(world?.processedInput?.excluded || []).map(r=>r.floor), ...(world?.processedInput?.rows || []).filter(r=>r.status === 'excluded').map(r=>r.floor)]);
  const processedRows = new Map((world?.processedInput?.rows || []).map(r=>[r.floor,r]));
  const dated = [];
  let latest = null;
  let conflict = null;
  let lastSerial = null;
  for (let index = 0; index < list.length; index += 1) {
    if (!relevant(list[index])) continue;
    if (excluded.has(index) && !known?.has(index) || manualHidden(list[index]) && (!known || !known.has(index))) continue;
    const message = excluded.has(index) && known?.has(index) ? {...list[index],mes:processedRows.get(index).timeFingerprint} : list[index];
    const extracted = extractFromMessage(message, mode, customTag);
    if (!extracted) continue;
    const item = {
      index,
      swipeId: typeof list[index].swipe_id === 'number' ? list[index].swipe_id : 0,
      ...extracted,
    };
    latest = item;
    if (item.conflict) {
      conflict = item;
      continue;
    }
    if (item.serial != null) {
      if (lastSerial != null && pointOf(item) < lastSerial) conflict = item;
      lastSerial = pointOf(item);
      dated.push(item);
    }
  }
  if (!latest && mode === 'baibai') {
    const label = baibaiApiLabel(list);
    if (label) {
      const kind = classifyLabel(label);
      const tip = currentTipCursor(list, mode, customTag);
      latest = {
        index: tip.floor,
        swipeId: tip.swipeId,
        label,
        raw: label,
        conflict: false,
        serial: kind.serial,
        delta: kind.delta,
        startSerial: kind.serial,
        endSerial: kind.serial,
      };
      if (latest.serial != null) dated.push(latest);
    }
  }
  if (conflict) {
    return baseReading(mode, clock, {
      status: 'conflict',
      fingerprint: conflict.raw,
      floor: conflict.index,
      swipeId: conflict.swipeId,
    });
  }
  if (!latest) return baseReading(mode, clock);

  const relativeTimeAnchor = latest.delta ? {
    mode,
    customTag: mode === 'custom' ? parseCustomTags(customTag).join('|') : '',
    floor: latest.index,
    swipeId: latest.swipeId,
    fingerprint: latest.raw,
  } : null;
  if (sameRelativeAnchor(clock.relativeTimeAnchor, relativeTimeAnchor)) {
    return baseReading(mode, clock, {
      status: 'same',
      dateLabel: latest.label,
      fingerprint: latest.raw,
      floor: latest.index,
      swipeId: latest.swipeId,
      relativeTimeAnchor,
    });
  }

  if (clock.originSerial != null && clock.serial != null && latest.serial != null) {
    if (latest.serial < clock.serial) {
      return baseReading(mode, clock, {
        status: 'conflict',
        fingerprint: latest.raw,
        floor: latest.index,
        swipeId: latest.swipeId,
      });
    }
    if (latest.serial === clock.serial) {
      return baseReading(mode, clock, {
        status: 'same',
        dateLabel: latest.label,
        fingerprint: latest.raw,
        floor: latest.index,
        swipeId: latest.swipeId,
      });
    }
    return finish({
      mode,
      status: 'advance',
      dayIndex: clock.dayIndex + (latest.serial - clock.serial),
      dateLabel: latest.label,
      originSerial: clock.originSerial,
      serial: latest.serial,
      fingerprint: latest.raw,
      floor: latest.index,
      swipeId: latest.swipeId,
    });
  }

  if (clock.originSerial == null && dated.length) {
    for (let index = 1; index < dated.length; index += 1) {
      if (pointOf(dated[index]) < pointOf(dated[index - 1])) {
        const last = dated[dated.length - 1];
        return baseReading(mode, clock, {
          status: 'conflict',
          fingerprint: last.raw,
          floor: last.index,
          swipeId: last.swipeId,
        });
      }
    }
    const first = dated[0];
    const last = dated[dated.length - 1];
    const firstPoint = first.startSerial ?? first.serial;
    // Bootstrap may encounter an absolute date followed by a relative final tag.
    // Align and consume that final tag together, rather than replaying it next turn.
    const target = relativeTimeAnchor ? latest : last;
    const lastPoint = pointOf(last) + (latest.delta || 0);
    const dayIndex = clock.dayIndex + (lastPoint - firstPoint);
    return finish({
      mode,
      status: lastPoint > firstPoint ? 'advance' : 'same',
      dayIndex,
      dateLabel: target.label,
      originSerial: firstPoint,
      serial: lastPoint,
      fingerprint: target.raw,
      floor: target.index,
      swipeId: target.swipeId,
      ...(relativeTimeAnchor ? { relativeTimeAnchor } : {}),
    });
  }

  if (latest.delta) {
    return finish({
      mode,
      status: 'advance',
      dayIndex: clock.dayIndex + latest.delta,
      dateLabel: latest.label,
      originSerial: clock.originSerial,
      serial: clock.serial == null ? null : clock.serial + latest.delta,
      fingerprint: latest.raw,
      floor: latest.index,
      swipeId: latest.swipeId,
      relativeTimeAnchor,
    });
  }

  return baseReading(mode, clock, {
    status: 'same',
    dateLabel: latest.label || clock.dateLabel,
    fingerprint: latest.raw,
    floor: latest.index,
    swipeId: latest.swipeId,
  });
}

export function applyClock(world, reading) {
  const previous = world.storyClock || {};
  world.storyClock = {
    ...previous,
    dateLabel: reading.dateLabel || previous.dateLabel || '',
    dayIndex: reading.dayIndex,
    source: reading.mode || previous.source || '',
    lastConfirmedAtFloor: reading.floor >= 0 ? reading.floor : (previous.lastConfirmedAtFloor ?? null),
    originSerial: reading.originSerial != null ? reading.originSerial : (previous.originSerial ?? null),
    serial: reading.serial != null ? reading.serial : (previous.serial ?? null),
  };
  if (reading.relativeTimeAnchor && (reading.status === 'advance' || reading.status === 'same')) {
    // Persist with the clock, so successful commits, reloads and rollback snapshots
    // share the same consumed anchor. Failed evolution only modifies its draft.
    world.storyClock.relativeTimeAnchor = { ...reading.relativeTimeAnchor };
  }
  if (!world.meta) world.meta = {};
  if (reading.status === 'missing') world.meta.clockHint = 'missing-tag';
  else if (reading.status === 'conflict') world.meta.clockHint = 'conflict';
  else world.meta.clockHint = '';
  return world;
}

export function activeMode() {
  return resolveTimeSourceMode(loadSettings(), baibaiPresent());
}

export function readTaggedStoryTime() {
  const settings = loadSettings();
  const mode = resolveTimeSourceMode(settings, baibaiPresent());
  return interpretStoryTime(loadWorld(), readChatFromHost(), mode, settings.timeSource?.customTag || '');
}

export function readChatFromHost() {
  const host = getHost();
  if (typeof host.readChat === 'function') {
    const chat = host.readChat();
    return Array.isArray(chat) ? chat : [];
  }
  const ctx = host.getContext?.();
  return Array.isArray(ctx?.chat) ? ctx.chat : [];
}
