/**
 * In-memory tip lock. Not part of WorldState (schema drops meta.generatingTip).
 * 末楼 regenerate / swipe 未落定。只有对账的事件回调可以置位。
 */
let generatingTip = false;

export function isGeneratingTip() {
  return generatingTip;
}

/** Production writer: M-Reconcile event bindings only. */
export function setGeneratingTip(value) {
  generatingTip = Boolean(value);
}
