import { renderTemplate } from './runtime.js';
self.onmessage = async ({data}) => {
  const result = await renderTemplate(data.entry, data.context, data.entries);
  self.postMessage(result);
};
