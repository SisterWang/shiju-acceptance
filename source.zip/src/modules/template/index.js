import { bookIdentity, bookListed, renderBlock } from '../worldbook/select.js';
import { getHost } from '../../host.js';
import { captureChatScope, assertChatScope } from '../../chatScope.js';
import { publishDiagnostics } from '../../diagnostics.js';
const control = /\[(?:GENERATE|RENDER):|@INJECT|@@(?:generate|render)_(?:before|after)/i;

/** One worker at a time; terminate it on completion/error/deadline. */
export function runWorker(entry, context, entries, timeout = 2000) {
  const factory = getHost().createTemplateWorker;
  return new Promise((resolve) => {
    let worker, timer;
    const finish = result => { clearTimeout(timer); worker?.terminate(); resolve(result); };
    try {
      worker = factory ? factory() : new Worker(new URL('../../../vendor/template-worker.js', import.meta.url));
      worker.onmessage = event => finish(event.data);
      worker.onerror = error => finish({text:null,diagnostics:[{kind:'skipped',reason:`只读执行器不可用：${error.message || '加载失败'}`} ]});
      timer = setTimeout(() => finish({text:null,timeout:true,diagnostics:[{kind:'skipped',reason:'计算超时'}]}), timeout);
      worker.postMessage({ entry, context, entries });
    } catch { finish({text:null,diagnostics:[{kind:'skipped',reason:'浏览器不支持只读执行器'}]}); }
  });
}

export async function renderSelected(selected, pack, settings) {
  const scope = captureChatScope(), start = Date.now();
  const entries = (pack.worldbook?.entries || []).filter(e => !bookListed(settings?.worldbook?.exclude, bookIdentity(e)) && !control.test(`${e.title}\n${e.content}`));
  const diagnostics = [...(pack.diagnostics || [])], bodies = [];
  let timedOut = false;
  for (const entry of selected.bodies) {
    assertChatScope(scope);
    if (control.test(`${entry.title}\n${entry.content}`)) {
      diagnostics.push({...entry,content:undefined,kind:'skipped',reason:'正文生命周期控制条目不执行'}); continue;
    }
    if (!/<%|{{/.test(entry.content)) { bodies.push(entry); continue; }
    const remaining = 10000 - (Date.now() - start);
    if (timedOut || remaining <= 0) {
      diagnostics.push({bookName:entry.bookName,title:entry.title,kind:'skipped',reason:'本轮动态计算预算已结束'}); continue;
    }
    const result = await runWorker(entry, pack.templateData || {}, entries, Math.min(2000, remaining));
    assertChatScope(scope);
    timedOut ||= result.timeout;
    diagnostics.push(...result.diagnostics.map(d => ({...d,bookName:entry.bookName,title:entry.title})));
    if (typeof result.text === 'string' && result.text.trim()) bodies.push({...entry, content:result.text});
  }
  const skipped = new Set(diagnostics.filter(d => d.kind === 'skipped').map(d => `${d.bookName}:${d.title}`));
  const roster = selected.roster.filter(e => !control.test(e.title) && !skipped.has(`${e.bookName}:${e.title}`));
  publishDiagnostics(diagnostics, scope);
  return {...selected, bodies, roster, text: renderBlock(roster,bodies), diagnostics};
}
