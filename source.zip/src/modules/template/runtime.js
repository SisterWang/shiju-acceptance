import 'ses';
import ejs from 'ejs/ejs.js';
import { evadeCensorSync } from '@endo/evasive-transform';
import get from 'lodash/get.js';
import has from 'lodash/has.js';
import cloneDeep from 'lodash/cloneDeep.js';
import sortBy from 'lodash/sortBy.js';
import groupBy from 'lodash/groupBy.js';
import uniq from 'lodash/uniq.js';
import pick from 'lodash/pick.js';
import omit from 'lodash/omit.js';
import range from 'lodash/range.js';
import sumBy from 'lodash/sumBy.js';
import escape from 'lodash/escape.js';

// No DOM, network, storage, module loader or host functions are endowed to SES.
// The worker is also disposable: a tight loop cannot block the UI thread.
lockdown({ errorTaming: 'safe', stackFiltering: 'concise' });
const pureLodash = harden({ get, has, cloneDeep, sortBy, groupBy, uniq, pick, range, sumBy, escape,
  // Lodash may retain nested arrays when omitting paths. Detach the entire
  // input first so deletion and subsequent edits never reach read-only proxies.
  omit: (value, ...paths) => omit(cloneDeep(value), ...paths),
  map: (v, f) => Object.values(v).map(typeof f === 'function' ? f : x => get(x, f)),
  filter: (v, f) => Object.values(v).filter(f),
  isArray: Array.isArray, isEmpty: v => v == null || Object.keys(v).length === 0,
  keys: Object.keys, values: Object.values, entries: Object.entries });
const control = /\[(?:GENERATE|RENDER):|@INJECT|@@(?:generate|render)_(?:before|after)/i;
export const lifecycleEntry = e => control.test(`${e.title || ''}\n${e.content || ''}`);

export async function renderTemplate(entry, data, entries) {
  const diagnostics = [], cache = new WeakMap();
  // Never copy arbitrary exception messages: templates can throw variable
  // values, and parser errors can include source excerpts.
  const failures = new WeakMap();
  function failure(code, reason, chain) {
    const error = new Error(reason);
    failures.set(error, {code, reason, chain});
    return error;
  }
  const executionReason = error => error instanceof ReferenceError ? '执行失败：辅助函数或变量未定义'
    : error instanceof TypeError ? '执行失败：类型或函数调用不兼容'
    : error instanceof SyntaxError ? '执行失败：语法不受隔离环境支持'
    : '执行失败：模板计算发生异常';
  const blocked = name => diagnostics.push({ kind: 'blocked', reason: `已拦截：${name}` });
  function readonly(value, path = 'variables') {
    if (!value || typeof value !== 'object') return value;
    if (cache.has(value)) return cache.get(value);
    const proxy = new Proxy(value, {
      get: (t, k) => readonly(Reflect.get(t, k), `${path}.${String(k)}`),
      set: (_t, k) => { blocked(`${path}.${String(k)} =`); return true; },
      deleteProperty: (_t, k) => { blocked(`delete ${path}.${String(k)}`); return true; },
      defineProperty: (_t, k) => { blocked(`define ${path}.${String(k)}`); return false; },
      setPrototypeOf: () => { blocked('setPrototypeOf'); return false; },
      preventExtensions: () => false,
    });
    cache.set(value, proxy); return proxy;
  }
  const chat = data.chat || [];
  function messageVars(filter = {}) {
    let end = filter.id == null ? chat.length - 1 : filter.id < 0 ? chat.length + filter.id : filter.id;
    for (let i = Math.min(end, chat.length - 1); i >= 0; i--) {
      const m = chat[i];
      if (filter.role && filter.role !== 'any' && (filter.role === 'user' ? !m.is_user : filter.role === 'system' ? !m.is_system : m.is_user || m.is_system)) continue;
      const v = m.variables?.[filter.swipe_id ?? m.swipe_id ?? 0];
      if (v) return v;
    }
    return {};
  }
  const scopes = { global: data.global || {}, initial: data.initial || {}, local: data.local || {}, message: messageVars() };
  const merged = Object.assign({}, scopes.global, scopes.initial, scopes.local, scopes.message);
  const read = (key, options = {}) => {
    if (typeof options === 'string') options = { scope: options };
    let obj = options.withMsg ? messageVars(options.withMsg) : scopes[options.scope] || merged;
    let val = key == null || key === '' ? obj : get(obj, key, options.defaults);
    if (options.index != null) { if(typeof val === 'string') val=JSON.parse(val || '{}'); val = get(val, options.index, options.defaults); }
    return readonly(val);
  };
  const base = { variables: readonly(merged), getvar: read, getLocalVar: (k,o) => read(k,{...o,scope:'local'}),
    getGlobalVar: (k,o) => read(k,{...o,scope:'global'}), getMessageVar: (k,o) => read(k,{...o,scope:'message'}),
    user: data.user, char: data.char, name1: data.user, name2: data.char, chara_name: data.char,
    character: readonly(data.character || {}), persona:data.persona || '',
    description:data.character?.description || data.character?.data?.description || '',
    personality:data.character?.personality || data.character?.data?.personality || '',
    scenario:data.character?.scenario || data.character?.data?.scenario || '',
    globalVariables:readonly(scopes.global), chatVariables:readonly(scopes.local), messageVariables:readonly(scopes.message), chat: readonly(chat, 'chat'), worldbooks: readonly(entries, 'worldbooks'), _: pureLodash };
  for (const name of ['setvar','incvar','decvar','delvar','insvar','setLocalVar','setGlobalVar','setMessageVar','deleteVariable','insertVariable','incrementVariable','decrementVariable']) {
    base[name] = (key, _value, options) => { blocked(name); return read(key, { ...options, ...(name.includes('Global') ? {scope:'global'} : name.includes('Local') ? {scope:'local'} : name.includes('Message') ? {scope:'message'} : {}) }); };
  }
  for (const name of ['execute','executeSlashCommands','sendMessage','saveChat','saveVariables','setWorldInfo','inject','fetch','XMLHttpRequest','WebSocket','importScripts']) {
    base[name] = () => { blocked(name); throw new Error(`不支持宿主操作：${name}`); };
  }
  function macro(text) {
    return text.replace(/{{([^{}]+)}}/g, (_, raw) => {
      const [name, ...args] = raw.split('::');
      if (/^(user|char|name1|name2)$/i.test(name)) return String(base[name.toLowerCase()] || '');
      if (/^(getvar|getglobalvar)$/i.test(name)) return String(read(args.join('::'), name.toLowerCase() === 'getglobalvar' ? {scope:'global'} : {scope:'local'}) ?? '');
      if (/^(setvar|setglobalvar|incvar|decvar|addvar)$/i.test(name)) { blocked(`宏 ${name}`); return ''; }
      throw new Error(`未支持的宏：${name}`);
    });
  }
  const compartment = new Compartment({ ...base });
  async function render(item, stack = [], extra = {}) {
    const id = `${item.bookUid || item.bookName}:${item.uid ?? item.title}`;
    const chain = [...stack, {id, bookName:item.bookName || '', title:item.title || '未命名条目'}];
    try {
      if (stack.some(row => row.id === id)) throw failure('EJS_CYCLE', '世界书循环引用', chain);
      if (lifecycleEntry(item)) throw failure('EJS_LIFECYCLE', '正文生命周期控制条目不执行', chain);
      const readEntry = async (book, title, extras = {}) => {
        if (title == null || typeof title === 'object' && !(title instanceof RegExp)) { extras = title || {}; title = book; book = null; }
        const found = entries.find(e => (!book || e.bookName === book || e.bookUid === book)
          && (typeof title === 'number' ? e.uid === title : title instanceof RegExp ? title.test(e.title) : e.title === title));
        if (!found) throw failure('EJS_DEPENDENCY', '依赖条目不存在或已被排除', chain);
        return render(found, chain, extras);
      };
      const context = { ...base, ...extra, world_info: readonly({ ...item, comment: item.title, world: item.bookName }, 'world_info'),
        getwi: readEntry, getWorldInfo: readEntry, include: readEntry };
      // EJS compiler runs on trusted options; ONLY its generated function executes
      // inside the compartment. No unsafe lodash template/mixin/runInContext export.
      const content = macro(item.content);
      const template = new ejs.Template(content, {compileDebug:false, _with:false});
      try { template.generateSource(); }
      catch { throw failure('EJS_TRANSFORM', '代码转换失败：EJS 标签或语法无效', chain); }
      const names = Object.keys(context).filter(k => /^[A-Za-z_$][\w$]*$/.test(k));
      const compiled = `(async function(locals, escapeFn) { const {${names.join(',')}} = locals;
        let __output = ''; function __append(s) { if (s != null) __output += s; } const print = __append;
        ${template.source}\n return __output; })`;
      let transformed;
      try {
        transformed = evadeCensorSync(compiled, {
          sourceType:'script',
          customVisitor(path) {
            // Changing a tag's raw strings or interpolation count is observable.
            // Endo intentionally leaves these intact; report the limitation here.
            if (path.node.type === 'TaggedTemplateExpression'
              && path.node.quasi.quasis.some(q => /<!--|-->|import\s*\(/.test(q.value.raw))) {
              throw failure('EJS_TAGGED_TEMPLATE', '代码转换失败：带标签模板中的 HTML 注释或 import 文本暂不支持', chain);
            }
          },
        }).code;
      } catch (error) {
        if (failures.has(error)) throw error;
        throw failure('EJS_TRANSFORM', '代码转换失败：JavaScript 语法或转换形式不受支持', chain);
      }
      const fn = compartment.evaluate(transformed);
      return await fn.call(context, context, escape, readEntry);
    } catch (error) {
      if (failures.has(error)) throw error;
      throw failure('EJS_EXECUTION', executionReason(error), chain);
    }
  }
  try { return { text: await render(entry), diagnostics }; }
  catch (error) {
    const detail = failures.get(error);
    const reason = detail.chain.length > 1
      ? `依赖条目失败（${detail.chain.map(row => [row.bookName,row.title].filter(Boolean).join(' / ')).join(' → ')}）：${detail.reason}`
      : detail.reason;
    return { text:null, diagnostics:[...diagnostics, {...detail, kind:'skipped', reason}] };
  }
}
