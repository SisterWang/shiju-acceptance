import { shijuError } from '../../errors.js';
import { assertChatScope } from '../../chatScope.js';
import { cloneJson } from '../../plain.js';
import { loadWorld, saveWorld } from '../../store/index.js';
import { normalizeUsage } from '../../store/schema.js';
import { applyEvolutionPatch } from '../evolve/patch.js';
import { isKnown, synchronizeKnowledge } from '../events.js';
import { minSubset } from './subset.js';
import { preserveCurrentEdits, protectRerunPatch } from './preserveEdits.js';

/**
 * M-Commit. The only successful submit.
 * Promoting lastEvolutionCheckpoint and appending evolutionLog both happen in this function.
 * Failures must not call it. Reconcile, evolve, and the panel must not append the log.
 */

const MAX_EVOLUTION_LOG = 8;

export function register() {}

export async function commitEvolutionSuccess(pending) {
  if (!pending || pending.ok !== true) {
    throw shijuError('SHIJU_COMMIT_REFUSED', '失败的推演不能提交');
  }
  if (!pending.baseWorld || !pending.checkpoint || !pending.entry?.id || !pending.chatScope) {
    throw shijuError('SHIJU_COMMIT_REFUSED', '成功提交缺少草稿');
  }
  assertChatScope(pending.chatScope);
  const saved = loadWorld();
  if (!saved?.plugin?.enabled) {
    throw shijuError('SHIJU_COMMIT_REFUSED', '世界未启用，不能提交推演');
  }

  const next = cloneJson(pending.baseWorld);
  if (pending.preferencesSnapshot) next.appliedPreferences = cloneJson(pending.preferencesSnapshot);
  const patch = pending.preserveEditsFrom ? protectRerunPatch(pending.patch || {}, pending.preserveEditsFrom) : pending.patch || {};
  applyEvolutionPatch(next, patch, {
    evolutionId: pending.entry.id,
    dayIndex: pending.entry.dayIndexAfter,
    evidence: '推演',
    evidenceText: pending.evidenceText || '',
  });
  if (pending.preserveEditsFrom) preserveCurrentEdits(next, pending.preserveEditsFrom);
  // Reruns restore a checkpoint, but must not undo later reader controls or
  // protagonist-knowledge overrides. Automatic evidence still comes from this run.
  for (const list of ['events', 'todayChanges']) {
    const previous = new Map((saved[list] || []).map((item) => [item.id, item]));
    for (const item of next[list] || []) {
      const source = previous.get(item.id);
      if (!source) continue;
      for (const key of ['knowledgeOverride', 'viewMode', 'revealed']) {
        if (key in source) item[key] = source[key];
      }
      item.knownMarked = isKnown(item);
    }
  }
  synchronizeKnowledge(next);
  if (pending.storyClock) next.storyClock = cloneJson(pending.storyClock);
  next.meta.lastEvolvedDayIndex = pending.lastEvolvedDayIndex;
  next.meta.evolutionCallCount = (pending.callCount ?? next.meta.evolutionCallCount ?? 0) + 1;
  next.meta.modelCallCount = (pending.modelCount ?? next.meta.modelCallCount ?? 0) + 1;
  next.meta.sources = {
    memory: pending.memory ?? next.meta.sources?.memory ?? null,
    mvu: typeof pending.mvu === 'boolean' ? pending.mvu : Boolean(next.meta.sources?.mvu),
    truncated: Boolean(pending.truncated),
    softWarn: Boolean(pending.softWarn),
  };
  const usage = normalizeUsage(pending.usage);
  if (usage) next.meta.usage = usage;
  next.meta.clockHint = '';
  next.dayBuffer = { items: [] };
  if (pending.inputBoundary) next.processedInput = cloneJson(pending.inputBoundary);
  next.userCorrections = (next.userCorrections || []).map((item) => ({ ...item, consumed: true }));
  next.meta.inputHint = '';

  const checkpoint = cloneJson(pending.checkpoint);
  if(pending.replayInput) checkpoint.replayInput=cloneJson(pending.replayInput);
  checkpoint.evolutionId = pending.entry.id;
  checkpoint.evolutionInputDigest = typeof pending.digest === 'string' ? pending.digest : '';
  const scan = normalizeWorldbookScan(pending.worldbookScan);
  if (scan) checkpoint.worldbookScan = scan;
  next.lastEvolutionCheckpoint = checkpoint;
  if (scan?.nextDiscovery) next.worldbookDiscovery = cloneJson(scan.nextDiscovery);

  const evolutionLog = Array.isArray(next.evolutionLog) ? next.evolutionLog.slice() : [];
  const entry = {
    id: pending.entry.id,
    dayIndexAfter: pending.entry.dayIndexAfter,
    tipFloor: pending.entry.tipFloor,
    tipSwipeId: pending.entry.tipSwipeId ?? 0,
    tipTimeFingerprint: pending.entry.tipTimeFingerprint ?? '',
    worldAfter: null,
  };
  entry.worldAfter = minSubset(next);
  // 全插件只有下一行会追加演进日志。
  evolutionLog.push(entry);
  next.evolutionLog = evolutionLog.length > MAX_EVOLUTION_LOG
    ? evolutionLog.slice(evolutionLog.length - MAX_EVOLUTION_LOG)
    : evolutionLog;

  return saveWorld(next, pending.chatScope);
}

function normalizeWorldbookScan(value) {
  if (!value || typeof value !== 'object') return null;
  const scanWords = Array.isArray(value.scanWords)
    ? value.scanWords.map((word) => String(word || '').trim()).filter(Boolean)
    : [];
  const cursor = typeof value.cursor === 'number' && Number.isFinite(value.cursor) && value.cursor >= 0
    ? Math.floor(value.cursor)
    : 0;
  return {
    cursor,
    dayDelta: Math.max(1, Math.floor(Number(value.dayDelta) || 1)),
    k: Math.max(0, Math.floor(Number(value.k) || 0)),
    rendered:cloneJson(value.rendered || null),
    scanWords, discoveryKeys:Array.isArray(value.discoveryKeys) ? value.discoveryKeys : [], nextDiscovery:cloneJson(value.nextDiscovery || null),
  };
}
