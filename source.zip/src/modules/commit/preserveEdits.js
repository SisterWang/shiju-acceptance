import { cloneJson } from '../../plain.js';

const KINDS = ['regions', 'factions', 'orgs', 'events', 'todayChanges', 'facts'];
const correctionKind = kind => ({region:'regions', faction:'factions', org:'orgs', event:'events', todayChange:'todayChanges'})[kind] || kind;

function protectedRecords(current, kind) {
  const pending = new Set((current.userCorrections || [])
    .filter(item => !item.consumed && correctionKind(item.kind) === kind).map(item => item.id));
  return (current[kind] || []).filter(item => item.manualMaintained || pending.has(item.id));
}

/** Discard historical updates to protected records before archive side effects run. */
export function protectRerunPatch(patch, current) {
  const safe = {...patch};
  for (const kind of KINDS) {
    if (!Array.isArray(safe[kind])) continue;
    const protectedItems = protectedRecords(current, kind);
    safe[kind] = safe[kind].filter(item => !protectedItems.some(row =>
      (item.id && item.id === row.id) ||
      (item.name && [row.name, ...(row.aliases || [])].includes(item.name)) ||
      (item.title && item.title === row.title) || (item.text && item.text === row.text)));
  }
  return safe;
}

/** A rerun recalculates model output, not edits made after its checkpoint. */
export function preserveCurrentEdits(target, current) {
  const references = [];
  for (const kind of KINDS) {
    target[kind] ||= [];
    for (const item of protectedRecords(current, kind)) {
      const index = target[kind].findIndex(row => row.id === item.id);
      if (index < 0) target[kind].push(cloneJson(item));
      else target[kind][index] = cloneJson(item);
      references.push(item);
    }
  }
  // A new manual organization may refer to an entity absent from the old checkpoint.
  const ids = new Set(KINDS.flatMap(kind => target[kind].map(item => item.id)));
  const originals = new Map(KINDS.flatMap(kind => (current[kind] || []).map(item => [item.id, {kind, item}])));
  for (let i = 0; i < references.length; i++) {
    const item = references[i];
    for (const ref of [item.regionRef, item.linkedEventId, item.sourceEventId, item.mergedInto, ...(item.relatedRefs || [])]) {
      if (!ref || ids.has(ref) || !originals.has(ref)) continue;
      const source = originals.get(ref);
      target[source.kind].push(cloneJson(source.item));
      ids.add(ref);
      references.push(source.item);
    }
  }
}
