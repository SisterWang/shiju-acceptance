import { cloneJson } from '../../plain.js';
import { normalizeAppliedPreferences } from '../../preferences.js';

/** Minimum world copy stored in a checkpoint or a log anchor. No nested log. */
export function minSubset(world) {
  const sources = world?.meta?.sources || {};
  return {
    appliedPreferences: normalizeAppliedPreferences(world?.appliedPreferences),
    processedInput: cloneJson(world?.processedInput ?? null),
    userCorrections: cloneJson(world?.userCorrections || []),
    storyClock: cloneJson(world?.storyClock || {}),
    protagonistFocus: {
      locationGuess: world?.protagonistFocus?.locationGuess ?? null,
    },
    regions: cloneJson(world?.regions || []),
    orgs: cloneJson(world?.orgs || []),
    factions: cloneJson(world?.factions || []),
    events: cloneJson(world?.events || []),
    facts: cloneJson(world?.facts || []),
    todayChanges: cloneJson(world?.todayChanges || []),
    timeline: cloneJson(world?.timeline || []),
    dayBuffer: cloneJson(world?.dayBuffer || { items: [] }),
    meta: {
      lastEvolvedDayIndex: world?.meta?.lastEvolvedDayIndex ?? null,
      evolutionCallCount: world?.meta?.evolutionCallCount ?? 0,
      builtFingerprint: world?.meta?.builtFingerprint ?? null,
      modelCallCount: world?.meta?.modelCallCount ?? 0,
      errorCount: world?.meta?.errorCount ?? 0,
      sources: {
        memory: typeof sources.memory === 'string' ? sources.memory : null,
        mvu: Boolean(sources.mvu),
        truncated: Boolean(sources.truncated),
        softWarn: Boolean(sources.softWarn),
      },
    },
  };
}

/** Copy a snapshot onto a world. Leaves the log, checkpoint, and initial snapshot alone. */
export function applySubset(world, subset) {
  if (!world || !subset) return world;
  world.appliedPreferences = normalizeAppliedPreferences(subset.appliedPreferences);
  world.processedInput = cloneJson(subset.processedInput ?? null);
  world.userCorrections = cloneJson(subset.userCorrections || []);
  if (subset.storyClock) world.storyClock = cloneJson(subset.storyClock);
  if (subset.protagonistFocus) {
    world.protagonistFocus = { locationGuess: subset.protagonistFocus.locationGuess ?? null };
  }
  for (const key of ['regions', 'orgs', 'factions', 'events', 'facts', 'todayChanges', 'timeline']) {
    if (Array.isArray(subset[key])) world[key] = cloneJson(subset[key]);
  }
  if (subset.dayBuffer) world.dayBuffer = cloneJson(subset.dayBuffer);
  if (subset.meta) {
    world.meta.lastEvolvedDayIndex = subset.meta.lastEvolvedDayIndex ?? null;
    if (typeof subset.meta.evolutionCallCount === 'number') world.meta.evolutionCallCount = subset.meta.evolutionCallCount;
    if (typeof subset.meta.modelCallCount === 'number') world.meta.modelCallCount = subset.meta.modelCallCount;
    if (typeof subset.meta.errorCount === 'number') world.meta.errorCount = subset.meta.errorCount;
    if (subset.meta.builtFingerprint) world.meta.builtFingerprint = subset.meta.builtFingerprint;
    if (subset.meta.sources) world.meta.sources = cloneJson(subset.meta.sources);
  }
  return world;
}
