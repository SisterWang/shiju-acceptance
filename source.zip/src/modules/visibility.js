/** Visibility is not message identity. SillyTavern's /hide sets is_system. */
export const physicalMessage = m => !!m && typeof m.mes === 'string';
export const hiddenMessage = m => !!(m?.is_system || m?.hidden || m?.extra?.hidden || m?.extra?.bbs_omit);
export const memoryHidden = m => hiddenMessage(m) && m?.extra?.bbs_hidden === true;
export const manualHidden = m => hiddenMessage(m) && !memoryHidden(m);
export const messageIdentity = m => JSON.stringify([m?.send_date ?? null, m?.name ?? '', !!m?.is_user]);
export function summaryNodes(baibai) {
  return baibai?.injectedHistory?.nodes || baibai?.history?.nodes || [];
}
