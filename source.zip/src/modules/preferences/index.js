import { enqueueEdit } from '../turn.js';
import { loadPreferences, saveChatMetadata } from '../../store/index.js';
import { normalizePreferences, validatePreferences } from '../../preferences.js';

/** Preferences are chat metadata, independent of whether a world has been built. */
export function saveEvolutionPreferences(request = {}) {
  return enqueueEdit(async (scope) => {
    const next = { ...loadPreferences(), ...request.preferences };
    validatePreferences(next);
    const preferences = normalizePreferences(next);
    await saveChatMetadata({ shijuPreferences: preferences }, scope, 'preferences');
    return preferences;
  }, request.chatScope);
}
