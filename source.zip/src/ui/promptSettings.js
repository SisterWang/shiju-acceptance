import { readDiagnostics } from '../diagnostics.js';
import { loadSettings, saveSettings, loadPreferences } from '../store/index.js';
import { saveEvolutionPreferences } from '../modules/preferences/index.js';
import { EVOLUTION_PRESETS, effectivePreferences, preferencesPending } from '../preferences.js';
import { BAIBAI_JAILBREAK } from '../prompts/baibai-jailbreak.js';
import { isWorldBusy } from '../modules/turn.js';

const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const radios = (name, items, selected, disabled = false) => `<div class="sj-prompt-options" role="radiogroup" aria-label="${name === 'sj-pref-mode' ? '演进偏好' : name === 'sj-channel-mode' ? '模型渠道' : '破限提示词模式'}">${items.map(({ id, label }) => `<label><input type="radio" name="${name}" value="${id}"${id === selected ? ' checked' : ''}${disabled ? ' disabled' : ''}>${label}</label>`).join('')}</div>`;
const button = (action, label, disabled = false) => `<button type="button" class="sj-btn sj-btn-sm" data-prompt-action="${action}"${disabled ? ' disabled' : ''}>${label}</button>`;
const feedback = (text, error, id) => text ? `<p id="${id}" class="sj-note${error ? ' sj-prompt-error' : ''}" role="${error ? 'alert' : 'status'}" tabindex="-1">${esc(text)}</p>` : '';

/** Local drafts: the preference editor is chat-bound; the model editor is global. */
export function createPromptSettings({ refresh, getScope }) {
  let prefDraft = null, modelDraft = null, prefSaving = false, advancedOpen = false;
  let prefNotice = '', modelNotice = '', prefError = false, modelError = false, skipCapture = false;
  const ownRefresh = () => { skipCapture = true; refresh(); };
  function capture(body) {
    if (skipCapture) { skipCapture = false; return; }
    const custom = body.querySelector('#sj-preference-text');
    if (prefDraft && custom) prefDraft.customText = custom.value;
    const jailbreak = body.querySelector('#sj-jailbreak-text');
    if (modelDraft?.jailbreakMode === 'custom' && jailbreak) modelDraft.customText = jailbreak.value;
    for (const field of ['endpoint','customModel','apiKey']) {
      const input = body.querySelector(`[data-channel-field="${field}"]`);
      if (modelDraft && input) modelDraft[field] = input.value;
    }
    const length = body.querySelector('#sj-response-length');
    if (modelDraft && length) modelDraft.lengthText = length.value;
  }
  function chatChanged() {
    prefDraft = null; prefSaving = false; prefNotice = ''; prefError = false;
  }
  function render(world, busy) {
    const prefs = prefDraft || loadPreferences();
    const preset = EVOLUTION_PRESETS.find((item) => item.id === prefs.mode);
    const disabled = busy || prefSaving;
    let pending = false;
    try { pending = preferencesPending(world, effectivePreferences(loadPreferences())); } catch { /* invalid imported preference can be edited */ }
    const prefBody = prefDraft ? `${radios('sj-pref-mode', [...EVOLUTION_PRESETS, { id: 'custom', label: '自定义' }], prefs.mode, disabled)}
      ${prefs.mode === 'custom' ? `<label class="sj-ts-extra-label" for="sj-preference-text">自定义演进偏好</label><textarea id="sj-preference-text" rows="6" aria-describedby="sj-preference-help"${disabled ? ' disabled' : ''}>${esc(prefs.customText)}</textarea><p id="sj-preference-help" class="sj-note">完全替换内置方向。既有事实、隐秘证据和事件保存规则仍然适用。</p>` : `<p class="sj-note">${esc(preset?.text)}</p>`}
      <div class="sj-acts">${button('pref-save', prefSaving ? '保存中…' : '保存偏好', disabled)}${button('pref-cancel', '取消', prefSaving)}</div>`
      : `<p class="sj-note">当前：${esc(preset?.label || '自定义')}</p><div class="sj-acts">${button('pref-edit', '编辑演进偏好', disabled)}</div>`;
    const saved = loadSettings().model;
    const model = modelDraft || saved;
    const modelBody = modelDraft ? `${radios('sj-jailbreak-mode', [{ id: 'builtin', label: '内置' }, { id: 'custom', label: '自定义' }, { id: 'off', label: '关闭' }], model.jailbreakMode)}
      ${model.jailbreakMode === 'off' ? '<p class="sj-note">不附加破限提示词。</p>' : `<label class="sj-ts-extra-label" for="sj-jailbreak-text">${model.jailbreakMode === 'builtin' ? '柏宝书内置原文（只读）' : '自定义破限提示词'}</label><textarea id="sj-jailbreak-text" rows="10" spellcheck="false"${model.jailbreakMode === 'builtin' ? ' readonly' : ''}>${esc(model.jailbreakMode === 'builtin' ? BAIBAI_JAILBREAK : model.customText)}</textarea>`}
      <p class="sj-field-label">世局模型渠道 · 全局</p>
      ${radios('sj-channel-mode', [{id:'follow',label:'跟随酒馆'},{id:'custom',label:'自定义渠道'}],model.channelMode)}
      ${model.channelMode === 'custom' ? `<label class="sj-ts-extra-label" for="sj-channel-url">兼容 API 地址</label><input id="sj-channel-url" data-channel-field="endpoint" type="url" value="${esc(model.endpoint)}" placeholder="https://example.com/v1">
        <label class="sj-ts-extra-label" for="sj-channel-model">模型名称</label><input id="sj-channel-model" data-channel-field="customModel" type="text" value="${esc(model.customModel)}" autocomplete="off">
        <label class="sj-ts-extra-label" for="sj-channel-key">密钥</label><input id="sj-channel-key" data-channel-field="apiKey" type="password" value="${esc(model.apiKey)}" autocomplete="off">
        <p class="sj-note">经酒馆后端转发；只用于世局，不写入聊天导出。切换渠道会保留这些配置。</p>` : ''}
      <label class="sj-ts-extra-label" for="sj-response-mode">模型回复长度</label>
      <select id="sj-response-mode"><option value="follow"${model.lengthMode === 'follow' ? ' selected' : ''}>跟随酒馆</option><option value="custom"${model.lengthMode === 'custom' ? ' selected' : ''}>独立设置</option></select>
      ${model.lengthMode === 'custom' ? `<label class="sj-ts-extra-label" for="sj-response-length">最大输出 token</label><input id="sj-response-length" type="number" min="1" step="1" value="${esc(model.lengthText)}"><p class="sj-note">请填写接口支持的正整数；请求失败时不会自动调整或重试。</p>` : ''}
      <div class="sj-acts">${button('model-save', '保存设置')}${button('model-reset', '恢复默认提示词')}${button('model-cancel', '取消')}</div>`
      : `<p class="sj-note">渠道：${saved.channelMode === 'custom' ? '自定义' : '跟随酒馆'} · 破限提示词：${({ builtin: '内置', custom: '自定义', off: '关闭' })[saved.jailbreakMode]} · 回复长度：${saved.responseLength == null ? '跟随酒馆' : esc(saved.responseLength) + ' token'}</p>${button('model-edit', '编辑模型设置')}`;
    const diagnostics = readDiagnostics();
    const diagnosis = diagnostics.length ? `<details class="sj-field"><summary>资料诊断 · ${diagnostics.length} 项</summary><ul>${diagnostics.map(d => `<li>${esc([d.bookName,d.title].filter(Boolean).join(' · '))}：${esc(d.reason)}</li>`).join('')}</ul></details>` : '';
    return `${diagnosis}<div class="sj-field sj-prompt-settings" data-preference-section>
      <p class="sj-field-label">演进偏好 · 当前聊天</p>${prefBody}
      ${disabled ? '<p class="sj-note">正在演进，完成后可修改</p>' : ''}
      ${pending ? '<p class="sj-note" data-preference-pending>演进偏好已修改，可立即演进一次</p>' : ''}
      <p class="sj-note">保存不会调用模型。偏好随这则聊天保存，切换聊天不会串用。</p>
      ${feedback(prefNotice, prefError, 'sj-pref-feedback')}
    </div>
    <details class="sj-field sj-prompt-settings" data-model-advanced${advancedOpen ? ' open' : ''}>
      <summary>模型高级设置 · 全局</summary><p class="sj-note">用于世局后台调用，不改变主聊天注入。等待期间的修改从后续请求生效。</p>
      ${modelBody}${feedback(modelNotice, modelError, 'sj-model-feedback')}
    </details>`;
  }
  function bind(body) {
    body.querySelector('[data-model-advanced]')?.addEventListener('toggle', (event) => { advancedOpen = event.currentTarget.open; });
    body.querySelectorAll('[name="sj-pref-mode"]').forEach((input) => input.addEventListener('change', () => {
      capture(body); prefDraft.mode = input.value; prefNotice = ''; ownRefresh();
    }));
    body.querySelectorAll('[name="sj-jailbreak-mode"]').forEach((input) => input.addEventListener('change', () => {
      capture(body); modelDraft.jailbreakMode = input.value;
      if (input.value === 'custom' && !modelDraft.customText) modelDraft.customText = BAIBAI_JAILBREAK;
      modelNotice = ''; ownRefresh();
    }));
    body.querySelectorAll('[name="sj-channel-mode"]').forEach(input => input.addEventListener('change', () => { capture(body); modelDraft.channelMode=input.value; ownRefresh(); }));
    body.querySelector('#sj-response-mode')?.addEventListener('change', (event) => {
      capture(body); modelDraft.lengthMode = event.target.value; ownRefresh();
    });
    body.querySelectorAll('[data-prompt-action]').forEach((el) => el.addEventListener('click', async () => {
      capture(body);
      const action = el.dataset.promptAction;
      if (action.startsWith('pref-')) {
        const scope = getScope();
        try {
          if (action === 'pref-edit') { prefDraft = loadPreferences(); prefNotice = ''; prefError = false; }
          if (action === 'pref-cancel') { prefDraft = null; prefNotice = ''; prefError = false; }
          if (action === 'pref-save') {
            if (isWorldBusy()) throw new Error('正在演进，完成后可修改');
            const preferences = { ...prefDraft }; prefSaving = true; ownRefresh();
            await saveEvolutionPreferences({ preferences, chatScope: scope });
            if (scope !== getScope()) return;
            prefDraft = null; prefNotice = '演进偏好已保存'; prefError = false;
          }
        } catch (error) {
          if (scope !== getScope()) return;
          prefNotice = error.message; prefError = true;
        } finally {
          if (scope === getScope()) { prefSaving = false; ownRefresh(); if (prefError) body.querySelector('#sj-pref-feedback')?.focus(); }
        }
        return;
      }
      try {
        if (action === 'model-edit') {
          const saved = loadSettings().model;
          modelDraft = { ...saved, lengthMode: saved.responseLength == null ? 'follow' : 'custom', lengthText: String(saved.responseLength ?? 16384) };
          modelNotice = '';
        }
        if (action === 'model-cancel') { modelDraft = null; modelNotice = ''; }
        if (action === 'model-reset') { modelDraft.jailbreakMode = 'builtin'; modelDraft.customText = BAIBAI_JAILBREAK; modelNotice = ''; }
        if (action === 'model-save') {
          const { lengthMode, lengthText, ...model } = modelDraft;
          model.responseLength = lengthMode === 'follow' ? null : Number(lengthText);
          saveSettings({ model }); modelDraft = null; modelNotice = '全局模型设置已保存';
        }
        modelError = false;
      } catch (error) { modelNotice = error.message; modelError = true; }
      ownRefresh(); if (modelError) body.querySelector('#sj-model-feedback')?.focus();
    }));
  }
  return { render, bind, capture, chatChanged };
}
