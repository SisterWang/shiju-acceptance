import { settingsCard } from './settingsLayout.js';
import { readDiagnostics } from '../diagnostics.js';
import { loadSettings, saveSettings, loadPreferences } from '../store/index.js';
import { saveEvolutionPreferences } from '../modules/preferences/index.js';
import { EVOLUTION_PRESETS, effectivePreferences, preferencesPending } from '../preferences.js';
import { BAIBAI_JAILBREAK } from '../prompts/baibai-jailbreak.js';
import { isWorldBusy } from '../modules/turn.js';
import { getHost } from '../host.js';
import { testCustomConnection } from '../modules/model/index.js';
import { createRequestHistory } from './requestHistory.js';

const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const radios = (name, items, selected, disabled = false) => `<div class="sj-prompt-options" role="radiogroup" aria-label="${name === 'sj-pref-mode' ? '演进偏好' : name === 'sj-channel-mode' ? '模型渠道' : '破限提示词模式'}">${items.map(({ id, label }) => `<label><input type="radio" name="${name}" value="${id}"${id === selected ? ' checked' : ''}${disabled ? ' disabled' : ''}>${label}</label>`).join('')}</div>`;
const button = (action, label, disabled = false) => `<button type="button" class="sj-btn sj-btn-sm" data-prompt-action="${action}"${disabled ? ' disabled' : ''}>${label}</button>`;
const feedback = (text, error, id) => text ? `<p id="${id}" class="sj-note${error ? ' sj-prompt-error' : ''}" role="${error ? 'alert' : 'status'}" tabindex="-1">${esc(text)}</p>` : '';

/** Local drafts: the preference editor is chat-bound; the model editor is global. */
export function createPromptSettings({ refresh, getScope, getSection, onNavigate }) {
  const history = createRequestHistory({ refresh, getScope, onNavigate });
  let prefDraft = null, modelDraft = null, prefSaving = false, advancedOpen = false;
  let prefNotice = '', modelNotice = '', prefError = false, modelError = false, skipCapture = false;
  let modelList = [], listPending = false, listGeneration = 0, testController = null;
  let testRevision = 0, testNotice = '', testError = false;
  const ownRefresh = () => { skipCapture = true; refresh(); };
  function invalidateTest(body, clear = false) {
    testRevision++;
    testNotice = !clear && (testNotice || testController) ? '配置已修改，请重新测试连接' : '';
    testError = false;
    const feedbackArea = body.querySelector('[data-connection-feedback]');
    if (feedbackArea) feedbackArea.innerHTML = feedback(testNotice, testError, 'sj-test-feedback');
  }
  function capture(body) {
    if (skipCapture) { skipCapture = false; return; }
    const custom = body.querySelector('#sj-preference-text');
    if (prefDraft && custom) prefDraft.customText = custom.value;
    const jailbreak = body.querySelector('#sj-jailbreak-text');
    if (modelDraft?.jailbreakMode === 'custom' && jailbreak) modelDraft.customText = jailbreak.value;
    for (const field of ['endpoint','customModel','apiKey']) {
      const input = body.querySelector(`[data-channel-field="${field}"]`);
      if (modelDraft && input) modelDraft[field] = input.value;
    }
    const length = body.querySelector('#sj-response-length');
    if (modelDraft && length) modelDraft.lengthText = length.value;
  }
  function chatChanged() {
    prefDraft = null; prefSaving = false; prefNotice = ''; prefError = false;
  }
  function render(world, busy) {
    history.setActive(getSection() === 'history');
    const prefs = prefDraft || loadPreferences();
    const preset = EVOLUTION_PRESETS.find(item => item.id === prefs.mode);
    const disabled = busy || prefSaving;
    let pending = false;
    try { pending = preferencesPending(world, effectivePreferences(loadPreferences())); } catch { /* editable imported value */ }
    const preference = settingsCard('演进偏好', '当前聊天', `
      ${prefDraft ? `${radios('sj-pref-mode', [...EVOLUTION_PRESETS, {id:'custom',label:'自定义'}], prefs.mode, disabled)}
        ${prefs.mode === 'custom' ? `<label for="sj-preference-text">自定义方向</label><textarea id="sj-preference-text" rows="5" aria-describedby="sj-preference-help"${disabled ? ' disabled' : ''}>${esc(prefs.customText)}</textarea><p id="sj-preference-help" class="sj-note">完全替换内置方向；事实一致性等基础规则仍然保留。</p>` : `<p class="sj-setting-explanation">${esc(preset?.text)}</p>`}
        <div class="sj-setting-actions">${button('pref-save', prefSaving ? '保存中…' : '保存偏好', disabled)}${button('pref-cancel', '取消', prefSaving)}</div>`
        : `<div class="sj-setting-row"><div><strong>${esc(preset?.label || '自定义')}</strong><p class="sj-note">${prefs.mode === 'custom' ? '使用你保存的自定义方向。' : esc(preset?.text)}</p></div>${button('pref-edit','编辑',disabled)}</div>`}
      ${disabled ? '<p class="sj-note" role="status">正在演进，完成后可修改</p>' : ''}
      ${pending ? '<p class="sj-setting-explanation" data-preference-pending>演进偏好已修改，可立即演进一次</p>' : ''}
      ${feedback(prefNotice,prefError,'sj-pref-feedback')}`, '决定世界未来的发展倾向。保存不会调用模型。', 'data-preference-section');
    const saved = loadSettings().model, model = modelDraft || saved;
    const promptMode = ({builtin:'柏宝书内置',custom:'自定义',off:'关闭'})[model.jailbreakMode];
    const channelFields = modelDraft ? `
      ${radios('sj-channel-mode',[{id:'follow',label:'跟随酒馆'},{id:'custom',label:'自定义渠道'}],model.channelMode)}
      ${model.channelMode === 'custom' ? `<div class="sj-form-fields">
        <div class="sj-form-field"><label for="sj-channel-url">API 地址</label><input id="sj-channel-url" data-channel-field="endpoint" type="url" value="${esc(model.endpoint)}" placeholder="https://example.com/v1"></div>
        <div class="sj-form-field"><label for="sj-channel-key">API 密钥</label><input id="sj-channel-key" data-channel-field="apiKey" type="password" value="${esc(model.apiKey)}" autocomplete="off" placeholder="渠道不需要时可留空"></div>
        <div class="sj-form-field"><label for="sj-channel-model">模型</label><div class="sj-input-action"><input id="sj-channel-model" data-channel-field="customModel" type="text" value="${esc(model.customModel)}" autocomplete="off" placeholder="输入模型名称">${button('model-list',listPending ? '获取中…' : '获取模型',listPending)}</div></div>
        ${modelList.length ? `<div class="sj-form-field"><label for="sj-model-filter">搜索并选择模型</label><input id="sj-model-filter" type="search" list="sj-model-options" placeholder="输入关键词筛选" autocomplete="off"><datalist id="sj-model-options">${modelList.map(id=>`<option value="${esc(id)}"></option>`).join('')}</datalist></div>` : ''}
        <label class="sj-setting-toggle" for="sj-channel-stream"><span><strong>流式传输</strong><small>显示接收进度，完整响应后再更新世界账。</small></span><input id="sj-channel-stream" type="checkbox"${model.stream ? ' checked' : ''}></label>
        <div class="sj-setting-test">${button(testController ? 'model-test-cancel' : 'model-test',testController ? '取消测试' : '测试连接')}<p class="sj-note">使用当前草稿发送一次短请求，可能收费。</p><div data-connection-feedback>${feedback(testNotice,testError,'sj-test-feedback')}</div></div>
      </div>` : '<p class="sj-setting-explanation">使用酒馆当前连接与模型。仅发送世局请求，不改变正文生成设置。</p>'}
      <div class="sj-form-field sj-setting-divider"><label for="sj-response-mode">回复长度</label><select id="sj-response-mode"><option value="follow"${model.lengthMode === 'follow' ? ' selected' : ''}>跟随酒馆</option><option value="custom"${model.lengthMode === 'custom' ? ' selected' : ''}>独立上限</option></select>
      ${model.lengthMode === 'custom' ? `<label for="sj-response-length">最大输出 token</label><input id="sj-response-length" type="number" min="1" step="1" value="${esc(model.lengthText)}">` : ''}<p class="sj-note">仅作用于世局当前请求，不修改酒馆或其他插件的长度。</p></div>`
      : `<dl class="sj-setting-summary"><div><dt>渠道</dt><dd>${saved.channelMode === 'custom' ? '自定义渠道' : '跟随酒馆'}</dd></div>${saved.channelMode === 'custom' ? `<div><dt>模型</dt><dd>${esc(saved.customModel || '尚未填写')}</dd></div><div><dt>传输</dt><dd>${saved.stream ? '流式' : '非流式'}</dd></div>` : ''}<div><dt>回复长度</dt><dd>${saved.responseLength == null ? '跟随酒馆' : esc(saved.responseLength) + ' token'}</dd></div><div><dt>提示词</dt><dd>${promptMode}</dd></div></dl><div class="sj-setting-actions">${button('model-edit','编辑模型设置')}</div>`;
    const promptFields = modelDraft ? `<details class="sj-settings-disclosure" data-model-advanced${advancedOpen ? ' open' : ''}>
      <summary><span>破限提示词</span><span class="sj-disclosure-value">${promptMode}</span></summary>
      <div class="sj-disclosure-body"><p class="sj-note">独立添加到世局请求，不写入主聊天。</p>
      ${radios('sj-jailbreak-mode',[{id:'builtin',label:'内置'},{id:'custom',label:'自定义'},{id:'off',label:'关闭'}],model.jailbreakMode)}
      ${model.jailbreakMode === 'off' ? '<p class="sj-note">不附加破限提示词。</p>' : `<label for="sj-jailbreak-text">${model.jailbreakMode === 'builtin' ? '内置原文 · 只读' : '自定义文本'}</label><textarea id="sj-jailbreak-text" rows="7" spellcheck="false"${model.jailbreakMode === 'builtin' ? ' readonly' : ''}>${esc(model.jailbreakMode === 'builtin' ? BAIBAI_JAILBREAK : model.customText)}</textarea>`}
      ${button('model-reset','恢复默认提示词')}<p class="sj-note">重置仅修改草稿，保存后生效。</p></div></details>` : '';
    const modelMarkup = settingsCard('模型连接', '全局', `<div class="sj-prompt-settings">${channelFields}${promptFields}${feedback(modelNotice,modelError,'sj-model-feedback')}
      ${modelDraft ? `<div class="sj-setting-actions sj-setting-save">${button('model-save','保存设置')}${button('model-cancel','取消')}</div>` : ''}</div>`, '用于建世界、演进和 AI 修订。配置在所有聊天中共用。');
    const diagnostics = readDiagnostics();
    const diagnosis = settingsCard('资料诊断','本次读取',diagnostics.length ? `<details class="sj-settings-disclosure"><summary>查看 ${diagnostics.length} 项诊断</summary><ul class="sj-diagnostic-list">${diagnostics.map(d=>`<li><strong>${esc([d.bookName,d.title].filter(Boolean).join(' · '))}</strong><p>${esc(d.reason)}</p></li>`).join('')}</ul></details>` : '<p class="sj-note">暂无需要处理的资料诊断。</p>','世界书读取或模板执行遇到问题时，会在这里说明原因。');
    return {preference, model:modelMarkup, diagnostics:diagnosis, history:history.render()};
  }
  function bind(body) {
    history.bind(body);
    if (history.isOpen()) return;
    body.querySelector('[data-model-advanced]')?.addEventListener('toggle', (event) => { advancedOpen = event.currentTarget.open; });
    body.querySelectorAll('[name="sj-pref-mode"]').forEach((input) => input.addEventListener('change', () => {
      capture(body); prefDraft.mode = input.value; prefNotice = ''; ownRefresh();
    }));
    body.querySelectorAll('[name="sj-jailbreak-mode"]').forEach((input) => input.addEventListener('change', () => {
      capture(body); modelDraft.jailbreakMode = input.value;
      if (input.value === 'custom' && !modelDraft.customText) modelDraft.customText = BAIBAI_JAILBREAK;
      modelNotice = ''; ownRefresh();
    }));
    body.querySelectorAll('[name="sj-channel-mode"]').forEach(input => input.addEventListener('change', () => { capture(body); modelDraft.channelMode=input.value; invalidateTest(body); ownRefresh(); }));
    body.querySelector('#sj-channel-stream')?.addEventListener('change', event => { modelDraft.stream = event.target.checked; invalidateTest(body); });
    for (const field of ['endpoint','apiKey','customModel']) body.querySelector(`[data-channel-field="${field}"]`)?.addEventListener('input', () => invalidateTest(body));
    body.querySelector('#sj-response-length')?.addEventListener('input', () => invalidateTest(body));
    for (const field of ['endpoint','apiKey']) body.querySelector(`[data-channel-field="${field}"]`)?.addEventListener('input', () => { listGeneration++; modelList = []; body.querySelector('#sj-model-options')?.replaceChildren(); });
    body.querySelector('#sj-model-filter')?.addEventListener('change', event => { if (modelList.includes(event.target.value)) { modelDraft.customModel = event.target.value; body.querySelector('#sj-channel-model').value = event.target.value; invalidateTest(body); } });
    body.querySelector('#sj-response-mode')?.addEventListener('change', (event) => {
      capture(body); modelDraft.lengthMode = event.target.value; invalidateTest(body); ownRefresh();
    });
    body.querySelectorAll('[data-prompt-action]').forEach((el) => el.addEventListener('click', async () => {
      capture(body);
      const action = el.dataset.promptAction;
      if (action.startsWith('pref-')) {
        const scope = getScope();
        try {
          if (action === 'pref-edit') { prefDraft = loadPreferences(); prefNotice = ''; prefError = false; }
          if (action === 'pref-cancel') { prefDraft = null; prefNotice = ''; prefError = false; }
          if (action === 'pref-save') {
            if (isWorldBusy()) throw new Error('正在演进，完成后可修改');
            const preferences = { ...prefDraft }; prefSaving = true; ownRefresh();
            await saveEvolutionPreferences({ preferences, chatScope: scope });
            if (scope !== getScope()) return;
            prefDraft = null; prefNotice = '演进偏好已保存'; prefError = false;
          }
        } catch (error) {
          if (scope !== getScope()) return;
          prefNotice = error.message; prefError = true;
        } finally {
          if (scope === getScope()) { prefSaving = false; ownRefresh(); if (prefError) body.querySelector('#sj-pref-feedback')?.focus(); }
        }
        return;
      }
      try {
        if (action === 'model-list') {
          const generation = ++listGeneration;
          const snapshot = { endpoint: modelDraft.endpoint, apiKey: modelDraft.apiKey };
          listPending = true; modelNotice = ''; ownRefresh();
          try {
            const models = await getHost().fetchCustomModels(snapshot);
            if (generation !== listGeneration) return;
            modelList = models;
            modelNotice = models.length ? `已获取 ${models.length} 个模型` : '渠道返回空模型列表，请手动填写模型名称'; modelError = false;
          } catch (error) { if (generation === listGeneration) { modelNotice = error.message; modelError = true; } }
          finally { listPending = false; capture(body); ownRefresh(); }
          return;
        }
        if (action === 'model-test-cancel') { testController?.abort(); return; }
        if (action === 'model-test') {
          if (testController) return;
          const { lengthMode, lengthText, ...model } = modelDraft;
          model.responseLength = lengthMode === 'follow' ? null : Number(lengthText);
          const controller = new AbortController(); testController = controller;
          const revision = testRevision;
          testNotice = '正在测试连接…'; testError = false; ownRefresh();
          try {
            const reply = await testCustomConnection(model, {signal:controller.signal});
            if (revision === testRevision) { testNotice = reply.trim() === 'ok' ? '连接测试通过' : '已连通，但回复未按测试要求'; testError = false; }
          } catch (error) { if (revision === testRevision) { testNotice = controller.signal.aborted ? '连接测试已取消' : String(error.message || '连接测试失败').split(model.apiKey || '\0').join('[已隐藏]'); testError = true; } }
          finally { testController = null; capture(body); ownRefresh(); }
          return;
        }
        if (action === 'model-edit') {
          invalidateTest(body, true);
          const saved = loadSettings().model;
          modelDraft = { ...saved, lengthMode: saved.responseLength == null ? 'follow' : 'custom', lengthText: String(saved.responseLength ?? 16384) };
          modelNotice = '';
        }
        if (action === 'model-cancel') { invalidateTest(body, true); listGeneration++; modelList = []; modelDraft = null; modelNotice = ''; }
        if (action === 'model-reset') { modelDraft.jailbreakMode = 'builtin'; modelDraft.customText = BAIBAI_JAILBREAK; modelNotice = ''; }
        if (action === 'model-save') {
          const { lengthMode, lengthText, ...model } = modelDraft;
          model.responseLength = lengthMode === 'follow' ? null : Number(lengthText);
          saveSettings({ model }); invalidateTest(body, true); modelDraft = null; modelNotice = '全局模型设置已保存';
        }
        modelError = false;
      } catch (error) { modelNotice = error.message; modelError = true; }
      ownRefresh(); if (action === 'model-edit') body.scrollTop = 0; if (modelError) body.querySelector('#sj-model-feedback')?.focus();
    }));
  }
  return { render, bind, capture, chatChanged };
}
