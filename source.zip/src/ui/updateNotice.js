import { updates } from '../update.js';
import { RUNNING_VERSION } from '../version.js';

export function mountUpdateNotice(root, { risks, reload = () => location.reload(), tracker = updates }) {
  const notice = document.createElement('section');
  notice.className = 'sj-update-notice'; notice.hidden = true; notice.setAttribute('aria-label','世局更新');
  notice.innerHTML = '<p role="status">世局新版本已下载，刷新页面后生效。</p><div class="sj-acts"><button type="button" class="sj-btn sj-btn-primary" data-refresh-app>刷新生效</button><button type="button" class="sj-btn" data-update-later>稍后</button></div>';
  const dialog = document.createElement('dialog');
  dialog.className = 'sj-reload-dialog'; dialog.setAttribute('aria-labelledby','sj-reload-title');
  dialog.innerHTML = '<h3 id="sj-reload-title">刷新使新版本生效</h3><p data-reload-risk></p><p class="sj-note">整页刷新也可能丢失其他插件的未保存内容，请先保存。</p><div class="sj-acts"><button type="button" class="sj-btn" data-reload-cancel autofocus>稍后</button><button type="button" class="sj-btn sj-btn-primary" data-reload-confirm>确认刷新</button></div>';
  root.append(notice, dialog);
  let returnFocus, riskTimer;
  function paint() {
    const state = tracker.state();
    notice.hidden = !state.pending || state.dismissed;
    const settings = root.querySelector('[data-update-settings]');
    if (settings) {
      settings.innerHTML = '<p class="sj-note">当前运行版本：<span data-running-version></span></p>' + (state.pending ? '<div class="sj-update-inline"><p>新版本已下载，刷新页面后生效。</p><button type="button" class="sj-btn sj-btn-sm" data-refresh-app>刷新生效</button></div>' : '');
      settings.querySelector('[data-running-version]').textContent = RUNNING_VERSION;
    }
  }
  function describe() {
    const risk = risks();
    dialog.querySelector('[data-reload-risk]').textContent = risk.busy
      ? '世局请求或保存仍在进行，或设置保存尚未得到酒馆确认。请等待完成；若酒馆提示保存失败，请先恢复连接。不会自动取消当前操作。'
      : risk.draft ? '世局有尚未保存的编辑、未采用的预览或未保存的请求记录。刷新将丢失这些内容；可以选择稍后，先完成保存。'
      : '刷新整个酒馆页面，载入已下载的新版本。';
    dialog.querySelector('[data-reload-confirm]').disabled = risk.busy;
    return risk;
  }
  root.addEventListener('click', event => {
    const target = event.target.closest('button');
    if (!target) return;
    if (target.hasAttribute('data-update-later')) tracker.dismiss();
    if (target.hasAttribute('data-refresh-app')) {
      returnFocus = target; describe(); if (!dialog.open) { dialog.showModal(); riskTimer = setInterval(describe, 250); }
    }
    if (target.hasAttribute('data-reload-cancel')) dialog.close();
    if (target.hasAttribute('data-reload-confirm') && !describe().busy) reload();
  });
  dialog.addEventListener('close', () => { clearInterval(riskTimer); if (returnFocus?.isConnected) returnFocus.focus(); });
  tracker.subscribe(paint);
  return { paint() { paint(); if (dialog.open) describe(); } };
}
