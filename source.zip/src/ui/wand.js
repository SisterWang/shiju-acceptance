/** Host menu can be created after extensions. One entry, including after replacement. */
export function mountWandEntry(openPanel, doc = document) {
  let entry, ownedContainer;
  const mount = () => {
    const menu = doc.getElementById('extensionsMenu');
    if (!menu) return;
    const existing = doc.getElementById('shiju-wand-entry');
    if (existing && menu.contains(existing)) { entry = existing; return; }
    ownedContainer?.remove();
    const container = doc.createElement('div');
    container.className = 'extension_container';
    ownedContainer = container;
    entry = doc.createElement('button');
    entry.id = 'shiju-wand-entry'; entry.type = 'button'; entry.className = 'list-group-item flex-container flexGap5';
    entry.setAttribute('aria-controls', 'shiju-panel');
    const icon = doc.createElement('i'); icon.className = 'fa-solid fa-earth-asia'; icon.setAttribute('aria-hidden','true');
    const label = doc.createElement('span'); label.textContent = '世局';
    entry.append(icon, label); container.append(entry); menu.append(container);
    entry.addEventListener('click', () => openPanel(entry));
  };
  mount();
  const observer = new MutationObserver(() => {
    if (!entry?.isConnected || !doc.getElementById('extensionsMenu')?.contains(entry)) mount();
  });
  observer.observe(doc.body, { childList: true, subtree: true });
  return () => { observer.disconnect(); ownedContainer?.remove(); };
}
