/** Settings radios. Stored id for 柏宝书 is `baibai`. `auto` means not chosen by hand. */
export const TIME_SOURCE_CHOICES = [
  {
    id: 'shiju',
    label: '世局标签',
    desc: '注入独立时间锚提示；正文标签用正则藏显示层，不真删',
  },
  {
    id: 'custom',
    label: '自定义标签',
    desc: '认你已有的时间标签；只解析、不另注世局时间锚',
  },
  {
    id: 'baibai',
    label: '柏宝书',
    desc: '跟柏宝书正文时间标签',
  },
];

const EXPLICIT = new Set(['shiju', 'custom', 'baibai']);

export function isExplicitTimeSource(mode) {
  return EXPLICIT.has(mode);
}

/**
 * Which radio looks selected.
 * `auto` follows 无柏宝书① / 有则③. A stored ③ falls back on screen when the book is gone.
 * This does not write settings.
 */
export function resolveTimeSourceMode(mode, hasBaibai) {
  if (mode === 'shiju' || mode === 'custom') return mode;
  if (mode === 'baibai') return hasBaibai ? 'baibai' : 'shiju';
  return hasBaibai ? 'baibai' : 'shiju';
}
