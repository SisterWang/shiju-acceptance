/** Settings radios. Stored id for 柏宝书 is `baibai`. `auto` means not chosen by hand. */
export const TIME_SOURCE_CHOICES = [
  {
    id: 'shiju',
    label: '世局标签',
    desc: '由世局提供时间标记，正文中的标记自动隐藏。',
  },
  {
    id: 'custom',
    label: '自定义标签',
    desc: '读取现有的时间标签，不额外添加时间提示。',
  },
  {
    id: 'baibai',
    label: '柏宝书',
    desc: '使用柏宝书在正文中生成的时间标记。',
  },
];

const EXPLICIT = new Set(['shiju', 'custom', 'baibai']);

export function isExplicitTimeSource(mode) {
  return EXPLICIT.has(mode);
}

/**
 * Which radio looks selected.
 * `auto` follows 无柏宝书① / 有则③. A stored ③ falls back on screen when the book is gone.
 * This does not write settings.
 */
export function resolveTimeSourceMode(mode, hasBaibai) {
  if (mode === 'shiju' || mode === 'custom') return mode;
  if (mode === 'baibai') return hasBaibai ? 'baibai' : 'shiju';
  return hasBaibai ? 'baibai' : 'shiju';
}
