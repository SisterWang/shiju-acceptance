/**
 * Local draft for one event or one today-change.
 * Cancel and 弃用 only touch this object. This file does not call the intervene API.
 */

export function planFixClick(dataset = {}) {
  if (dataset.fixDismiss) return { effect: 'drop-draft', action: dataset.fixDismiss };
  if (dataset.fixApply) return { effect: 'apply' };
  if (dataset.fixSave) return { effect: 'save' };
  if (dataset.fixGenerate) return { effect: 'preview' };
  if (dataset.fixMode === 'manual' || dataset.fixMode === 'ai') {
    return { effect: 'mode', mode: dataset.fixMode };
  }
  if (dataset.fixOpen) return { effect: 'open', target: dataset.fixOpen };
  return null;
}

export function parseFixTarget(target) {
  const text = typeof target === 'string' ? target : '';
  const sep = text.indexOf(':');
  if (sep <= 0) return null;
  const kind = text.slice(0, sep);
  const id = text.slice(sep + 1);
  if ((kind !== 'event' && kind !== 'todayChange') || !id) return null;
  return { kind, id };
}

export function openFixDraft(item, kind) {
  return {
    kind,
    id: item.id,
    mode: 'manual',
    stage: 'prompt',
    instruction: '',
    draft: '',
    manualTitle: typeof item.title === 'string' ? item.title : '',
    manualBody: typeof item.body === 'string' ? item.body : '',
    busy: false,
    notice: '',
    error: '',
  };
}

/** 取消 closes the editor. 弃用 returns to the instruction step. Neither writes. */
export function dismissFixDraft(fix, action) {
  if (action === 'discard' && fix) {
    return {
      ...fix,
      stage: 'prompt',
      draft: '',
      notice: '',
      error: '',
      busy: false,
    };
  }
  return null;
}
