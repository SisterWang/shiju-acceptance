import { isSecret, isFactVisible } from '../modules/events.js';
/**
 * Read-only projection of a world ledger for the panel.
 * Drops body text, logs, and checkpoints. Null means there is no ledger.
 */

const EVENT_KINDS = ['macro', 'news', 'secret'];

function cleanText(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function factId(item) {
  return typeof item?.id === 'string' ? item.id : '';
}

/** Unrevealed secrets have no correction entry. Revealed secrets stay editable. */
export function isUnrevealedSecret(item) {
  if (!item || typeof item !== 'object') return false;
  return isSecret(item) && !isFactVisible(item);
}

/** Read one event or today-change off a ledger copy. Does not write. */
export function findFact(world, kind, id) {
  const key = kind === 'event' ? 'events' : kind === 'todayChange' ? 'todayChanges' : '';
  if (!key || typeof id !== 'string' || !id) return null;
  const list = Array.isArray(world?.[key]) ? world[key] : [];
  const item = list.find((entry) => entry && entry.id === id);
  return item && typeof item === 'object' ? item : null;
}

function readClock(world) {
  const clock = world.storyClock && typeof world.storyClock === 'object' ? world.storyClock : {};
  const dateLabel = cleanText(clock.dateLabel);
  const dayIndex = typeof clock.dayIndex === 'number' && Number.isFinite(clock.dayIndex)
    ? clock.dayIndex
    : null;
  const parts = [];
  if (dateLabel) parts.push(dateLabel);
  if (dayIndex != null && dayIndex > 0) parts.push(`D${dayIndex}`);
  return { dateLabel, dayIndex, text: parts.join(' · ') };
}

function readPlugin(world) {
  const plugin = world.plugin && typeof world.plugin === 'object' ? world.plugin : {};
  const frozen = plugin.frozenAt != null;
  const enabled = Boolean(plugin.enabled);
  let text = '未启用';
  if (frozen) text = '已冻结';
  else if (enabled) text = '已启用';
  return { enabled, frozen, text };
}

function readToday(list) {
  const items = Array.isArray(list) ? list : [];
  let secretHidden = 0;
  const titles = [];
  for (const item of items) {
    const kind = item?.kind === 'macro' || item?.kind === 'news' || item?.kind === 'secret'
      ? item.kind
      : '';
    const unrevealedSecret = isUnrevealedSecret(item);
    if (unrevealedSecret) {
      secretHidden += 1;
      titles.push({ id: factId(item), title: '未揭晓的隐秘', kind: 'secret', secret: true, revealed: false });
      continue;
    }
    const title = cleanText(item?.title);
    if (title) {
      titles.push({
        id: factId(item),
        title,
        kind,
        secret: item?.secret === true || kind === 'secret',
        revealed: item?.revealed === true,
      });
    }
  }
  return { total: items.length, secretHidden, titles };
}

function readEntities(list) {
  const items = Array.isArray(list) ? list : [];
  const named = [];
  for (const item of items) {
    const name = cleanText(item?.name);
    if (!name) continue;
    named.push({
      name,
      secret: item?.secret === true && item?.revealed !== true,
    });
  }
  return { total: items.length, items: named };
}

function readEvents(list) {
  const source = Array.isArray(list) ? list : [];
  const items = [];
  for (const event of source) {
    const kind = event?.kind;
    if (!EVENT_KINDS.includes(kind)) continue;
    items.push({
      id: factId(event),
      kind,
      title: isUnrevealedSecret(event) ? '未揭晓的隐秘' : cleanText(event?.title),
      lifecycle: event.lifecycle || 'active',
      secret: event?.secret === true || kind === 'secret',
      revealed: event?.revealed === true,
    });
  }
  const counts = { all: items.length, macro: 0, news: 0, secret: 0 };
  for (const item of items) counts[item.kind] += 1;
  return { counts, items };
}

function readUsage(usage) {
  if (!usage || typeof usage !== 'object') return null;
  const num = (value) => (typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0);
  const worldbook = num(usage.worldbook);
  const mvu = num(usage.mvu);
  const recent = num(usage.recent);
  return {
    worldbook,
    mvu,
    recent,
    total: worldbook + mvu + recent,
    unit: 'token',
  };
}

/** @param {object | null | undefined} world */
export function projectWorld(world) {
  if (!world || typeof world !== 'object') {
    return {
      empty: true,
      clock: { dateLabel: '', dayIndex: null, text: '' },
      plugin: { enabled: false, frozen: false, text: '还没有世界账' },
      truncated: false,
      softWarn: false,
      usage: null,
      today: null,
      entities: null,
      events: null,
    };
  }
  return {
    empty: false,
    clock: readClock(world),
    plugin: readPlugin(world),
    truncated: world.meta?.sources?.truncated === true,
    softWarn: world.meta?.sources?.softWarn === true,
    usage: readUsage(world.meta?.usage),
    today: readToday(world.todayChanges),
    entities: {
      regions: readEntities(world.regions),
      orgs: readEntities(world.orgs),
      factions: readEntities(world.factions),
    },
    events: readEvents(world.events),
  };
}
