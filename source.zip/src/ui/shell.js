import { subscribeDiagnostics } from '../diagnostics.js';
import { assertChatScope, captureChatScope } from '../chatScope.js';
import { isWorldBusy, subscribeOperations } from '../modules/turn.js';
import { getHost } from '../host.js';
import { isGeneratingTip } from '../modules/generatingTip.js';
import { getInjectPreview } from '../modules/inject/index.js';
import {
  AI_CORRECTION_CONFIRM,
  applyAiCorrection,
  previewAiCorrection,
  saveFactManual,
  setFactVisibility,
} from '../modules/intervene/index.js';
import { correctStoryDay, getLifecycleStatus, setPluginEnabled } from '../modules/lifecycle/index.js';
import { rerunLastEvolution, runImmediateEvolution } from '../modules/timeGate/index.js';
import { detectBaibaiBook, watchBaibaiReady } from '../source/baibai.js';
import { loadSettings, loadWorld, saveSettings, subscribe } from '../store/index.js';
import { applyBookMode, bookKey, booksFromRead } from './bookMode.js';
import { evolutionGates, evolutionResultText } from './evolve.js';
import { mountFab } from './fab.js';
import { dismissFixDraft, openFixDraft, parseFixTarget, planFixClick } from './fixDraft.js';
import { closeIconSvg, fabIconSvg } from './icons.js';
import { PAGES, renderPage } from './pages.js';
import { findFact, isUnrevealedSecret, projectWorld } from './readout.js';
import { isExplicitTimeSource } from './timeSource.js';
import { createPromptSettings } from './promptSettings.js';
import { loadPreferences } from '../store/index.js';
import { effectivePreferences, preferencesPending } from '../preferences.js';

function tabButtons(kind) {
  return PAGES.map((page, index) => {
    const selected = index === 0 ? 'true' : 'false';
    const tabIndex = index === 0 ? '0' : '-1';
    const id = kind === 'bottom' ? `sj-bnav-${page.id}` : `sj-tab-${page.id}`;
    const icon = kind === 'bottom' ? `<span class="sj-bnav-ic" aria-hidden="true">${page.icon}</span>` : '';
    return `<button type="button" class="sj-tab" role="tab" id="${id}" data-page="${page.id}" aria-controls="shiju-page" aria-selected="${selected}" tabindex="${tabIndex}">${icon}<span>${page.label}</span></button>`;
  }).join('');
}

export function renderShellMarkup() {
  return `
    <button type="button" class="sj-fab is-default" draggable="false" aria-label="世局" title="世局" aria-expanded="false" aria-controls="shiju-panel">${fabIconSvg()}</button>
    <section id="shiju-panel" class="sj-panel" role="dialog" aria-labelledby="sj-title" hidden>
      <header class="sj-head">
        <div class="sj-brand">
          <h2 id="sj-title" class="sj-title">世局</h2>
          <p class="sj-sub">宏观演进 · 不碰眼前戏</p>
        </div>
        <span class="sj-day" id="sj-day">—</span>
        <button type="button" class="sj-close" aria-label="关闭">${closeIconSvg()}</button>
      </header>
      <div class="sj-status" aria-live="polite">
        <span class="sj-dot" aria-hidden="true"></span>
        <span class="sj-status-txt" id="sj-status">还没有世界账</span>
        <span class="sj-trunc" id="sj-trunc" hidden>资料被截断</span>
        <div class="sj-status-acts">
          <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" disabled data-action="evolve" title="还没有已启用的世界">立即演进</button>
          <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" disabled data-action="rerun" title="还没有已启用的世界">重跑</button>
        </div>
      </div>
      <nav class="sj-tabs sj-tabs-top" role="tablist" aria-label="世局分页">${tabButtons('top')}</nav>
      <div id="shiju-page" class="sj-body" role="tabpanel" aria-labelledby="sj-tab-feed" data-page="feed"></div>
      <nav class="sj-tabs sj-tabs-bottom" role="tablist" aria-label="世局分页">${tabButtons('bottom')}</nav>
      <div id="sj-confirm" class="sj-dlg" hidden>
        <div class="sj-dlg-card" role="alertdialog" aria-modal="true" aria-labelledby="sj-confirm-title">
          <h3 id="sj-confirm-title">生成修订稿</h3>
          <p id="sj-confirm-body"></p>
          <div class="sj-dlg-acts">
            <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-confirm="cancel">取消</button>
            <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-confirm="ok">生成</button>
          </div>
        </div>
      </div>
    </section>
  `;
}

function safeLoadWorld() {
  try {
    return loadWorld();
  } catch (error) {
    console.error('[shiju]', error);
    return null;
  }
}

/** Mount the floating shell. Caller must set the host and ensure settings first. */
export function mountShell() {
  const root = document.createElement('div');
  root.id = 'shiju-chrome';
  root.className = 'sj-root';
  root.lang = 'zh-Hans';
  root.dataset.wave = 'w4';
  root.dataset.theme = loadSettings().ui.theme;
  root.innerHTML = renderShellMarkup();
  document.body.appendChild(root);

  const panel = root.querySelector('.sj-panel');
  const body = root.querySelector('.sj-body');
  const fab = root.querySelector('.sj-fab');
  const tabs = [...root.querySelectorAll('[role="tab"]')];
  const state = {
    page: 'feed',
    worldKind: 'region',
    eventFilter: 'all',
    pending: '',
    notice: '',
    noticeTone: '',
    fix: null,
    archiveOpen: false,
    archivePage: 0,
    advOpen: false,
    worldbooks: [],
    worldbooksReady: false,
    worldbooksSig: '',
  };
  let surfaceScope = captureChatScope();
  const promptSettings = createPromptSettings({ refresh, getScope: () => surfaceScope });
  let catalogSeq = 0;
  let confirmResolver = null;

  function applyTheme(theme) {
    root.dataset.theme = theme;
  }

  function visibleTabs() {
    const top = root.querySelector('.sj-tabs-top');
    const useTop = top && getComputedStyle(top).display !== 'none';
    const nav = useTop ? top : root.querySelector('.sj-tabs-bottom');
    return [...nav.querySelectorAll('[role="tab"]')];
  }

  function paintChrome(world, life, preview) {
    const view = projectWorld(world);
    const day = root.querySelector('#sj-day');
    day.textContent = view.clock.text || '—';
    day.classList.toggle('is-on', Boolean(view.clock.text));
    const status = root.querySelector('.sj-status');
    const frozen = view.plugin.frozen || Boolean(life?.frozen);
    status.classList.toggle('is-empty', view.empty);
    status.classList.toggle('is-frozen', frozen);
    status.classList.toggle('is-off', !view.empty && !view.plugin.enabled && !frozen);
    status.classList.toggle('is-live', !view.empty && view.plugin.enabled && !frozen);
    let text = view.plugin.text;
    try {
      if (preferencesPending(world, effectivePreferences(loadPreferences()))) text += ' · 演进偏好已修改，可立即演进一次';
    } catch { text += ' · 请填写自定义演进偏好'; }
    if (isWorldBusy()) text += ' · 正在演进，完成后可修改';
    if (world?.meta?.inputHint === 'baseline-established') text += ' · 已从当前正文建立增量基线';
    if (world?.meta?.inputHint === 'history-changed') text += ' · 已处理的正文有修改，请重对齐';
    if (state.pending === 'rerun') text = '正在重跑…';
    else if (state.pending === 'evolve') text = '正在立即演进…';
    else {
      if (!view.empty && !frozen && life?.promptRequired) text = '日期冲突，先校正';
      else if (!frozen && preview?.active) text += ` · 注入 ${preview.items.length}`;
      else if (!frozen && life?.hasWorld && life?.injectEnabled === false) text += ' · 注入关';
      if (state.notice) text += ` · ${state.notice}`;
    }
    status.classList.toggle('is-busy', Boolean(state.pending));
    status.classList.toggle('is-error', !state.pending && state.noticeTone === 'error');
    if (state.pending) status.setAttribute('aria-busy', 'true');
    else status.removeAttribute('aria-busy');
    root.querySelector('#sj-status').textContent = text;
    const trunc = root.querySelector('#sj-trunc');
    if (trunc) trunc.hidden = !view.truncated;
    root.dataset.frozen = frozen ? '1' : '0';
    root.dataset.enabled = (view.plugin.enabled || life?.enabled) ? '1' : '0';
    root.dataset.inject = preview?.active ? '1' : '0';
  }

  function bindPage() {
    promptSettings.bind(body);
    const mutateSecret = (target, action, value) => {
      const parsed = parseFixTarget(target);
      if (!parsed) return;
      const scope = surfaceScope;
      setFactVisibility({ ...parsed, action, value, chatScope: scope }).catch((error) => {
        if (surfaceScope !== scope) return;
        state.notice = error.message;
        refresh();
      });
    };
    for (const button of body.querySelectorAll('[data-secret-target]')) {
      button.addEventListener('click', () => mutateSecret(button.dataset.secretTarget, button.dataset.secretAction));
    }
    for (const input of body.querySelectorAll('[data-knowledge-target]')) {
      input.addEventListener('change', () => mutateSecret(input.dataset.knowledgeTarget, 'knowledge', input.value));
    }
    body.querySelector('[data-archive-toggle]')?.addEventListener('click', () => {
      state.archiveOpen = !state.archiveOpen;
      state.archivePage = 0;
      state.fix = null;
      refresh();
    });
    for (const button of body.querySelectorAll('[data-archive-page]')) {
      button.addEventListener('click', () => {
        if (button.disabled) return;
        state.archivePage = Math.max(0, Number(button.dataset.archivePage) || 0);
        state.fix = null;
        refresh();
      });
    }
    for (const input of body.querySelectorAll('input[name="sj-theme"]')) {
      input.addEventListener('change', () => {
        if (!input.checked) return;
        saveSettings({ ui: { theme: input.value } });
      });
    }
    for (const input of body.querySelectorAll('input[name="sj-time-source"]')) {
      const commit = () => {
        if (input.disabled || !input.checked) return;
        const mode = input.value;
        if (!isExplicitTimeSource(mode)) return;
        if (loadSettings().timeSource.mode === mode) return;
        saveSettings({ timeSource: { mode } });
        refresh();
        body.querySelector(`input[name="sj-time-source"][value="${mode}"]`)?.focus();
      };
      input.addEventListener('change', commit);
      input.addEventListener('click', commit);
    }
    const tag = body.querySelector('#sj-custom-tag');
    if (tag) {
      tag.addEventListener('input', () => {
        saveSettings({ timeSource: { mode: 'custom', customTag: tag.value } });
      });
    }
    for (const button of body.querySelectorAll('[data-world-kind]')) {
      button.addEventListener('click', () => {
        state.page = 'world';
        state.worldKind = button.dataset.worldKind;
        refresh();
      });
    }
    for (const button of body.querySelectorAll('[data-event-filter]')) {
      button.addEventListener('click', () => {
        state.eventFilter = button.dataset.eventFilter;
        refresh();
      });
    }
    const plugin = body.querySelector('[data-action="toggle-plugin"]');
    if (plugin) {
      plugin.addEventListener('click', () => {
        const turningOn = plugin.dataset.enabled !== '1';
        setPluginEnabled(turningOn)
          .then(() => refresh())
          .catch((error) => console.error('[shiju]', error));
      });
    }
    const injectToggle = body.querySelector('[data-action="toggle-inject"]');
    if (injectToggle) {
      injectToggle.addEventListener('click', () => {
        const on = loadSettings().inject?.enabled !== false;
        saveSettings({ inject: { enabled: !on } });
        refresh();
      });
    }
    for (const button of body.querySelectorAll('[data-choice]')) {
      button.addEventListener('click', () => {
        correctStoryDay({ choice: button.dataset.choice })
          .then(() => refresh())
          .catch((error) => console.error('[shiju]', error));
      });
    }
    const correct = body.querySelector('[data-action="correct-day"]');
    if (correct) {
      correct.addEventListener('click', () => {
        const dayIndex = Number.parseInt(body.querySelector('#sj-day-index')?.value, 10);
        const dateLabel = body.querySelector('#sj-day-label')?.value ?? '';
        correctStoryDay({ choice: 'set', dayIndex, dateLabel })
          .then(() => refresh())
          .catch((error) => console.error('[shiju]', error));
      });
    }
    const adv = body.querySelector('details.sj-adv');
    if (adv) {
      adv.addEventListener('toggle', () => {
        state.advOpen = adv.open;
      });
    }
    for (const button of body.querySelectorAll('[data-wb-mode]')) {
      button.addEventListener('click', () => {
        const mode = button.dataset.wbMode;
        if (mode !== 'default' && mode !== 'pin' && mode !== 'exclude') return;
        const book = { uid: button.dataset.wbUid || '', name: button.dataset.wbName || '' };
        if (!book.uid && !book.name) return;
        const next = applyBookMode(loadSettings(), book, mode);
        state.advOpen = true;
        saveSettings({ worldbook: next });
        refresh();
      });
    }
  }

  function commitCatalog(seq, books) {
    if (seq !== catalogSeq) return;
    const sig = books.map((book) => bookKey(book)).join('\n');
    const changed = !state.worldbooksReady || sig !== state.worldbooksSig;
    state.worldbooksReady = true;
    state.worldbooksSig = sig;
    state.worldbooks = books;
    if (changed && state.page === 'settings' && !panel.hidden) refresh();
  }

  function reloadWorldbooks() {
    const seq = ++catalogSeq;
    let pending;
    try {
      const host = getHost();
      if (typeof host.readWorldbook !== 'function') {
        commitCatalog(seq, []);
        return;
      }
      pending = host.readWorldbook();
    } catch (error) {
      console.error('[shiju]', error);
      commitCatalog(seq, []);
      return;
    }
    Promise.resolve(pending).then(
      (read) => commitCatalog(seq, booksFromRead(read)),
      (error) => {
        console.error('[shiju]', error);
        commitCatalog(seq, []);
      },
    );
  }

  function captureFixFields() {
    const fix = state.fix;
    if (!fix) return;
    const panel = body.querySelector('.sj-fix');
    if (!panel || panel.dataset.factKind !== fix.kind || panel.dataset.factId !== fix.id) return;
    const title = panel.querySelector('#sj-fix-title');
    const text = panel.querySelector('#sj-fix-body');
    const instr = panel.querySelector('#sj-fix-instr');
    const draft = panel.querySelector('#sj-fix-draft');
    if (title) fix.manualTitle = title.value;
    if (text) fix.manualBody = text.value;
    if (instr) fix.instruction = instr.value;
    if (draft) fix.draft = draft.value;
  }

  function clearDraftField() {
    const draft = body.querySelector('#sj-fix-draft');
    if (draft) draft.value = '';
  }

  function refresh() {
    try { assertChatScope(surfaceScope); } catch {
      promptSettings.chatChanged();
      settleConfirm(false);
      state.fix = null;
      state.pending = '';
      state.notice = '';
      state.worldbooks = [];
      state.worldbooksReady = false;
      state.archiveOpen = false;
      state.archivePage = 0;
      catalogSeq += 1;
      surfaceScope = captureChatScope();
    }
    captureFixFields();
    promptSettings.capture(body);
    const settings = loadSettings();
    const hasBaibai = detectBaibaiBook();
    let lifecycle = null;
    let injectPreview = null;
    try {
      lifecycle = getLifecycleStatus();
      injectPreview = getInjectPreview();
    } catch (error) {
      console.error('[shiju]', error);
    }
    const world = safeLoadWorld();
    const evolution = evolutionGates(world, {
      busy: Boolean(state.pending) || isWorldBusy(),
      generating: isGeneratingTip(),
    });
    const view = {
      page: state.page,
      theme: settings.ui.theme,
      world,
      timeSource: settings.timeSource,
      hasBaibai,
      worldKind: state.worldKind,
      eventFilter: state.eventFilter,
      lifecycle,
      injectPreview,
      injectEnabled: settings.inject?.enabled !== false,
      worldbook: settings.worldbook,
      worldbooks: state.worldbooks,
      worldbooksReady: state.worldbooksReady,
      advOpen: state.advOpen,
      evolution,
      pending: state.pending,
      notice: state.pending ? '' : state.notice,
      fix: state.fix,
      worldBusy: isWorldBusy(),
      archiveOpen: state.archiveOpen,
      archivePage: state.archivePage,
      promptSettings: state.page === 'settings' ? promptSettings.render(world, isWorldBusy()) : '',
    };
    applyTheme(view.theme);
    root.dataset.baibai = hasBaibai ? '1' : '0';
    paintChrome(view.world, lifecycle, injectPreview);
    body.innerHTML = renderPage(view);
    body.dataset.page = view.page;
    const labelled = document.getElementById(`sj-tab-${view.page}`) ? `sj-tab-${view.page}` : `sj-bnav-${view.page}`;
    body.setAttribute('aria-labelledby', labelled);
    for (const tab of tabs) {
      const on = tab.dataset.page === view.page;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      tab.tabIndex = on ? 0 : -1;
    }
    bindPage();
    paintActions(evolution);
    if (view.page === 'settings') reloadWorldbooks();
  }

  function paintActions(gates) {
    const byAction = { evolve: gates.evolve, rerun: gates.rerun };
    for (const button of root.querySelectorAll('[data-action="evolve"], [data-action="rerun"]')) {
      const gate = byAction[button.dataset.action];
      if (!gate) continue;
      button.disabled = gate.enabled !== true;
      button.title = gate.title || '';
      if (gate.busy) button.setAttribute('aria-busy', 'true');
      else button.removeAttribute('aria-busy');
    }
  }

  function runManual(action) {
    if (state.pending) return;
    const gates = evolutionGates(safeLoadWorld(), { generating: isGeneratingTip() });
    const gate = action === 'rerun' ? gates.rerun : gates.evolve;
    if (!gate.enabled) return;
    const operationScope = surfaceScope;
    state.pending = action;
    state.notice = '';
    state.noticeTone = '';
    refresh();
    const call = action === 'rerun' ? rerunLastEvolution() : runImmediateEvolution();
    call.then((result) => {
      if (surfaceScope !== operationScope) return;
      const ok = Boolean(result?.ok && result?.evolved);
      state.notice = evolutionResultText(action, result);
      state.noticeTone = ok ? 'ok' : 'error';
      if (!ok) console.error('[shiju]', result?.reason || state.notice);
    }, (error) => {
      if (surfaceScope !== operationScope) return;
      console.error('[shiju]', error);
      state.notice = error?.code?.startsWith('SHIJU_') ? error.message : '演进没有完成';
      state.noticeTone = 'error';
    }).then(() => {
      if (surfaceScope !== operationScope) return;
      state.pending = null;
      refresh();
    });
  }

  function watchGeneration() {
    let host;
    try {
      host = getHost();
    } catch (error) {
      console.error('[shiju]', error);
      return;
    }
    const types = host.event_types || {};
    const source = host.eventSource;
    if (!source || typeof source.on !== 'function') return;
    const schedule = () => {
      queueMicrotask(() => {
        try {
          refresh();
        } catch (error) {
          console.error('[shiju]', error);
        }
      });
    };
    for (const name of [
      types.GENERATION_STARTED,
      types.GENERATION_ENDED,
      types.GENERATION_STOPPED,
      types.CHARACTER_MESSAGE_RENDERED,
      types.CHAT_CHANGED,
    ]) {
      if (name) source.on(name, schedule);
    }
  }

  function askConfirm() {
    const dialog = root.querySelector('#sj-confirm');
    const copy = root.querySelector('#sj-confirm-body');
    if (copy) copy.textContent = AI_CORRECTION_CONFIRM;
    if (dialog) dialog.hidden = false;
    return new Promise((resolve) => {
      confirmResolver = resolve;
    });
  }

  function settleConfirm(accepted) {
    const resolve = confirmResolver;
    confirmResolver = null;
    const dialog = root.querySelector('#sj-confirm');
    if (dialog) dialog.hidden = true;
    if (resolve) resolve(accepted === true);
  }

  function dropFixDraft(action) {
    clearDraftField();
    state.fix = dismissFixDraft(state.fix, action);
    refresh();
  }

  function toggleFix(target) {
    const parsed = parseFixTarget(target);
    if (!parsed) return;
    const item = findFact(safeLoadWorld(), parsed.kind, parsed.id);
    if (!item || isUnrevealedSecret(item) || isWorldBusy()) return;
    if (state.fix?.kind === parsed.kind && state.fix.id === parsed.id) {
      state.fix = null;
    } else {
      state.fix = { ...openFixDraft(item, parsed.kind), chatScope: captureChatScope() };
    }
    refresh();
    body.querySelector('.sj-fix')?.scrollIntoView({ block: 'nearest' });
  }

  function switchFixMode(mode) {
    const fix = state.fix;
    if (!fix || fix.busy || (mode !== 'manual' && mode !== 'ai') || fix.mode === mode) return;
    clearDraftField();
    const next = dismissFixDraft(fix, 'discard');
    next.mode = mode;
    state.fix = next;
    refresh();
  }

  async function saveManualEdit() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'manual' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    fix.busy = true;
    fix.error = '';
    fix.notice = '';
    refresh();
    try {
      await saveFactManual({
        chatScope: fix.chatScope,
        kind: fix.kind,
        id: fix.id,
        patch: { title: fix.manualTitle, body: fix.manualBody },
      });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '没有保存';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    const saved = findFact(safeLoadWorld(), fix.kind, fix.id);
    fix.busy = false;
    fix.notice = '已保存';
    fix.error = '';
    if (saved) {
      fix.manualTitle = typeof saved.title === 'string' ? saved.title : '';
      fix.manualBody = typeof saved.body === 'string' ? saved.body : '';
    }
    refresh();
  }

  async function generatePreview() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'ai' || fix.stage === 'preview' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    const accepted = await askConfirm();
    if (!accepted || state.fix !== fix) return;
    fix.busy = true;
    fix.error = '';
    refresh();
    let result;
    try {
      result = await previewAiCorrection({
        chatScope: fix.chatScope,
        kind: fix.kind,
        id: fix.id,
        instruction: fix.instruction,
      });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '修订稿没有生成';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    fix.busy = false;
    fix.stage = 'preview';
    fix.draft = typeof result?.previewText === 'string' ? result.previewText : '';
    fix.error = '';
    refresh();
  }

  async function adoptRevision() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'ai' || fix.stage !== 'preview' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    const text = fix.draft;
    fix.busy = true;
    fix.error = '';
    refresh();
    try {
      await applyAiCorrection({ chatScope: fix.chatScope, kind: fix.kind, id: fix.id, text });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '没有写入';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    const saved = findFact(safeLoadWorld(), fix.kind, fix.id);
    fix.busy = false;
    fix.mode = 'manual';
    fix.stage = 'prompt';
    fix.draft = '';
    fix.notice = '已保存';
    fix.error = '';
    if (saved) {
      fix.manualTitle = typeof saved.title === 'string' ? saved.title : fix.manualTitle;
      fix.manualBody = typeof saved.body === 'string' ? saved.body : '';
    }
    clearDraftField();
    refresh();
  }

  function onFixClick(event) {
    const confirmButton = event.target?.closest?.('[data-confirm]');
    if (confirmButton) {
      settleConfirm(confirmButton.dataset.confirm === 'ok');
      return;
    }
    const hit = event.target?.closest?.(
      '[data-fix-dismiss], [data-fix-apply], [data-fix-save], [data-fix-generate], [data-fix-mode], [data-fix-open]',
    );
    if (!hit) return;
    const plan = planFixClick(hit.dataset);
    if (!plan) return;
    if (plan.effect === 'drop-draft') {
      dropFixDraft(plan.action);
      return;
    }
    if (plan.effect === 'apply') {
      adoptRevision();
      return;
    }
    if (plan.effect === 'save') {
      saveManualEdit();
      return;
    }
    if (plan.effect === 'preview') {
      generatePreview();
      return;
    }
    if (plan.effect === 'mode') {
      switchFixMode(plan.mode);
      return;
    }
    if (plan.effect === 'open') toggleFix(plan.target);
  }

  function leaveFixOnPageChange(nextPage) {
    if (state.page !== nextPage) state.fix = null;
    state.page = nextPage;
  }

  function openPanel() {
    panel.hidden = false;
    fab.hidden = true;
    fab.setAttribute('aria-expanded', 'true');
    refresh();
    root.querySelector('.sj-close')?.focus();
  }

  function closePanel() {
    settleConfirm(false);
    state.fix = null;
    panel.hidden = true;
    fab.hidden = false;
    fab.setAttribute('aria-expanded', 'false');
    fab.focus();
  }

  mountFab(fab, {
    getPosition() {
      return loadSettings().ui.fab;
    },
    onCommit(pos) {
      saveSettings({ ui: { fab: pos } });
    },
    onActivate: openPanel,
  });

  for (const tab of tabs) {
    tab.addEventListener('click', () => {
      leaveFixOnPageChange(tab.dataset.page);
      refresh();
      tab.focus();
    });
  }

  for (const nav of root.querySelectorAll('.sj-tabs')) {
    nav.addEventListener('keydown', (event) => {
      const keys = ['ArrowLeft', 'ArrowRight', 'Home', 'End'];
      if (!keys.includes(event.key)) return;
      const currentTabs = visibleTabs();
      if (!currentTabs.includes(event.target)) return;
      event.preventDefault();
      const current = currentTabs.findIndex((tab) => tab.dataset.page === state.page);
      let next = current < 0 ? 0 : current;
      if (event.key === 'ArrowRight') next = (next + 1) % currentTabs.length;
      if (event.key === 'ArrowLeft') next = (next - 1 + currentTabs.length) % currentTabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = currentTabs.length - 1;
      leaveFixOnPageChange(currentTabs[next].dataset.page);
      refresh();
      visibleTabs()[next]?.focus();
    });
  }

  root.addEventListener('click', (event) => {
    const button = event.target?.closest?.('[data-action="evolve"], [data-action="rerun"]');
    if (!button || button.disabled || state.pending) return;
    runManual(button.dataset.action === 'rerun' ? 'rerun' : 'evolve');
  });
  root.addEventListener('click', onFixClick);
  root.querySelector('#sj-confirm')?.addEventListener('click', (event) => {
    if (event.target?.id === 'sj-confirm') settleConfirm(false);
  });

  root.querySelector('.sj-close').addEventListener('click', closePanel);
  root.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || panel.hidden) return;
    const dialog = root.querySelector('#sj-confirm');
    if (dialog && !dialog.hidden) {
      event.stopPropagation();
      settleConfirm(false);
      return;
    }
    if (state.fix) {
      event.stopPropagation();
      dropFixDraft('cancel');
      return;
    }
    if (event.target?.id === 'sj-custom-tag' || event.target?.id === 'sj-day-index' || event.target?.id === 'sj-day-label') return;
    event.stopPropagation();
    closePanel();
  });

  subscribe((kind) => {
    if (kind === 'settings') {
      applyTheme(loadSettings().ui.theme);
      return;
    }
    refresh();
  });

  subscribeOperations(refresh);
  subscribeDiagnostics(refresh);
  watchBaibaiReady(refresh);
  watchGeneration();
  refresh();
  return { refresh, openPanel, closePanel };
}
