import { mountUpdateNotice } from './updateNotice.js';
import { updates } from '../update.js';
import { timeIssueLabel } from './timeDiagnosis.js';
import { getHistory, historySaving, historyStatus } from '../modules/model/history.js';
import { pendingWorldWrites } from '../store/index.js';
import { createWorldManagement } from './worldManagement.js';
import { subscribeDiagnostics } from '../diagnostics.js';
import { assertChatScope, captureChatScope } from '../chatScope.js';
import { isWorldBusy, subscribeOperations } from '../modules/turn.js';
import { getHost } from '../host.js';
import { isGeneratingTip } from '../modules/generatingTip.js';
import { getInjectPreview } from '../modules/inject/index.js';
import {
  AI_CORRECTION_CONFIRM,
  applyAiCorrection,
  previewAiCorrection,
  saveFactManual,
  setFactVisibility,
} from '../modules/intervene/index.js';
import { correctStoryDay, getLifecycleStatus, setPluginEnabled } from '../modules/lifecycle/index.js';
import { rerunLastEvolution, runImmediateEvolution } from '../modules/timeGate/index.js';
import { detectBaibaiBook, watchBaibaiReady } from '../source/baibai.js';
import { loadSettings, loadWorld, saveSettings, subscribe } from '../store/index.js';
import { applyBookMode, bookKey, booksFromRead } from './bookMode.js';
import { evolutionGates, evolutionResultText } from './evolve.js';
import { mountFab } from './fab.js';
import { dismissFixDraft, openFixDraft, parseFixTarget, planFixClick } from './fixDraft.js';
import { closeIconSvg, fabIconSvg } from './icons.js';
import { PAGES, renderPage } from './pages.js';
import { findFact, isUnrevealedSecret, projectWorld } from './readout.js';
import { isExplicitTimeSource } from './timeSource.js';
import { createPromptSettings } from './promptSettings.js';
import { captureHistoryView } from './historyViewState.js';
import { loadPreferences } from '../store/index.js';
import { effectivePreferences, preferencesPending } from '../preferences.js';

function tabButtons(kind) {
  return PAGES.map((page, index) => {
    const selected = index === 0 ? 'true' : 'false';
    const tabIndex = index === 0 ? '0' : '-1';
    const id = kind === 'bottom' ? `sj-bnav-${page.id}` : `sj-tab-${page.id}`;
    const icon = kind === 'bottom' ? `<span class="sj-bnav-ic" aria-hidden="true">${page.icon}</span>` : '';
    return `<button type="button" class="sj-tab" role="tab" id="${id}" data-page="${page.id}" aria-controls="shiju-page" aria-selected="${selected}" tabindex="${tabIndex}">${icon}<span>${page.label}</span></button>`;
  }).join('');
}

export function renderShellMarkup() {
  return `
    <button type="button" class="sj-fab is-default" draggable="false" aria-label="世局" title="世局" aria-expanded="false" aria-controls="shiju-panel">${fabIconSvg()}</button>
    <section id="shiju-panel" class="sj-panel" role="dialog" aria-labelledby="sj-title" hidden>
      <header class="sj-head">
        <div class="sj-brand">
          <h2 id="sj-title" class="sj-title">世局</h2>
          <p class="sj-sub">宏观演进 · 不碰眼前戏</p>
        </div>
        <span class="sj-day" id="sj-day">—</span>
        <button type="button" class="sj-close" aria-label="关闭">${closeIconSvg()}</button>
      </header>
      <div class="sj-status" aria-live="polite">
        <span class="sj-dot" aria-hidden="true"></span>
        <span class="sj-status-txt" id="sj-status">还没有世界账</span>
        <button type="button" class="sj-time-issue" data-action="time-diagnosis" hidden></button>
        <span class="sj-trunc" id="sj-trunc" hidden>旧版截断记录</span>
        <div class="sj-status-acts">
          <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" disabled data-action="evolve" title="还没有已启用的世界">立即演进</button>
          <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" disabled data-action="rerun" title="还没有已启用的世界">重跑</button>
        </div>
      </div>
      <nav class="sj-tabs sj-tabs-top" role="tablist" aria-label="世局分页">${tabButtons('top')}</nav>
      <div id="shiju-page" class="sj-body" role="tabpanel" aria-labelledby="sj-tab-feed" data-page="feed"></div>
      <nav class="sj-tabs sj-tabs-bottom" role="tablist" aria-label="世局分页">${tabButtons('bottom')}</nav>
      <div id="sj-confirm" class="sj-dlg" hidden>
        <div class="sj-dlg-card" role="alertdialog" aria-modal="true" aria-labelledby="sj-confirm-title">
          <h3 id="sj-confirm-title">生成修订稿</h3>
          <p id="sj-confirm-body"></p>
          <div class="sj-dlg-acts">
            <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-confirm="cancel">取消</button>
            <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-confirm="ok">生成</button>
          </div>
        </div>
      </div>
    </section>
  `;
}

function safeLoadWorld() {
  try {
    return loadWorld();
  } catch (error) {
    console.error('[shiju]', error);
    return null;
  }
}

/** Mount the floating shell. Caller must set the host and ensure settings first. */
export function mountShell() {
  const root = document.createElement('div');
  root.id = 'shiju-chrome';
  root.className = 'sj-root';
  root.lang = 'zh-Hans';
  root.dataset.wave = 'w4';
  root.dataset.theme = loadSettings().ui.theme;
  root.innerHTML = renderShellMarkup();
  document.body.appendChild(root);

  const panel = root.querySelector('.sj-panel');
  const body = root.querySelector('.sj-body');
  const fab = root.querySelector('.sj-fab');
  const tabs = [...root.querySelectorAll('[role="tab"]')];
  const state = {
    page: 'feed',
    settingsSection: 'world',
    settingsFolds: {},
    openDetails: Object.create(null),
    worldKind: 'region',
    eventFilter: 'all',
    pending: '',
    notice: '',
    noticeTone: '',
    fix: null,
    dateDraft: null,
    archiveOpen: false,
    archivePage: 0,
    advOpen: true,
    worldbooks: [],
    worldbooksReady: false,
    worldbooksSig: '',
  };
  let surfaceScope = captureChatScope();
  let bootstrapController=null;
  const management = createWorldManagement({refresh,getScope:()=>surfaceScope,locateEntity:(kind,id)=>{
    state.page='world';state.worldKind=({regions:'region',factions:'faction',orgs:'org'})[kind];refresh();
    const card=[...body.querySelectorAll('[data-entity-id]')].find(el=>el.dataset.entityKind===kind&&el.dataset.entityId===id);
    card?.scrollIntoView({block:'center'});card?.querySelector('[data-detail-toggle]')?.focus({preventScroll:true});
  }});
  const promptSettings = createPromptSettings({ refresh, getScope: () => surfaceScope, getSection: () => state.settingsSection, onNavigate: selectSettingsSection });
  let catalogSeq = 0;
  let confirmResolver = null;
  let confirmFocus = null;
  let panelOpener = null;
  const updateNotice = mountUpdateNotice(root, { risks() {
    const prompts = promptSettings.reloadState(), entities = management.reloadState();
    return { busy: Boolean(state.pending || isWorldBusy() || pendingWorldWrites() || historySaving() || isGeneratingTip() || prompts.busy || entities.busy || getHistory().some(r => r.status === 'running') || getHost().hasPendingSettingsSave?.()),
      draft: Boolean(state.fix || state.dateDraft || prompts.draft || entities.draft || historyStatus()) };
  } });

  function applyTheme(theme) {
    root.dataset.theme = theme;
  }

  function visibleTabs() {
    const top = root.querySelector('.sj-tabs-top');
    const useTop = top && getComputedStyle(top).display !== 'none';
    const nav = useTop ? top : root.querySelector('.sj-tabs-bottom');
    return [...nav.querySelectorAll('[role="tab"]')];
  }

  function paintChrome(world, life, preview) {
    const view = projectWorld(world);
    const day = root.querySelector('#sj-day');
    day.textContent = view.clock.text || '—';
    day.classList.toggle('is-on', Boolean(view.clock.text));
    const status = root.querySelector('.sj-status');
    const frozen = view.plugin.frozen || Boolean(life?.frozen);
    status.classList.toggle('is-empty', view.empty);
    status.classList.toggle('is-frozen', frozen);
    status.classList.toggle('is-off', !view.empty && !view.plugin.enabled && !frozen);
    status.classList.toggle('is-live', !view.empty && view.plugin.enabled && !frozen);
    let text = view.plugin.text;
    try {
      if (preferencesPending(world, effectivePreferences(loadPreferences()))) text += ' · 演进偏好已修改，可立即演进一次';
    } catch { text += ' · 请填写自定义演进偏好'; }
    if (isWorldBusy()) text += ' · 正在演进，完成后可修改';
    if (world?.meta?.inputHint === 'baseline-established') text += ' · 已从当前正文建立增量基线';
    if (world?.meta?.inputHint === 'history-changed') text += ' · 已处理的正文有修改，请重对齐';
    if (state.pending === 'rerun') text = '正在重跑…';
    else if (state.pending === 'evolve') text = '正在立即演进…';
    else {
      if (!view.empty && !frozen && life?.blocked) text = '演进已暂停';
      else if (!frozen && preview?.active) text += ` · 注入 ${preview.items.length}`;
      else if (!frozen && life?.hasWorld && life?.injectEnabled === false) text += ' · 注入关';
      if (state.notice) text += ` · ${state.notice}`;
    }
    status.classList.toggle('is-busy', Boolean(state.pending));
    status.classList.toggle('is-error', !state.pending && state.noticeTone === 'error');
    if (state.pending) status.setAttribute('aria-busy', 'true');
    else status.removeAttribute('aria-busy');
    root.querySelector('#sj-status').textContent = text;
    const issue = root.querySelector('[data-action="time-diagnosis"]');
    issue.textContent = timeIssueLabel(life);
    issue.hidden = !issue.textContent;
    const trunc = root.querySelector('#sj-trunc');
    if (trunc) trunc.hidden = !view.truncated;
    root.dataset.frozen = frozen ? '1' : '0';
    root.dataset.enabled = (view.plugin.enabled || life?.enabled) ? '1' : '0';
    root.dataset.inject = preview?.active ? '1' : '0';
  }

  function selectSettingsSection(section) {
    if (!['world','model','sources','appearance','history'].includes(section)) return;
    promptSettings.capture(body); management.capture(body);
    state.settingsSection = section;
    refresh();
    body.scrollTop = 0;
    body.querySelector(`[data-settings-section="${section}"]`)?.focus();
  }

  function bindPage() {
    updateNotice.paint();
    body.querySelector('[data-action="toggle-fab"]')?.addEventListener('click', () => {
      saveSettings({ ui: { showFab: loadSettings().ui.showFab === false } }); refresh();
      body.querySelector('[data-action="toggle-fab"]')?.focus();
    });
    body.querySelector('[data-action="recheck-time"]')?.addEventListener('click', () => { refresh(); body.querySelector('#sj-time-diagnosis')?.focus(); });
    for (const id of ['sj-day-index','sj-day-label']) body.querySelector('#'+id)?.addEventListener('input', () => {
      state.dateDraft = { dayIndex: body.querySelector('#sj-day-index').value, dateLabel: body.querySelector('#sj-day-label').value };
    });
    promptSettings.bind(body); management.bind(body);
    const detailScope = surfaceScope;
    body.querySelectorAll('[data-detail-toggle]').forEach(button => button.addEventListener('click', () => {
      try { assertChatScope(detailScope); } catch { refresh(); return; }
      const key = button.dataset.detailToggle, scroll = body.scrollTop;
      state.openDetails[key] = state.openDetails[key] !== true;
      refresh();
      [...body.querySelectorAll('[data-detail-toggle]')].find(el => el.dataset.detailToggle === key)?.focus({preventScroll:true});
      body.scrollTop = scroll;
    }));
    body.querySelectorAll('[data-settings-section]').forEach(button => button.addEventListener('click', () => selectSettingsSection(button.dataset.settingsSection)));
    const mutateSecret = (target, action, value) => {
      const parsed = parseFixTarget(target);
      if (!parsed) return;
      const scope = surfaceScope;
      if (action === 'view' || action === 'hide') state.openDetails[target] = action === 'view';
      setFactVisibility({ ...parsed, action, value, chatScope: scope }).catch((error) => {
        if (surfaceScope !== scope) return;
        state.notice = error.message;
        refresh();
      });
    };
    for (const button of body.querySelectorAll('[data-secret-target]')) {
      button.addEventListener('click', () => mutateSecret(button.dataset.secretTarget, button.dataset.secretAction));
    }
    for (const input of body.querySelectorAll('[data-knowledge-target]')) {
      input.addEventListener('change', () => mutateSecret(input.dataset.knowledgeTarget, 'knowledge', input.value));
    }
    body.querySelector('[data-archive-toggle]')?.addEventListener('click', () => {
      state.archiveOpen = !state.archiveOpen;
      state.archivePage = 0;
      state.fix = null;
      refresh();
    });
    for (const button of body.querySelectorAll('[data-archive-page]')) {
      button.addEventListener('click', () => {
        if (button.disabled) return;
        state.archivePage = Math.max(0, Number(button.dataset.archivePage) || 0);
        state.fix = null;
        refresh();
      });
    }
    for (const input of body.querySelectorAll('input[name="sj-theme"]')) {
      input.addEventListener('change', () => {
        if (!input.checked) return;
        saveSettings({ ui: { theme: input.value } });
      });
    }
    for (const input of body.querySelectorAll('input[name="sj-time-source"]')) {
      const commit = () => {
        if (input.disabled || !input.checked) return;
        const mode = input.value;
        if (!isExplicitTimeSource(mode)) return;
        if (loadSettings().timeSource.mode === mode) return;
        saveSettings({ timeSource: { mode } });
        refresh();
        body.querySelector(`input[name="sj-time-source"][value="${mode}"]`)?.focus();
      };
      input.addEventListener('change', commit);
      input.addEventListener('click', commit);
    }
    const tag = body.querySelector('#sj-custom-tag');
    if (tag) {
      tag.addEventListener('input', () => {
        const selection = [tag.selectionStart, tag.selectionEnd];
        saveSettings({ timeSource: { mode: 'custom', customTag: tag.value } });
        refresh();
        const replacement = body.querySelector('#sj-custom-tag');
        replacement?.focus({preventScroll:true});
        replacement?.setSelectionRange(...selection);
      });
    }
    for (const button of body.querySelectorAll('[data-world-kind]')) {
      button.addEventListener('click', () => {
        state.page = 'world';
        state.worldKind = button.dataset.worldKind;
        refresh();
      });
    }
    for (const button of body.querySelectorAll('[data-event-filter]')) {
      button.addEventListener('click', () => {
        state.eventFilter = button.dataset.eventFilter;
        refresh();
      });
    }
    const plugin = body.querySelector('[data-action="toggle-plugin"]');
    if (plugin) {
      plugin.addEventListener('click', () => {
        if(isWorldBusy())return;
        const turningOn = plugin.dataset.enabled !== '1', scope=surfaceScope;
        const controller=new AbortController(); bootstrapController=controller;
        setPluginEnabled(turningOn,{signal:controller.signal,onProgress:progress=>{
          if(scope!==surfaceScope)return;
          const el=body.querySelector('[data-bootstrap-progress]');if(el)el.textContent=`正在处理世界书 ${progress.completed} / ${progress.total}`;
        }}).then(result=>{if(scope===surfaceScope){if(!result?.ok)state.notice=result?.message || '操作未完成';else if(result.created)state.notice=`世界已建立：${result.world?.events?.length || 0} 条宏观事态。资料不足时允许少量事件，可在世界资料管理中重新整理。`;else state.notice='';}})
          .catch(error=>{if(scope===surfaceScope)state.notice=controller.signal.aborted?'已取消':error.message;})
          .finally(()=>{if(bootstrapController===controller)bootstrapController=null;if(scope===surfaceScope)refresh();});
        refresh();
      });
    }
    body.querySelector('[data-cancel-bootstrap]')?.addEventListener('click',()=>bootstrapController?.abort());
    const injectToggle = body.querySelector('[data-action="toggle-inject"]');
    if (injectToggle) {
      injectToggle.addEventListener('click', () => {
        const on = loadSettings().inject?.enabled !== false;
        saveSettings({ inject: { enabled: !on } });
        refresh();
      });
    }
    async function correctTime(input, scope) {
      try {
        assertChatScope(scope);
        if (isWorldBusy()) return;
        const result = await correctStoryDay(input);
        if (scope !== surfaceScope) return;
        if (!result?.ok) state.notice = result?.message || '校正未完成，请检查日期与故事日';
        else { state.dateDraft = null; state.notice = input.choice === 'keep' ? '已保留世界账；尚存的日期矛盾仍会阻止演进' : '日期处理完成，请查看最新诊断'; }
      } catch (error) { if (scope === surfaceScope) state.notice = error.message; }
      if (scope === surfaceScope) { refresh(); body.querySelector('#sj-time-diagnosis')?.focus(); }
    }
    for (const button of body.querySelectorAll('[data-choice]')) {
      button.addEventListener('click', async () => {
        const scope = surfaceScope, choice = button.dataset.choice;
        if (choice === 'realign' && !await askConfirmation('重对齐世界账', '将调用当前模型，以现有正文重新对齐世界账。不会修改聊天正文。', '调用模型重对齐')) return;
        await correctTime({ choice }, scope);
      });
    }
    const correct = body.querySelector('[data-action="correct-day"]');
    correct?.addEventListener('click', async () => {
      const scope = surfaceScope;
      const dayIndex = Number(body.querySelector('#sj-day-index')?.value);
      const dateLabel = body.querySelector('#sj-day-label')?.value ?? '';
      const old = safeLoadWorld()?.storyClock;
      if (!Number.isInteger(dayIndex) || dayIndex < 0 || !dateLabel.trim()) { state.notice = '请填写有效日期和非负整数故事日'; refresh(); return; }
      if (!await askConfirmation('确认校正日期', `世界账将从「${old?.dateLabel || '未定'} · 第 ${old?.dayIndex ?? 0} 日」改为「${dateLabel} · 第 ${dayIndex} 日」。来源楼层保持原样，不调用模型。`, '确认校正')) return;
      if (scope !== surfaceScope) return;
      if (JSON.stringify(safeLoadWorld()?.storyClock) !== JSON.stringify(old)) {
        state.notice = '世界日期已变化，请核对当前日期后重新确认'; refresh(); return;
      }
      await correctTime({ choice: 'set', dayIndex, dateLabel }, scope);
    });
    const adv = body.querySelector('details.sj-adv');
    if (adv) {
      adv.addEventListener('toggle', () => {
        state.advOpen = adv.open;
      });
    }
    for (const button of body.querySelectorAll('[data-wb-mode]')) {
      button.addEventListener('click', () => {
        const mode = button.dataset.wbMode;
        if (mode !== 'default' && mode !== 'pin' && mode !== 'exclude') return;
        const book = { uid: button.dataset.wbUid || '', name: button.dataset.wbName || '' };
        if (!book.uid && !book.name) return;
        const next = applyBookMode(loadSettings(), book, mode);
        state.advOpen = true;
        saveSettings({ worldbook: next });
        refresh();
      });
    }
  }

  function commitCatalog(seq, books) {
    if (seq !== catalogSeq) return;
    const sig = books.map((book) => bookKey(book)).join('\n');
    const changed = !state.worldbooksReady || sig !== state.worldbooksSig;
    state.worldbooksReady = true;
    state.worldbooksSig = sig;
    state.worldbooks = books;
    if (changed && state.page === 'settings' && !panel.hidden) refresh();
  }

  function reloadWorldbooks() {
    const seq = ++catalogSeq;
    let pending;
    try {
      const host = getHost();
      if (typeof host.readWorldbook !== 'function') {
        commitCatalog(seq, []);
        return;
      }
      pending = host.readWorldbook();
    } catch (error) {
      console.error('[shiju]', error);
      commitCatalog(seq, []);
      return;
    }
    Promise.resolve(pending).then(
      (read) => commitCatalog(seq, booksFromRead(read)),
      (error) => {
        console.error('[shiju]', error);
        commitCatalog(seq, []);
      },
    );
  }

  function captureFixFields() {
    const fix = state.fix;
    if (!fix) return;
    const panel = body.querySelector('.sj-fix');
    if (!panel || panel.dataset.factKind !== fix.kind || panel.dataset.factId !== fix.id) return;
    const title = panel.querySelector('#sj-fix-title');
    const text = panel.querySelector('#sj-fix-body');
    const instr = panel.querySelector('#sj-fix-instr');
    const draft = panel.querySelector('#sj-fix-draft');
    if (title) fix.manualTitle = title.value;
    if (text) fix.manualBody = text.value;
    if (instr) fix.instruction = instr.value;
    if (draft) fix.draft = draft.value;
  }

  function clearDraftField() {
    const draft = body.querySelector('#sj-fix-draft');
    if (draft) draft.value = '';
  }

  function refresh() {
    try { assertChatScope(surfaceScope); } catch {
      promptSettings.chatChanged(); management.chatChanged(); bootstrapController?.abort(); bootstrapController=null;
      settleConfirm(false);
      state.fix = null;
      state.dateDraft = null;
      state.pending = '';
      state.notice = '';
      state.worldbooks = [];
      state.worldbooksReady = false;
      state.archiveOpen = false;
      state.archivePage = 0;
      catalogSeq += 1;
      state.openDetails = Object.create(null);
      surfaceScope = captureChatScope();
    }
    captureFixFields();
    promptSettings.capture(body); management.capture(body);
    const settings = loadSettings();
    const hasBaibai = detectBaibaiBook();
    let lifecycle = null;
    let injectPreview = null;
    try {
      lifecycle = getLifecycleStatus();
      injectPreview = getInjectPreview();
    } catch (error) {
      console.error('[shiju]', error);
    }
    const world = safeLoadWorld();
    const evolution = evolutionGates(world, {
      busy: Boolean(state.pending) || isWorldBusy(),
      generating: isGeneratingTip(),
      lifecycle,
    });
    const view = {
      page: state.page,
      settingsSection: state.settingsSection,
      theme: settings.ui.theme,
      showFab: settings.ui.showFab,
      world,
      timeSource: settings.timeSource,
      hasBaibai,
      worldKind: state.worldKind,
      eventFilter: state.eventFilter,
      lifecycle,
      injectPreview,
      injectEnabled: settings.inject?.enabled !== false,
      worldbook: settings.worldbook,
      worldbooks: state.worldbooks,
      worldbooksReady: state.worldbooksReady,
      advOpen: state.advOpen,
      evolution,
      pending: state.pending,
      notice: state.pending ? '' : state.notice,
      fix: state.fix,
      worldBusy: isWorldBusy(),
      archiveOpen: state.archiveOpen,
      archivePage: state.archivePage,
      openDetails: state.openDetails,
      bootstrapPending:Boolean(bootstrapController),
      management: management.render(world,state.worldKind,state.page),
      promptSettings: state.page === 'settings' ? promptSettings.render(world, isWorldBusy()) : '',
    };
    applyTheme(view.theme);
    root.dataset.baibai = hasBaibai ? '1' : '0';
    paintChrome(view.world, lifecycle, injectPreview);
    for (const fold of body.querySelectorAll('[data-settings-fold]')) state.settingsFolds[fold.dataset.settingsFold] = fold.open;
    const restoreHistoryView = captureHistoryView(body);
    body.innerHTML = renderPage(view);
    for (const fold of body.querySelectorAll('[data-settings-fold]')) fold.open = state.settingsFolds[fold.dataset.settingsFold] === true;
    body.dataset.page = view.page;
    const labelled = document.getElementById(`sj-tab-${view.page}`) ? `sj-tab-${view.page}` : `sj-bnav-${view.page}`;
    body.setAttribute('aria-labelledby', labelled);
    for (const tab of tabs) {
      const on = tab.dataset.page === view.page;
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
      tab.tabIndex = on ? 0 : -1;
    }
    if (state.dateDraft) {
      const day = body.querySelector('#sj-day-index'), label = body.querySelector('#sj-day-label');
      if (day) day.value = state.dateDraft.dayIndex;
      if (label) label.value = state.dateDraft.dateLabel;
    }
    bindPage();
    restoreHistoryView();
    paintActions(evolution);
    if (view.page === 'settings') reloadWorldbooks();
  }

  function paintActions(gates) {
    const byAction = { evolve: gates.evolve, rerun: gates.rerun };
    for (const button of root.querySelectorAll('[data-action="evolve"], [data-action="rerun"]')) {
      const gate = byAction[button.dataset.action];
      if (!gate) continue;
      button.disabled = gate.enabled !== true;
      button.title = gate.title || '';
      if (gate.busy) button.setAttribute('aria-busy', 'true');
      else button.removeAttribute('aria-busy');
    }
  }

  function runManual(action) {
    if (state.pending) return;
    const gates = evolutionGates(safeLoadWorld(), { generating: isGeneratingTip(), lifecycle: getLifecycleStatus() });
    const gate = action === 'rerun' ? gates.rerun : gates.evolve;
    if (!gate.enabled) return;
    const operationScope = surfaceScope;
    state.pending = action;
    state.notice = '';
    state.noticeTone = '';
    refresh();
    const call = action === 'rerun' ? rerunLastEvolution() : runImmediateEvolution();
    call.then((result) => {
      if (surfaceScope !== operationScope) return;
      const ok = Boolean(result?.ok && result?.evolved);
      state.notice = evolutionResultText(action, result);
      state.noticeTone = ok ? 'ok' : 'error';
      if (!ok) console.error('[shiju]', result?.reason || state.notice);
    }, (error) => {
      if (surfaceScope !== operationScope) return;
      console.error('[shiju]', error);
      state.notice = error?.code?.startsWith('SHIJU_') ? error.message : '演进没有完成';
      state.noticeTone = 'error';
    }).then(() => {
      if (surfaceScope !== operationScope) return;
      state.pending = null;
      refresh();
    });
  }

  function watchGeneration() {
    let host;
    try {
      host = getHost();
    } catch (error) {
      console.error('[shiju]', error);
      return;
    }
    const types = host.event_types || {};
    const source = host.eventSource;
    if (!source || typeof source.on !== 'function') return;
    const schedule = () => {
      queueMicrotask(() => {
        try {
          refresh();
        } catch (error) {
          console.error('[shiju]', error);
        }
      });
    };
    for (const name of [
      types.SETTINGS_UPDATED,
      types.MESSAGE_EDITED,
      types.MESSAGE_UPDATED,
      types.MESSAGE_SWIPED,
      types.GENERATION_STARTED,
      types.GENERATION_ENDED,
      types.GENERATION_STOPPED,
      types.CHARACTER_MESSAGE_RENDERED,
      types.CHAT_CHANGED,
    ]) {
      if (name) source.on(name, schedule);
    }
  }

  function askConfirmation(title, message, action) {
    settleConfirm(false);
    const dialog = root.querySelector('#sj-confirm');
    confirmFocus = document.activeElement;
    root.querySelector('#sj-confirm-title').textContent = title;
    root.querySelector('#sj-confirm-body').textContent = message;
    root.querySelector('[data-confirm="ok"]').textContent = action;
    dialog.hidden = false;
    root.querySelector('[data-confirm="cancel"]').focus();
    return new Promise(resolve => { confirmResolver = resolve; });
  }
  function askConfirm() { return askConfirmation('生成修订稿', AI_CORRECTION_CONFIRM, '生成'); }

  function settleConfirm(accepted) {
    const resolve = confirmResolver;
    confirmResolver = null;
    const dialog = root.querySelector('#sj-confirm');
    if (dialog) dialog.hidden = true;
    if (resolve) {
      if (confirmFocus?.isConnected && confirmFocus.getClientRects().length) confirmFocus.focus({preventScroll:true});
      confirmFocus = null;
      resolve(accepted === true);
    }
  }

  function dropFixDraft(action) {
    clearDraftField();
    state.fix = dismissFixDraft(state.fix, action);
    refresh();
  }

  function toggleFix(target) {
    const parsed = parseFixTarget(target);
    if (!parsed) return;
    const item = findFact(safeLoadWorld(), parsed.kind, parsed.id);
    if (!item || isUnrevealedSecret(item) || isWorldBusy()) return;
    if (state.fix?.kind === parsed.kind && state.fix.id === parsed.id) {
      state.fix = null;
    } else {
      state.fix = { ...openFixDraft(item, parsed.kind), chatScope: captureChatScope() };
    }
    refresh();
    body.querySelector('.sj-fix')?.scrollIntoView({ block: 'nearest' });
  }

  function switchFixMode(mode) {
    const fix = state.fix;
    if (!fix || fix.busy || (mode !== 'manual' && mode !== 'ai') || fix.mode === mode) return;
    clearDraftField();
    const next = dismissFixDraft(fix, 'discard');
    next.mode = mode;
    state.fix = next;
    refresh();
  }

  async function saveManualEdit() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'manual' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    fix.busy = true;
    fix.error = '';
    fix.notice = '';
    refresh();
    try {
      await saveFactManual({
        chatScope: fix.chatScope,
        kind: fix.kind,
        id: fix.id,
        patch: { title: fix.manualTitle, body: fix.manualBody },
      });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '没有保存';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    const saved = findFact(safeLoadWorld(), fix.kind, fix.id);
    fix.busy = false;
    fix.notice = '已保存';
    fix.error = '';
    if (saved) {
      fix.manualTitle = typeof saved.title === 'string' ? saved.title : '';
      fix.manualBody = typeof saved.body === 'string' ? saved.body : '';
    }
    refresh();
  }

  async function generatePreview() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'ai' || fix.stage === 'preview' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    const accepted = await askConfirm();
    if (!accepted || state.fix !== fix) return;
    fix.busy = true;
    fix.error = '';
    refresh();
    let result;
    try {
      result = await previewAiCorrection({
        chatScope: fix.chatScope,
        kind: fix.kind,
        id: fix.id,
        instruction: fix.instruction,
      });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '修订稿没有生成';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    fix.busy = false;
    fix.stage = 'preview';
    fix.draft = typeof result?.previewText === 'string' ? result.previewText : '';
    fix.error = '';
    refresh();
  }

  async function adoptRevision() {
    const fix = state.fix;
    if (!fix || fix.mode !== 'ai' || fix.stage !== 'preview' || fix.busy || isWorldBusy()) return;
    captureFixFields();
    const text = fix.draft;
    fix.busy = true;
    fix.error = '';
    refresh();
    try {
      await applyAiCorrection({ chatScope: fix.chatScope, kind: fix.kind, id: fix.id, text });
    } catch (error) {
      if (state.fix !== fix) return;
      fix.busy = false;
      fix.error = error?.message || '没有写入';
      refresh();
      return;
    }
    if (state.fix !== fix) return;
    const saved = findFact(safeLoadWorld(), fix.kind, fix.id);
    fix.busy = false;
    fix.mode = 'manual';
    fix.stage = 'prompt';
    fix.draft = '';
    fix.notice = '已保存';
    fix.error = '';
    if (saved) {
      fix.manualTitle = typeof saved.title === 'string' ? saved.title : fix.manualTitle;
      fix.manualBody = typeof saved.body === 'string' ? saved.body : '';
    }
    clearDraftField();
    refresh();
  }

  function onFixClick(event) {
    const confirmButton = event.target?.closest?.('[data-confirm]');
    if (confirmButton) {
      settleConfirm(confirmButton.dataset.confirm === 'ok');
      return;
    }
    const hit = event.target?.closest?.(
      '[data-fix-dismiss], [data-fix-apply], [data-fix-save], [data-fix-generate], [data-fix-mode], [data-fix-open]',
    );
    if (!hit) return;
    const plan = planFixClick(hit.dataset);
    if (!plan) return;
    if (plan.effect === 'drop-draft') {
      dropFixDraft(plan.action);
      return;
    }
    if (plan.effect === 'apply') {
      adoptRevision();
      return;
    }
    if (plan.effect === 'save') {
      saveManualEdit();
      return;
    }
    if (plan.effect === 'preview') {
      generatePreview();
      return;
    }
    if (plan.effect === 'mode') {
      switchFixMode(plan.mode);
      return;
    }
    if (plan.effect === 'open') toggleFix(plan.target);
  }

  function leaveFixOnPageChange(nextPage) {
    if (state.page !== nextPage) state.fix = null;
    state.page = nextPage;
  }

  function syncFab() { fab.hidden = !panel.hidden || loadSettings().ui.showFab === false; }

  function openPanel(opener) {
    panelOpener = opener instanceof HTMLElement ? opener : document.activeElement;
    panel.hidden = false;
    fab.hidden = true;
    fab.setAttribute('aria-expanded', 'true');
    refresh();
    root.querySelector('.sj-close')?.focus();
    void updates.check();
  }

  function closePanel() {
    settleConfirm(false);
    state.fix = null;
    panel.hidden = true;
    syncFab();
    fab.setAttribute('aria-expanded', 'false');
    const visible = element => element?.isConnected && element.getClientRects().length > 0;
    const target = visible(panelOpener) ? panelOpener : !fab.hidden ? fab : document.getElementById('extensionsMenuButton');
    // Some host versions render the wand as a div, without a focusable tabindex.
    if (target && !target.hasAttribute('tabindex') && target.tabIndex < 0) {
      target.setAttribute('tabindex', '-1');
      target.addEventListener('blur', () => target.removeAttribute('tabindex'), {once:true});
    }
    target?.focus();
  }

  mountFab(fab, {
    getPosition() {
      return loadSettings().ui.fab;
    },
    onCommit(pos) {
      saveSettings({ ui: { fab: pos } });
    },
    onActivate: openPanel,
  });

  for (const tab of tabs) {
    tab.addEventListener('click', () => {
      leaveFixOnPageChange(tab.dataset.page);
      refresh();
      tab.focus();
    });
  }

  for (const nav of root.querySelectorAll('.sj-tabs')) {
    nav.addEventListener('keydown', (event) => {
      const keys = ['ArrowLeft', 'ArrowRight', 'Home', 'End'];
      if (!keys.includes(event.key)) return;
      const currentTabs = visibleTabs();
      if (!currentTabs.includes(event.target)) return;
      event.preventDefault();
      const current = currentTabs.findIndex((tab) => tab.dataset.page === state.page);
      let next = current < 0 ? 0 : current;
      if (event.key === 'ArrowRight') next = (next + 1) % currentTabs.length;
      if (event.key === 'ArrowLeft') next = (next - 1 + currentTabs.length) % currentTabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = currentTabs.length - 1;
      leaveFixOnPageChange(currentTabs[next].dataset.page);
      refresh();
      visibleTabs()[next]?.focus();
    });
  }

  root.addEventListener('click', (event) => {
    if (event.target.closest('[data-action="time-diagnosis"]')) {
      state.page = 'settings'; state.settingsSection = 'world'; refresh();
      const fold = body.querySelector('[data-settings-fold="date"]');
      if (fold) { fold.open = true; state.settingsFolds.date = true; }
      const diagnosis = body.querySelector('#sj-time-diagnosis');
      diagnosis?.scrollIntoView({block:'nearest'}); diagnosis?.focus({preventScroll:true});
      return;
    }
    const button = event.target?.closest?.('[data-action="evolve"], [data-action="rerun"]');
    if (!button || button.disabled || state.pending) return;
    runManual(button.dataset.action === 'rerun' ? 'rerun' : 'evolve');
  });
  root.addEventListener('click', onFixClick);
  root.querySelector('#sj-confirm')?.addEventListener('click', (event) => {
    if (event.target?.id === 'sj-confirm') settleConfirm(false);
  });

  root.querySelector('.sj-close').addEventListener('click', closePanel);
  root.addEventListener('keydown', (event) => {
    if (root.querySelector('.sj-reload-dialog')?.open) return;
    if (event.key === 'Tab' && !root.querySelector('#sj-confirm').hidden) {
      const buttons = [...root.querySelectorAll('#sj-confirm button')].filter(button => !button.disabled);
      const index = buttons.indexOf(document.activeElement);
      event.preventDefault(); buttons[(index + (event.shiftKey ? -1 : 1) + buttons.length) % buttons.length]?.focus();
      return;
    }
    if (event.key !== 'Escape' || panel.hidden) return;
    const dialog = root.querySelector('#sj-confirm');
    if (dialog && !dialog.hidden) {
      event.stopPropagation();
      settleConfirm(false);
      return;
    }
    if (state.fix) {
      event.stopPropagation();
      dropFixDraft('cancel');
      return;
    }
    if (event.target?.id === 'sj-custom-tag' || event.target?.id === 'sj-day-index' || event.target?.id === 'sj-day-label') return;
    event.stopPropagation();
    closePanel();
  });

  subscribe((kind) => {
    if (kind === 'settings') {
      applyTheme(loadSettings().ui.theme);
      syncFab();
      const life = getLifecycleStatus();
      paintChrome(safeLoadWorld(), life, getInjectPreview());
      paintActions(evolutionGates(safeLoadWorld(), { busy: Boolean(state.pending) || isWorldBusy(), generating: isGeneratingTip(), lifecycle: life }));
      return;
    }
    refresh();
  });

  subscribeOperations(refresh);
  subscribeDiagnostics(refresh);
  watchBaibaiReady(refresh);
  watchGeneration();
  syncFab();
  refresh();
  return { refresh, openPanel, closePanel };
}
