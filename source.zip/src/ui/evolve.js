/**
 * Enablement for the two manual buttons.
 * Mirrors the time gate: an armed world, the generating-tip lock, and a
 * checkpoint for rerun. This file does not evolve, commit, or inject.
 */

function blockTitle(reason) {
  if (reason === 'conflict') return '日期冲突，请查看时间校正';
  if (reason === 'history-changed') return '历史正文已修改，请查看处理方式';
  if (reason === 'busy') return '正在演进';
  if (reason === 'generating') return '末楼正在生成';
  if (reason === 'frozen') return '世界已冻结';
  if (reason === 'disabled') return '世界未启用';
  if (reason === 'no-checkpoint') return '还没有可重跑的演进';
  return '还没有已启用的世界';
}

function describe(reason, action) {
  if (reason) {
    return {
      enabled: false,
      reason,
      title: blockTitle(reason),
      busy: reason === 'busy',
    };
  }
  if (action === 'rerun') {
    return { enabled: true, reason: '', title: '覆盖上次结果，故事日不加一', busy: false };
  }
  return { enabled: true, reason: '', title: '不等跨日，故事日不加一', busy: false };
}

function armed(world) {
  return Boolean(world?.plugin?.enabled)
    && world?.plugin?.frozenAt == null
    && Boolean(world?.meta?.builtFingerprint);
}

/** True only when the ledger holds a checkpoint object. The object is not copied out. */
export function hasRerunCheckpoint(world) {
  const checkpoint = world?.lastEvolutionCheckpoint;
  return checkpoint != null && typeof checkpoint === 'object';
}

/**
 * @param {object | null | undefined} world
 * @param {{ busy?: boolean, generating?: boolean }} [options]
 */
export function evolutionGates(world, options = {}) {
  const busy = Boolean(options.busy);
  const generating = Boolean(options.generating);
  let block = '';
  if (busy) block = 'busy';
  else if (generating) block = 'generating';
  else if (!world?.meta?.builtFingerprint) block = 'no-world';
  else if (world?.plugin?.frozenAt != null) block = 'frozen';
  else if (!world?.plugin?.enabled) block = 'disabled';
  else if (!armed(world)) block = 'no-world';

  if (!block && options.lifecycle?.blocked) block = options.lifecycle.reason === 'history-changed' ? 'history-changed' : 'conflict';
  const rerunBlock = block || (hasRerunCheckpoint(world) ? '' : 'no-checkpoint');
  return {
    evolve: describe(block, 'evolve'),
    rerun: describe(rerunBlock, 'rerun'),
  };
}

/** Short status copy for a finished call. Does not include ledger fields. */
export function evolutionResultText(action, result) {
  if (result?.ok && result?.evolved) {
    return action === 'rerun'
      ? '已重跑，故事日没有前进'
      : '已立即演进，故事日按正文时间对齐';
  }
  if (result?.reason === 'no-increment') return '暂无新的变化可演进';
  if (result?.reason === 'history-changed') return '已处理的正文有修改，请先以正文为准重对齐';
  if (result?.reason === 'generating') return '末楼正在生成，这次没有演进';
  if (result?.reason === 'chat-changed') return '聊天已切换，本次演进已取消';
  if (result?.reason === 'no-world') return '还没有已启用的世界';
  if (result?.reason === 'no-checkpoint') return '还没有可重跑的演进';
  if (result?.message) return result.message;
  return '演进没有完成';
}
