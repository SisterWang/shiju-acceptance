import { initHistory, getHistory, historyStatus, retryHistory, clearHistory, subscribeHistory } from '../modules/model/history.js';
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels = {bootstrap:'建世界',auto:'自动演进',immediate:'立即演进',rerun:'重跑',realign:'重对齐',correct:'AI 修订',evolve:'世界演进','connection-test':'连接测试'};
const statuses = {running:'进行中',success:'成功',failed:'失败',cancelled:'已取消',interrupted:'结果未知／页面中断'};
const estimated = text => Math.ceil(Array.from(String(text || '')).length / 2);
const count = (real, text, characters) => Number.isFinite(real) && real >= 0 ? `${real} token` : `≈${characters == null ? estimated(text) : Math.ceil(characters / 2)} token`;
export function createRequestHistory({refresh, getScope, onNavigate}) {
  let open=false, page=0, chatFilter='all', purpose='all', status='all', notice='';
  let activeBody=null, signature='', timer=null;
  const currentSignature = () => JSON.stringify([getHistory().map(r => [r.id,r.status,r.status === 'running' ? '运行中' : r.business,Boolean(r.bodyOmitted),Boolean(r.notPersisted)]),historyStatus()]);
  function paintProgress() {
    if (!open || !activeBody) return;
    for (const el of activeBody.querySelectorAll('[data-history-progress]')) {
      const r=getHistory().find(item => item.id === el.dataset.historyProgress);
      if (r?.status === 'running') el.textContent=`${r.business} · ${((Date.now()-Date.parse(r.startedAt))/1000).toFixed(1)} 秒 · 已接收 ${r.characters || 0} 字`;
    }
  }
  subscribeHistory(() => {
    if (!open) {
      const el=activeBody?.querySelector('[data-history-save-status]');
      if (el) { el.textContent=historyStatus(); el.hidden=!historyStatus(); }
      return;
    }
    const next=currentSignature(); if(next!==signature) { signature=next; refresh(); } else paintProgress();
  });
  initHistory().then(()=>{ if(open) refresh(); });
  function render() {
    if(!open) return `<div class="sj-settings-card sj-history-entry"><p class="sj-field-label">请求历史 · 当前酒馆账号</p><p class="sj-note">查看调用结果、耗时与错误详情。</p><button type="button" class="sj-btn sj-btn-sm" data-history-action="open">查看请求历史</button><p class="sj-prompt-error" role="status" data-history-save-status${historyStatus() ? '' : ' hidden'}>${esc(historyStatus())}</p></div>`;
    const all=getHistory(), scope=getScope(); signature=currentSignature();
    const matches=all.filter(r => (chatFilter==='all' || (r.chatId === (scope?.chatId ?? '') && (r.characterId ?? null) === (scope?.characterId ?? null) && (r.groupId ?? null) === (scope?.groupId ?? null))) && (purpose==='all'||r.purpose===purpose) && (status==='all'||r.status===status));
    page=Math.max(0,Math.min(page,Math.ceil(matches.length/10)-1));
    const option=(v,label,selected) => `<option value="${esc(v)}"${v===selected?' selected':''}>${esc(label)}</option>`;
    const rows=matches.slice(page*10,page*10+10).map(r=>{
      const input=(r.messages || []).map(m=>m.content || '').join('\n');
      const usage=r.usage || {};
      const body=(r.messages || []).map((m,i)=>`<details><summary>${esc(String(m.role || 'message').toUpperCase())} · ${count(null,m.content)}</summary><pre class="sj-history-text">${esc(m.content)}</pre><button type="button" class="sj-btn sj-btn-sm" data-history-copy="${esc(r.id)}" data-part="${i}">复制本段</button></details>`).join('');
      return `<details class="sj-field sj-history-item" data-history-record="${esc(r.id)}" data-history-status="${esc(r.status)}"><summary>${esc(labels[r.purpose] || r.purpose)} · ${esc(r.chatId || '无聊天')} · ${esc(r.model || r.channel)} · ${esc(new Date(r.startedAt).toLocaleString())} · ${r.elapsedMs != null ? `${(r.elapsedMs/1000).toFixed(1)} 秒 · ` : ''}${esc(statuses[r.status] || r.status)}</summary>
        <p class="sj-note">${esc(r.channel)} · ${esc(r.model || '模型未知')} · ${esc(r.endpoint || '当前酒馆连接')} · ${esc(r.length ?? '未知')} token 上限 · ${r.requestedStream ? '请求流式' : '非流式'}${r.requestedStream && r.actualStream === false ? '（实际非流式）' : ''}</p>
        <p class="sj-note" data-history-progress="${esc(r.id)}">${esc(r.business)} · ${((r.elapsedMs || (r.status === 'running' ? Date.now()-Date.parse(r.startedAt) : 0))/1000).toFixed(1)} 秒${r.status === 'running' ? ` · 已接收 ${r.characters || 0} 字` : ''}${r.firstTextMs != null ? ` · 首段 ${(r.firstTextMs/1000).toFixed(1)} 秒` : ''}</p>
        <p class="sj-note">输入 ${count(usage.prompt_tokens,input,r.inputCharacters)} · 输出 ${count(usage.completion_tokens,r.response,r.characters)} · ≈ 为字符数除以 2 的粗估</p>
        ${r.transportStatus ? `<p class="sj-note">接口：${r.transportStatus === 'success' ? '响应成功' : r.transportStatus === 'cancelled' ? '已取消' : '请求失败'} · 业务结果：${esc(r.business)}</p>` : ''}${r.errorStage ? `<p class="sj-note">错误阶段：${esc(r.errorStage)}</p>` : ''}${r.httpStatus ? `<p class="sj-note">酒馆 HTTP ${esc(r.httpStatus)}；上游状态可能不可见</p>` : ''}${r.finishReason ? `<p class="sj-note">结束原因：${esc(r.finishReason)}</p>` : ''}${r.error ? `<p class="sj-prompt-error">${esc(r.error)}</p>` : ''}${r.notPersisted ? '<p class="sj-note">超出历史容量，仅本页保留，刷新后不可用。可复制或导出备份。</p>' : ''}${r.summaryOnly ? '<p class="sj-note">页面中断前仅保存了请求摘要，完整正文不可用。</p>' : ''}${r.bodyOmitted ? '<p class="sj-note">正文未持久保存（超出容量限制）</p>' : ''}
        ${body}<details><summary>返回内容</summary><pre class="sj-history-text">${esc(r.response || '')}</pre><button type="button" class="sj-btn sj-btn-sm" data-history-copy="${esc(r.id)}" data-part="response">复制返回</button></details>
        <button type="button" class="sj-btn sj-btn-sm" data-history-copy="${esc(r.id)}" data-part="all">复制整条</button></details>`;
    }).join('');
    return `<div class="sj-field sj-request-history"><p class="sj-field-label">请求历史 · 当前酒馆账号</p><p class="sj-note">历史可能包含隐秘；独立历史文件请勿清理。</p><details class="sj-history-help"><summary>保存范围与隐私说明</summary><p class="sj-note">展开、复制或导出会显示完整提示词和世界隐秘。最多保存 30 条，超出容量时清理最旧记录。</p><p class="sj-note">历史独立保存在酒馆服务器的 shiju-request-history-v1.json 文件中。数据清理工具可能将它列为未引用文件，请勿清理；建议定期导出备份。设备间轮流使用时请刷新页面。</p></details>
      <div class="sj-acts"><button class="sj-btn sj-btn-sm" type="button" data-history-action="back">返回设置</button><button class="sj-btn sj-btn-sm" type="button" data-history-action="export">导出历史</button><button class="sj-btn sj-btn-sm" type="button" data-history-action="clear">清空历史</button>${historyStatus() ? '<button class="sj-btn sj-btn-sm" type="button" data-history-action="retry">重试保存</button>' : ''}</div>
      ${historyStatus() ? `<p role="alert" class="sj-prompt-error">${esc(historyStatus())}</p>` : ''}${notice ? `<p role="status" class="sj-note">${esc(notice)}</p>` : ''}
      <div class="sj-history-filters"><label>聊天 <select data-history-filter="chat">${option('all','全部聊天',chatFilter)}${option('current','当前聊天',chatFilter)}</select></label>
      <label>任务 <select data-history-filter="purpose">${option('all','全部任务',purpose)}${Object.entries(labels).map(([k,v])=>option(k,v,purpose)).join('')}</select></label>
      <label>状态 <select data-history-filter="status">${option('all','全部状态',status)}${Object.entries(statuses).map(([k,v])=>option(k,v,status)).join('')}</select></label></div>
      ${rows || '<p class="sj-note">暂无请求记录</p>'}<div class="sj-acts"><button type="button" class="sj-btn sj-btn-sm" data-history-action="previous"${page===0?' disabled':''}>上一页</button><span>${page+1} / ${Math.max(1,Math.ceil(matches.length/10))}</span><button type="button" class="sj-btn sj-btn-sm" data-history-action="next"${(page+1)*10>=matches.length?' disabled':''}>下一页</button></div></div>`;
  }
  function bind(body) {
    activeBody=body;
    // Stable keys let the shell restore reading context after a status update.
    for (const row of body.querySelectorAll('[data-history-record]')) {
      [row, ...row.querySelectorAll('details')].forEach((detail, index) => {
        const key = [row.dataset.historyRecord, index];
        detail.dataset.historyView = JSON.stringify([...key, 'fold']);
        detail.querySelector(':scope > summary').dataset.historyView = JSON.stringify([...key, 'summary']);
        const text = detail.querySelector(':scope > pre');
        if (text) text.dataset.historyView = JSON.stringify([...key, 'text']);
      });
    }
    const help = body.querySelector('.sj-history-help');
    if (help) { help.dataset.historyView = 'help'; help.querySelector('summary').dataset.historyView = 'help-summary'; }
    for (const el of body.querySelectorAll('[data-history-action], [data-history-filter], [data-history-copy], [data-settings-section]')) {
      el.dataset.historyView = JSON.stringify([el.dataset.historyAction, el.dataset.historyFilter, el.dataset.historyCopy, el.dataset.part, el.dataset.settingsSection]);
    }
    body.querySelectorAll('[data-history-filter]').forEach(el=>el.addEventListener('change',()=>{if(el.dataset.historyFilter==='chat') chatFilter=el.value; if(el.dataset.historyFilter==='purpose') purpose=el.value; if(el.dataset.historyFilter==='status') status=el.value;page=0;refresh();}));
    body.querySelectorAll('[data-history-action]').forEach(el=>el.addEventListener('click',async()=>{
      const action=el.dataset.historyAction; notice='';
      if(action==='open') { onNavigate('history'); return; }
      if(action==='back') { onNavigate('model'); return; }
      if(action==='previous') page--;
      if(action==='next') page++;
      if(action==='clear') { if(!globalThis.confirm('清空所有世局请求历史？此操作无法撤销。')) return; await clearHistory(); notice=historyStatus() ? '本页历史已清空，服务器尚未确认；刷新后旧记录可能再次出现' : '历史已清空'; }
      if(action==='retry') { el.disabled=true; el.textContent='正在重试…'; await retryHistory(); notice=historyStatus() || '历史已保存'; }
      if(action==='export') { const blob=new Blob([JSON.stringify(getHistory(),null,2)],{type:'application/json'}), url=URL.createObjectURL(blob), a=document.createElement('a');a.href=url;a.download='shiju-request-history.json';a.click();URL.revokeObjectURL(url);notice='已导出历史'; }
      refresh();
    }));
    body.querySelectorAll('[data-history-copy]').forEach(el=>el.addEventListener('click',async()=>{
      const r=getHistory().find(x=>x.id===el.dataset.historyCopy); if(!r) return;
      const part=el.dataset.part, text=part==='all'?JSON.stringify(r,null,2):part==='response'?r.response || '':r.messages?.[Number(part)]?.content || '';
      try { await navigator.clipboard.writeText(text); el.textContent='已复制'; } catch { el.textContent='复制失败'; }
    }));
  }
  function setActive(active) { open=active; if(active && !timer) timer=setInterval(paintProgress,1000); if(!active) { clearInterval(timer); timer=null; } }
  return {render,bind,isOpen:()=>open,setActive};
}
