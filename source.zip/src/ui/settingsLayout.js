// Shared structure for settings groups; colors come from the current theme.
export function settingsCard(title, scope, content, description = '', extra = '') {
  return `<section class="sj-settings-card" ${extra}>
    <header class="sj-settings-card-head"><h3>${title}</h3>${scope ? `<span class="sj-setting-scope">${scope}</span>` : ''}</header>
    ${description ? `<p class="sj-settings-description">${description}</p>` : ''}
    <div class="sj-settings-card-content">${content}</div>
  </section>`;
}
