import { settingsCard } from './settingsLayout.js';
import { isSecret, isFactVisible, isKnown } from '../modules/events.js';
import { THEME_OPTIONS } from '../store/schema.js';
import { bookMode } from './bookMode.js';
import { evolutionGates } from './evolve.js';
import { findFact, isUnrevealedSecret, projectWorld } from './readout.js';
import { resolveTimeSourceMode, TIME_SOURCE_CHOICES } from './timeSource.js';
import { usageParts } from './usage.js';

export const PAGES = [
  { id: 'feed', label: '动态', icon: '◎' },
  { id: 'world', label: '世界', icon: '▣' },
  { id: 'events', label: '事件', icon: '☰' },
  { id: 'settings', label: '设置', icon: '⚙' },
];

export const WORLD_KINDS = [
  { id: 'region', label: '地区', key: 'regions' },
  { id: 'faction', label: '势力', key: 'factions' },
  { id: 'org', label: '组织', key: 'orgs' },
];

export const EVENT_FILTERS = [
  { id: 'all', label: '全部' },
  { id: 'macro', label: '宏观事态' },
  { id: 'news', label: '远方见闻' },
  { id: 'secret', label: '隐秘' },
];

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

const KIND_LABEL = {
  macro: '宏观事态',
  news: '远方见闻',
  secret: '隐秘',
};

function countText(bucket) {
  if (!bucket) return '—';
  return String(bucket.total);
}

function emptyCard(title, lead) {
  return `<div class="sj-empty"><b>${escapeHtml(title)}</b><span>${escapeHtml(lead)}</span></div>`;
}

function truncatedNote(view) {
  if (!view.truncated) return '';
  return '<p class="sj-trunc-note">资料被截断</p>';
}

function usageBar(usage) {
  const parts = usageParts(usage);
  if (!parts) {
    return `<div class="sj-usage is-empty" role="status" aria-label="本轮用量">
      <span class="sj-ub-label">本轮用量（估算 token）</span>
      <span class="sj-ub-parts">尚无 · 演进结束后可见</span>
    </div>`;
  }
  return `<div class="sj-usage" role="status" aria-label="本轮用量（估算 token）">
    <span class="sj-ub-label">本轮用量（估算 token）</span>
    <span class="sj-ub-parts">
      <span><span class="sj-ub-k">世界书</span> <span class="sj-ub-v">${escapeHtml(parts.worldbook)}</span></span>
      <span class="sj-ub-plus">+</span>
      <span><span class="sj-ub-k">MVU</span> <span class="sj-ub-v">${escapeHtml(parts.mvu)}</span></span>
      <span class="sj-ub-plus">+</span>
      <span><span class="sj-ub-k">近期正文</span> <span class="sj-ub-v">${escapeHtml(parts.recent)}</span></span>
      <span class="sj-ub-dot">·</span>
      <span class="sj-ub-sum"><span class="sj-ub-k">共</span> <span class="sj-ub-v">${escapeHtml(parts.total)}</span></span>
    </span>
  </div>`;
}

const BOOK_MODES = [
  ['default', '默认'],
  ['pin', '常驻'],
  ['exclude', '排除'],
];

function worldbookRows(books, worldbook) {
  const settings = { worldbook };
  return books.map((book) => {
    const mode = bookMode(settings, book);
    const uid = escapeHtml(book.uid || '');
    const name = escapeHtml(book.name || '');
    const buttons = BOOK_MODES.map(([id, label]) => {
      const on = mode === id;
      return `<button type="button" data-wb-mode="${id}" data-wb-uid="${uid}" data-wb-name="${name}" class="${on ? 'is-on' : ''}" aria-pressed="${on ? 'true' : 'false'}">${label}</button>`;
    }).join('');
    return `<div class="sj-wb-row">
      <span class="sj-wb-name">${name}</span>
      <div class="sj-wb-seg" role="group" aria-label="${name} 装配">${buttons}</div>
    </div>`;
  }).join('');
}

function worldbookAdvanced(state) {
  const open = state.advOpen ? ' open' : '';
  const ready = state.worldbooksReady === true;
  const books = ready && Array.isArray(state.worldbooks) ? state.worldbooks : [];
  let list;
  if (!ready) list = '<p class="sj-wb-empty">正在读取已加载的世界书…</p>';
  else if (!books.length) list = '<p class="sj-wb-empty">没有已加载的世界书。</p>';
  else list = `<div class="sj-wb-list">${worldbookRows(books, state.worldbook)}</div>`;
  return `<details class="sj-adv"${open}>
    <summary>已绑定的世界书</summary>
    <div class="sj-field sj-wb-field">
      <p class="sj-field-label">世界书 · 书级常驻 / 排除</p>
      <p class="sj-wb-note">按书选择读取方式；未修改的书沿用默认规则。</p>
      ${list}
      <details class="sj-wb-legend"><summary>这些选项有什么区别？</summary>
        <b>常驻</b>：每轮读取该书所有已启用条目，包括绿灯条目。<br>
        <b>排除</b>：不读取该书的条目和名册。<br>
        <b>默认</b>：按默认选择规则读取蓝灯和本轮相关的绿灯条目。
      </details>
    </div>
  </details>`;
}

function canCorrect(entry) {
  return Boolean(entry?.id) && !isUnrevealedSecret(entry);
}

function fixPanel(state, factKind, id) {
  const fix = state.fix;
  if (!fix || fix.kind !== factKind || fix.id !== id) return '';
  const item = findFact(state.world, factKind, id);
  if (!item || isUnrevealedSecret(item)) return '';
  const mode = fix.mode === 'ai' ? 'ai' : 'manual';
  const stage = fix.stage === 'preview' ? 'preview' : 'prompt';
  const busy = Boolean(fix.busy || state.worldBusy);
  const disabled = busy ? ' disabled' : '';
  const savedBody = typeof item.body === 'string' ? item.body : '';
  const notice = typeof fix.notice === 'string' ? fix.notice : '';
  const error = typeof fix.error === 'string' ? fix.error : '';
  const manualTitle = typeof fix.manualTitle === 'string' ? fix.manualTitle : '';
  const manualBody = typeof fix.manualBody === 'string' ? fix.manualBody : '';
  const instruction = typeof fix.instruction === 'string' ? fix.instruction : '';
  const draft = typeof fix.draft === 'string' ? fix.draft : '';
  let inner = '';
  if (mode === 'manual') {
    inner = `
      <label class="sj-fix-label" for="sj-fix-title">标题</label>
      <input id="sj-fix-title" type="text" maxlength="40" autocomplete="off" value="${escapeHtml(manualTitle)}"${disabled}>
      <div class="sj-fix-grid">
        <div>
          <div class="sj-fix-label">原文</div>
          <div class="sj-fix-orig">${escapeHtml(savedBody)}</div>
        </div>
        <div>
          <label class="sj-fix-label" for="sj-fix-body">改正文</label>
          <textarea id="sj-fix-body" maxlength="500"${disabled}>${escapeHtml(manualBody)}</textarea>
        </div>
      </div>
      <div class="sj-fix-foot">
        <span class="sj-fix-toast">${escapeHtml(notice)}</span>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
        <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-save="1"${disabled}>保存</button>
      </div>`;
  } else if (stage === 'prompt') {
    inner = `
      <div class="sj-fix-prompt">
        <p class="sj-fix-line">只改这一条 · 先出修订稿 · 采用后才写入</p>
        <input id="sj-fix-instr" class="sj-fix-instr" type="text" maxlength="200" autocomplete="off"
          placeholder="可选：语气更冷、去掉人名" value="${escapeHtml(instruction)}"${disabled}>
        <div class="sj-fix-foot">
          <span class="sj-fix-toast">${escapeHtml(notice)}</span>
          <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
          <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-generate="1"${disabled}>生成修订稿 · 消耗 1 次</button>
        </div>
      </div>`;
  } else {
    inner = `
      <div class="sj-fix-grid">
        <div>
          <div class="sj-fix-label">原文</div>
          <div class="sj-fix-orig">${escapeHtml(savedBody)}</div>
        </div>
        <div>
          <label class="sj-fix-label" for="sj-fix-draft">修订稿</label>
          <textarea id="sj-fix-draft" class="sj-fix-draft" maxlength="500"${disabled}>${escapeHtml(draft)}</textarea>
        </div>
      </div>
      <div class="sj-fix-foot">
        <span class="sj-fix-toast">${escapeHtml(notice)}</span>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="discard" data-fix-action="discard">弃用</button>
        <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-apply="1"${disabled}>采用此修订</button>
      </div>`;
  }
  const errorLine = state.worldBusy ? '<p class="sj-fix-error" role="status">正在演进，完成后可修改</p>' : error ? `<p class="sj-fix-error" role="alert">${escapeHtml(error)}</p>` : '';
  return `<div class="sj-fix" data-fact-kind="${escapeHtml(factKind)}" data-fact-id="${escapeHtml(id)}" data-fix-mode="${mode}" data-fix-stage="${stage}"${busy ? ' aria-busy="true"' : ''}>
    <div class="sj-fix-top">
      <span class="sj-fix-title">修正此条</span>
      <div class="sj-fix-seg" role="group" aria-label="修正方式">
        <button type="button" class="sj-fix-seg-btn${mode === 'manual' ? ' is-on' : ''}" data-fix-mode="manual" aria-pressed="${mode === 'manual' ? 'true' : 'false'}"${disabled}>手动</button>
        <button type="button" class="sj-fix-seg-btn${mode === 'ai' ? ' is-on' : ''}" data-fix-mode="ai" aria-pressed="${mode === 'ai' ? 'true' : 'false'}"${disabled}>AI</button>
      </div>
    </div>
    <div class="sj-fix-body">${inner}${errorLine}</div>
  </div>`;
}

function detailButton(key, open, label = '查看详情') {
  return `<button type="button" class="sj-btn sj-detail-toggle" data-detail-toggle="${escapeHtml(key)}" aria-expanded="${open}" aria-controls="sj-detail-${escapeHtml(encodeURIComponent(key))}">${open ? '收起详情' : label}<span aria-hidden="true">${open ? '−' : '+'}</span></button>`;
}
const closedDetail = key => `<div id="sj-detail-${escapeHtml(encodeURIComponent(key))}" hidden></div>`;

function referenceName(world, ref) {
  const items = ['regions','factions','orgs','events'].flatMap(key => world?.[key] || []);
  const item = items.find(item => item.id === ref || item.name === ref || item.title === ref);
  return item ? isFactVisible(item) ? item.name || item.title : '未揭晓的隐秘' : ref;
}

function recordDetail(world, raw, key, entity = false) {
  const text = entity ? raw.summary || raw.body : raw.body;
  const fields = [];
  if (entity) {
    const status = {active:'活跃',dormant:'沉寂',resolved:'已结束'}[raw.status];
    if (status) fields.push(['当前状态',status]);
    if (raw.regionRef) fields.push(['所属地区',referenceName(world,raw.regionRef)]);
    if (raw.evidence) fields.push(['记录依据',raw.evidence]);
  } else {
    if (raw.phase) fields.push(['发展阶段',raw.phase]);
    if (raw.lifecycle) fields.push(['事件状态',raw.lifecycle === 'archived' ? '已归档' : '进行中']);
    if (raw.relatedRefs?.length) fields.push(['关联资料',raw.relatedRefs.map(ref=>referenceName(world,ref)).join('、')]);
    if (raw.linkedEventId) fields.push(['关联事件',referenceName(world,raw.linkedEventId)]);
    if (raw.mergedInto) fields.push(['合并至',referenceName(world,raw.mergedInto)]);
  }
  if (Number.isFinite(raw.updatedAtDay)) fields.push(['更新于',`世界第 ${raw.updatedAtDay} 日`]);
  const section = (label, content) => content ? `<section class="sj-detail-section"><h4>${label}</h4><p class="sj-detail-text">${escapeHtml(content)}</p></section>` : '';
  return `<div class="sj-record-detail" id="sj-detail-${escapeHtml(encodeURIComponent(key))}">
    ${section(entity ? '概况' : '事件详情',text) || '<p class="sj-detail-empty">暂无详情，这条记录尚未保存正文。</p>'}
    ${section('长期后果',raw.outcome)}${section('与当前剧情的联系',raw.playerRipple)}
    ${fields.length ? `<dl class="sj-detail-meta">${fields.map(([label,value])=>`<div><dt>${label}</dt><dd>${escapeHtml(value)}</dd></div>`).join('')}</dl>` : ''}
  </div>`;
}

function factCards(state, entries, factKind) {
  if (!entries.length) return '';
  const cards = entries.map((entry) => {
    const raw = findFact(state.world, factKind, entry.id) || state.world?.[factKind === 'event' ? 'events' : 'todayChanges']?.[entry.index] || entry;
    const secret = isSecret(raw);
    const visible = isFactVisible(raw);
    const title = visible ? (raw.title || raw.name) : '未揭晓的隐秘';
    const tag = entry.kind && KIND_LABEL[entry.kind]
      ? `<span class="sj-tag${secret ? ' sj-tag-secret' : ''}">${KIND_LABEL[entry.kind]}</span>` : '';
    const disabled = state.worldBusy ? ' disabled' : '';
    const target = `${factKind}:${escapeHtml(entry.id)}`;
    const detailKey = `${factKind}:${entry.id || `@${entry.index}`}`;
    const expanded = visible && state.openDetails?.[detailKey] === true;
    const knowledge = raw.knowledgeOverride || 'auto';
    const controls = secret ? `<div class="sj-acts">
      <button type="button" class="sj-btn sj-btn-sm" data-secret-target="${target}" data-secret-action="${visible ? 'hide' : 'view'}"${disabled}>${visible ? '收起内容' : '查看内容'}</button>
      <label>知情状态 <select data-knowledge-target="${target}"${disabled}>
        <option value="auto"${knowledge === 'auto' ? ' selected' : ''}>自动（${isKnown({ ...raw, knowledgeOverride: 'auto' }) ? '已知' : '未知'}）</option>
        <option value="known"${knowledge === 'known' ? ' selected' : ''}>主角已知</option>
        <option value="unknown"${knowledge === 'unknown' ? ' selected' : ''}>主角未知</option>
      </select></label></div>` : '';
    const acts = visible ? `<div class="sj-record-actions">${detailButton(detailKey,expanded)}${raw.id ? `<button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-open="${target}"${disabled}>修正</button>` : ''}</div>` : '';
    const phase = visible && raw.phase ? `<p class="sj-record-caption">${escapeHtml(raw.phase)}${raw.lifecycle === 'archived' ? ' · 已归档' : ''}</p>` : '';
    return `<article class="sj-card sj-record-card${secret ? ' sj-card-secret' : ''}"><div class="sj-card-row"><strong>${escapeHtml(title)}</strong>${tag}</div>${phase}${acts}${expanded ? recordDetail(state.world,raw,detailKey) : visible ? closedDetail(detailKey) : ''}${controls}${visible && raw.id ? fixPanel(state,factKind,entry.id) : ''}</article>`;
  }).join('');
  return `<div class="sj-list">${cards}</div>`;
}

function entityCards(state, items, kind) {
  if (!items.length) return '';
  const cards = items.map((item) => {
    const raw = state.world?.[kind.key]?.[item.index] || item;
    const key = `entity:${kind.id}:${item.id || item.index}`;
    const open = state.openDetails?.[key] === true;
    const hidden = !isFactVisible(raw);
    const tag = isSecret(raw) ? '<span class="sj-tag sj-tag-secret">隐秘</span>' : '';
    return `<article class="sj-card sj-record-card${isSecret(raw) ? ' sj-card-secret' : ''}"><div class="sj-card-row"><strong>${escapeHtml(hidden && !open ? '未揭晓的隐秘' : item.name)}</strong>${tag}</div>
      ${hidden ? '<p class="sj-record-caption">仅查看内容，不改变主角知情状态。</p>' : ''}
      <div class="sj-record-actions">${detailButton(key,open,hidden ? '查看隐秘' : '查看详情')}</div>
      ${open ? recordDetail(state.world,raw,key,true) : closedDetail(key)}</article>`;
  }).join('');
  return `<div class="sj-list">${cards}</div>`;
}

function renderInjectPreview(preview) {
  if (!preview || (!preview.previewText && !preview.active)) return '';
  const count = Array.isArray(preview.items) ? preview.items.length : 0;
  const omitted = preview.omittedSecrets ? '隐秘默认不注入。' : '';
  const lead = preview.active ? `本轮将注入 ${count} 条。` : `本轮不注入。可预览 ${count} 条。`;
  return `<p class="sj-note" data-inject-preview="1" data-macro-key="shiju_macro" data-macro-depth="4">${escapeHtml(lead)}${escapeHtml(omitted)}背景参考，不必强行写入正文。</p>`;
}

function renderFeed(state) {
  const view = projectWorld(state.world);
  const today = view.today;
  const todayN = today ? String(today.total) : '—';
  let card;
  if (view.empty) {
    card = emptyCard('还没有世界账', '记录会跟着这则聊天，不会散落在浏览器里。');
  } else if (today.total === 0) {
    card = emptyCard('这一日还没有变动', '同一故事日里，这里保持安静。');
  } else {
    const titled = factCards(state, today.titles, 'todayChange');
    const hidden = today.secretHidden > 0
      ? `<p class="sj-secret-count"><span class="sj-tag sj-tag-secret">隐秘</span> ${today.secretHidden} 条，未揭晓前不列标题。</p>`
      : '';
    card = titled || hidden
      ? `${titled}${hidden}`
      : emptyCard('今日变更', `${today.total} 条已记下。没有可列的标题。`);
  }
  const entities = view.entities;
  const rail = [
    ['region', '地区', entities?.regions],
    ['faction', '势力', entities?.factions],
    ['org', '组织', entities?.orgs],
  ].map(([kind, label, bucket], index) => {
    const sep = index === 0 ? '' : '<span class="sj-sep" aria-hidden="true">·</span>';
    return `${sep}<button type="button" class="sj-rail-btn" data-world-kind="${kind}">${label} ${escapeHtml(countText(bucket))}</button>`;
  }).join('');
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <p class="sj-lede">今日变更记在这一日。隐秘未揭晓前不列标题、不摊开正文。</p>
    <div class="sj-rail">${rail}<span class="sj-rail-n">今日 ${escapeHtml(todayN)} 条</span></div>
    ${usageBar(view.usage)}
    <div class="sj-tl-head"><h3>今日变更</h3><span class="sj-tl-n">${escapeHtml(todayN)}</span></div>
    ${renderInjectPreview(state.injectPreview)}
    ${card}
  </section>`;
}

function renderWorld(state) {
  const view = projectWorld(state.world);
  const kind = WORLD_KINDS.some((item) => item.id === state.worldKind) ? state.worldKind : 'region';
  const current = WORLD_KINDS.find((item) => item.id === kind);
  const buttons = WORLD_KINDS.map((item) => {
    const on = item.id === kind;
    const bucket = view.entities ? view.entities[item.key] : null;
    return `<button type="button" class="sj-seg-btn${on ? ' is-on' : ''}" data-world-kind="${item.id}" aria-pressed="${on ? 'true' : 'false'}">${item.label} ${escapeHtml(countText(bucket))}</button>`;
  }).join('');
  const bucket = view.entities ? view.entities[current.key] : null;
  const lead = view.empty
    ? '这则聊天还没有世局记录。'
    : '展开查看概况、状态与关联资料。';
  const cards = bucket ? entityCards(state,bucket.items,current) : '';
  let body;
  if (view.empty) body = emptyCard('还没有实体', '地区、势力和组织会分列在这里。');
  else if (!bucket.total) body = emptyCard(`还没有记下的${current.label}`, '同一档里保持空白。');
  else if (!cards) body = emptyCard(`已记下 ${bucket.total} 个${current.label}`, '没有可显示的名字。');
  else body = cards;
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <div class="sj-seg" role="group" aria-label="实体">${buttons}</div>
    <p class="sj-hint">${escapeHtml(current.label)} · ${escapeHtml(lead)}</p>
    ${body}
  </section>`;
}

function renderEvents(state) {
  const view = projectWorld(state.world);
  const filter = EVENT_FILTERS.some((item) => item.id === state.eventFilter) ? state.eventFilter : 'all';
  const all = view.events?.items || [];
  const archive = Boolean(state.archiveOpen);
  const selected = all.filter((item) => (item.lifecycle === 'archived') === archive);
  const counts = view.events ? { all: selected.length, macro: 0, news: 0, secret: 0 } : null;
  if (counts) for (const item of selected) counts[item.kind] += 1;
  const buttons = EVENT_FILTERS.map((item) => {
    const on = item.id === filter;
    const suffix = counts ? ` ${counts[item.id]}` : '';
    return `<button type="button" class="sj-seg-btn${on ? ' is-on' : ''}" data-event-filter="${item.id}" aria-pressed="${on ? 'true' : 'false'}">${item.label}${suffix}</button>`;
  }).join('');
  const rows = view.events
    ? selected.filter((item) => filter === 'all' || item.kind === filter)
    : [];
  const n = counts ? counts[filter] : null;
  let card;
  if (view.empty) card = emptyCard('还没有事件', '宏观事态、远方见闻和隐秘会分列在这里。');
  else if (n === 0) card = emptyCard('这一档还没有记下', '有新的事件时，会在这里展示。');
  else {
    const page = Math.min(Math.max(0, state.archivePage || 0), Math.max(0, Math.ceil(rows.length / 10) - 1));
    const shown = archive ? rows.slice(page * 10, page * 10 + 10) : rows;
    const titled = factCards(state, shown.filter((item) => item.title), 'event');
    if (archive && rows.length > 10) card = `<div class="sj-acts"><button data-archive-page="${page - 1}"${page === 0 ? ' disabled' : ''}>上一页</button><span>${page + 1} / ${Math.ceil(rows.length / 10)}</span><button data-archive-page="${page + 1}"${(page + 1) * 10 >= rows.length ? ' disabled' : ''}>下一页</button></div>`;
    card = (titled + (card || '')) || emptyCard('已记下事件', `${n} 条。没有可列的标题。`);
  }
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <div class="sj-seg" role="group" aria-label="事件">${buttons}</div>
    <button type="button" class="sj-btn" data-archive-toggle="1">${archive ? '返回进行中' : `查看归档（${all.filter((item) => item.lifecycle === 'archived').length}）`}</button>
    ${card}
  </section>`;
}

function choiceCard(choice, selected, hasBaibai, customTag) {
  const disabled = choice.id === 'baibai' && !hasBaibai;
  const on = selected === choice.id;
  const desc = disabled ? '未检测到柏宝书' : choice.desc;
  let extra = '';
  if (choice.id === 'custom' && on) {
    extra = `<span class="sj-ts-extra">
      <label class="sj-ts-extra-label" for="sj-custom-tag">时间标签名</label>
      <input id="sj-custom-tag" type="text" autocomplete="off" value="${escapeHtml(customTag)}" placeholder="例如 time 或 story_end">
      <span class="sj-ts-note">填写预设或其他插件正在使用的标签名。</span>
    </span>`;
  } else if (choice.id === 'baibai' && on) {
    extra = `<span class="sj-ts-extra"><span class="sj-ts-note">从最新正文读取柏宝书的时间标记，优先采用剧情中的日期。</span></span>`;
  }
  return `<label class="sj-ts${on ? ' is-on' : ''}${disabled ? ' is-disabled' : ''}">
    <input class="sj-sr" type="radio" name="sj-time-source" value="${choice.id}"${on ? ' checked' : ''}${disabled ? ' disabled' : ''}>
    <span class="sj-ts-row">
      <span class="sj-ts-radio" aria-hidden="true"></span>
      <span class="sj-ts-main">
        <span class="sj-ts-name">${escapeHtml(choice.label)}</span>
        <span class="sj-ts-desc">${escapeHtml(desc)}</span>
        ${extra}
      </span>
    </span>
  </label>`;
}

function manualActions(state) {
  if (state.evolution?.evolve && state.evolution?.rerun) return state.evolution;
  return evolutionGates(state.world, {
    busy: state.pending === 'evolve' || state.pending === 'rerun',
    generating: Boolean(state.generating),
  });
}

function actionButton(action, label, gate, primary) {
  const enabled = gate?.enabled === true;
  const title = typeof gate?.title === 'string' ? gate.title : '';
  const klass = primary ? 'sj-btn sj-btn-primary sj-btn-sm' : 'sj-btn sj-btn-ghost sj-btn-sm';
  const disabled = enabled ? '' : ' disabled';
  const titleAttr = title ? ` title="${escapeHtml(title)}"` : '';
  const busy = gate?.busy ? ' aria-busy="true"' : '';
  return `<button type="button" class="${klass}"${disabled} data-action="${action}"${titleAttr}${busy}>${escapeHtml(label)}</button>`;
}

function renderManualActions(state) {
  const gates = manualActions(state);
  const pendingText = state.pending === 'rerun'
    ? '正在重跑…'
    : state.pending === 'evolve'
      ? '正在立即演进…'
      : '';
  const outcome = pendingText || (typeof state.notice === 'string' ? state.notice : '');
  const outcomeHtml = outcome
    ? `<p class="sj-note" data-evolve-notice="1">${escapeHtml(outcome)}</p>`
    : '';
  return `<div class="sj-field">
      <p class="sj-field-label">推演操作</p>
      <div class="sj-acts">
        ${actionButton('evolve', '立即演进', gates.evolve, true)}
        ${actionButton('rerun', '重跑上次演进', gates.rerun, false)}
      </div>
      <p class="sj-note">立即演进不等跨日，故事日不加一。重跑覆盖上次结果，故事日也不加一。</p>
      ${outcomeHtml}
    </div>`;
}

function renderSettings(state) {
  const theme = state.theme;
  const stored = state.timeSource && typeof state.timeSource === 'object' ? state.timeSource : {};
  const customTag = typeof stored.customTag === 'string' ? stored.customTag : '';
  const hasBaibai = Boolean(state.hasBaibai);
  const selected = resolveTimeSourceMode(stored.mode, hasBaibai);
  const radios = THEME_OPTIONS.map((item) => {
    const checked = item.id === theme ? ' checked' : '';
    return `<label class="sj-theme"><input class="sj-sr" type="radio" name="sj-theme" value="${escapeHtml(item.id)}"${checked}><span class="sj-swatch" data-swatch="${escapeHtml(item.id)}"></span><span class="sj-theme-name">${escapeHtml(item.label)}</span></label>`;
  }).join('');
  const hint = hasBaibai
    ? '<p class="sj-ts-hint">已检测到<strong class="sj-em">柏宝书</strong>，也可以选择其他时间来源。</p>'
    : '<p class="sj-ts-hint">未检测到柏宝书 · 默认「世局标签」档</p>';
  const choices = TIME_SOURCE_CHOICES.map((choice) => choiceCard(choice, selected, hasBaibai, customTag)).join('');
  const life = state.lifecycle && typeof state.lifecycle === 'object' ? state.lifecycle : {};
  const world = state.world;
  const enabled = Boolean(life.enabled);
  const frozen = Boolean(life.frozen);
  const injectOn = state.injectEnabled !== false;
  let pluginLabel = '启用';
  if (enabled) pluginLabel = '冻结';
  else if (frozen) pluginLabel = '重开';
  const dayIndex = world?.storyClock?.dayIndex;
  const dateLabel = typeof world?.storyClock?.dateLabel === 'string' ? world.storyClock.dateLabel : '';
  const showPrompt = Boolean(life.promptRequired && life.prompt && enabled);
  const choiceButtons = showPrompt
    ? (Array.isArray(life.choices) ? life.choices : []).filter((choice) => choice === 'keep' || choice === 'realign').map((choice) => {
      const label = choice === 'realign' ? '以正文为准重对齐' : '保持插件状态';
      return `<button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-choice="${choice}">${label}</button>`;
    }).join('')
    : '';
  const promptBlock = showPrompt
    ? `<div class="sj-field" data-lifecycle-prompt="1">
        <p class="sj-note">${escapeHtml(life.prompt)}</p>
        <div class="sj-acts">${choiceButtons}</div>
      </div>`
    : '';
  const dayBlock = world
    ? `<div class="sj-day-fix">
        <label class="sj-ts-extra-label" for="sj-day-index">故事日</label>
        <input id="sj-day-index" type="number" min="0" step="1" inputmode="numeric" value="${escapeHtml(dayIndex ?? 0)}"${enabled ? '' : ' disabled'}>
        <label class="sj-ts-extra-label" for="sj-day-label">日期标签</label>
        <input id="sj-day-label" type="text" autocomplete="off" value="${escapeHtml(dateLabel)}" placeholder="例如 1988/1/3"${enabled ? '' : ' disabled'}>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-action="correct-day"${enabled ? '' : ' disabled'}>校正故事日</button>
      </div>`
    : '';
  const parts = state.promptSettings || {};
  const sections = [
    ['world','演进','世界演进','管理当前世界的运行方式与发展方向。'],
    ['model','模型','模型与请求','配置世局使用的连接、输出和提示词。'],
    ['sources','资料','世界资料','选择演进可读取的世界书，并检查资料诊断。'],
    ['appearance','外观','界面外观','选择适合当前阅读环境的主题。'],
    ['history','记录','请求记录','查看模型调用结果、用量和错误详情。'],
  ];
  const active = sections.find(item => item[0] === state.settingsSection) || sections[0];
  const nav = `<nav class="sj-settings-nav" aria-label="设置分类">${sections.map(([id,label])=>`<button type="button" data-settings-section="${id}" aria-current="${active[0]===id ? 'page' : 'false'}">${label}</button>`).join('')}</nav>`;
  const statusCard = settingsCard('世界运行','当前聊天',`
    <div class="sj-setting-row"><div><strong>${enabled ? '演进已启用' : frozen ? '世界已冻结' : '尚未启用'}</strong><p class="sj-note">${enabled ? '有新的跨日剧情时自动演进。' : frozen ? '世界账已保留，恢复后从当前剧情继续。' : '启用后将根据当前资料建立世界。'}</p></div><button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-action="toggle-plugin" data-enabled="${enabled ? '1' : '0'}">${pluginLabel}</button></div>
    <div class="sj-setting-divider sj-setting-row"><div><strong>正文参考</strong><span class="sj-setting-scope">全局</span><p class="sj-note">允许将世界动态作为正文背景参考。</p></div><button type="button" class="sj-btn sj-btn-sm" data-action="toggle-inject" aria-pressed="${injectOn}">${injectOn ? '已开启' : '已关闭'}</button></div>
    ${renderInjectPreview(state.injectPreview)}
    <p class="sj-note">冻结期间停止演进与注入，恢复时不补演。</p>`);
  const timeCard = settingsCard('故事时间','全局',`
    <details class="sj-settings-disclosure" data-settings-fold="time"><summary><span>时间来源</span><span class="sj-disclosure-value">${escapeHtml(TIME_SOURCE_CHOICES.find(c=>c.id===selected)?.label || selected)}</span></summary><div class="sj-disclosure-body">${hint}<div class="sj-ts-list" role="radiogroup" aria-label="时间源">${choices}</div><p class="sj-note">同日或未识别到日期时，不自动演进。</p></div></details>
    ${world ? `<details class="sj-settings-disclosure" data-settings-fold="date"><summary><span>手动校正日期</span><span class="sj-setting-scope">当前聊天</span></summary><div class="sj-disclosure-body"><p class="sj-note">仅在识别的故事日期不准确时使用。</p>${dayBlock}</div></details>` : ''}`);
  const content = active[0] === 'world' ? `${promptBlock}${statusCard}${parts.preference || ''}${timeCard}<details class="sj-settings-disclosure sj-settings-tools" data-settings-fold="tools"><summary>手动演进操作</summary>${renderManualActions(state)}</details>`
    : active[0] === 'model' ? `${parts.model || ''}${parts.history || ''}`
    : active[0] === 'sources' ? `${settingsCard('世界书读取','全局',worldbookAdvanced(state),'规则按书名保存；常驻会增加每次请求的输入量。')}${parts.diagnostics || ''}`
    : active[0] === 'appearance' ? settingsCard('配色主题','全局',`<div class="sj-themes" role="radiogroup" aria-label="主题">${radios}</div><p class="sj-note">选择后立即生效。悬浮球可拖动，位置会自动保存。</p>`)
    : parts.history || '';
  return `<section class="sj-settings">${nav}<header class="sj-settings-heading"><h2>${active[2]}</h2><p>${active[3]}</p></header><div class="sj-settings-content" id="sj-settings-${active[0]}">${content}</div></section>`;
}

/** Pure markup for one page. State is passed in; this does not touch storage. */
export function renderPage(state) {
  const page = PAGES.some((item) => item.id === state.page) ? state.page : 'feed';
  if (page === 'world') return renderWorld(state);
  if (page === 'events') return renderEvents(state);
  if (page === 'settings') return renderSettings(state);
  return renderFeed(state);
}
