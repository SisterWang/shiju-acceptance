import { isSecret, isFactVisible, isKnown } from '../modules/events.js';
import { THEME_OPTIONS } from '../store/schema.js';
import { bookMode } from './bookMode.js';
import { evolutionGates } from './evolve.js';
import { findFact, isUnrevealedSecret, projectWorld } from './readout.js';
import { resolveTimeSourceMode, TIME_SOURCE_CHOICES } from './timeSource.js';
import { usageParts } from './usage.js';

export const PAGES = [
  { id: 'feed', label: '动态', icon: '◎' },
  { id: 'world', label: '世界', icon: '▣' },
  { id: 'events', label: '事件', icon: '☰' },
  { id: 'settings', label: '设置', icon: '⚙' },
];

export const WORLD_KINDS = [
  { id: 'region', label: '地区', key: 'regions' },
  { id: 'faction', label: '势力', key: 'factions' },
  { id: 'org', label: '组织', key: 'orgs' },
];

export const EVENT_FILTERS = [
  { id: 'all', label: '全部' },
  { id: 'macro', label: '宏观事态' },
  { id: 'news', label: '远方见闻' },
  { id: 'secret', label: '隐秘' },
];

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

const KIND_LABEL = {
  macro: '宏观事态',
  news: '远方见闻',
  secret: '隐秘',
};

function countText(bucket) {
  if (!bucket) return '—';
  return String(bucket.total);
}

function emptyCard(title, lead) {
  return `<div class="sj-empty"><b>${escapeHtml(title)}</b><span>${escapeHtml(lead)}</span></div>`;
}

function truncatedNote(view) {
  if (!view.truncated) return '';
  return '<p class="sj-trunc-note">资料被截断</p>';
}

function usageBar(usage) {
  const parts = usageParts(usage);
  if (!parts) {
    return `<div class="sj-usage is-empty" role="status" aria-label="本轮用量">
      <span class="sj-ub-label">本轮用量（估算 token）</span>
      <span class="sj-ub-parts">尚无 · 演进结束后可见</span>
    </div>`;
  }
  return `<div class="sj-usage" role="status" aria-label="本轮用量（估算 token）">
    <span class="sj-ub-label">本轮用量（估算 token）</span>
    <span class="sj-ub-parts">
      <span><span class="sj-ub-k">世界书</span> <span class="sj-ub-v">${escapeHtml(parts.worldbook)}</span></span>
      <span class="sj-ub-plus">+</span>
      <span><span class="sj-ub-k">MVU</span> <span class="sj-ub-v">${escapeHtml(parts.mvu)}</span></span>
      <span class="sj-ub-plus">+</span>
      <span><span class="sj-ub-k">近期正文</span> <span class="sj-ub-v">${escapeHtml(parts.recent)}</span></span>
      <span class="sj-ub-dot">·</span>
      <span class="sj-ub-sum"><span class="sj-ub-k">共</span> <span class="sj-ub-v">${escapeHtml(parts.total)}</span></span>
    </span>
  </div>`;
}

const BOOK_MODES = [
  ['default', '默认'],
  ['pin', '常驻'],
  ['exclude', '排除'],
];

function worldbookRows(books, worldbook) {
  const settings = { worldbook };
  return books.map((book) => {
    const mode = bookMode(settings, book);
    const uid = escapeHtml(book.uid || '');
    const name = escapeHtml(book.name || '');
    const buttons = BOOK_MODES.map(([id, label]) => {
      const on = mode === id;
      return `<button type="button" data-wb-mode="${id}" data-wb-uid="${uid}" data-wb-name="${name}" class="${on ? 'is-on' : ''}" aria-pressed="${on ? 'true' : 'false'}">${label}</button>`;
    }).join('');
    return `<div class="sj-wb-row">
      <span class="sj-wb-name">${name}</span>
      <div class="sj-wb-seg" role="group" aria-label="${name} 装配">${buttons}</div>
    </div>`;
  }).join('');
}

function worldbookAdvanced(state) {
  const open = state.advOpen ? ' open' : '';
  const ready = state.worldbooksReady === true;
  const books = ready && Array.isArray(state.worldbooks) ? state.worldbooks : [];
  let list;
  if (!ready) list = '<p class="sj-wb-empty">正在读取已加载的世界书…</p>';
  else if (!books.length) list = '<p class="sj-wb-empty">没有已加载的世界书。</p>';
  else list = `<div class="sj-wb-list">${worldbookRows(books, state.worldbook)}</div>`;
  return `<details class="sj-adv"${open}>
    <summary>高级设置（默认可不改）</summary>
    <div class="sj-field sj-wb-field">
      <p class="sj-field-label">世界书 · 书级常驻 / 排除</p>
      <p class="sj-wb-note">可选。不配则跟蓝绿策略。按<strong>书</strong>配，不是逐条勾。</p>
      ${list}
      <div class="sj-wb-legend">
        <b>常驻</b>＝该书所有启用条目正文全文进演进（含绿灯，不经轮转；不是只进名册、不是只蓝灯）<br>
        <b>排除</b>＝名册 + 正文都不进<br>
        <b>默认</b>＝跟蓝绿策略
      </div>
    </div>
  </details>`;
}

function canCorrect(entry) {
  return Boolean(entry?.id) && !isUnrevealedSecret(entry);
}

function fixPanel(state, factKind, id) {
  const fix = state.fix;
  if (!fix || fix.kind !== factKind || fix.id !== id) return '';
  const item = findFact(state.world, factKind, id);
  if (!item || isUnrevealedSecret(item)) return '';
  const mode = fix.mode === 'ai' ? 'ai' : 'manual';
  const stage = fix.stage === 'preview' ? 'preview' : 'prompt';
  const busy = Boolean(fix.busy || state.worldBusy);
  const disabled = busy ? ' disabled' : '';
  const savedBody = typeof item.body === 'string' ? item.body : '';
  const notice = typeof fix.notice === 'string' ? fix.notice : '';
  const error = typeof fix.error === 'string' ? fix.error : '';
  const manualTitle = typeof fix.manualTitle === 'string' ? fix.manualTitle : '';
  const manualBody = typeof fix.manualBody === 'string' ? fix.manualBody : '';
  const instruction = typeof fix.instruction === 'string' ? fix.instruction : '';
  const draft = typeof fix.draft === 'string' ? fix.draft : '';
  let inner = '';
  if (mode === 'manual') {
    inner = `
      <label class="sj-fix-label" for="sj-fix-title">标题</label>
      <input id="sj-fix-title" type="text" maxlength="40" autocomplete="off" value="${escapeHtml(manualTitle)}"${disabled}>
      <div class="sj-fix-grid">
        <div>
          <div class="sj-fix-label">原文</div>
          <div class="sj-fix-orig">${escapeHtml(savedBody)}</div>
        </div>
        <div>
          <label class="sj-fix-label" for="sj-fix-body">改正文</label>
          <textarea id="sj-fix-body" maxlength="500"${disabled}>${escapeHtml(manualBody)}</textarea>
        </div>
      </div>
      <div class="sj-fix-foot">
        <span class="sj-fix-toast">${escapeHtml(notice)}</span>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
        <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-save="1"${disabled}>保存</button>
      </div>`;
  } else if (stage === 'prompt') {
    inner = `
      <div class="sj-fix-prompt">
        <p class="sj-fix-line">只改这一条 · 先出修订稿 · 采用后才写入</p>
        <input id="sj-fix-instr" class="sj-fix-instr" type="text" maxlength="200" autocomplete="off"
          placeholder="可选：语气更冷、去掉人名" value="${escapeHtml(instruction)}"${disabled}>
        <div class="sj-fix-foot">
          <span class="sj-fix-toast">${escapeHtml(notice)}</span>
          <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
          <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-generate="1"${disabled}>生成修订稿 · 消耗 1 次</button>
        </div>
      </div>`;
  } else {
    inner = `
      <div class="sj-fix-grid">
        <div>
          <div class="sj-fix-label">原文</div>
          <div class="sj-fix-orig">${escapeHtml(savedBody)}</div>
        </div>
        <div>
          <label class="sj-fix-label" for="sj-fix-draft">修订稿</label>
          <textarea id="sj-fix-draft" class="sj-fix-draft" maxlength="500"${disabled}>${escapeHtml(draft)}</textarea>
        </div>
      </div>
      <div class="sj-fix-foot">
        <span class="sj-fix-toast">${escapeHtml(notice)}</span>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="cancel" data-fix-action="cancel">取消</button>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-fix-dismiss="discard" data-fix-action="discard">弃用</button>
        <button type="button" class="sj-btn sj-btn-primary sj-btn-sm" data-fix-apply="1"${disabled}>采用此修订</button>
      </div>`;
  }
  const errorLine = state.worldBusy ? '<p class="sj-fix-error" role="status">正在演进，完成后可修改</p>' : error ? `<p class="sj-fix-error" role="alert">${escapeHtml(error)}</p>` : '';
  return `<div class="sj-fix" data-fact-kind="${escapeHtml(factKind)}" data-fact-id="${escapeHtml(id)}" data-fix-mode="${mode}" data-fix-stage="${stage}"${busy ? ' aria-busy="true"' : ''}>
    <div class="sj-fix-top">
      <span class="sj-fix-title">修正此条</span>
      <div class="sj-fix-seg" role="group" aria-label="修正方式">
        <button type="button" class="sj-fix-seg-btn${mode === 'manual' ? ' is-on' : ''}" data-fix-mode="manual" aria-pressed="${mode === 'manual' ? 'true' : 'false'}"${disabled}>手动</button>
        <button type="button" class="sj-fix-seg-btn${mode === 'ai' ? ' is-on' : ''}" data-fix-mode="ai" aria-pressed="${mode === 'ai' ? 'true' : 'false'}"${disabled}>AI</button>
      </div>
    </div>
    <div class="sj-fix-body">${inner}${errorLine}</div>
  </div>`;
}

function factCards(state, entries, factKind) {
  if (!entries.length) return '';
  const cards = entries.map((entry) => {
    const raw = findFact(state.world, factKind, entry.id) || entry;
    const secret = isSecret(raw);
    const visible = isFactVisible(raw);
    const title = visible ? (raw.title || raw.name) : '未揭晓的隐秘';
    const tag = entry.kind && KIND_LABEL[entry.kind]
      ? `<span class="sj-tag${secret ? ' sj-tag-secret' : ''}">${KIND_LABEL[entry.kind]}</span>` : '';
    const disabled = state.worldBusy ? ' disabled' : '';
    const target = `${factKind}:${escapeHtml(entry.id)}`;
    const knowledge = raw.knowledgeOverride || 'auto';
    const controls = secret ? `<div class="sj-acts">
      <button type="button" class="sj-btn sj-btn-sm" data-secret-target="${target}" data-secret-action="${visible ? 'hide' : 'view'}"${disabled}>${visible ? '收起内容' : '查看内容'}</button>
      <label>知情状态 <select data-knowledge-target="${target}"${disabled}>
        <option value="auto"${knowledge === 'auto' ? ' selected' : ''}>自动（${isKnown({ ...raw, knowledgeOverride: 'auto' }) ? '已知' : '未知'}）</option>
        <option value="known"${knowledge === 'known' ? ' selected' : ''}>主角已知</option>
        <option value="unknown"${knowledge === 'unknown' ? ' selected' : ''}>主角未知</option>
      </select></label></div>` : '';
    const acts = visible && raw.id
      ? `<div class="sj-acts"><button type="button" class="sj-btn sj-btn-sm" data-fix-open="${target}"${disabled}>修正</button></div>${fixPanel(state, factKind, entry.id)}` : '';
    const detail = visible && (secret || raw.lifecycle === 'archived') && raw.body ? `<p>${escapeHtml(raw.body)}</p>` : '';
    const outcome = visible && raw.lifecycle === 'archived' && raw.outcome ? `<p>长期后果：${escapeHtml(raw.outcome)}</p>` : '';
    return `<article class="sj-card${secret ? ' sj-card-secret' : ''}"><div class="sj-card-row"><strong>${escapeHtml(title)}</strong>${tag}</div>${detail}${outcome}${controls}${acts}</article>`;
  }).join('');
  return `<div class="sj-list">${cards}</div>`;
}

function entityCards(items) {
  if (!items.length) return '';
  const cards = items.map((item) => {
    const tag = item.secret ? '<span class="sj-tag sj-tag-secret">隐秘</span>' : '';
    return `<article class="sj-card${item.secret ? ' sj-card-secret' : ''}"><div class="sj-card-row"><strong>${escapeHtml(item.name)}</strong>${tag}</div></article>`;
  }).join('');
  return `<div class="sj-list">${cards}</div>`;
}

function renderInjectPreview(preview) {
  if (!preview || (!preview.previewText && !preview.active)) return '';
  const count = Array.isArray(preview.items) ? preview.items.length : 0;
  const omitted = preview.omittedSecrets ? '隐秘默认不注入。' : '';
  const lead = preview.active ? `本轮将注入 ${count} 条。` : `本轮不注入。可预览 ${count} 条。`;
  return `<p class="sj-note" data-inject-preview="1" data-macro-key="shiju_macro" data-macro-depth="4">${escapeHtml(lead)}${escapeHtml(omitted)}背景参考，不必强行写入正文。</p>`;
}

function renderFeed(state) {
  const view = projectWorld(state.world);
  const today = view.today;
  const todayN = today ? String(today.total) : '—';
  let card;
  if (view.empty) {
    card = emptyCard('还没有世界账', '记录会跟着这则聊天，不会散落在浏览器里。');
  } else if (today.total === 0) {
    card = emptyCard('这一日还没有变动', '同一故事日里，这里保持安静。');
  } else {
    const titled = factCards(state, today.titles, 'todayChange');
    const hidden = today.secretHidden > 0
      ? `<p class="sj-secret-count"><span class="sj-tag sj-tag-secret">隐秘</span> ${today.secretHidden} 条，未揭晓前不列标题。</p>`
      : '';
    card = titled || hidden
      ? `${titled}${hidden}`
      : emptyCard('今日变更', `${today.total} 条已记下。没有可列的标题。`);
  }
  const entities = view.entities;
  const rail = [
    ['region', '地区', entities?.regions],
    ['faction', '势力', entities?.factions],
    ['org', '组织', entities?.orgs],
  ].map(([kind, label, bucket], index) => {
    const sep = index === 0 ? '' : '<span class="sj-sep" aria-hidden="true">·</span>';
    return `${sep}<button type="button" class="sj-rail-btn" data-world-kind="${kind}">${label} ${escapeHtml(countText(bucket))}</button>`;
  }).join('');
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <p class="sj-lede">今日变更记在这一日。隐秘未揭晓前不列标题、不摊开正文。</p>
    <div class="sj-rail">${rail}<span class="sj-rail-n">今日 ${escapeHtml(todayN)} 条</span></div>
    ${usageBar(view.usage)}
    <div class="sj-tl-head"><h3>今日变更</h3><span class="sj-tl-n">${escapeHtml(todayN)}</span></div>
    ${renderInjectPreview(state.injectPreview)}
    ${card}
  </section>`;
}

function renderWorld(state) {
  const view = projectWorld(state.world);
  const kind = WORLD_KINDS.some((item) => item.id === state.worldKind) ? state.worldKind : 'region';
  const current = WORLD_KINDS.find((item) => item.id === kind);
  const buttons = WORLD_KINDS.map((item) => {
    const on = item.id === kind;
    const bucket = view.entities ? view.entities[item.key] : null;
    return `<button type="button" class="sj-seg-btn${on ? ' is-on' : ''}" data-world-kind="${item.id}" aria-pressed="${on ? 'true' : 'false'}">${item.label} ${escapeHtml(countText(bucket))}</button>`;
  }).join('');
  const bucket = view.entities ? view.entities[current.key] : null;
  const lead = view.empty
    ? '这则聊天还没有世局记录。'
    : '数目读自这则聊天的世界账。只列名字。';
  const cards = bucket ? entityCards(bucket.items) : '';
  let body;
  if (view.empty) body = emptyCard('还没有实体', '地区、势力和组织会分列在这里。');
  else if (!bucket.total) body = emptyCard(`还没有记下的${current.label}`, '同一档里保持空白。');
  else if (!cards) body = emptyCard(`已记下 ${bucket.total} 个${current.label}`, '没有可显示的名字。');
  else body = cards;
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <div class="sj-seg" role="group" aria-label="实体">${buttons}</div>
    <p class="sj-hint">${escapeHtml(current.label)} · ${escapeHtml(lead)}</p>
    ${body}
  </section>`;
}

function renderEvents(state) {
  const view = projectWorld(state.world);
  const filter = EVENT_FILTERS.some((item) => item.id === state.eventFilter) ? state.eventFilter : 'all';
  const all = view.events?.items || [];
  const archive = Boolean(state.archiveOpen);
  const selected = all.filter((item) => (item.lifecycle === 'archived') === archive);
  const counts = view.events ? { all: selected.length, macro: 0, news: 0, secret: 0 } : null;
  if (counts) for (const item of selected) counts[item.kind] += 1;
  const buttons = EVENT_FILTERS.map((item) => {
    const on = item.id === filter;
    const suffix = counts ? ` ${counts[item.id]}` : '';
    return `<button type="button" class="sj-seg-btn${on ? ' is-on' : ''}" data-event-filter="${item.id}" aria-pressed="${on ? 'true' : 'false'}">${item.label}${suffix}</button>`;
  }).join('');
  const rows = view.events
    ? selected.filter((item) => filter === 'all' || item.kind === filter)
    : [];
  const n = counts ? counts[filter] : null;
  let card;
  if (view.empty) card = emptyCard('还没有事件', '宏观事态、远方见闻和隐秘会分列在这里。');
  else if (n === 0) card = emptyCard('这一档还没有记下', '正文不在这一页摊开。');
  else {
    const page = Math.min(Math.max(0, state.archivePage || 0), Math.max(0, Math.ceil(rows.length / 10) - 1));
    const shown = archive ? rows.slice(page * 10, page * 10 + 10) : rows;
    const titled = factCards(state, shown.filter((item) => item.title), 'event');
    if (archive && rows.length > 10) card = `<div class="sj-acts"><button data-archive-page="${page - 1}"${page === 0 ? ' disabled' : ''}>上一页</button><span>${page + 1} / ${Math.ceil(rows.length / 10)}</span><button data-archive-page="${page + 1}"${(page + 1) * 10 >= rows.length ? ' disabled' : ''}>下一页</button></div>`;
    card = (titled + (card || '')) || emptyCard('已记下事件', `${n} 条。没有可列的标题。`);
  }
  return `<section class="sj-block">
    ${truncatedNote(view)}
    <div class="sj-seg" role="group" aria-label="事件">${buttons}</div>
    <button type="button" class="sj-btn" data-archive-toggle="1">${archive ? '返回进行中' : `查看归档（${all.filter((item) => item.lifecycle === 'archived').length}）`}</button>
    ${card}
  </section>`;
}

function choiceCard(choice, selected, hasBaibai, customTag) {
  const disabled = choice.id === 'baibai' && !hasBaibai;
  const on = selected === choice.id;
  const desc = disabled ? '未检测到柏宝书' : choice.desc;
  let extra = '';
  if (choice.id === 'custom' && on) {
    extra = `<span class="sj-ts-extra">
      <label class="sj-ts-extra-label" for="sj-custom-tag">标签名（起止或单点）</label>
      <input id="sj-custom-tag" type="text" autocomplete="off" value="${escapeHtml(customTag)}" placeholder="例如 time 或 story_end">
      <span class="sj-ts-note">只解析、默认不另注世局时间锚。填你预设或别的插件已有的标签名。</span>
    </span>`;
  } else if (choice.id === 'baibai' && on) {
    extra = `<span class="sj-ts-extra"><span class="sj-ts-note">读最新楼正文 &lt;bbs_start&gt; / &lt;bbs_end&gt;（由新到旧扫），<b>不独信</b>可能滞后的 state.time。</span></span>`;
  }
  return `<label class="sj-ts${on ? ' is-on' : ''}${disabled ? ' is-disabled' : ''}">
    <input class="sj-sr" type="radio" name="sj-time-source" value="${choice.id}"${on ? ' checked' : ''}${disabled ? ' disabled' : ''}>
    <span class="sj-ts-row">
      <span class="sj-ts-radio" aria-hidden="true"></span>
      <span class="sj-ts-main">
        <span class="sj-ts-name">${escapeHtml(choice.label)}</span>
        <span class="sj-ts-desc">${escapeHtml(desc)}</span>
        ${extra}
      </span>
    </span>
  </label>`;
}

function manualActions(state) {
  if (state.evolution?.evolve && state.evolution?.rerun) return state.evolution;
  return evolutionGates(state.world, {
    busy: state.pending === 'evolve' || state.pending === 'rerun',
    generating: Boolean(state.generating),
  });
}

function actionButton(action, label, gate, primary) {
  const enabled = gate?.enabled === true;
  const title = typeof gate?.title === 'string' ? gate.title : '';
  const klass = primary ? 'sj-btn sj-btn-primary sj-btn-sm' : 'sj-btn sj-btn-ghost sj-btn-sm';
  const disabled = enabled ? '' : ' disabled';
  const titleAttr = title ? ` title="${escapeHtml(title)}"` : '';
  const busy = gate?.busy ? ' aria-busy="true"' : '';
  return `<button type="button" class="${klass}"${disabled} data-action="${action}"${titleAttr}${busy}>${escapeHtml(label)}</button>`;
}

function renderManualActions(state) {
  const gates = manualActions(state);
  const pendingText = state.pending === 'rerun'
    ? '正在重跑…'
    : state.pending === 'evolve'
      ? '正在立即演进…'
      : '';
  const outcome = pendingText || (typeof state.notice === 'string' ? state.notice : '');
  const outcomeHtml = outcome
    ? `<p class="sj-note" data-evolve-notice="1">${escapeHtml(outcome)}</p>`
    : '';
  return `<div class="sj-field">
      <p class="sj-field-label">推演操作</p>
      <div class="sj-acts">
        ${actionButton('evolve', '立即演进', gates.evolve, true)}
        ${actionButton('rerun', '重跑上次演进', gates.rerun, false)}
      </div>
      <p class="sj-note">立即演进不等跨日，故事日不加一。重跑覆盖上次结果，故事日也不加一。</p>
      ${outcomeHtml}
    </div>`;
}

function renderSettings(state) {
  const theme = state.theme;
  const stored = state.timeSource && typeof state.timeSource === 'object' ? state.timeSource : {};
  const customTag = typeof stored.customTag === 'string' ? stored.customTag : '';
  const hasBaibai = Boolean(state.hasBaibai);
  const selected = resolveTimeSourceMode(stored.mode, hasBaibai);
  const radios = THEME_OPTIONS.map((item) => {
    const checked = item.id === theme ? ' checked' : '';
    return `<label class="sj-theme"><input class="sj-sr" type="radio" name="sj-theme" value="${escapeHtml(item.id)}"${checked}><span class="sj-swatch" data-swatch="${escapeHtml(item.id)}"></span><span class="sj-theme-name">${escapeHtml(item.label)}</span></label>`;
  }).join('');
  const hint = hasBaibai
    ? '<p class="sj-ts-hint">检测到<strong class="sj-em">柏宝书</strong> · 可选手改</p>'
    : '<p class="sj-ts-hint">未检测到柏宝书 · 默认「世局标签」档</p>';
  const choices = TIME_SOURCE_CHOICES.map((choice) => choiceCard(choice, selected, hasBaibai, customTag)).join('');
  const life = state.lifecycle && typeof state.lifecycle === 'object' ? state.lifecycle : {};
  const world = state.world;
  const enabled = Boolean(life.enabled);
  const frozen = Boolean(life.frozen);
  const injectOn = state.injectEnabled !== false;
  let pluginLabel = '启用';
  if (enabled) pluginLabel = '冻结';
  else if (frozen) pluginLabel = '重开';
  const dayIndex = world?.storyClock?.dayIndex;
  const dateLabel = typeof world?.storyClock?.dateLabel === 'string' ? world.storyClock.dateLabel : '';
  const showPrompt = Boolean(life.promptRequired && life.prompt && enabled);
  const choiceButtons = showPrompt
    ? (Array.isArray(life.choices) ? life.choices : []).filter((choice) => choice === 'keep' || choice === 'realign').map((choice) => {
      const label = choice === 'realign' ? '以正文为准重对齐' : '保持插件状态';
      return `<button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-choice="${choice}">${label}</button>`;
    }).join('')
    : '';
  const promptBlock = showPrompt
    ? `<div class="sj-field" data-lifecycle-prompt="1">
        <p class="sj-note">${escapeHtml(life.prompt)}</p>
        <div class="sj-acts">${choiceButtons}</div>
      </div>`
    : '';
  const dayBlock = world
    ? `<div class="sj-day-fix">
        <label class="sj-ts-extra-label" for="sj-day-index">故事日</label>
        <input id="sj-day-index" type="number" min="0" step="1" inputmode="numeric" value="${escapeHtml(dayIndex ?? 0)}"${enabled ? '' : ' disabled'}>
        <label class="sj-ts-extra-label" for="sj-day-label">日期标签</label>
        <input id="sj-day-label" type="text" autocomplete="off" value="${escapeHtml(dateLabel)}" placeholder="例如 1988/1/3"${enabled ? '' : ' disabled'}>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-action="correct-day"${enabled ? '' : ' disabled'}>校正故事日</button>
      </div>`
    : '';
  return `<section class="sj-block">
    <div class="sj-field">
      <p class="sj-field-label">启停</p>
      <div class="sj-acts">
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-action="toggle-plugin" data-enabled="${enabled ? '1' : '0'}">${pluginLabel}</button>
        <button type="button" class="sj-btn sj-btn-ghost sj-btn-sm" data-action="toggle-inject" aria-pressed="${injectOn ? 'true' : 'false'}">${injectOn ? '注入开' : '注入关'}</button>
      </div>
      <p class="sj-note">冻结会停演进、停注入。重开不补演关闭期间，也不删楼层。注入开关只停宏观注入。</p>
      ${renderInjectPreview(state.injectPreview)}
    </div>
    ${promptBlock}
    ${state.promptSettings || ''}
    <div class="sj-field">
      <p class="sj-field-label">时间源</p>
      ${hint}
      <div class="sj-ts-list" role="radiogroup" aria-label="时间源">${choices}</div>
      <p class="sj-ts-gate">无标签或同日 → 不自动推、不强制校正；日期打架才提示校正。故事日校正是自愿的。</p>
      <p class="sj-note">无标签时不会强制弹窗。</p>
      ${dayBlock}
    </div>
    <div class="sj-field">
      <p class="sj-field-label">主题</p>
      <div class="sj-themes" role="radiogroup" aria-label="主题">${radios}</div>
    </div>
    ${renderManualActions(state)}
    <p class="sj-note">主题、时间源和悬浮球位置跟酒馆设置走。世界账跟这则聊天走。宏观注入走 shiju_macro，depth 4。</p>
    ${worldbookAdvanced(state)}
  </section>`;
}

/** Pure markup for one page. State is passed in; this does not touch storage. */
export function renderPage(state) {
  const page = PAGES.some((item) => item.id === state.page) ? state.page : 'feed';
  if (page === 'world') return renderWorld(state);
  if (page === 'events') return renderEvents(state);
  if (page === 'settings') return renderSettings(state);
  return renderFeed(state);
}
