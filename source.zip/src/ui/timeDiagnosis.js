const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const modes = {baibai:'柏宝书', shiju:'世局标签', custom:'自定义标签'};
const reasons = {
  'range-reversed':'同一楼层的结束日期早于开始日期',
  'timeline-reversed':'后续楼层的日期早于前面的日期',
  'clock-ahead':'世界账日期晚于当前来源日期',
  'clock-baseline':'世界账日期与故事日起点不一致',
  'missing':'没有读取到日期', 'unrecognized':'无法识别日期文字',
};
export function timeIssueLabel(life) {
  if (life?.reason === 'history-changed') return '历史正文已修改 · 查看处理方式';
  if (life?.status === 'conflict') return '日期冲突 · 查看原因';
  if (life?.status === 'unrecognized') return '日期未识别 · 查看原因';
  if (life?.status === 'missing' && life?.hasWorld) return '未读取到日期 · 查看来源';
  return '';
}
function pointMarkup(point, title) {
  if (!point) return '';
  const place = point.kind === 'world' ? '世界账' : point.floor >= 0 ? `楼层 #${point.floor}（第 ${point.floor + 1} 条消息）` : '公开时间接口（未提供楼层）';
  const kind = {tag:'正文标签',leaf:'柏宝书叶节点',api:'柏宝书公开接口',world:'已保存日期'}[point.kind] || point.kind;
  return `<div class="sj-time-point"><strong>${esc(title)}</strong><p>${esc(point.dateLabel || '未定')}</p><small>${esc(place)} · ${esc(modes[point.mode] || point.mode)} · ${esc(kind)}${point.field ? ` · ${esc(point.field)}` : ''}${point.swipeId != null && point.floor >= 0 ? ` · swipe ${esc(point.swipeId)}` : ''}</small></div>`;
}
export function renderTimeDiagnosis(life = {}) {
  const issue = life.diagnostic;
  return `<section id="sj-time-diagnosis" class="sj-time-diagnosis" tabindex="-1" aria-labelledby="sj-time-diagnosis-title">
    <h3 id="sj-time-diagnosis-title">${esc(life.reason === 'history-changed' ? '已处理正文需要重新确认' : reasons[issue?.reason] || '时间读取结果')}</h3>
    <p class="sj-note">当前来源：${esc(modes[life.mode] || life.mode || '未定')} · 世界账：${esc(life.plugin?.dateLabel || '未定')} · 故事日 ${esc(life.plugin?.dayIndex ?? 0)}</p>
    ${issue && life.source && JSON.stringify(life.source) !== JSON.stringify(issue.to) ? pointMarkup(life.source,'当前来源最新日期') : ''}
    ${issue?.from || issue?.to ? pointMarkup(issue.from,'对照日期') + pointMarkup(issue.to,'来源日期') : pointMarkup(life.source,'实际读取日期')}
    ${issue?.reason === 'clock-baseline' && issue.expectedDayIndex != null ? `<p class="sj-note">已保存故事日 ${esc(issue.savedDayIndex)}；按当前起点和来源日期计算为第 ${esc(issue.expectedDayIndex)} 日。请核对希望采用的日期与故事日。</p>` : ''}
    ${life.prompt ? `<p class="sj-note">${esc(life.prompt)}</p>` : ''}
    ${life.blocked ? '<p class="sj-note sj-prompt-error">问题尚未解决，演进已暂停。保持现状只表示暂不处理。</p>' : ''}
    <button type="button" class="sj-btn sj-btn-sm" data-action="recheck-time">重新检查</button>
  </section>`;
}
