/** v4.2 orb: ring, center, short ticks. Not a text label. */
export function fabIconSvg() {
  return `<svg class="sj-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <circle cx="12" cy="12" r="8.25" fill="none" stroke="currentColor" stroke-width="1.4"></circle>
    <circle cx="12" cy="12" r="2.1" fill="currentColor"></circle>
    <path d="M12 3.8v2.2M12 18v2.2M3.8 12h2.2M18 12h2.2" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" opacity="0.55"></path>
  </svg>`;
}

export function closeIconSvg() {
  return `<svg class="sj-close-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
    <path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"></path>
  </svg>`;
}
