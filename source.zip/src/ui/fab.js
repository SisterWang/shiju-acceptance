const FAB_SIZE = 46;
const MARGIN = 8;
const DRAG_THRESHOLD_PX = 5;

export function clampFab(x, y, viewport) {
  const view = viewport || {
    width: window.innerWidth,
    height: window.innerHeight,
    size: FAB_SIZE,
    margin: MARGIN,
  };
  const size = view.size ?? FAB_SIZE;
  const margin = view.margin ?? MARGIN;
  const maxX = Math.max(margin, view.width - size - margin);
  const maxY = Math.max(margin, view.height - size - margin);
  return {
    x: Math.round(Math.min(Math.max(margin, x), maxX)),
    y: Math.round(Math.min(Math.max(margin, y), maxY)),
  };
}

/**
 * Drag vs click. A small move keeps the click; a real drag stores left/top.
 * 拖动结束才写入设置。默认角落不写坐标。
 */
export function mountFab(fab, { getPosition, onCommit, onActivate }) {
  apply(getPosition());
  let suppressClick = false;

  fab.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    const startX = event.clientX;
    const startY = event.clientY;
    const origin = fab.getBoundingClientRect();
    let moved = false;

    const onMove = (ev) => {
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      if (!moved && Math.hypot(dx, dy) < DRAG_THRESHOLD_PX) return;
      moved = true;
      fab.classList.add('is-dragging');
      place(origin.left + dx, origin.top + dy);
    };

    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      fab.classList.remove('is-dragging');
      if (!moved) return;
      suppressClick = true;
      const rect = fab.getBoundingClientRect();
      const pos = place(rect.left, rect.top);
      try {
        onCommit(pos);
      } catch (error) {
        console.error('[shiju]', error);
      }
    };

    try {
      fab.setPointerCapture(event.pointerId);
    } catch {
      /* Synthetic events and some browsers refuse capture. Window listeners still track the drag. */
    }
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  });

  fab.addEventListener('click', (event) => {
    if (suppressClick) {
      suppressClick = false;
      event.preventDefault();
      event.stopPropagation();
      return;
    }
    onActivate();
  });

  window.addEventListener('resize', () => {
    if (fab.hidden || fab.classList.contains('is-default')) return;
    const rect = fab.getBoundingClientRect();
    place(rect.left, rect.top);
  });

  function place(x, y) {
    const pos = clampFab(x, y);
    fab.classList.remove('is-default');
    fab.style.left = `${pos.x}px`;
    fab.style.top = `${pos.y}px`;
    fab.style.right = 'auto';
    fab.style.bottom = 'auto';
    return pos;
  }

  function apply(pos) {
    if (typeof pos?.x !== 'number' || typeof pos?.y !== 'number') {
      fab.classList.add('is-default');
      fab.style.left = '';
      fab.style.top = '';
      fab.style.right = '';
      fab.style.bottom = '';
      return;
    }
    place(pos.x, pos.y);
  }
}
