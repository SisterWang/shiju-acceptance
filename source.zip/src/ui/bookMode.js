/**
 * Book-level pin / exclude (A31).
 * Writes only worldbook.forceInclude and worldbook.exclude.
 * A book with a uid is stored and matched by uid; otherwise by name.
 */

import { bookListed } from '../modules/worldbook/select.js';

function clean(value) {
  return typeof value === 'string' ? value.trim() : '';
}

export function bookKey(book) {
  const uid = clean(book?.uid);
  const name = clean(book?.name);
  if (uid) return `uid:${uid}`;
  if (name) return `name:${name}`;
  return '';
}

/** Prefer uid. Name-only books stay a plain string, matching the stored lists. */
export function bookRef(book) {
  const uid = clean(book?.uid);
  const name = clean(book?.name);
  if (uid) {
    const ref = { uid };
    if (name) ref.name = name;
    return ref;
  }
  return name || null;
}

function asBook(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const uid = clean(raw.uid || raw.bookUid || raw.book?.uid);
  const name = clean(raw.name || raw.bookName || raw.world || raw.book?.name);
  if (!uid && !name) return null;
  return { uid, name: name || uid };
}

function pushBook(books, seen, raw) {
  const book = asBook(raw);
  if (!book) return;
  const key = bookKey(book);
  if (!key || seen.has(key)) return;
  seen.add(key);
  books.push(book);
}

function listOf(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === 'object') return Object.values(value);
  return [];
}

/** Unique loaded books from a host.readWorldbook() result. Does not read entries' bodies. */
export function booksFromRead(read) {
  const books = [];
  const seen = new Set();
  if (Array.isArray(read)) {
    for (const entry of read) pushBook(books, seen, entry);
    return books;
  }
  if (!read || typeof read !== 'object') return books;
  for (const book of listOf(read.catalog)) pushBook(books, seen, book);
  for (const book of listOf(read.books)) {
    pushBook(books, seen, book);
    const entries = Array.isArray(book?.entries)
      ? book.entries
      : (book?.entries && typeof book.entries === 'object' ? Object.values(book.entries) : []);
    for (const entry of entries) {
      pushBook(books, seen, {
        uid: entry?.bookUid || book.uid || book.bookUid,
        name: entry?.bookName || entry?.world || book.name || book.bookName,
      });
    }
  }
  for (const entry of listOf(read.entries)) pushBook(books, seen, entry);
  return books;
}

/** @returns {'exclude' | 'pin' | 'default'} */
export function bookMode(settings, book) {
  const worldbook = settings?.worldbook && typeof settings.worldbook === 'object' ? settings.worldbook : {};
  const identity = { uid: clean(book?.uid), name: clean(book?.name) };
  if (bookListed(worldbook.exclude, identity)) return 'exclude';
  if (bookListed(worldbook.forceInclude, identity)) return 'pin';
  return 'default';
}

function withoutBook(list, book) {
  const identity = { uid: clean(book?.uid), name: clean(book?.name) };
  return (Array.isArray(list) ? list : []).filter((item) => !bookListed([item], identity));
}

/**
 * Next forceInclude / exclude after one book changes mode.
 * Other books' refs are kept. Exclude and pin are mutually exclusive.
 * @param {object} settings
 * @param {{ uid?: string, name?: string }} book
 * @param {'default' | 'pin' | 'exclude'} mode
 */
export function applyBookMode(settings, book, mode) {
  const worldbook = settings?.worldbook && typeof settings.worldbook === 'object' ? settings.worldbook : {};
  let forceInclude = withoutBook(worldbook.forceInclude, book);
  let exclude = withoutBook(worldbook.exclude, book);
  const ref = bookRef(book);
  if (ref && mode === 'pin') forceInclude = [...forceInclude, ref];
  if (ref && mode === 'exclude') exclude = [...exclude, ref];
  return { forceInclude, exclude };
}
