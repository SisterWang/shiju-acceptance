/**
 * Feed usage bar (A30). Numbers are estimated tokens from projectWorld().usage.
 * Missing MVU is stored as 0 and shown as 「无」.
 */

function stripDecimal(value) {
  const rounded = Math.round(value * 10) / 10;
  if (Number.isInteger(rounded)) return String(rounded);
  return rounded.toFixed(1);
}

const STEPS = [
  { divisor: 1000, label: '千', bump: 10 },
  { divisor: 10000, label: '万', bump: 10000 },
  { divisor: 100000000, label: '亿', bump: Infinity },
];

function formatStep(n, index) {
  const step = STEPS[index];
  const rounded = Math.round((n / step.divisor) * 10) / 10;
  if (rounded >= step.bump && index < STEPS.length - 1) return formatStep(n, index + 1);
  return stripDecimal(rounded) + step.label;
}

/** Compact token count: 2000 → 2千, 322000 → 32.2万. */
export function formatTokenCount(value) {
  const n = Math.max(0, Math.round(Number(value) || 0));
  if (n < 1000) return String(n);
  if (n >= 100000000) return formatStep(n, 2);
  if (n >= 10000) return formatStep(n, 1);
  return formatStep(n, 0);
}

function count(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0;
}

/**
 * @param {object | null | undefined} usage
 * @returns {{ worldbook: string, mvu: string, recent: string, total: string } | null}
 */
export function usageParts(usage) {
  if (!usage || typeof usage !== 'object') return null;
  const worldbook = count(usage.worldbook);
  const mvu = count(usage.mvu);
  const recent = count(usage.recent);
  const total = worldbook + mvu + recent;
  return {
    worldbook: formatTokenCount(worldbook),
    mvu: mvu === 0 ? '无' : formatTokenCount(mvu),
    recent: formatTokenCount(recent),
    total: formatTokenCount(total),
  };
}
