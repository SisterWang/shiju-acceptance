/** Preserve reading context when a background history update rebuilds the panel. */
export function captureHistoryView(body) {
  if (!body.querySelector('.sj-request-history')) return () => {};
  const doc = body.ownerDocument;
  const elements = [...body.querySelectorAll('[data-history-view]')];
  const states = elements.map(el => ({key:el.dataset.historyView, open:el.tagName === 'DETAILS' ? el.open : null,
    top:el.scrollTop, left:el.scrollLeft}));
  const focusKey = elements.find(el => el === doc.activeElement)?.dataset.historyView;
  const top = body.scrollTop, left = body.scrollLeft;
  const selection = doc.getSelection();
  // History text is rendered as plain text in a single PRE text node.
  const textElement = node => node?.nodeType === 3 && node.parentElement?.matches('pre[data-history-view]') ? node.parentElement : null;
  const anchor = textElement(selection?.anchorNode), focus = textElement(selection?.focusNode);
  const selected = anchor && focus ? {anchor:anchor.dataset.historyView, anchorOffset:selection.anchorOffset,
    focus:focus.dataset.historyView, focusOffset:selection.focusOffset} : null;
  return () => {
    if (!body.querySelector('.sj-request-history')) return;
    const current = new Map([...body.querySelectorAll('[data-history-view]')].map(el => [el.dataset.historyView, el]));
    for (const state of states) {
      const el = current.get(state.key);
      if (!el) continue;
      if (state.open !== null) el.open = state.open;
      el.scrollTop = state.top; el.scrollLeft = state.left;
    }
    if (focusKey) current.get(focusKey)?.focus({preventScroll:true});
    if (selected) {
      const a = current.get(selected.anchor)?.firstChild, f = current.get(selected.focus)?.firstChild;
      if (a?.nodeType === 3 && f?.nodeType === 3) selection.setBaseAndExtent(a, Math.min(selected.anchorOffset,a.length), f, Math.min(selected.focusOffset,f.length));
    }
    body.scrollTop = top; body.scrollLeft = left;
  };
}
