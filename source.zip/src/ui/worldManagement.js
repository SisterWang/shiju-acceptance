import { beginEntityEdit, saveEntity, generateManagementPreview, adoptManagementPreview, readRebuildBackup, beginBackupRestore, restoreRebuildBackup, discardManagementSession } from '../modules/management/index.js';
import { loadWorld } from '../store/index.js';
import { isWorldBusy } from '../modules/turn.js';
const esc=v=>String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={regions:'地区',factions:'势力',orgs:'组织'};
const button=(action,label,disabled=false)=>`<button type="button" class="sj-btn sj-btn-sm" data-manage="${esc(action)}"${disabled?' disabled':''}>${label}</button>`;
export function createWorldManagement({refresh,getScope,locateEntity}) {
  let editor=null,preview=null,controller=null,restore=null,notice='',error=false,reveal=false,skip=false,duplicate=null;
  const repaint=()=>{skip=true;refresh();};
  function capture(body) {
    if(skip) {skip=false;return;}
    if(!editor) return;
    for(const field of ['name','summary','status','regionRef','secret']) {
      const el=body.querySelector(`[data-entity-field="${field}"]`);
      if(el) editor.item[field]=field==='secret' ? el.checked : el.value;
    }
  }
  function chatChanged() {
    controller?.abort();controller=null;
    if(preview) discardManagementSession(preview.token);
    if(editor) discardManagementSession(editor.token);
    editor=null;preview=null;restore=null;notice='';reveal=false;duplicate=null;
  }
  function render(world,kind,page) {
    const busy=isWorldBusy() || Boolean(controller), exists=Boolean(world?.meta?.builtFingerprint);
    const category=({region:'regions',faction:'factions',org:'orgs'})[kind];
    let markup=page==='world' ? `<div class="sj-management-actions">${button(`new:${category}`,'新增',busy||!exists)}${button(`generate:${category}`,'重新生成',busy||!exists)}</div><p class="sj-note">重新生成会补全并更新本分类，保留人工内容；先预览，再采用。</p>`
      : `<div class="sj-settings-card"><h3>世界资料管理</h3><p class="sj-note">重新初始化先生成预览，采用后替换模型资料并重建剧情基线。人工记录保留，旧演进日志和重跑点会清空。启用／冻结状态保持不变。</p><div class="sj-management-actions">${button('generate:all','重新初始化',busy||!exists)}${readRebuildBackup() ? button('backup-export','导出重建备份')+button('restore','恢复最近重建备份',busy) : ''}</div></div>`;
    if(restore) markup+=`<div class="sj-management-panel" role="alertdialog" aria-label="恢复重建备份"><p>确认恢复重建前的世界账？当前聊天偏好不变，之后新增的剧情仍待处理。</p>${button('restore-confirm','确认恢复',busy)}${button('restore-cancel','取消')}</div>`;
    if(controller) markup+=`<div class="sj-management-panel"><p role="status">${esc(notice || '正在读取完整资料…')}</p>${button('cancel-generation','取消生成')}</div>`;
    if(editor) {
      const item=editor.item;
      markup+=`<form class="sj-management-panel sj-form-fields" data-entity-form><h3>${editor.isNew?'新增':'编辑'}${labels[editor.kind]}</h3><p class="sj-note">仅修改资料，不调用模型。${busy?'正在演进，完成后可修改；草稿已保留。':''}</p><fieldset${busy?' disabled':''}>
      <label for="sj-entity-name">名称（必填）</label><input id="sj-entity-name" data-entity-field="name" required value="${esc(item.name)}">
      <label for="sj-entity-summary">概况（必填）</label><textarea id="sj-entity-summary" data-entity-field="summary" rows="7" required>${esc(item.summary)}</textarea>
      <label for="sj-entity-status">状态</label><select id="sj-entity-status" data-entity-field="status">${[['active','活跃'],['dormant','休眠'],['resolved','结束']].map(([v,t])=>`<option value="${v}"${item.status===v?' selected':''}>${t}</option>`).join('')}</select>
      ${editor.kind!=='regions'?`<label for="sj-entity-region">所属地区</label><select id="sj-entity-region" data-entity-field="regionRef"><option value="">未指定</option>${(world?.regions || []).map(row=>`<option value="${esc(row.id)}"${item.regionRef===row.id?' selected':''}>${esc(row.secret ? '隐秘地区' : row.name)}</option>`).join('')}</select>`:''}
      <label class="sj-setting-toggle"><span>隐秘资料（查看／编辑不会改变主角知情状态）</span><input type="checkbox" data-entity-field="secret"${item.secret?' checked':''}></label></fieldset><div class="sj-management-actions">${button('save','保存资料',busy)}${button('edit-cancel','取消')}</div></form>`;
    }
    if(preview) {
      const counts=type=>preview.changes.filter(row=>row.type===type).length;
      markup+=`<div class="sj-management-panel"><h3>${preview.kind?`${labels[preview.kind]}补全`:'重新初始化'}预览</h3><p>新增 ${counts('added')} · 更新 ${counts('updated')} · 保留 ${counts('preserved')}</p><p class="sj-note">采用前可检查变化；世界账或正文变化后需重新生成。</p>${button('reveal',reveal?'收起变更内容':'查看变更内容（可能含隐秘）')}
      ${reveal?`<p>${esc(preview.note)}</p>${preview.changes.map(row=>`<details><summary>${esc(({added:'新增',updated:'更新',preserved:'保留'})[row.type])} · ${esc(row.after.name || row.after.title || '资料')}</summary><div class="sj-diff-columns"><section><h4>原资料</h4><pre>${esc(row.before ? JSON.stringify(row.before,null,2) : '无')}</pre></section><section><h4>采用后</h4><pre>${esc(JSON.stringify(row.after,null,2))}</pre></section></div></details>`).join('')}`:''}
      <div class="sj-management-actions">${button('adopt','确认采用',busy)}${button('discard','放弃预览',busy)}</div></div>`;
    }
    if(notice && !controller) markup+=`<p class="sj-note${error?' sj-prompt-error':''}" role="${error?'alert':'status'}" data-management-feedback tabindex="-1">${esc(notice)}</p>${duplicate ? button(`locate:${duplicate.kind}:${duplicate.id}`,'定位已有记录') : ''}`;
    return markup;
  }
  function bind(body) {
    body.querySelector('[data-entity-form]')?.addEventListener('submit',event=>event.preventDefault());
    body.querySelectorAll('[data-manage]').forEach(el=>el.addEventListener('click',async()=>{
      capture(body); const scope=getScope(), [action,arg,...idParts]=el.dataset.manage.split(':'); const id=idParts.join(':'); error=false;
      try {
        if(action==='locate') {locateEntity?.(arg,id);return;}
        duplicate=null;
        if(action==='new'||action==='edit') {
          if(editor) discardManagementSession(editor.token);
          editor={...beginEntityEdit(arg,id || null,action==='edit'),kind:arg,isNew:action==='new'};notice='';
        }
        if(action==='edit-cancel') {discardManagementSession(editor?.token);editor=null;}
        if(action==='save') {await saveEntity(editor.token,editor.item);if(scope!==getScope())return;editor=null;notice='资料已保存，将作为修正交给下轮演进';}
        if(action==='generate') {
          if(controller)return;
          if(preview)discardManagementSession(preview.token); preview=null;reveal=false;
          const own=new AbortController();controller=own;notice='正在读取完整资料…';repaint();
          try { const result=await generateManagementPreview(arg==='all'?null:arg,{signal:own.signal,onProgress:progress=>{
            if(scope!==getScope())return;notice=`正在处理世界书 ${progress.completed} / ${progress.total}`;
            const status=body.querySelector('.sj-management-panel [role="status"]');if(status)status.textContent=notice;
          }}); if(scope!==getScope())return; if(result?.ok===false)throw new Error(result.message || '聊天已切换'); preview=result;notice='草稿已生成，尚未修改世界账'; }
          finally {if(controller===own)controller=null;}
        }
        if(action==='cancel-generation') {controller?.abort();notice='已取消生成';}
        if(action==='reveal')reveal=!reveal;
        if(action==='adopt') {await adoptManagementPreview(preview.token);if(scope!==getScope())return;preview=null;notice='已采用';}
        if(action==='discard') {discardManagementSession(preview.token);preview=null;notice='已放弃预览';}
        if(action==='restore')restore=beginBackupRestore();
        if(action==='restore-cancel'){discardManagementSession(restore);restore=null;}
        if(action==='restore-confirm'){await restoreRebuildBackup(restore);if(scope!==getScope())return;restore=null;notice='已恢复重建前的世界账';}
        if(action==='backup-export') {
          const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(readRebuildBackup(),null,2)],{type:'application/json'}));
          a.href=url;a.download='shiju-rebuild-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice='重建备份已导出（包含完整世界资料）';
        }
      }catch(e){if(scope!==getScope())return;notice=e.name==='AbortError'?'生成已取消':e.message;error=true;if(e.code==='SHIJU_DUPLICATE_ENTITY')duplicate={kind:e.kind,id:e.entityId};}
      if(scope!==getScope())return; repaint();
      if(action==='new'||action==='edit')body.querySelector('#sj-entity-name')?.focus();
      else if(error)body.querySelector('[data-management-feedback]')?.focus();
      else if(action==='restore')body.querySelector('[data-manage="restore-confirm"]')?.focus();
      else if(action==='restore-cancel')body.querySelector('[data-manage="restore"]')?.focus();
      else if(action==='reveal')body.querySelector('[data-manage="reveal"]')?.focus();
      else if(['save','adopt','restore-confirm'].includes(action))body.querySelector('[data-management-feedback]')?.focus();
    }));
  }
  return {render,bind,capture,chatChanged,reloadState:()=>({busy:Boolean(controller),draft:Boolean(editor || preview || restore)})};
}
