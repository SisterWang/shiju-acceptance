import { cloneJson, isPlainObject } from '../plain.js';
import { createMemoryHost } from '../host/memory.js';

/**
 * M-Fixture. Native SillyTavern path with no BaiBai book and no MVU.
 * Test-only. Production index.js does not import this file.
 * installNativeFixture does nothing unless enabled is exactly true.
 * 降级夹具。默认关。不把浏览器本地仓当世界账。
 */

export const FIXTURE_ID = 'native-no-book';
export const FIXTURE_ENABLED_BY_DEFAULT = false;

export const NATIVE_REGION = '江左';
export const NATIVE_ORG = '漕帮';
export const NATIVE_MACRO = '江左大旱';
export const NATIVE_NEWS = '北境粮草';
export const NATIVE_SECRET = '密信';
export const NATIVE_SECRET_BODY = '不可见';
export const DECOY_REGION = '诱饵城';

const LOCKED_GLOBALS = ['STBaiBaiBook', 'bbs_generateInterceptor'];

let nativeGlobalsLocked = false;

function fixtureError(code, message) {
  const error = new Error(message);
  error.code = code;
  return error;
}

function decoyVault() {
  return {
    note: 'decoy-store',
    shiju: { regions: [{ name: DECOY_REGION }] },
  };
}

function lockNativeGlobals() {
  for (const key of LOCKED_GLOBALS) {
    try {
      delete globalThis[key];
    } catch {
      /* A non-configurable marker cannot be the native path. */
    }
    Object.defineProperty(globalThis, key, {
      configurable: true,
      enumerable: false,
      get() {
        return undefined;
      },
      set() {
        /* The fixture keeps the page on the native path. */
      },
    });
  }
  nativeGlobalsLocked = true;
}

/** Drop the global lock so other checks can install a book marker again. */
export function releaseNativeFixture() {
  if (!nativeGlobalsLocked) return;
  for (const key of LOCKED_GLOBALS) {
    try {
      delete globalThis[key];
    } catch {
      /* Already gone. */
    }
  }
  nativeGlobalsLocked = false;
}

function canned(request) {
  if (request?.purpose === 'bootstrap') {
    return JSON.stringify({
      regions: [{ name: NATIVE_REGION, summary: '水乡' }],
      orgs: [{ name: NATIVE_ORG, summary: '管粮' }],
      events: [
        { kind: 'macro', title: NATIVE_MACRO, body: '河水见底' },
        { kind: 'news', title: NATIVE_NEWS, body: '边镇缺粮' },
        { kind: 'secret', title: NATIVE_SECRET, body: NATIVE_SECRET_BODY },
      ],
      todayChanges: [],
    });
  }
  return JSON.stringify({
    regions: [{ name: NATIVE_REGION, summary: '水乡' }],
    todayChanges: [{ title: '夹具不应推演', kind: 'macro', body: '降级冒烟不该走到这里' }],
  });
}

/**
 * Turn a memory host into the native path.
 * `enabled` must be exactly true. Any other value, including omission, is a no-op.
 */
export function installNativeFixture(host, options = {}) {
  if (options.enabled !== true) {
    return { enabled: false, id: FIXTURE_ID };
  }
  if (!host || typeof host !== 'object' || !host.state) {
    throw fixtureError('SHIJU_FIXTURE_HOST', '世局夹具：需要一个宿主');
  }
  lockNativeGlobals();
  host.state.hasBaibai = false;
  host.state.mvu = null;
  host.state.localVault = decoyVault();
  host.state.fixtureCalls = [];
  host.hasBaibaiBook = () => false;
  host.readMvu = () => null;
  host.generateViaBackend = async (request) => {
    host.state.fixtureCalls.push({
      purpose: request?.purpose,
      systemPrompt: request?.systemPrompt,
      prompt: request?.prompt,
    });
    return canned(request);
  };
  return { enabled: true, id: FIXTURE_ID };
}

/** New chat. One visible floor, no memory plugin and no time tag yet. */
export function nativeNewChat() {
  return [{ mes: '我们在渡口等船。', swipe_id: 0, is_user: true }];
}

/** Old archive. Two historical floors the enable path must not rewrite. */
export function nativeOldFloors() {
  return [
    {
      mes: '<shiju_start>1988/1/1</shiju_start>甲楼原文<shiju_end>1988/1/1</shiju_end>',
      swipe_id: 0,
      is_user: true,
    },
    {
      mes: '<shiju_start>1988/1/2</shiju_start>乙楼原文<shiju_end>1988/1/2</shiju_end>',
      swipe_id: 0,
      is_user: false,
    },
  ];
}

/** A later floor used while the plugin is frozen. The gate must not evolve. */
export function nativeLaterFloor() {
  return {
    mes: '<shiju_start>1988/1/2</shiju_start>丙楼<shiju_end>1988/1/6</shiju_end>',
    swipe_id: 0,
    is_user: false,
  };
}

/** Stable hash of floor text. The ledger is not part of the hash. */
export function floorHash(chat) {
  let hash = 5381;
  const text = (Array.isArray(chat) ? chat : []).map((message) => String(message?.mes ?? '')).join('\u0001');
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash) ^ text.charCodeAt(index);
  }
  return (hash >>> 0).toString(16);
}

/**
 * Chat file shaped like a SillyTavern export.
 * The header keeps the on-disk `chat_metadata` and the live `chatMetadata`.
 * Both carry `shiju` when this chat has a ledger. The decoy vault is not copied.
 */
export function exportChatFile(host) {
  const metadata = cloneJson(isPlainObject(host?.state?.chatMetadata) ? host.state.chatMetadata : {});
  const header = {
    user_name: '你',
    character_name: '对方',
    chat_id: host?.state?.chatId || 'native-chat',
    chat_metadata: cloneJson(metadata),
    chatMetadata: cloneJson(metadata),
  };
  const messages = Array.isArray(host?.state?.chat)
    ? host.state.chat.map((message) => cloneJson(message))
    : [];
  return [header, ...messages];
}

/**
 * Open an exported chat onto the host.
 * A SillyTavern file may only have `chat_metadata`. A fixture export has both keys,
 * and they must name the same `shiju` ledger.
 */
export function openChatFile(host, file) {
  if (!host?.state || !Array.isArray(file) || file.length === 0 || !isPlainObject(file[0])) {
    throw fixtureError('SHIJU_FIXTURE_EXPORT', '世局夹具：聊天文件不是导出的数组');
  }
  const header = file[0];
  const fromFile = header.chat_metadata;
  const fromLive = header.chatMetadata;
  const fileOk = isPlainObject(fromFile);
  const liveOk = isPlainObject(fromLive);
  if (!fileOk && !liveOk) {
    throw fixtureError('SHIJU_FIXTURE_EXPORT', '世局夹具：导出里没有聊天元数据');
  }
  if (fileOk && liveOk && JSON.stringify(fromFile.shiju ?? null) !== JSON.stringify(fromLive.shiju ?? null)) {
    throw fixtureError('SHIJU_FIXTURE_EXPORT', '世局夹具：chat_metadata.shiju 与 chatMetadata.shiju 不一致');
  }
  const metadata = cloneJson(liveOk ? fromLive : fromFile);
  host.state.chatMetadata = metadata;
  host.state.chat = file.slice(1).map((message) => (isPlainObject(message) ? cloneJson(message) : { mes: '' }));
  if (typeof header.chat_id === 'string' && header.chat_id) host.state.chatId = header.chat_id;
  return metadata.shiju ?? null;
}

/**
 * Extension code leaves memory. The chat file and the settings bag stay,
 * because those live with the chat and the server settings, not in the package.
 */
export function uninstallKeepingChat(host) {
  const chatFile = exportChatFile(host);
  const settings = cloneJson(isPlainObject(host?.state?.extensionSettings) ? host.state.extensionSettings : {});
  if (host?.state) {
    host.state.prompts = {};
    host.state.chat = [];
    host.state.chatMetadata = {};
    host.state.mvu = null;
    host.state.localVault = decoyVault();
  }
  if (host) delete host.generateViaBackend;
  return { chatFile, settings };
}

/** A new host, as if the extension was installed again and the same chat was opened. */
export function reinstallNativeHost(chatFile, settings) {
  const host = createMemoryHost({ hasBaibai: false, mvu: null, chatMetadata: {} });
  openChatFile(host, chatFile);
  host.state.extensionSettings = cloneJson(isPlainObject(settings) ? settings : {});
  installNativeFixture(host, { enabled: true });
  return host;
}
