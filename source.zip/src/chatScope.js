import { shijuError } from './errors.js';
import { getHost } from './host.js';

const sessions = new WeakMap();

/** Bind before chat-mutation handlers so new-chat work captures the new epoch. */
export function watchChatChanges(host = getHost()) {
  if (!sessions.has(host)) {
    const session = { epoch: 0 };
    sessions.set(host, session);
    const type = host.event_types?.CHAT_CHANGED;
    if (type && typeof host.eventSource?.on === 'function') {
      host.eventSource.on(type, () => { session.epoch += 1; });
    }
  }
  return sessions.get(host);
}

function identity(host) {
  const ctx = host.getContext();
  const chatId = ctx?.getCurrentChatId?.() ?? ctx?.chatId ?? null;
  return {
    chatId,
    characterId: ctx?.characterId ?? null,
    groupId: ctx?.groupId ?? null,
    // Hosts without chat IDs can still distinguish their in-memory chats.
    // Metadata is deliberately excluded: a normal save replaces that object.
    fallback: chatId == null ? (ctx?.chat ?? null) : null,
  };
}

/** Runtime-only ownership token; never store it in chat metadata or model input. */
export function captureChatScope() {
  const host = getHost();
  return Object.freeze({ host, epoch: watchChatChanges(host).epoch, ...identity(host) });
}

export function assertChatScope(scope) {
  const host = getHost();
  const current = identity(host);
  if (!scope || scope.host !== host || scope.epoch !== watchChatChanges(host).epoch
    || scope.chatId !== current.chatId || scope.characterId !== current.characterId
    || scope.groupId !== current.groupId || scope.fallback !== current.fallback) {
    throw shijuError('SHIJU_CHAT_CHANGED', '聊天已切换，本次操作已取消');
  }
}
