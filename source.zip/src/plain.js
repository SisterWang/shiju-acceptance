export function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

export function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

/** Deep-merge plain objects. Arrays and scalars replace. 嵌套对象合并，数组整段替换。 */
export function deepMerge(base, patch) {
  if (!isPlainObject(base)) return isPlainObject(patch) ? cloneJson(patch) : {};
  if (!isPlainObject(patch)) return cloneJson(base);
  const out = { ...base };
  for (const [key, value] of Object.entries(patch)) {
    if (isPlainObject(value) && isPlainObject(out[key])) out[key] = deepMerge(out[key], value);
    else out[key] = value;
  }
  return out;
}
