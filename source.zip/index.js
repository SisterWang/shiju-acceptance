import { observeHiddenFloors } from './src/modules/visibility-observer.js';
import * as stScript from '../../../../script.js';
import { captureConnection } from './src/host/connection.js';
import { sendRequest, fetchCustomModels } from './src/host/transport.js';
import { createHistoryFileStore } from './src/host/history-file.js';
/**
 * SillyTavern third-party entry.
 * Lives at public/scripts/extensions/third-party/shiju/index.js
 * 酒馆入口。相对路径按第三方扩展目录写死。
 */
import { extension_settings, getContext } from '../../../extensions.js';
import {
  eventSource,
  event_types,
  extension_prompt_types,
  extension_prompt_roles,
  saveSettingsDebounced,
} from '../../../../script.js';
import { setHost } from './src/host.js';
import { start } from './src/main.js';

function listOf(book) {
  if (!book) return [];
  if (Array.isArray(book)) return book;
  if (Array.isArray(book.entries)) return book.entries;
  if (book.entries && typeof book.entries === 'object') return Object.values(book.entries);
  return [];
}

function bookStamp(book, fallbackName) {
  const bookName = typeof book?.name === 'string' && book.name.trim()
    ? book.name.trim()
    : (typeof fallbackName === 'string' ? fallbackName.trim() : '');
  const bookUid = typeof book?.uid === 'string' && book.uid.trim()
    ? book.uid.trim()
    : (typeof book?.bookUid === 'string' ? book.bookUid.trim() : '');
  return { bookName, bookUid };
}

function inlineEntries(book, fallbackName) {
  const stamp = bookStamp(book, fallbackName);
  const out = [];
  for (const entry of listOf(book)) {
    if (!entry || entry.disable === true || entry.enabled === false) continue;
    out.push({
      ...entry,
      bookName: entry.bookName || entry.world || stamp.bookName,
      bookUid: typeof entry.bookUid === 'string' && entry.bookUid ? entry.bookUid : stamp.bookUid,
    });
  }
  return out;
}

function pushCatalog(catalog, seen, book, fallbackName) {
  const stamp = bookStamp(book, fallbackName);
  if (!stamp.bookName && !stamp.bookUid) return;
  const key = stamp.bookUid ? `uid:${stamp.bookUid}` : `name:${stamp.bookName}`;
  if (seen.has(key)) return;
  seen.add(key);
  catalog.push({ name: stamp.bookName, uid: stamp.bookUid });
}

async function readWorldbook() {
  const ctx = getContext();
  const entries = [], catalog = [], seen = new Set(), loaded = new Set();
  const character = ctx?.characters?.[ctx.characterId];
  const card = character?.data?.character_book || character?.character_book;
  const primary = character?.data?.extensions?.world;
  try {
    const wi = await import('../../../world-info.js');
    const names = new Set();
    const add = (name) => { if (typeof name === 'string' && name.trim()) names.add(name.trim()); };
    add(primary);
    for (const name of wi.selected_world_info || []) add(name);
    const file = String(character?.avatar || '').replace(/\.[^/.]+$/, '');
    const extra = (wi.world_info?.charLore || []).find((item) => item.name === file);
    for (const name of extra?.extraBooks || []) add(name);
    add(ctx?.chatMetadata?.[wi.METADATA_KEY || 'world_info']);
    add(ctx?.powerUserSettings?.persona_description_lorebook);
    for (const name of names) {
      let book;
      try { book = typeof wi.loadWorldInfo === 'function' ? await wi.loadWorldInfo(name) : null; }
      catch (error) { console.error('[shiju] 世界书读取失败', name, error); }
      pushCatalog(catalog, seen, book, name);
      if (!book) continue;
      // ST returns { entries: {} } for a missing file as well as an empty book.
      // Only a listed empty book is authoritative over the embedded fallback.
      if (book.entries && !Object.keys(book.entries).length
        && Array.isArray(wi.world_names) && !wi.world_names.includes(name)) continue;
      loaded.add(name);
      if (book.name) loaded.add(book.name);
      entries.push(...inlineEntries(book, name));
    }
  } catch (error) {
    console.error('[shiju] 世界书来源不可用，使用内嵌书', error);
  }
  // A linked external book is authoritative; the card copy may be stale.
  const cardName = card?.name || primary || '';
  if (card && !loaded.has(cardName) && !(primary && loaded.has(primary))) {
    pushCatalog(catalog, seen, card, cardName);
    entries.push(...inlineEntries(card, cardName));
  }
  return { entries, catalog };
}

// Import only configuration readers; never call host generation methods.
const modules = Object.fromEntries(await Promise.all([
  ['text','../../../textgen-settings.js'], ['kobold','../../../kai-settings.js'],
  ['novel','../../../nai-settings.js'], ['horde','../../../horde.js'], ['tokenizers','../../../tokenizers.js'],
  ['lib','../../../../lib.js'],
].map(async ([name,path]) => { try { return [name,await import(path)]; } catch { return [name,null]; } })));
const activeRequests = new Set();
eventSource.on(event_types.CHAT_CHANGED, () => { for (const controller of activeRequests) controller.abort(); });
async function generateViaBackend(request, assertCurrent = () => {}, options = {}) {
  assertCurrent();
  const controller = new AbortController(); activeRequests.add(controller);
  const abort = () => controller.abort(options.signal?.reason);
  if (options.signal?.aborted) abort(); else options.signal?.addEventListener('abort', abort, { once:true });
  try {
    return await sendRequest(request,{headers:getContext().getRequestHeaders(), assertCurrent, ...options, signal:controller.signal});
  } finally { options.signal?.removeEventListener('abort', abort); activeRequests.delete(controller); }
}

function setExtensionPrompt(key, value, position, depth, scan, role) {
  const ctx = getContext();
  if (typeof ctx?.setExtensionPrompt === 'function') {
    ctx.setExtensionPrompt(key, value, position, depth, scan, role);
  }
}

setHost({
  getContext,
  getExtensionSettings() {
    return extension_settings;
  },
  saveSettingsDebounced,
  ...createHistoryFileStore({getHeaders: () => getContext().getRequestHeaders()}),
  notifyHistoryFailure(message) { globalThis.toastr?.warning(message, '世局请求历史'); },
  eventSource,
  event_types,
  extension_prompt_types,
  extension_prompt_roles,
  generateViaBackend,
  captureModelConnection(model) { return captureConnection(getContext(), stScript, modules, model); },
  fetchCustomModels(model, signal) { return fetchCustomModels(model, { headers:getContext().getRequestHeaders(), signal }); },
  setExtensionPrompt,
  readChat() {
    const ctx = getContext();
    return Array.isArray(ctx?.chat) ? ctx.chat : [];
  },
  readMvu() {
    const ctx = getContext();
    const stat = ctx?.chatMetadata?.stat_data;
    if (stat && typeof stat === 'object') return stat;
    return null;
  },
  readWorldbook,
});

start();
// /hide and /unhide do not emit message-edit events in ST 1.16/1.17.
// Observe their DOM visibility marker without patching any host/plugin method.
const chatElement = typeof document !== 'undefined' ? document.getElementById('chat') : null;
if (chatElement && typeof MutationObserver !== 'undefined') {
  new MutationObserver(records => {
    const floors = records.filter(r=>r.target.hasAttribute('mesid')).map(r => Number(r.target.getAttribute('mesid'))).filter(Number.isInteger);
    observeHiddenFloors(getContext().chat || [], floors).catch(error => console.error('[shiju]',error));
  }).observe(chatElement,{subtree:true,attributes:true,attributeFilter:['is_system','hidden']});
}
