import { runCompatibilityChecks } from './compatibility-check.mjs';
import { runHistoryEditChecks } from './history-edit-check.mjs';
import { runPromptPreferencesChecks } from './prompt-preferences-check.mjs';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { clampFab } from '../src/ui/fab.js';
import { evolutionGates, evolutionResultText } from '../src/ui/evolve.js';
import { dismissFixDraft, planFixClick } from '../src/ui/fixDraft.js';
import { applyBookMode, bookMode, booksFromRead } from '../src/ui/bookMode.js';
import { renderPage } from '../src/ui/pages.js';
import { projectWorld } from '../src/ui/readout.js';
import { formatTokenCount, usageParts } from '../src/ui/usage.js';
import { renderShellMarkup } from '../src/ui/shell.js';
import {
  createEmptyWorld,
  ensureSettings,
  loadSettings,
  loadWorld,
  migrateWorld,
  saveSettings,
  saveWorld,
  subscribe,
} from '../src/store/index.js';
import * as model from '../src/modules/model/index.js';
import * as source from '../src/modules/source/index.js';
import * as bootstrap from '../src/modules/bootstrap/index.js';
import * as timetag from '../src/modules/timetag/index.js';
import * as timeGate from '../src/modules/timeGate/index.js';
import * as evolve from '../src/modules/evolve/index.js';
import * as commit from '../src/modules/commit/index.js';
import * as reconcile from '../src/modules/reconcile/index.js';
import * as inject from '../src/modules/inject/index.js';
import * as intervene from '../src/modules/intervene/index.js';
import { runCoreChecks } from './core-check.mjs';
import { runFixtureChecks } from './fixture-smoke.mjs';
import { runChatScopeChecks } from './chat-scope-check.mjs';
import { runEntryWorldbookChecks } from './entry-worldbook-check.mjs';
import { runTimeTagRefreshChecks } from './timetag-refresh-check.mjs';
import { runRelativeTimeChecks } from './relative-time-check.mjs';
import { runConsistencyChecks } from './consistency-check.mjs';
import { runPromptDepthChecks } from './prompt-depth-check.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
let checks = 0;

function assert(condition, message) {
  checks += 1;
  if (!condition) {
    console.error(`FAIL #${checks}: ${message}`);
    process.exit(1);
  }
}

async function expectCode(fn, code) {
  try {
    await fn();
  } catch (error) {
    assert(error.code === code, `${code} ≠ ${error.code}: ${error.message}`);
    return;
  }
  assert(false, `expected ${code}`);
}

function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/.*$/gm, '$1');
}

function walk(dir) {
  const files = [];
  for (const name of readdirSync(dir)) {
    const path = join(dir, name);
    if (statSync(path).isDirectory()) files.push(...walk(path));
    else files.push(path);
  }
  return files;
}

const metadataHost = createMemoryHost({ chatMetadata: { existing: true } });
const oldMetadata = metadataHost.getContext().chatMetadata;
metadataHost.getContext().updateChatMetadata({ added: true }, false);
assert(metadataHost.state.chatMetadata.existing && metadataHost.state.chatMetadata.added, 'metadata update merges by default');
assert(oldMetadata.added === undefined, 'metadata update replaces the metadata reference');
metadataHost.getContext().updateChatMetadata({ reset: true }, true);
assert(metadataHost.state.chatMetadata.existing === undefined && metadataHost.state.chatMetadata.reset, 'metadata reset discards previous fields');
assert(metadataHost.state.savedMetadata === 0, 'metadata update does not persist');

const otherMetadata = { scenario: '原有场景', otherPlugin: { enabled: true, notes: ['保留'] } };
const host = createMemoryHost({ chatMetadata: structuredClone(otherMetadata) });
setHost(host);

const fresh = createEmptyWorld();
assert(fresh.schemaVersion === 8, 'schema 8');
assert(fresh.evolutionLog.length === 0, 'empty log');
assert(fresh.lastEvolutionCheckpoint === null, 'no checkpoint');
assert(fresh.preferences === undefined, 'no preferences');
assert(fresh.plugin.package === 'shiju', 'package');
assert(fresh.plugin.enabled === false, 'not enabled');

await saveWorld(fresh);
assert(host.state.chatMetadata.scenario === otherMetadata.scenario, 'world save preserves chat configuration');
assert(JSON.stringify(host.state.chatMetadata.otherPlugin) === JSON.stringify(otherMetadata.otherPlugin), 'world save preserves other plugin metadata');
assert(host.state.savedMetadata === 1, 'metadata saved once');
assert(JSON.stringify(loadWorld()) === JSON.stringify(fresh), 'empty round trip');

const edited = loadWorld();
edited.storyClock.dateLabel = '甲辰春';
edited.regions.push({ id: 'r1', name: '江左', summary: '水乡' });
await saveWorld(edited);
edited.regions.push({ id: 'nope' });
const loaded = loadWorld();
assert(loaded.storyClock.dateLabel === '甲辰春', 'date label');
assert(loaded.regions.length === 1 && loaded.regions[0].summary === '水乡', 'region kept');
assert(loaded.evolutionLog.length === 0, 'save does not append a log');

host.state.chatMetadata.shiju = {
  schemaVersion: 1,
  preferences: { tone: 'soft' },
  regions: [{ id: 'r', name: '江左' }],
  protagonistFocus: { locationGuess: '渡口', locationCorrection: 'no' },
  meta: { generatingTip: true },
};
const migrated = loadWorld();
assert(migrated.schemaVersion === 8, 'migrated to 8');
assert(migrated.preferences === undefined, 'preferences stripped');
assert(migrated.protagonistFocus.locationGuess === '渡口', 'guess kept');
assert(migrated.protagonistFocus.locationCorrection === undefined, 'correction stripped');
assert(migrated.meta.generatingTip === undefined, 'generating tip is not world state');
assert(host.state.chatMetadata.shiju.preferences.tone === 'soft', 'load does not rewrite disk');
await saveWorld(migrated);
assert(host.state.chatMetadata.shiju.preferences === undefined, 'save drops preferences');

host.state.chatMetadata.shiju = { schemaVersion: 9, extra: { a: 1 } };
const future = loadWorld();
assert(future.schemaVersion === 9, 'future schema kept');
assert(future.extra.a === 1, 'unknown field kept');
assert(Array.isArray(future.evolutionLog), 'log slot exists');

const direct = migrateWorld({ dayBuffer: ['一句'] });
assert(direct.dayBuffer.items[0] === '一句', 'buffer array wrapped');

// Both host paths must await persistence before reporting a successful world save.
for (const fallback of [false, true]) {
  const savingHost = createMemoryHost({ chatMetadata: structuredClone(otherMetadata) });
  const getContext = savingHost.getContext;
  let finishSave;
  let diskMetadata;
  let saveCalls = 0;
  savingHost.getContext = () => {
    const ctx = getContext();
    if (fallback) delete ctx.updateChatMetadata;
    ctx.saveMetadata = () => {
      saveCalls += 1;
      return new Promise((resolve) => {
        finishSave = () => {
          diskMetadata = structuredClone(savingHost.state.chatMetadata);
          resolve();
        };
      });
    };
    return ctx;
  };
  setHost(savingHost);
  const events = [];
  const unsubscribe = subscribe((kind) => events.push(kind));
  let settled = false;
  const saving = saveWorld(fresh).then(() => { settled = true; });
  await Promise.resolve();
  assert(saveCalls === 1, `explicit persistence called once (fallback=${fallback})`);
  assert(!settled && events.length === 0, 'world save waits for persistence before resolving or notifying');
  finishSave();
  await saving;
  assert(JSON.stringify(diskMetadata.shiju) === JSON.stringify(fresh), 'persisted metadata contains the world');
  assert(diskMetadata.scenario === otherMetadata.scenario && JSON.stringify(diskMetadata.otherPlugin) === JSON.stringify(otherMetadata.otherPlugin), 'persisted metadata retains unrelated fields');
  assert(events.length === 1 && events[0] === 'world', 'world save notifies once after persistence');

  const failure = Object.assign(new Error('metadata save failed'), { code: 'TEST_SAVE_FAILED' });
  const currentContext = savingHost.getContext;
  savingHost.getContext = () => ({ ...currentContext(), saveMetadata: async () => { throw failure; } });
  await expectCode(() => saveWorld(fresh), 'TEST_SAVE_FAILED');
  assert(events.length === 1, 'failed persistence does not report world save success');
  unsubscribe();
}

setHost(null);
await expectCode(() => loadSettings(), 'SHIJU_NO_HOST');

const chatless = createMemoryHost({ chatMetadata: null });
setHost(chatless);
await expectCode(() => saveWorld(createEmptyWorld()), 'SHIJU_NO_CHAT');
assert(loadWorld() === null, 'no chat reads as null');
await expectCode(() => saveWorld(null), 'SHIJU_INVALID_WORLD');

setHost(host);
assert(loadSettings().ui.theme === 'st', 'default theme');
assert(loadSettings().timeSource.mode === 'auto', 'time source unset');
const seen = [];
const off = subscribe((kind) => seen.push(kind));
saveSettings({ ui: { theme: 'night' } });
saveSettings({ ui: { fab: { x: 12, y: 0 } } });
saveSettings({ experimental: { a: 1 } });
const settings = loadSettings();
assert(settings.ui.theme === 'night', 'theme saved');
assert(settings.ui.fab.x === 12 && settings.ui.fab.y === 0, 'partial save keeps fab');
assert(settings.experimental.a === 1, 'unknown settings kept');
assert(seen.includes('settings'), 'settings event');
off();
const mark = seen.length;
saveSettings({ ui: { theme: 'green' } });
assert(seen.length === mark, 'unsubscribe');
saveSettings({ ui: { theme: 'purple' } });
assert(loadSettings().ui.theme === 'st', 'unknown theme falls back');
saveSettings({ timeSource: { mode: 'baibai', customTag: 'time' } });
let timed = loadSettings();
assert(timed.timeSource.mode === 'baibai' && timed.timeSource.customTag === 'time', 'time source saved');
assert(timed.ui.theme === 'st', 'time source save keeps theme');
saveSettings({ timeSource: { mode: 'nope' } });
assert(loadSettings().timeSource.mode === 'auto', 'unknown time source falls back');
assert(loadSettings().timeSource.customTag === 'time', 'invalid mode keeps the tag');
saveSettings({ ui: { theme: 'night' } });
assert(loadSettings().timeSource.mode === 'auto' && loadSettings().timeSource.customTag === 'time', 'theme save keeps time source');
saveSettings({ ui: { theme: 'st' } });
assert(loadSettings().inject.enabled === true, 'inject defaults on');
saveSettings({ inject: { enabled: false } });
assert(loadSettings().inject.enabled === false, 'inject can turn off');
assert(loadSettings().ui.theme === 'st' && loadSettings().timeSource.customTag === 'time', 'inject save keeps the rest');
saveSettings({ inject: { enabled: true } });
assert(loadSettings().inject.enabled === true, 'inject turns back on');

const beforeEnsure = host.state.savedSettings;
ensureSettings();
ensureSettings();
assert(host.state.savedSettings === beforeEnsure, 'ensure is quiet when complete');

const corner = clampFab(-20, 10, { width: 200, height: 120, size: 46, margin: 8 });
assert(corner.x === 8 && corner.y === 10, 'clamp min');
const far = clampFab(999, 999, { width: 200, height: 120, size: 46, margin: 8 });
assert(far.x === 146 && far.y === 66, 'clamp max');

const shell = renderShellMarkup();
for (const label of ['动态', '世界', '事件', '设置']) assert(shell.includes(label), label);
const fabMarkup = shell.match(/<button[^>]*class="sj-fab[^"]*"[\s\S]*?<\/button>/);
assert(fabMarkup, 'fab button');
const fabInner = fabMarkup[0].replace(/^<button[^>]*>/, '').replace(/<\/button>$/, '');
assert(fabInner.includes('<svg'), 'fab icon');
assert(!fabInner.includes('世局'), 'fab is not the two characters');
assert(shell.includes('aria-label="世局"'), 'accessible name');
assert(shell.includes('宏观演进 · 不碰眼前戏'), 'subtitle');
assert(shell.includes('disabled data-action="evolve"'), 'evolve placeholder disabled');
assert(shell.includes('disabled data-action="rerun"'), 'rerun placeholder disabled');

const forbidden = ['调方向', '位置纠偏', '可参与', '场景'];
const pages = ['feed', 'world', 'events', 'settings'].map((page) => renderPage({
  page,
  theme: 'pastel',
  world: null,
})).join('\n');
const secretOnly = renderPage({
  page: 'feed',
  theme: 'day',
  world: { ...createEmptyWorld(), todayChanges: [{ id: 't', title: '秘密标题', kind: 'secret', body: '隐秘正文' }] },
});
const withWorld = renderPage({
  page: 'feed',
  theme: 'day',
  world: {
    ...createEmptyWorld(),
    todayChanges: [
      { id: 't', title: '秘密标题', kind: 'secret', body: '隐秘正文' },
      { id: 'p', title: '<b>公开标题</b>', kind: 'macro', body: '公开正文' },
      { id: 'r', title: '揭晓标题', kind: 'secret', revealed: true, body: '揭晓正文' },
    ],
    meta: { sources: { truncated: true } },
  },
});
const worldPage = renderPage({
  page: 'world',
  worldKind: 'region',
  world: {
    ...createEmptyWorld(),
    regions: [{ name: '江左', summary: '水乡正文', where: '渡口', secret: true }],
    orgs: [{ summary: '没有名字的组织' }],
  },
});
const eventsPage = renderPage({
  page: 'events',
  eventFilter: 'all',
  world: {
    ...createEmptyWorld(),
    events: [
      { kind: 'macro', title: '宏观题', body: '宏观正文' },
      { kind: 'news', title: '远方题', body: '远方正文' },
      { kind: 'secret', title: '隐秘题', body: '隐秘事件正文' },
      { kind: 'other', title: '不该出现的别类' },
    ],
  },
});
const markup = `${shell}\n${pages}\n${secretOnly}\n${withWorld}\n${worldPage}\n${eventsPage}`;
for (const word of forbidden) assert(!markup.includes(word), `forbidden ${word}`);
assert(formatTokenCount(300000) === '30万', '300000 tokens read 30万');
assert(formatTokenCount(2000) === '2千', '2000 tokens read 2千');
assert(formatTokenCount(20000) === '2万', '20000 tokens read 2万');
assert(formatTokenCount(322000) === '32.2万', '322000 tokens read 32.2万');
assert(formatTokenCount(0) === '0', 'zero stays a digit for non-mvu');
const noMvu = usageParts({ worldbook: 300000, mvu: 0, recent: 20000, total: 322000, unit: 'token' });
assert(noMvu.mvu === '无' && noMvu.worldbook === '30万' && noMvu.recent === '2万' && noMvu.total === '32万', 'mvu zero is 无 and total is summed');
assert(usageParts(null) === null, 'missing usage is empty');
assert(pages.includes('尚无 · 演进结束后可见'), 'feed empty usage copy');
assert(pages.includes('本轮用量（估算 token）'), 'usage unit is estimated tokens');
assert(!pages.includes('扫描词') && !secretOnly.includes('萌芽'), 'usage bar does not draw scan phase');
const usedFeed = renderPage({
  page: 'feed',
  theme: 'day',
  world: {
    ...createEmptyWorld(),
    meta: { usage: { worldbook: 300000, mvu: 0, recent: 2000, total: 302000, unit: 'token' } },
  },
});
assert(usedFeed.includes('世界书') && usedFeed.includes('30万'), 'usage shows worldbook');
assert(usedFeed.includes('>无<') || usedFeed.includes('>无</span>'), 'usage shows 无 for missing mvu');
assert(usedFeed.includes('近期正文') && usedFeed.includes('2千') && usedFeed.includes('30.2万'), 'usage shows recent and total');
assert(usedFeed.indexOf('class="sj-usage"') < usedFeed.indexOf('<h3>今日变更</h3>'), 'usage bar sits above today changes');
const loadedBooks = booksFromRead({
  catalog: [{ name: '北境纪年', uid: 'wb-1' }, { name: '空书', uid: '' }],
  entries: [
    { bookName: '北境纪年', bookUid: 'wb-1', content: '重复' },
    { bookName: '东湾通商志', content: '通商' },
  ],
});
assert(loadedBooks.map((book) => book.name).join(',') === '北境纪年,空书,东湾通商志', 'catalog and entries dedupe by uid');
const bookSettings = {
  worldbook: {
    forceInclude: [{ uid: 'wb-1', name: '北境纪年' }, '王都秘辛'],
    exclude: ['东湾通商志'],
  },
};
assert(bookMode(bookSettings, { uid: 'wb-1', name: '北境纪年' }) === 'pin', 'uid pin');
assert(bookMode(bookSettings, { name: '东湾通商志' }) === 'exclude', 'name exclude wins display');
assert(bookMode(bookSettings, { name: '西原驿录' }) === 'default', 'unset book is default');
const pinned = applyBookMode(bookSettings, { name: '西原驿录' }, 'pin');
assert(pinned.forceInclude.includes('西原驿录'), 'name-only pin is a string');
assert(pinned.exclude.includes('东湾通商志'), 'pin keeps other excludes');
const excluded = applyBookMode(bookSettings, { uid: 'wb-1', name: '北境纪年' }, 'exclude');
assert(excluded.exclude.some((item) => item?.uid === 'wb-1'), 'exclude stores uid');
assert(!excluded.forceInclude.some((item) => item?.uid === 'wb-1'), 'exclude leaves the pin list');
assert(excluded.forceInclude.includes('王都秘辛'), 'other pins stay');
const cleared = applyBookMode({ worldbook: pinned }, { name: '西原驿录' }, 'default');
assert(!cleared.forceInclude.includes('西原驿录') && !cleared.exclude.includes('西原驿录'), 'default writes neither list');
const bookPage = renderPage({
  page: 'settings',
  settingsSection: 'sources',
  theme: 'day',
  worldbooksReady: true,
  advOpen: true,
  worldbooks: loadedBooks,
  worldbook: bookSettings.worldbook,
});
assert(bookPage.includes('已绑定的世界书'), 'advanced fold');
assert(bookPage.includes('世界书 · 书级常驻 / 排除'), 'book field label');
assert(bookPage.includes('常驻') && bookPage.includes('排除') && bookPage.includes('默认'), 'three modes');
assert(bookPage.includes('包括绿灯条目') && bookPage.includes('不读取该书的条目和名册') && bookPage.includes('按默认选择规则'), 'mode legend');
assert(bookPage.includes('data-wb-mode="pin" data-wb-uid="wb-1"') && bookPage.includes('class="is-on"'), 'pinned book is marked');
assert(!bookPage.includes('type="checkbox"'), 'no entry checkboxes');
saveSettings({ worldbook: excluded });
const storedBooks = loadSettings().worldbook;
assert(storedBooks.exclude.some((item) => item?.uid === 'wb-1'), 'exclude persisted');
assert(storedBooks.forceInclude.includes('王都秘辛'), 'remaining pin persisted');
assert(loadSettings().ui.theme === 'st', 'book save keeps the theme');
assert(loadSettings().timeSource.customTag === 'time', 'book save keeps the time tag');
const previousRead = host.readWorldbook.bind(host);
host.readWorldbook = () => ({
  catalog: [{ name: '只有名册', uid: '' }],
  entries: [{ comment: '正文条', content: '正文MARKER', bookName: '设定集' }],
});
const packedSource = await source.readSourcePack();
host.readWorldbook = previousRead;
assert(packedSource.worldbook.entries.some((entry) => entry.content === '正文MARKER'), 'catalog field does not replace entries');
assert(!secretOnly.includes('秘密标题') && !secretOnly.includes('隐秘正文'), 'unrevealed change hides title and body');
assert(secretOnly.includes('1 条，未揭晓前不列标题'), 'unrevealed change is count only');
assert(withWorld.includes('&lt;b&gt;公开标题&lt;/b&gt;'), 'public change title is escaped');
assert(withWorld.includes('揭晓标题'), 'revealed secret change keeps its title');
assert(!withWorld.includes('公开正文') && !withWorld.includes('揭晓正文') && !withWorld.includes('秘密标题'), 'details are collapsed; hidden secret title stays off the feed');
assert(withWorld.includes('旧版本曾记录输入截断'), 'truncated hint');
assert(!worldPage.includes('江左') && worldPage.includes('查看隐秘'), 'secret entity hides its name until explicitly viewed');
assert(!worldPage.includes('水乡正文') && !worldPage.includes('渡口') && !worldPage.includes('没有名字的组织'), 'entity body and nameless rows stay hidden');
assert(eventsPage.includes('宏观题') && eventsPage.includes('远方题') && !eventsPage.includes('隐秘题'), 'public titles visible; secret title hidden');
assert(!eventsPage.includes('宏观正文') && !eventsPage.includes('远方正文') && !eventsPage.includes('隐秘事件正文'), 'event bodies stay hidden');
assert(!eventsPage.includes('不该出现的别类'), 'unknown event kind is not listed');
assert(!eventsPage.includes('data-fix-open'), 'events without an id have no correction entry');
assert(withWorld.includes('data-fix-open="todayChange:p"'), 'public change can be corrected');
assert(withWorld.includes('data-fix-open="todayChange:r"'), 'revealed secret change can be corrected');
assert(!withWorld.includes('data-fix-open="todayChange:t"'), 'unrevealed change has no correction entry');
assert(!secretOnly.includes('data-fix-open') && !secretOnly.includes('修正'), 'unrevealed feed has no correction entry');
const fixWorld = {
  ...createEmptyWorld(),
  todayChanges: [
    { id: 'p', title: '公开标题', kind: 'macro', body: '公开正文' },
    { id: 'sec', title: '暗题', kind: 'secret', secret: true, revealed: false, body: '暗线正文' },
  ],
  events: [
    { id: 'e1', kind: 'news', title: '远讯', body: '见闻正文' },
    { id: 'e2', kind: 'secret', title: '密室', body: '隐秘事件正文', revealed: false },
    { id: 'e3', kind: 'secret', title: '已揭晓', body: '揭晓事件正文', revealed: true },
  ],
};
const manualOpen = renderPage({
  page: 'feed',
  world: fixWorld,
  fix: {
    kind: 'todayChange',
    id: 'p',
    mode: 'manual',
    stage: 'prompt',
    manualTitle: '公开标题',
    manualBody: '公开正文',
    instruction: '',
    draft: '',
    notice: '',
    error: '',
  },
});
assert(manualOpen.includes('修正此条') && manualOpen.includes('>手动<') && manualOpen.includes('>AI<'), 'manual segment');
assert(manualOpen.includes('原文') && manualOpen.includes('改正文') && manualOpen.includes('公开正文'), 'manual editor shows the body');
assert(manualOpen.includes('data-fix-save="1"') && manualOpen.includes('data-fix-dismiss="cancel"'), 'manual save and cancel');
assert(!manualOpen.includes('data-fix-apply'), 'manual mode has no adopt button');
const aiPrompt = renderPage({
  page: 'feed',
  world: fixWorld,
  fix: {
    kind: 'todayChange',
    id: 'p',
    mode: 'ai',
    stage: 'prompt',
    manualTitle: '公开标题',
    manualBody: '公开正文',
    instruction: '',
    draft: '',
  },
});
assert(aiPrompt.includes('只改这一条 · 先出修订稿 · 采用后才写入'), 'ai prompt copy');
assert(aiPrompt.includes('生成修订稿 · 消耗 1 次'), 'preview button names the one call');
assert(!aiPrompt.includes('data-fix-apply'), 'prompt stage cannot adopt');
const aiPreview = renderPage({
  page: 'feed',
  world: fixWorld,
  fix: {
    kind: 'todayChange',
    id: 'p',
    mode: 'ai',
    stage: 'preview',
    manualTitle: '公开标题',
    manualBody: '公开正文',
    draft: '修订稿正文',
  },
});
assert(aiPreview.includes('修订稿') && aiPreview.includes('修订稿正文'), 'preview shows the draft');
assert(aiPreview.includes('data-fix-apply="1"') && aiPreview.includes('采用此修订'), 'adopt is explicit');
assert(aiPreview.includes('data-fix-dismiss="cancel"') && aiPreview.includes('data-fix-dismiss="discard"'), 'cancel and discard sit beside adopt');
const secretEvents = renderPage({ page: 'events', eventFilter: 'all', world: fixWorld });
assert(!secretEvents.includes('密室') && secretEvents.includes('已揭晓'), 'unrevealed secret titles stay hidden');
assert(!secretEvents.includes('隐秘事件正文'), 'unrevealed event body stays hidden');
assert(!secretEvents.includes('data-fix-open="event:e2"'), 'unrevealed event has no correction entry');
assert(secretEvents.includes('data-fix-open="event:e1"') && secretEvents.includes('data-fix-open="event:e3"'), 'news and revealed secrets can be corrected');
const forcedSecret = renderPage({
  page: 'events',
  world: fixWorld,
  fix: {
    kind: 'event',
    id: 'e2',
    mode: 'manual',
    manualTitle: '密室',
    manualBody: '隐秘事件正文',
    draft: '隐秘事件正文',
  },
});
assert(!forcedSecret.includes('隐秘事件正文') && !forcedSecret.includes('sj-fix-body'), 'refused secret is not placed in an editor');
assert(planFixClick({ fixDismiss: 'cancel' }).effect === 'drop-draft', 'cancel plans a draft drop');
assert(planFixClick({ fixDismiss: 'discard' }).effect === 'drop-draft', 'discard plans a draft drop');
assert(planFixClick({ fixDismiss: 'cancel', fixApply: '1' }).effect === 'drop-draft', 'cancel wins over adopt');
assert(planFixClick({ fixApply: '1' }).effect === 'apply', 'adopt is a separate plan');
assert(planFixClick({ fixSave: '1' }).effect === 'save', 'manual save is its own plan');
assert(planFixClick({ fixGenerate: '1' }).effect === 'preview', 'generate plans a preview');
assert(dismissFixDraft({ draft: '稿', stage: 'preview' }, 'cancel') === null, 'cancel returns no draft');
assert(dismissFixDraft({ draft: '稿', stage: 'preview', mode: 'ai' }, 'discard').draft === '', 'discard clears the local draft');
const fixDraftSource = readFileSync(join(root, 'src/ui/fixDraft.js'), 'utf8');
assert(!fixDraftSource.includes('applyAiCorrection'), 'draft dismiss does not call apply');
assert(!fixDraftSource.includes('previewAiCorrection') && !fixDraftSource.includes('saveFactManual'), 'draft dismiss does not call the other intervene writers');
const projected = projectWorld({
  ...createEmptyWorld(),
  plugin: { enabled: true, frozenAt: 9 },
  storyClock: { dateLabel: '甲辰春', dayIndex: 2 },
  todayChanges: [{ title: '公开', body: '投影正文', kind: 'macro' }],
  meta: { sources: { truncated: true } },
});
assert(projected.plugin.frozen && projected.plugin.text === '已冻结', 'frozen readout');
assert(projected.clock.text === '甲辰春 · D2', 'clock label and day');
assert(projected.truncated === true, 'truncated flag');
assert(!JSON.stringify(projected).includes('投影正文'), 'readout drops bodies');
assert(projectWorld(null).empty === true && projectWorld(null).today === null, 'null world stays empty');
for (const label of ['日间', '夜间', '粉彩', '木白', '跟随ST']) {
  assert(renderPage({page:'settings',settingsSection:'appearance',theme:'pastel'}).includes(label), `theme ${label}`);
}

function radioTag(html, value) {
  const match = html.match(new RegExp(`<input[^>]*name="sj-time-source"[^>]*value="${value}"[^>]*>`));
  assert(match, `time source radio ${value}`);
  return match[0];
}

const settingsOff = renderPage({
  page: 'settings',
  theme: 'day',
  world: null,
  timeSource: { mode: 'auto', customTag: '' },
  hasBaibai: false,
});
assert(settingsOff.includes('世局标签') && settingsOff.includes('自定义标签') && settingsOff.includes('柏宝书'), 'three modes');
assert(settingsOff.includes('未检测到柏宝书'), 'missing book copy');
assert(settingsOff.includes('默认「世局标签」'), 'default copy without the book');
assert(!settingsOff.includes('也可以选择其他时间来源'), 'no hand-edit hint');
assert(!settingsOff.includes('sj-custom-tag'), 'custom input hidden');
assert(radioTag(settingsOff, 'shiju').includes('checked'), 'auto resolves to shiju');
assert(radioTag(settingsOff, 'baibai').includes('disabled'), 'baibai grayed');
assert(settingsOff.includes('未识别到日期时，不自动演进'), 'gate note');
assert(settingsOff.includes('disabled data-action="evolve"'), 'settings evolve disabled');
assert(settingsOff.includes('故事日不加一'), 'manual actions state the day rule');

function actionTag(html, action) {
  const match = html.match(new RegExp(`<button[^>]*data-action="${action}"[^>]*>`));
  assert(match, `action ${action}`);
  return match[0];
}

const armedWorld = createEmptyWorld();
armedWorld.plugin.enabled = true;
armedWorld.meta.builtFingerprint = 'fp';
const armedSettings = renderPage({
  page: 'settings',
  theme: 'day',
  world: armedWorld,
  timeSource: { mode: 'auto', customTag: '' },
  hasBaibai: false,
});
assert(!actionTag(armedSettings, 'evolve').includes('disabled'), 'armed world enables immediate evolve');
assert(actionTag(armedSettings, 'evolve').includes('故事日不加一'), 'evolve does not wait for a new day');
assert(actionTag(armedSettings, 'rerun').includes('disabled'), 'rerun stays disabled without a checkpoint');
assert(actionTag(armedSettings, 'rerun').includes('还没有可重跑'), 'rerun explains the missing checkpoint');
assert(!armedSettings.includes('lastEvolutionCheckpoint'), 'checkpoint name stays off the settings page');

armedWorld.lastEvolutionCheckpoint = { evolutionId: 'kept-out-of-html' };
const rerunSettings = renderPage({
  page: 'settings',
  theme: 'day',
  world: armedWorld,
});
assert(!actionTag(rerunSettings, 'rerun').includes('disabled'), 'checkpoint enables rerun');
assert(!rerunSettings.includes('kept-out-of-html'), 'checkpoint payload stays off the page');

const frozenWorld = createEmptyWorld();
frozenWorld.plugin.enabled = true;
frozenWorld.plugin.frozenAt = 4;
frozenWorld.meta.builtFingerprint = 'fp';
frozenWorld.lastEvolutionCheckpoint = { evolutionId: 'hidden' };
const frozenSettings = renderPage({ page: 'settings', theme: 'day', world: frozenWorld });
assert(actionTag(frozenSettings, 'evolve').includes('disabled'), 'frozen evolve stays disabled');
assert(actionTag(frozenSettings, 'rerun').includes('disabled'), 'frozen rerun stays disabled');

const offWorld = createEmptyWorld();
offWorld.plugin.enabled = false;
offWorld.meta.builtFingerprint = 'fp';
offWorld.lastEvolutionCheckpoint = { evolutionId: 'hidden' };
const offSettings = renderPage({ page: 'settings', theme: 'day', world: offWorld });
assert(actionTag(offSettings, 'evolve').includes('disabled'), 'disabled plugin keeps evolve off');

const tippedSettings = renderPage({
  page: 'settings',
  theme: 'day',
  world: armedWorld,
  generating: true,
});
assert(actionTag(tippedSettings, 'evolve').includes('disabled'), 'generating tip disables evolve');
assert(actionTag(tippedSettings, 'rerun').includes('disabled'), 'generating tip disables rerun');
assert(actionTag(tippedSettings, 'evolve').includes('末楼正在生成'), 'generating tip is named');

const busySettings = renderPage({
  page: 'settings',
  theme: 'day',
  world: armedWorld,
  pending: 'evolve',
});
assert(actionTag(busySettings, 'evolve').includes('disabled'), 'in-flight evolve disables itself');
assert(actionTag(busySettings, 'rerun').includes('disabled'), 'in-flight evolve disables rerun');
assert(busySettings.includes('正在立即演进'), 'busy copy is visible');

const noLedger = evolutionGates(null);
assert(noLedger.evolve.enabled === false && noLedger.evolve.reason === 'no-world', 'no ledger');
assert(noLedger.rerun.reason === 'no-world', 'rerun also waits for a ledger');
const armedGate = evolutionGates(armedWorld);
assert(armedGate.evolve.enabled === true && armedGate.rerun.enabled === true, 'armed checkpoint opens both');
const sameDay = evolutionGates({
  plugin: { enabled: true, frozenAt: null },
  meta: { builtFingerprint: 'fp' },
  storyClock: { dayIndex: 2 },
  lastEvolutionCheckpoint: null,
});
assert(sameDay.evolve.enabled === true, 'immediate evolve does not require a cross-day increment');
assert(sameDay.rerun.reason === 'no-checkpoint', 'rerun reason');
assert(evolutionGates(frozenWorld).evolve.reason === 'frozen', 'frozen reason');
assert(evolutionGates(offWorld).evolve.reason === 'disabled', 'disabled reason');
assert(evolutionGates(armedWorld, { generating: true }).evolve.reason === 'generating', 'generating reason');
assert(evolutionGates(armedWorld, { busy: true }).rerun.reason === 'busy', 'busy reason');
assert(evolutionResultText('evolve', { ok: true, evolved: true }).includes('故事日按正文时间对齐'), 'immediate result');
assert(evolutionResultText('rerun', { ok: true, evolved: true }).includes('故事日没有前进'), 'rerun result');
assert(evolutionResultText('evolve', { ok: false, reason: 'model' }) === '演进没有完成', 'model failure copy');
assert(evolutionResultText('rerun', { ok: false, reason: 'no-checkpoint' }) === '还没有可重跑的演进', 'checkpoint failure copy');

const settingsOn = renderPage({
  page: 'settings',
  theme: 'day',
  world: null,
  timeSource: { mode: 'auto', customTag: '' },
  hasBaibai: true,
});
assert(settingsOn.includes('检测到') && settingsOn.includes('也可以选择其他时间来源'), 'book hint');
assert(radioTag(settingsOn, 'baibai').includes('checked'), 'auto resolves to baibai');
assert(!radioTag(settingsOn, 'baibai').includes('disabled'), 'baibai can be chosen');
assert(settingsOn.includes('从最新正文读取柏宝书'), 'baibai note');

const locked = renderPage({
  page: 'settings',
  theme: 'day',
  world: null,
  timeSource: { mode: 'shiju', customTag: 'keep' },
  hasBaibai: true,
});
assert(radioTag(locked, 'shiju').includes('checked'), 'hand choice sticks');
assert(locked.includes('也可以选择其他时间来源'), 'hint stays after a hand choice');

const custom = renderPage({
  page: 'settings',
  theme: 'st',
  world: null,
  timeSource: { mode: 'custom', customTag: 'time' },
  hasBaibai: false,
});
assert(custom.includes('id="sj-custom-tag"'), 'custom input');
assert(custom.includes('value="time"'), 'custom tag value');
assert(custom.includes('时间标签名'), 'custom label');
assert(!custom.includes('从最新正文读取柏宝书'), 'baibai note hidden off that mode');

const live = [
  [model, 'generateViaST'],
  [source, 'readSourcePack'],
  [bootstrap, 'bootstrapWorld'],
  [timetag, 'refreshTimeTag'],
  [timetag, 'readTaggedStoryTime'],
  [timetag, 'syncHideRegex'],
  [timeGate, 'runAutomaticGate'],
  [timeGate, 'runImmediateEvolution'],
  [timeGate, 'rerunLastEvolution'],
  [evolve, 'runEvolutionOnce'],
  [commit, 'commitEvolutionSuccess'],
  [reconcile, 'reconcileOnChatMutation'],
];
for (const [mod, name] of live) {
  assert(typeof mod.register === 'function', `${name} module registers`);
  assert(typeof mod[name] === 'function', `${name} is exported`);
}
assert(typeof inject.register === 'function', 'inject registers');
assert(typeof intervene.register === 'function', 'intervene registers');
assert(typeof intervene.saveFactManual === 'function', 'saveFactManual is exported');
assert(typeof intervene.previewAiCorrection === 'function', 'previewAiCorrection is exported');
assert(typeof intervene.applyAiCorrection === 'function', 'applyAiCorrection is exported');
assert(String(intervene.AI_CORRECTION_CONFIRM).includes('消耗 1 次调用'), 'confirm copy names the one call');
const interveneSource = readFileSync(join(root, 'src/modules/intervene/index.js'), 'utf8');
assert(interveneSource.includes('generateViaST'), 'correction leaves through generateViaST');
assert(!interveneSource.includes('generateViaBackend'), 'correction does not call the host backend');
assert(!interveneSource.includes('commitEvolutionSuccess'), 'correction does not commit');
assert(!interveneSource.includes('runImmediateEvolution') && !interveneSource.includes('rerunLastEvolution'), 'correction is not an evolution');
const contract = readFileSync(join(root, 'UI-CONTRACT.md'), 'utf8');
for (const name of ['saveFactManual', 'previewAiCorrection', 'applyAiCorrection']) {
  assert(contract.includes(name), `contract lists ${name}`);
}
assert(contract.includes('消耗 1 次调用') && contract.includes('SHIJU_INTERVENE_REFUSED'), 'contract lists the confirm copy and the secret refusal');
const coreDoc = readFileSync(join(root, 'CORE.md'), 'utf8');
assert(coreDoc.includes('saveFactManual') && coreDoc.includes('previewAiCorrection') && coreDoc.includes('applyAiCorrection'), 'core doc names the three calls');
inject.register({});
const tagBeforeClear = host.state.prompts.shiju_timetag;
const preview = inject.refreshInject();
assert(preview.key === 'shiju_macro' && preview.depth === 4, 'refresh names the macro slot');
assert(preview.disclaimer === '背景参考，不必强行写入正文', 'disclaimer is the D17 sentence');
inject.clearInject();
assert(host.state.prompts.shiju_macro?.value === '', 'clear empties the macro prompt');
assert(host.state.prompts.shiju_timetag === tagBeforeClear, 'clear leaves the timetag key');
assert(timetag.TIMETAG_PROMPT_KEY === 'shiju_timetag' && timetag.TIMETAG_DEPTH === 0, 'timetag key');
assert(timetag.HIDE_REGEX_ID === 'shiju-time-tag-hide', 'hide regex id');
assert(inject.MACRO_KEY === 'shiju_macro' && inject.MACRO_DEPTH === 4, 'macro key');
assert(loadWorld().evolutionLog.length === 0, 'register did not append');

const jsFiles = [
  ...walk(join(root, 'src')),
  join(root, 'index.js'),
  ...walk(join(root, 'dev')),
].filter((file) => file.endsWith('.js'));
const sources = jsFiles.map((file) => stripComments(readFileSync(file, 'utf8'))).join('\n');
assert(!/\bindexedDB\b/i.test(sources), 'no indexedDB');
assert(!/\blocalStorage\b/.test(sources), 'no localStorage');
const businessSources = jsFiles.filter(file => !file.endsWith('/host/history-file.js')).map(file => stripComments(readFileSync(file, 'utf8'))).join('\n');
assert(!/\bfetch\s*\(/.test(businessSources), 'no direct fetch outside explicit host file adapter');
assert(!sources.includes('shiju_contactable'), 'old inject key stays gone');
assert(!sources.includes('api.openai.com'), 'no upstream openai url');
assert(!sources.includes('api.anthropic.com'), 'no upstream anthropic url');

const appendSites = [];
for (const file of jsFiles) {
  const text = readFileSync(file, 'utf8');
  const found = text.match(/evolutionLog\s*\.\s*push\s*\(/g);
  if (found) appendSites.push(`${file}:${found.length}`);
}
assert(appendSites.length === 1 && appendSites[0].endsWith('modules/commit/index.js:1'), `one append site, got ${appendSites.join(',')}`);
const setterSites = jsFiles.filter((file) => /setGeneratingTip\s*\(/.test(readFileSync(file, 'utf8')));
assert(setterSites.length === 2, `generating tip writers: ${setterSites.join(',')}`);
assert(setterSites.every((file) => file.endsWith('generatingTip.js') || file.endsWith('reconcile/index.js')), 'tip flag writers');
const productFiles = jsFiles.filter((file) => {
  const parts = file.split('/');
  // The native fixture stubs the host. It is not a product call site.
  return !parts.includes('dev') && !parts.includes('fixture');
});
const backendSites = productFiles.filter((file) => stripComments(readFileSync(file, 'utf8')).includes('generateViaBackend'));
const allowedBackend = new Set([
  join(root, 'index.js'),
  join(root, 'src/modules/model/index.js'),
]);
assert(
  backendSites.length === allowedBackend.size && backendSites.every((file) => allowedBackend.has(file)),
  `A25 generateViaBackend only in the tavern entry and M-Model, got ${backendSites.join(',')}`,
);
const rawSites = productFiles.filter((file) => stripComments(readFileSync(file, 'utf8')).includes('generateRaw'));
assert(rawSites.length === 0, 'A25 no generateRaw entry or fallback');
const viaSites = productFiles.filter((file) => /generateViaST\s*\(/.test(stripComments(readFileSync(file, 'utf8'))));
const allowedVia = [
  'src/modules/management/index.js',
  'src/modules/model/index.js',
  'src/modules/bootstrap/index.js',
  'src/modules/evolve/index.js',
  'src/modules/lifecycle/index.js',
  'src/modules/intervene/index.js',
];
assert(
  viaSites.length === allowedVia.length && allowedVia.every((suffix) => viaSites.some((file) => file.endsWith(suffix))),
  `A25 generateViaST call sites, got ${viaSites.join(',')}`,
);

const uiSource = walk(join(root, 'src/ui')).map((file) => stripComments(readFileSync(file, 'utf8'))).join('\n');
assert(!uiSource.includes('chatMetadata'), 'ui does not touch chat metadata');
assert(!uiSource.includes('extension_settings'), 'ui does not touch extension settings');
for (const name of [
  'saveWorld',
  'commitEvolutionSuccess',
  'bootstrapWorld',
  'runAutomaticGate',
  'refreshInject',
  'clearInject',
  'setExtensionPrompt',
  'evolutionLog',
  'dayBuffer',
  'setGeneratingTip',
]) {
  assert(!uiSource.includes(name), `ui does not reference ${name}`);
}
assert(uiSource.includes('runImmediateEvolution()'), 'panel calls runImmediateEvolution');
assert(uiSource.includes('rerunLastEvolution()'), 'panel calls rerunLastEvolution');
assert(uiSource.includes('lastEvolutionCheckpoint'), 'rerun gate reads the checkpoint');
assert(uiSource.includes('saveFactManual('), 'manual save uses saveFactManual');
assert(uiSource.includes('previewAiCorrection('), 'preview uses previewAiCorrection');
assert(uiSource.includes('applyAiCorrection('), 'adopt uses applyAiCorrection');
assert(uiSource.includes('AI_CORRECTION_CONFIRM'), 'confirm copy is the exported constant');
const shellSource = readFileSync(join(root, 'src/ui/shell.js'), 'utf8');
const fixClick = shellSource.slice(shellSource.indexOf('function onFixClick'));
const dismissAt = fixClick.indexOf("plan.effect === 'drop-draft'");
const applyAt = fixClick.indexOf('adoptRevision()');
assert(dismissAt > 0 && applyAt > dismissAt, 'cancel returns before adopt');
assert(fixClick.slice(dismissAt, applyAt).includes('return;'), 'cancel returns before adopt is called');
assert(shellSource.includes('if (!accepted || state.fix !== fix) return;'), 'declined confirm does not preview');

const moduleSource = walk(join(root, 'src/modules')).map((file) => stripComments(readFileSync(file, 'utf8'))).join('\n');
assert(!/chatMetadata\s*=(?!=)/.test(moduleSource), 'modules do not replace metadata');
assert(!moduleSource.includes('/ui/'), 'stubs do not import the shell');

const entry = readFileSync(join(root, 'index.js'), 'utf8');
assert(entry.includes("from '../../../extensions.js'"), 'ST extensions import');
assert(entry.includes("from '../../../../script.js'"), 'ST script import');
assert(entry.includes('start()'), 'entry boots');

const manifest = JSON.parse(readFileSync(join(root, 'manifest.json'), 'utf8'));
assert(manifest.display_name === '世局', 'display name');
assert(manifest.js === 'index.js' && manifest.css === 'style.css', 'manifest files');
assert(manifest.version === JSON.parse(readFileSync(join(root, 'package.json'),'utf8')).version, 'version');

const css = readFileSync(join(root, 'style.css'), 'utf8');
for (const theme of ['day', 'night', 'pastel', 'green', 'st']) {
  assert(css.includes(`data-theme="${theme}"`), `css ${theme}`);
}
assert(css.includes('--sj-accent') && css.includes('--sj-bg'), 'tokens');
assert(css.includes('color-mix') && css.includes('SmartTheme'), 'st theme hook');
assert(css.includes('--sj-fab-size: 46px'), 'fab size');
assert(css.includes('safe-area-inset-bottom'), 'safe area');
assert(css.includes('overflow-y: auto'), 'scrolling body');
assert(css.includes('#c4486d'), 'pastel accent');
assert(css.includes('.sj-usage') && css.includes('.sj-wb-seg'), 'usage bar and book modes are styled');

const fixtureCount = await runFixtureChecks();
checks += fixtureCount;

const coreCount = await runCoreChecks();
checks += coreCount;

const chatScopeCount = await runChatScopeChecks();
checks += chatScopeCount;

const entryWorldbookCount = await runEntryWorldbookChecks();
checks += entryWorldbookCount;

const timeTagRefreshCount = await runTimeTagRefreshChecks();
checks += timeTagRefreshCount;

const relativeTimeCount = await runRelativeTimeChecks();
checks += relativeTimeCount;

const promptDepthCount = runPromptDepthChecks();
checks += promptDepthCount;

const consistencyCount = await runConsistencyChecks();
checks += consistencyCount;
console.log(`shiju consistency-check ok (${consistencyCount} checks)`);

console.log(`shiju core-check ok (${coreCount} checks)`);
console.log(`shiju chat-scope-check ok (${chatScopeCount} checks)`);
console.log(`shiju entry-worldbook-check ok (${entryWorldbookCount} checks)`);
console.log(`shiju timetag-refresh-check ok (${timeTagRefreshCount} checks)`);
console.log(`shiju relative-time-check ok (${relativeTimeCount} checks)`);
console.log(`shiju prompt-depth-check ok (${promptDepthCount} checks)`);
const promptPreferencesCount = await runPromptPreferencesChecks();
checks += promptPreferencesCount;
console.log(`shiju prompt-preferences-check ok (${promptPreferencesCount} checks)`);

const compatibilityCount = await runCompatibilityChecks();
checks += compatibilityCount;
console.log(`shiju compatibility-check ok (${compatibilityCount} checks)`);

const historyEditCount = await runHistoryEditChecks();
checks += historyEditCount;
console.log(`shiju history-edit-check ok (${historyEditCount} checks)`);

console.log(`shiju smoke ok (${checks} checks)`);
