import assert from 'node:assert/strict';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { loadWorld } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { runImmediateEvolution, runAutomaticGate, rerunLastEvolution } from '../src/modules/timeGate/index.js';
import { correctStoryDay } from '../src/modules/lifecycle/index.js';
import { generateManagementPreview, discardManagementSession } from '../src/modules/management/index.js';
import { validateWorldPatch } from '../src/modules/evolve/validate.js';
import { applyEvolutionPatch } from '../src/modules/evolve/patch.js';
import { createEmptyWorld } from '../src/store/schema.js';

let checks=0;
const check=(condition,message)=>{assert.ok(condition,message);checks++;};
const event={id:'bridge',kind:'macro',title:'桥梁修缮',body:'渡口木桥正在修缮。',lifecycle:'active'};
const change={id:'bridge-today',kind:'macro',title:'木桥修缮开始',body:'渡口安排工人修缮木桥。',linkedEventId:'bridge'};
const host=createMemoryHost({chat:[{mes:'渡口发布中性修桥公告<shiju_end>2026/1/1</shiju_end>',swipe_id:0}],settings:{timeSource:{mode:'shiju'}},worldInfoEntries:[{uid:1,constant:true,bookName:'虚构资料',content:'渡口贸易依赖木桥。'}]});
const calls=[];let broken=false;
host.generateViaBackend=async request=>{
  calls.push(request);
  if(broken)return JSON.stringify({events:[event],todayChanges:[{id:'malformed',text:'木桥修缮开始。',linkedEventId:'bridge'}]});
  if(request.purpose.startsWith('regenerate-'))return JSON.stringify({[request.purpose.slice('regenerate-'.length)]:[{id:'fixture-entity',name:'虚构资料',summary:'中性测试概况'}]});
  return JSON.stringify({regions:[{id:'valley',name:'河谷',summary:'沿河有一个渡口。'}],events:[event],todayChanges:['bootstrap','reinitialize'].includes(request.purpose)?[]:[change]});
};
setHost(host);
check((await bootstrapWorld()).created,'initialization succeeds with prescribed empty today changes');
check((await runImmediateEvolution()).evolved,'immediate evolution accepts title/body change');
check(loadWorld().todayChanges[0].title===change.title&&loadWorld().todayChanges[0].body===change.body,'both change title and detail are committed');
check((await rerunLastEvolution()).evolved,'rerun accepts prescribed format');
host.state.chat.push({mes:'次日中性施工公告<shiju_end>2026/1/2</shiju_end>',swipe_id:0});
check((await runAutomaticGate()).evolved,'automatic evolution accepts prescribed format');
check((await correctStoryDay({choice:'realign'})).ok,'realign accepts prescribed format');
const rebuild=await generateManagementPreview();discardManagementSession(rebuild.token);
for(const kind of ['regions','factions','orgs']){const preview=await generateManagementPreview(kind);discardManagementSession(preview.token);}
check(calls.length===9,'all nine structured task paths captured with local fixed replies');
for(const request of calls){
  const protocol=request.messages.filter(message=>message.role==='system').map(message=>message.content).join('\n');
  check(protocol.includes('todayChanges 每项必须明确输出非空字符串 title')&&protocol.includes('不要用 text、name、summary、description 替代 title 或 body'),'actual request contains exact today-change field contract: '+request.purpose);
  check(protocol.includes('text 是 facts 的字段')&&protocol.includes('即使关联了事件，也不能省略 title 或 body'),'actual request distinguishes facts and linked changes: '+request.purpose);
  const sampleLine=protocol.split('\n').find(line=>line.startsWith('{"events":[{"id":"event-example-bridge"'));
  check(Boolean(sampleLine),'actual request includes parseable neutral example: '+request.purpose);
  const sample=JSON.parse(sampleLine);validateWorldPatch(sample);
  const world=createEmptyWorld();applyEvolutionPatch(world,sample,{dayIndex:0});
  check(world.todayChanges.length===1&&world.todayChanges[0].body===sample.todayChanges[0].body&&world.todayChanges[0].linkedEventId===world.events[0].id,'example survives actual validation and storage: '+request.purpose);
}
const bootstrap=calls.find(call=>call.purpose==='bootstrap');
check(bootstrap.messages.some(m=>m.role==='system'&&m.content.includes('todayChanges 必须是空数组')),'initialization retains stricter empty-list instruction');
for(const call of calls.filter(c=>c.purpose.startsWith('regenerate-'))){
  check(call.prompt.includes('输出仅可有')&&call.messages.some(m=>m.role==='system'&&m.content.includes('分类补全不得输出 todayChanges')),'category-only instruction remains explicit');
}
// Synthetic reproduction of the reported shape. No private chat text is embedded.
broken=true;
const before=loadWorld(),count=calls.length;
const failure=await runImmediateEvolution();
check(!failure.ok&&failure.message.includes('todayChanges'),'missing fields still fail validation; no compatibility rewrite was introduced');
check(calls.length===count+1,'format failure does not automatically retry');
const after=loadWorld();
for(const field of ['regions','events','todayChanges','processedInput','appliedPreferences','userCorrections','lastEvolutionCheckpoint'])check(JSON.stringify(after[field])===JSON.stringify(before[field]),'failed reply preserves '+field);
console.log(`output format checks ok: ${checks}; real model calls 0`);
