import { writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';

const port = Number(process.env.SHIJU_CDP_PORT || 9334);
const url = process.env.SHIJU_PREVIEW_URL || 'http://127.0.0.1:43123/dev/preview.html?autotest=1';
const chromeBin = process.env.CHROME_PATH || '/usr/bin/google-chrome';
const pages = process.env.SHIJU_TEST_URLS ? process.env.SHIJU_TEST_URLS.split(',') : [url, fixturePage(url)];

function fixturePage(pageUrl) {
  const next = new URL(pageUrl);
  next.searchParams.set('fixture', '1');
  next.searchParams.set('autotest', '1');
  next.searchParams.delete('intervene');
  next.searchParams.delete('baibai');
  return next.toString();
}

const ping = await fetch(url).catch(() => null);
if (!ping?.ok) {
  console.error('预览服务没开。先在仓库根目录跑 npm run preview');
  process.exit(1);
}

const chrome = process.env.SHIJU_ATTACH_CDP ? null : spawn(chromeBin, [
  '--headless=new',
  '--no-sandbox',
  '--disable-gpu',
  '--disable-dev-shm-usage',
  `--remote-debugging-port=${port}`,
  `--user-data-dir=/tmp/shiju-cdp-${port}-${process.pid}`,
  '--window-size=1280,800',
  'about:blank',
], { detached: true, stdio: 'ignore' });
chrome?.unref();

try {
  const version = await waitForJson(`http://127.0.0.1:${port}/json/version`);
  const ws = new WebSocket(version.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('CDP 连接失败')), { once: true });
  });

  let seq = 0;
  const pending = new Map();
  ws.addEventListener('message', (event) => {
    const data = JSON.parse(event.data);
    if (!data.id || !pending.has(data.id)) return;
    pending.get(data.id)(data);
    pending.delete(data.id);
  });

  function send(method, params = {}, sessionId) {
    const id = ++seq;
    return new Promise((resolve) => {
      pending.set(id, resolve);
      const payload = { id, method, params };
      if (sessionId) payload.sessionId = sessionId;
      ws.send(JSON.stringify(payload));
    });
  }

  const failures = [];
  for (const page of pages) {
    const detail = await runPage(send, page);
    if (detail) failures.push(`${page}\n${detail}`);
  }

  if (failures.length) {
    console.error(failures.join('\n'));
    process.exitCode = 1;
  } else {
    console.log('shiju browser smoke ok');
  }
  ws.close();
} finally {
  try {
    if(chrome?.pid) process.kill(-chrome.pid, 'SIGKILL');
  } catch {
    /* Chrome already left. */
  }
}

async function runPage(send, pageUrl) {
  const created = await send('Target.createTarget', { url: 'about:blank' });
  const targetId = created.result?.targetId;
  if (!targetId) return '没有打开页面';
  const session = await send('Target.attachToTarget', { targetId, flatten: true });
  const sessionId = session.result?.sessionId;
  if (!sessionId) return '没有连上页面';
  await send('Page.enable', {}, sessionId);
  await send('Runtime.enable', {}, sessionId);
  if(process.env.SHIJU_QA_WIDTH) await send('Emulation.setDeviceMetricsOverride',{width:Number(process.env.SHIJU_QA_WIDTH),height:900,deviceScaleFactor:1,mobile:Number(process.env.SHIJU_QA_WIDTH)<500},sessionId);
  await send('Page.navigate',{url:pageUrl},sessionId);

  let status = '';
  let detail = '';
  for (let i = 0; i < 240; i += 1) {
    const evaluated = await send('Runtime.evaluate', {
      expression: `JSON.stringify({
        status: document.documentElement.dataset.sjAutotest || '',
        error: document.documentElement.dataset.sjAutotestError || '',
        text: document.getElementById('sj-autotest')?.textContent || ''
      })`,
      returnByValue: true,
    }, sessionId);
    const value = evaluated.result?.result?.value;
    if (typeof value === 'string') {
      const parsed = JSON.parse(value);
      status = parsed.status;
      detail = parsed.error || parsed.text;
      if (status === 'ok' || status === 'fail') break;
    }
    await delay(250);
  }

  if(process.env.SHIJU_SCREENSHOT_PREFIX && status==='ok') {
    const shot=await send('Page.captureScreenshot',{format:'png'},sessionId);
    if(shot.result?.data) await writeFile(`${process.env.SHIJU_SCREENSHOT_PREFIX}-${process.env.SHIJU_QA_WIDTH || 1280}${new URL(pageUrl).searchParams.has('fixture') ? '-fixture' : ''}.png`,Buffer.from(shot.result.data,'base64'));
  }
  try {
    await send('Target.closeTarget', { targetId });
  } catch {
    /* The page can already be gone. */
  }
  if (status !== 'ok') return detail || '面板自检没有在限定时间内通过';
  console.log(`shiju browser smoke ok ${pageUrl} — ${detail}`);
  return '';
}

async function waitForJson(versionUrl) {
  for (let i = 0; i < 40; i += 1) {
    try {
      const response = await fetch(versionUrl);
      if (response.ok) return response.json();
    } catch {
      /* Chrome is still booting. */
    }
    await delay(100);
  }
  throw new Error('Chrome 调试端口没有起来');
}
