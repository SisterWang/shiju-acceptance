// Neutral fixtures shared by Node and real-browser Worker acceptance tests.
export const templateCases = [
  ['plain comment', '<!-- 桥梁备注 -->\n状态：<%= getvar("status") %>', '<!-- 桥梁备注 -->\n状态：已验收'],
  ['plain arrow', '仓库 --> 桥头：<%= getvar("status") %>', '仓库 --> 桥头：已验收'],
  ['string literal', '<%- "<!-- 普通备注 -->" %>', '<!-- 普通备注 -->'],
  ['escaped output', '<%= "<!-- 普通备注 -->" %>', '&lt;!-- 普通备注 --&gt;'],
  ['line comment', '<% // <!-- 注释 -->\n const x=1; %><%= x %>', '1'],
  ['block comment', '<% /* <!-- 注释 --> */ const x=2; %><%= x %>', '2'],
  ['EJS comment', '<%# <!-- EJS 注释 --> %><%= getvar("status") %>', '已验收'],
  ['template escapes', '<%- `<!-- \\n\\t${getvar("status")} \\u6865 -->` %>', '<!-- \n\t已验收 桥 -->'],
  ['string escapes', '<%- "<!-- \\n\\t\\\"\\\\ -->" %>', '<!-- \n\t"\\ -->'],
  ['import text', '<%- "示例 import( 不执行" %>', '示例 import( 不执行'],
  ['regexp match', '<%= /<!--.*-->/.test("<!-- x -->") %>', 'true'],
  ['decrement comparison', '<% let x=3; const y=x-->1; %><%= x %>:<%= y %>', '2:true'],
  ['ordinary tag', '<% const tag=(s,...v)=>s[0]+v[0]+s[1]; %><%- tag`状态：${getvar("status")}。` %>', '状态：已验收。'],
];

export const templateData = {
  global:{status:'已验收', state:{bridge:'通行', secret:'内部备注', nested:{keep:1, drop:2}, rows:[{keep:3, drop:4}] }},
};

// render(content, entries) must create a fresh disposable Worker, with the
// normal two-second budget (including cold start). No model or host writes.
export async function checkTemplateCompatibility(render, check) {
  for (const [label, content, expected] of templateCases) {
    const result = await render(content);
    check(result.text === expected && result.diagnostics.length === 0, `EJS output preserved: ${label} (${JSON.stringify(result)})`);
  }
  const omissions = [
    ['"secret"', {bridge:'通行',nested:{keep:1,drop:2},rows:[{keep:3,drop:4}]}],
    ['["secret","bridge"]', {nested:{keep:1,drop:2},rows:[{keep:3,drop:4}]}],
    ['"secret", "nested.drop", "rows[0].drop", "missing"', {bridge:'通行',nested:{keep:1},rows:[{keep:3}]}],
    ['[["nested","drop"],["rows",0,"drop"]]', {bridge:'通行',secret:'内部备注',nested:{keep:1},rows:[{keep:3}]}],
  ];
  for (const [paths, expected] of omissions) {
    const result = await render(`<%- JSON.stringify(_.omit(getvar("state"), ${paths})) %>`);
    check(result.text === JSON.stringify(expected) && result.diagnostics.length === 0, `omit copy: ${paths}`);
  }
  const detached = await render('<% const before=JSON.stringify(getvar("state")); const copy=_.omit(getvar("state"), "rows[0].drop"); copy.rows[0].keep=99; copy.nested.keep=99; copy.rows.push({}); %><%= JSON.stringify(getvar("state"))===before %>');
  check(detached.text === 'true' && detached.diagnostics.length === 0, 'omit results remain detached and locally writable');
  check((await render('<%- JSON.stringify(_.omit(null,"x")) %>')).text === '{}', 'omit null input');
  check((await render('<%= typeof _.unset %>/<%= typeof _.mixin %>/<%= typeof _.template %>')).text === 'undefined/undefined/undefined', 'no unrelated lodash exports');
  const pollution = await render('<% const before=Object.prototype.toString; const number=Number.prototype.toFixed; _.omit({}, [["constructor",["prototype"],"toString"]]); _.omit({}, [["__proto__","toString"]]); _.omit({n:1}, [["n","constructor","prototype","toFixed"]]); %><%= before===Object.prototype.toString && number===Number.prototype.toFixed %>');
  check(pollution.text === 'true', 'prototype paths cannot delete built-in properties');
  const entries = [
    {bookName:'测试书', title:'child', content:'<!-- 子条目 -->\n<%= getvar("status") %>'},
    {bookName:'测试书', title:'parent', content:'<%- await include("child") %>'},
    {bookName:'测试书', title:'broken', content:'<%= missingHelper() %>'},
  ];
  for (const helper of ['getwi','getWorldInfo','include']) {
    check((await render(`<%- await ${helper}("测试书","parent") %>`, entries)).text === '<!-- 子条目 -->\n已验收', `nested dependency: ${helper}`);
  }
  const dependency = await render('<%- await include("broken") %>', entries);
  check(dependency.text === null && dependency.diagnostics.some(d => d.code === 'EJS_EXECUTION' && d.reason.includes('依赖条目失败') && d.reason.includes('main') && d.reason.includes('broken')), 'dependency diagnostic identifies parent and failed entry');
  const cycle = await render('<%- await include("cycle") %>', [{title:'cycle',content:'<%- await include("cycle") %>'}]);
  check(cycle.text === null && cycle.diagnostics.some(d => d.code === 'EJS_CYCLE'), 'cycle still rejected');
  for (const content of ['<%- String.raw`<!-- x -->` %>', '<%- String.raw`import("x")` %>']) {
    const result = await render(content);
    check(result.text === null && result.diagnostics.some(d => d.code === 'EJS_TAGGED_TEMPLATE'), 'unsupported tagged template explicitly diagnosed');
  }
  const malformed = await render('<% const secretValue = ; %>');
  check(malformed.text === null && malformed.diagnostics.some(d => d.code === 'EJS_TRANSFORM') && !JSON.stringify(malformed.diagnostics).includes('secretValue'), 'parser failure does not expose source');
  const thrown = await render('<% throw new Error(getvar("state.secret")); %>');
  check(thrown.text === null && !JSON.stringify(thrown.diagnostics).includes('内部备注'), 'exception diagnostics do not expose variable contents');
  for (const content of [
    '<%= await import("https://example.invalid/module.js") %>',
    '<%= await fetch("https://example.invalid") %>',
    '<%= ({}).constructor.constructor("return this")() %>',
    '<%= eval("1") %>',
    '<%= sendMessage("hello") %>',
  ]) check((await render(content)).text === null, 'restricted capabilities remain unavailable');
  const write = await render('<% setvar("status","changed"); variables.state.rows[0].keep=99; delete variables.state.secret; variables.state.rows.push({}); %><!-- still readonly --><%= getvar("status") %>:<%= getvar("state.rows[0].keep") %>:<%= getvar("state.rows").length %>');
  check(write.text === '<!-- still readonly -->已验收:3:1' && write.diagnostics.filter(d => d.kind === 'blocked').length >= 4, 'writes blocked even after transformation');
}
