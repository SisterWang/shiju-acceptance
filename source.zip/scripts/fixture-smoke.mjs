/**
 * A5 / A24 on the native fixture.
 * A5: no BaiBai book and no MVU, A1–A4 still finish.
 * A24: the ledger is chatMetadata.shiju, the export carries it,
 * uninstall + reinstall of the same chat resumes, settings stay on extension_settings.shiju.
 *
 * Still manual, because this repo has no SillyTavern server:
 * - the chat menu's real Export / Open
 * - uninstalling the extension from the extensions panel and installing the folder again
 * The fixture copies those two data shapes. It does not start SillyTavern.
 * A2 checks the shiju_macro slot, not the prose the main model later writes (that is A12).
 * A1's single world-build uses the fixture's canned backend, not a live model.
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { ensureSettings, loadSettings, loadWorld, saveSettings } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { countEntities } from '../src/modules/evolve/patch.js';
import { freezeWorld, reopenWorld } from '../src/modules/lifecycle/index.js';
import { MACRO_DISCLAIMER } from '../src/modules/inject/index.js';
import { readSourcePack } from '../src/modules/source/index.js';
import { clearEvolutionHold, runAutomaticGate } from '../src/modules/timeGate/index.js';
import { setGeneratingTip } from '../src/modules/generatingTip.js';
import { renderPage } from '../src/ui/pages.js';
import * as model from '../src/modules/model/index.js';
import * as source from '../src/modules/source/index.js';
import * as bootstrap from '../src/modules/bootstrap/index.js';
import * as timetag from '../src/modules/timetag/index.js';
import * as timeGate from '../src/modules/timeGate/index.js';
import * as evolve from '../src/modules/evolve/index.js';
import * as commit from '../src/modules/commit/index.js';
import * as reconcile from '../src/modules/reconcile/index.js';
import * as inject from '../src/modules/inject/index.js';
import * as lifecycle from '../src/modules/lifecycle/index.js';
import * as intervene from '../src/modules/intervene/index.js';
import {
  DECOY_REGION,
  FIXTURE_ENABLED_BY_DEFAULT,
  FIXTURE_ID,
  NATIVE_MACRO,
  NATIVE_NEWS,
  NATIVE_ORG,
  NATIVE_REGION,
  NATIVE_SECRET,
  NATIVE_SECRET_BODY,
  exportChatFile,
  floorHash,
  installNativeFixture,
  nativeLaterFloor,
  nativeNewChat,
  nativeOldFloors,
  openChatFile,
  reinstallNativeHost,
  releaseNativeFixture,
  uninstallKeepingChat,
} from '../src/fixture/native.js';

const root = fileURLToPath(new URL('..', import.meta.url));
const MODULES = [model, source, bootstrap, timetag, timeGate, evolve, commit, reconcile, inject, lifecycle, intervene];

function bindModules() {
  for (const mod of MODULES) mod.register({});
}

function mesOf(host) {
  return host.state.chat.map((message) => message.mes);
}

function names(list) {
  return (Array.isArray(list) ? list : []).map((item) => item?.name).filter(Boolean);
}

export async function runFixtureChecks() {
  let checks = 0;
  function assert(condition, message) {
    checks += 1;
    if (!condition) {
      console.error(`FAIL fixture #${checks}: ${message}`);
      process.exit(1);
    }
  }

  const previousFetch = globalThis.fetch;
  let fetches = 0;
  globalThis.fetch = async () => {
    fetches += 1;
    throw new Error('fetch blocked');
  };

  try {
    assert(FIXTURE_ENABLED_BY_DEFAULT === false, 'fixture default is off');
    assert(FIXTURE_ID === 'native-no-book', 'fixture id');
    const idle = createMemoryHost({ hasBaibai: true, mvu: { hp: 1 } });
    idle.generateViaBackend = async () => 'leave-me';
    for (const options of [undefined, {}, { enabled: false }, { enabled: '1' }, { enabled: 1 }]) {
      const installed = installNativeFixture(idle, options);
      assert(installed.enabled === false, 'omitted flag does not enable');
    }
    assert(idle.state.hasBaibai === true && idle.state.mvu.hp === 1, 'disabled fixture does not strip the host');
    assert(idle.state.fixtureCalls === undefined, 'disabled fixture records nothing');
    const left = await idle.generateViaBackend();
    assert(left === 'leave-me', 'disabled fixture does not replace the backend');

    const entry = readFileSync(join(root, 'index.js'), 'utf8');
    const main = readFileSync(join(root, 'src/main.js'), 'utf8');
    const preview = readFileSync(join(root, 'dev/preview.js'), 'utf8');
    assert(!entry.includes('fixture') && !entry.includes('installNativeFixture'), 'production entry skips the fixture');
    assert(!main.includes('fixture') && !main.includes('installNativeFixture'), 'boot skips the fixture');
    assert(preview.includes("const fixtureOn = params.get('fixture') === '1'"), 'preview flag is exact');
    assert(preview.includes('if (fixtureOn) installNativeFixture(host, { enabled: true })'), 'preview opts in only then');

    await assertNativePath(assert);
    assert(fetches === 0, `native path fetch count ${fetches}`);
  } finally {
    releaseNativeFixture();
    globalThis.fetch = previousFetch;
    setGeneratingTip(false);
    clearEvolutionHold();
  }

  return checks;
}

async function assertNativePath(assert) {
  const host = createMemoryHost();
  setHost(host);
  const installed = installNativeFixture(host, { enabled: true });
  assert(installed.enabled === true && installed.id === FIXTURE_ID, 'native fixture on');
  globalThis.STBaiBaiBook = {
    getSnapshot() {
      return { state: { time: '三年前', location: '渡口' } };
    },
    getHistory() {
      return { relativeText: '旧史' };
    },
  };
  globalThis.bbs_generateInterceptor = () => 'book';
  host.state.mvu = { hp: 9, note: '变量' };
  host.state.hasBaibai = true;
  ensureSettings();
  bindModules();

  host.state.chat = nativeNewChat();
  host.state.chatMetadata = {};
  host.state.chatId = 'native-new';
  const freshHash = floorHash(host.state.chat);
  const freshMes = mesOf(host);
  const pack = await readSourcePack();
  assert(pack.baibai === undefined && pack.mvu === undefined, 'A5 pack has no book and no MVU');
  assert(host.readMvu() === null && host.hasBaibaiBook() === false, 'A5 host hooks stay native');
  const built = await bootstrapWorld();
  assert(built.ok === true && built.created === true && built.evolved === false, 'A1 one build, no evolve');
  const bootCalls = host.state.fixtureCalls.filter((call) => call.purpose === 'bootstrap');
  const evolveCalls = host.state.fixtureCalls.filter((call) => call.purpose === 'evolve');
  assert(bootCalls.length === 1 && evolveCalls.length === 0, 'A1 a single bootstrap call');
  assert(!String(bootCalls[0].prompt).includes('旧史') && !String(bootCalls[0].prompt).includes('三年前'), 'A5 prompt ignores the book');
  assert(!String(bootCalls[0].prompt).includes(DECOY_REGION) && !String(bootCalls[0].prompt).includes('"hp"'), 'A5 prompt ignores the decoy and MVU');
  const world = loadWorld();
  assert(world.plugin.enabled === true, 'A1 enabled');
  assert(countEntities(world) >= 1, 'A1 at least one entity');
  assert(names(world.regions).includes(NATIVE_REGION), 'A1 region');
  assert(names(world.orgs).includes(NATIVE_ORG), 'A1 org');
  assert(world.events.some((event) => event.kind === 'macro' && event.title === NATIVE_MACRO), 'A1 macro event');
  assert(world.meta.sources.memory === 'native' && world.meta.sources.mvu === false, 'A5 source flags');
  assert(world.evolutionLog.length === 0, 'A1 build does not append');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(freshMes), 'A1 does not rewrite the new chat');
  assert(floorHash(host.state.chat) === freshHash, 'A1 floor hash');
  assert(host.state.chatMetadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'A1 ledger is on chatMetadata.shiju');
  assert(host.state.localVault.shiju.regions[0].name === DECOY_REGION, 'decoy vault stays aside');
  assert(!names(world.regions).includes(DECOY_REGION), 'A1 does not read the decoy');
  const regionPage = renderPage({ page: 'world', theme: 'st', world, worldKind: 'region' });
  const orgPage = renderPage({ page: 'world', theme: 'st', world, worldKind: 'org' });
  const eventPage = renderPage({ page: 'events', theme: 'st', world, eventFilter: 'macro' });
  assert(regionPage.includes(NATIVE_REGION) && orgPage.includes(NATIVE_ORG), 'A1 panel lists entities');
  assert(eventPage.includes(NATIVE_MACRO) && !eventPage.includes(NATIVE_SECRET_BODY), 'A1 macro event is listed without the secret body');

  host.eventSource.emit(host.event_types.GENERATION_STARTED);
  const macro = String(host.state.prompts.shiju_macro?.value || '');
  assert(macro.includes(MACRO_DISCLAIMER), 'A2 disclaimer');
  assert(macro.includes(NATIVE_MACRO), 'A2 macro is injected');
  assert(macro.includes(`发生于远方。${NATIVE_NEWS}`), 'A2 far news carries the marker');
  assert(!macro.includes(NATIVE_SECRET) && !macro.includes(NATIVE_SECRET_BODY), 'A2 unrevealed secret stays out');
  assert(!macro.includes('必须前往') && !macro.includes('必须介入'), 'A2 does not force the protagonist');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(freshMes), 'A2 does not rewrite floors');

  host.state.chat = nativeOldFloors();
  host.state.chatMetadata = {};
  host.state.chatId = 'native-old';
  host.state.prompts = {};
  host.state.fixtureCalls = [];
  const oldMes = mesOf(host);
  const oldHash = floorHash(host.state.chat);
  const oldPack = await readSourcePack();
  assert(oldPack.baibai === undefined && oldPack.mvu === undefined, 'A3 pack stays native');
  const resumedBuild = await bootstrapWorld();
  assert(resumedBuild.created === true && resumedBuild.evolved === false, 'A3 old chat builds once');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(oldMes), 'A3 historical floors stay');
  assert(floorHash(host.state.chat) === oldHash, 'A3 floor hash');
  assert(host.state.chat[0].mes.includes('甲楼原文') && host.state.chat[1].mes.includes('乙楼原文'), 'A3 original sentences');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length === 0, 'A3 does not evolve');
  const caught = loadWorld();
  assert(names(caught.regions).includes(NATIVE_REGION), 'A3 still has the entity');
  assert(caught.meta.sources.memory === 'native' && caught.meta.sources.mvu === false, 'A3 flags stay native');

  const snapshot = {
    regions: names(caught.regions),
    orgs: names(caught.orgs),
    log: caught.evolutionLog.length,
  };
  const frozenMes = mesOf(host);
  const frozenHash = floorHash(host.state.chat);
  await freezeWorld();
  const frozen = loadWorld();
  assert(frozen.plugin.enabled === false && typeof frozen.plugin.frozenAt === 'number', 'A4 close freezes the ledger');
  assert(host.state.chatMetadata.shiju.plugin.enabled === false, 'A4 freeze is on chatMetadata.shiju');
  assert(host.state.prompts.shiju_macro?.value === '' && host.state.prompts.shiju_timetag?.value === '', 'A4 close clears injection');
  assert(floorHash(host.state.chat) === frozenHash, 'A4 close keeps the floor hash');
  host.state.chat.push(nativeLaterFloor());
  const during = host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length;
  const held = await runAutomaticGate();
  assert(held.evolved === false, 'A4 no evolution while closed');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length === during, 'A4 close makes no evolve call');
  assert(mesOf(host).slice(0, frozenMes.length).join('\n') === frozenMes.join('\n'), 'A4 historical floors survive the extra floor');
  const reopened = await reopenWorld();
  assert(reopened.evolved === false, 'A4 reopen does not backfill');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length === during, 'A4 reopen makes no evolve call');
  const resumed = loadWorld();
  assert(resumed.plugin.enabled === true && resumed.plugin.frozenAt == null, 'A4 state restored');
  assert(JSON.stringify(names(resumed.regions)) === JSON.stringify(snapshot.regions), 'A4 regions restored');
  assert(JSON.stringify(names(resumed.orgs)) === JSON.stringify(snapshot.orgs), 'A4 orgs restored');
  assert(resumed.evolutionLog.length === snapshot.log, 'A4 log length restored');
  assert(mesOf(host).slice(0, frozenMes.length).join('\n') === frozenMes.join('\n'), 'A4 floor hash prefix');
  assert(floorHash(host.state.chat.slice(0, frozenMes.length)) === frozenHash, 'A4 original floor hash');
  assert(host.state.chatMetadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'A4 ledger still on chatMetadata.shiju');
  assert(loadWorld().regions.some((item) => item.name === NATIVE_REGION), 'A4 loadWorld reads the chat');
  assert(!names(loadWorld().regions).includes(DECOY_REGION), 'A4 still ignores the decoy');

  saveSettings({ ui: { theme: 'night' } });
  assert(host.getExtensionSettings().shiju.ui.theme === 'night', 'A24 settings live on extension_settings.shiju');
  const exported = JSON.parse(JSON.stringify(exportChatFile(host)));
  assert(exported[0].chatMetadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'A24 export includes chatMetadata.shiju');
  assert(exported[0].chat_metadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'A24 export also keeps the on-disk chat_metadata');
  assert(JSON.stringify(exported[0].chatMetadata.shiju) === JSON.stringify(exported[0].chat_metadata.shiju), 'A24 the two keys match');
  assert(exported.slice(1).some((message) => String(message.mes).includes('甲楼原文')), 'A24 export keeps the floors');
  assert(!JSON.stringify(exported).includes(DECOY_REGION), 'A24 export does not take the decoy');
  assert(!JSON.stringify(exported[0].chatMetadata.shiju).includes('"theme"'), 'A24 settings are not stuffed into the ledger');

  const stOnly = JSON.parse(JSON.stringify(exported));
  delete stOnly[0].chatMetadata;
  const stHost = createMemoryHost({ chatMetadata: {} });
  setHost(stHost);
  openChatFile(stHost, stOnly);
  assert(loadWorld().regions.some((item) => item.name === NATIVE_REGION), 'A24 opening a chat_metadata file restores the ledger');

  const packed = uninstallKeepingChat(host);
  assert(host.state.chatMetadata.shiju === undefined, 'uninstall drops the in-memory ledger');
  assert(typeof host.generateViaBackend !== 'function', 'uninstall drops the extension backend');
  assert(packed.chatFile[0].chatMetadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'uninstalled chat file still has the ledger');
  assert(packed.settings.shiju.ui.theme === 'night', 'uninstalled settings bag still has the theme');
  const next = reinstallNativeHost(packed.chatFile, packed.settings);
  setHost(next);
  ensureSettings();
  bindModules();
  const restored = loadWorld();
  assert(restored.regions.some((item) => item.name === NATIVE_REGION), 'A24 reinstall resumes the same chat');
  assert(!names(restored.regions).includes(DECOY_REGION), 'A24 reinstall does not read the decoy');
  assert(next.state.localVault.shiju.regions[0].name === DECOY_REGION, 'A24 decoy is present and unused');
  assert(loadSettings().ui.theme === 'night', 'A24 settings survived on extension_settings.shiju');
  assert(next.getExtensionSettings().shiju.ui.theme === 'night', 'A24 settings bag is the one loadSettings reads');
  const beforeResume = next.state.fixtureCalls.length;
  const again = await bootstrapWorld();
  assert(again.created === false && again.evolved === false, 'A24 resume does not rebuild');
  assert(next.state.fixtureCalls.length === beforeResume, 'A24 resume makes no model call');
  assert(floorHash(next.state.chat.slice(0, frozenMes.length)) === frozenHash, 'A24 reopened floors match');

  const otherFile = [{
    user_name: '你',
    character_name: '对方',
    chat_id: 'other-chat',
    chat_metadata: {},
    chatMetadata: {},
  }, { mes: '另一则聊天', is_user: true, swipe_id: 0 }];
  const other = reinstallNativeHost(otherFile, packed.settings);
  setHost(other);
  ensureSettings();
  assert(loadWorld() === null, 'A24 another chat does not inherit the ledger');
  assert(loadSettings().ui.theme === 'night', 'A24 settings still apply on the other chat');
  assert(other.state.chatId === 'other-chat', 'A24 the other chat is a different file');
}
