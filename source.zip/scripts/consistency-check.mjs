import { strict as nodeAssert } from 'node:assert';
import { performance } from 'node:perf_hooks';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { captureChatScope } from '../src/chatScope.js';
import { createEmptyWorld, loadWorld, saveWorld } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { runAutomaticGate, runImmediateEvolution, rerunLastEvolution, clearEvolutionHold } from '../src/modules/timeGate/index.js';
import { isWorldBusy } from '../src/modules/turn.js';
import { saveFactManual, applyAiCorrection, setFactVisibility } from '../src/modules/intervene/index.js';
import { captureInputBoundary, ensureInputBoundary, readIncrement } from '../src/modules/incremental.js';
import { applyEvolutionPatch } from '../src/modules/evolve/patch.js';
import { runEvolutionOnce } from '../src/modules/evolve/index.js';
import { isKnown, isFactVisible } from '../src/modules/events.js';
import { refreshInject } from '../src/modules/inject/index.js';
import { interpretStoryTime } from '../src/modules/timetag/read.js';
import { correctStoryDay, freezeWorld, reopenWorld } from '../src/modules/lifecycle/index.js';
import { minSubset, applySubset } from '../src/modules/commit/subset.js';
import { rotationPool } from '../src/modules/worldbook/select.js';
import { renderPage } from '../src/ui/pages.js';
import { reconcileOnChatMutation } from '../src/modules/reconcile/index.js';

const msg = (body, day = 1) => ({ mes: `${body}<shiju_end>2026/1/${day}</shiju_end>`, swipe_id: 0 });
const deferred = () => { let resolve; const promise = new Promise((r) => { resolve = r; }); return { promise, resolve }; };
const boot = { regions: [{ name: '江左' }], events: [
  { id: 'e', kind: 'macro', title: '税制调整', body: '原有税率' },
  { id: 's', kind: 'secret', title: '皇帝是幕后凶手', body: '密谋正文' },
] };
async function fresh() {
  const host = createMemoryHost({ chat: [msg('旧剧情')], settings: { timeSource: { mode: 'shiju' } } });
  const calls = [];
  host.generateViaBackend = async (request) => { calls.push(request); return JSON.stringify(request.purpose === 'bootstrap' ? boot : { todayChanges: [] }); };
  setHost(host);
  clearEvolutionHold();
  await bootstrapWorld();
  return { host, calls };
}

export async function runConsistencyChecks() {
  let checks = 0;
  const assert = (condition, message) => { checks++; nodeAssert.ok(condition, message); };
  const refused = async (promise, code, label) => {
    let error;
    try { await promise; } catch (caught) { error = caught; }
    assert(error?.code === code, label);
  };

  // The actual public gate holds a lock before reading sources through persistence.
  for (const failed of [false, true]) {
    const { host } = await fresh();
    host.state.chat.push(msg('新增情节', 2));
    const started = deferred(), response = deferred();
    host.generateViaBackend = () => { started.resolve(); return response.promise; };
    const operation = runAutomaticGate();
    assert(isWorldBusy(), 'queued automatic work already blocks editing');
    await started.promise;
    const before = JSON.stringify(loadWorld());
    await refused(saveFactManual({ kind: 'event', id: 'e', patch: { body: '覆盖' } }), 'SHIJU_WORLD_BUSY', 'manual writer refuses during automatic evolution');
    await refused(applyAiCorrection({ kind: 'event', id: 'e', text: '覆盖' }), 'SHIJU_WORLD_BUSY', 'AI adoption refuses during automatic evolution');
    await refused(setFactVisibility({ kind: 'event', id: 's', action: 'knowledge', value: 'known' }), 'SHIJU_WORLD_BUSY', 'knowledge writes refuse during evolution');
    assert(JSON.stringify(loadWorld()) === before, 'refused writers do not touch the ledger');
    response.resolve(failed ? 'invalid' : '{"todayChanges":[]}');
    await operation;
    assert(!isWorldBusy(), 'success and failure both release the lock');
    await saveFactManual({ kind: 'event', id: 'e', patch: { body: '完成后修改' } });
    assert(loadWorld().events[0].body === '完成后修改', 'editing resumes after completion');
  }
  {
    const { host } = await fresh();
    const originalContext = host.getContext;
    const started = deferred(), persisted = deferred();
    host.getContext = () => ({ ...originalContext(), saveMetadata: () => { started.resolve(); return persisted.promise; } });
    const edit = saveFactManual({ kind: 'event', id: 'e', patch: { body: '排队之前的用户修正' } });
    await started.promise;
    host.state.chat.push(msg('排队的新剧情'));
    let prompt;
    host.generateViaBackend = async (request) => { prompt = request.prompt; return '{}'; };
    const evolution = runImmediateEvolution();
    assert(isWorldBusy() && !prompt, 'evolution waits for earlier manual persistence');
    persisted.resolve();
    await edit; await evolution;
    assert(prompt.includes('排队之前的用户修正') && loadWorld().events[0].body === '排队之前的用户修正', 'shared writer queue preserves earlier manual correction');
  }
  {
    const { host } = await fresh();
    host.state.chat.push(msg('待对齐的剧情', 2));
    const started = deferred(), response = deferred();
    host.generateViaBackend = () => { started.resolve(); return response.promise; };
    const alignment = correctStoryDay({ choice: 'realign' }); await started.promise;
    await refused(saveFactManual({ kind: 'event', id: 'e', patch: { body: '覆盖' } }), 'SHIJU_WORLD_BUSY', 'realignment also locks manual writes');
    host.state.chat.push(msg('模型等待期间新增的正文', 3));
    response.resolve('{}'); await alignment;
    assert(readIncrement(loadWorld(), host.state.chat).text.includes('模型等待期间新增的正文'), 'realignment does not consume text arriving during model wait');
  }
  {
    const { host, calls } = await fresh();
    host.state.chat.push(msg('第二日剧情', 2)); await runAutomaticGate();
    const ledger = loadWorld();
    host.state.chat[1].mes = '矛盾<shiju_start>2026/1/9</shiju_start><shiju_end>2026/1/2</shiju_end>';
    const conflict = await reconcileOnChatMutation({ cause: 'edit' });
    assert(conflict.reason === 'conflict' && conflict.dropped === 0, 'date contradictions stop before anchor rollback');
    assert(JSON.stringify(loadWorld().evolutionLog) === JSON.stringify(ledger.evolutionLog) && JSON.stringify(loadWorld().events) === JSON.stringify(ledger.events), 'contradictory dates preserve ledger and anchors');
    host.state.chat[1] = msg('第二日剧情', 2);
    await reconcileOnChatMutation({ cause: 'edit' });
    assert(!loadWorld().meta.clockHint && !loadWorld().meta.inputHint && calls.length === 2, 'restoring the original prose and date resumes without replay or date warning');
    host.state.chat.push(msg('第三日剧情', 3));
    assert((await runAutomaticGate()).evolved, 'automatic evolution resumes after date correction');
  }
  {
    const { host } = await fresh();
    const scope = captureChatScope();
    host.state.chat.push(msg('新增')); const response = deferred(), started = deferred();
    host.generateViaBackend = () => { started.resolve(); return response.promise; };
    const pending = runImmediateEvolution(); await started.promise;
    host.state.chatId = 'B'; host.state.chatMetadata = { shiju: structuredClone(loadWorld()) };
    host.eventSource.emit(host.event_types.CHAT_CHANGED);
    assert(!isWorldBusy(), 'old chat operation does not lock the new chat');
    await refused(saveFactManual({ chatScope: scope, kind: 'event', id: 'e', patch: { body: 'A稿件' } }), 'SHIJU_CHAT_CHANGED', 'same-ID manual draft is bound to originating chat');
    await refused(applyAiCorrection({ chatScope: scope, kind: 'event', id: 'e', text: 'A稿件' }), 'SHIJU_CHAT_CHANGED', 'same-ID AI draft is bound to originating chat');
    await saveFactManual({ kind: 'event', id: 'e', patch: { body: 'B自己的修正' } });
    assert(loadWorld().events[0].body === 'B自己的修正', 'new chat can save before the old chat model returns');
    response.resolve('{"todayChanges":[]}');
    assert((await pending).reason === 'chat-changed', 'old operation cancels');
    assert(loadWorld().events[0].body === 'B自己的修正', 'B retains its fact');
    host.state.chatId = 'preview'; host.eventSource.emit(host.event_types.CHAT_CHANGED);
    await refused(applyAiCorrection({ chatScope: scope, kind: 'event', id: 'e', text: 'A旧稿件' }), 'SHIJU_CHAT_CHANGED', 'returning to A does not revive stale editor scope');
  }
  {
    const { host, calls } = await fresh();
    host.state.chat.push(msg('产生上次演进'));
    await runImmediateEvolution();
    await saveFactManual({ kind: 'event', id: 'e', patch: { body: '重跑前刚作出的修正' } });
    await setFactVisibility({ kind: 'event', id: 's', action: 'knowledge', value: 'known' });
    await rerunLastEvolution();
    assert(calls.at(-1).prompt.includes('重跑前刚作出的修正'), 'rerun receives current pending corrections separately from historical input');
    assert(isKnown(loadWorld().events.find((item) => item.id === 's')), 'rerun retains manual knowledge override made after checkpoint');
  }
  {
    const { host, calls } = await fresh();
    assert((await runImmediateEvolution()).reason === 'no-increment' && calls.length === 1, 'bootstrap establishes a consumed baseline');
    host.state.chat[0].mes += '只追加这一段';
    assert((await runImmediateEvolution()).evolved, 'tip continuation is new input');
    const incremental = calls.at(-1).prompt.split('本轮待处理新增正文（只处理这一窗口）：')[1];
    assert(incremental.includes('只追加这一段') && !incremental.includes('旧剧情'), 'continuation includes only appended suffix');
    assert((await runImmediateEvolution()).reason === 'no-increment' && calls.length === 2, 'repeat immediate does not repeat input or call');
    host.state.chat.push(msg('下一楼'));
    assert((await runImmediateEvolution()).evolved, 'new same-day floor evolves once');
    host.state.chat[0].mes = host.state.chat[0].mes.replace('旧剧情', '被改写的旧剧情');
    assert((await runImmediateEvolution()).reason === 'history-changed', 'nonappend historical edit is not treated as new input');
    await correctStoryDay({ choice: 'keep' });
    assert((await runImmediateEvolution()).reason === 'no-increment', 'explicit keep establishes a new baseline without replay');
    const old = loadWorld().processedInput;
    host.state.chat.push(msg('失败后重试'));
    host.generateViaBackend = async () => 'invalid';
    assert(!(await runImmediateEvolution()).ok, 'failure is reported');
    assert(JSON.stringify(loadWorld().processedInput) === JSON.stringify(old), 'failed call does not consume input');
    host.generateViaBackend = async () => '{"todayChanges":[]}';
    assert((await runImmediateEvolution()).evolved, 'failed input can be retried');
    await freezeWorld(); host.state.chat.push(msg('关闭期间的正文', 8)); await reopenWorld();
    assert((await runImmediateEvolution()).reason === 'no-increment', 'reopen consumes frozen gap without backfill');
  }
  {
    const { host, calls } = await fresh();
    const w = loadWorld();
    w.todayChanges = [{ id: 'c', kind: 'macro', title: '边境局势', body: '旧事实' }];
    w.regions[0].summary = '背景'.repeat(5000);
    await saveWorld(w);
    await saveFactManual({ kind: 'todayChange', id: 'c', patch: { body: '双方已经永久缔结停战条约' } });
    assert((await runImmediateEvolution()).evolved, 'unconsumed correction is an increment');
    assert(calls.at(-1).prompt.includes('双方已经永久缔结停战条约'), 'today correction survives summary truncation and reaches model');
    assert(loadWorld().userCorrections[0].consumed, 'successful evolution consumes correction');
    assert((await runImmediateEvolution()).reason === 'no-increment', 'correction is processed once');
    await applyAiCorrection({ kind: 'event', id: 'e', text: 'AI采用的新事实' });
    assert(loadWorld().userCorrections.some((item) => item.body === 'AI采用的新事实' && !item.consumed), 'adopted AI correction is also an increment');
    await saveFactManual({ kind: 'event', id: 'e', patch: { body: '再次修正' } });
    assert(loadWorld().userCorrections.filter((item) => item.id === 'e').length === 1, 'corrections replace prior revisions of the same target');
    host.state.chat.push(msg('剧情继续'));
  }
  {
    const { host } = await fresh();
    const w = loadWorld(); w.todayChanges = [{ id: 'c', kind: 'secret', linkedEventId: 's', title: '关联隐秘', body: '秘密细节' }]; await saveWorld(w);
    let html = renderPage({ page: 'events', world: loadWorld() });
    assert(!html.includes('皇帝是幕后凶手') && !html.includes('密谋正文') && html.includes('未揭晓的隐秘'), 'hidden title and body are absent from rendered markup');
    await setFactVisibility({ kind: 'todayChange', id: 'c', action: 'view' });
    assert(isFactVisible(loadWorld().events[1]) && !isKnown(loadWorld().events[1]), 'viewing linked change reveals reader content without protagonist knowledge');
    assert(!refreshInject().text.includes('皇帝是幕后凶手'), 'view-only secret is not injected');
    const known = { knowledge: [{ kind: 'event', id: 's', known: true, evidenceQuote: '主角读到了皇帝策划谋杀的密信' }] };
    let next = loadWorld();
    applyEvolutionPatch(next, known, { evidenceText: '无关剧情' });
    assert(!isKnown(next.events[1]), 'unsupported model evidence does not reveal secret');
    applyEvolutionPatch(next, known, { evidenceText: '主角读到了皇帝策划谋杀的密信' });
    await saveWorld(next);
    assert(isKnown(loadWorld().events[1]) && isKnown(loadWorld().todayChanges[0]), 'supported evidence shares knowledge with linked change');
    assert(refreshInject().text.includes('皇帝是幕后凶手'), 'known secret enters injection');
    await setFactVisibility({ kind: 'event', id: 's', action: 'knowledge', value: 'unknown' });
    next = loadWorld(); applyEvolutionPatch(next, known, { evidenceText: '主角读到了皇帝策划谋杀的密信' }); await saveWorld(next);
    assert(!isKnown(loadWorld().events[1]) && !refreshInject().text.includes('皇帝是幕后凶手'), 'manual unknown wins over automatic model knowledge');
    await setFactVisibility({ kind: 'event', id: 's', action: 'knowledge', value: 'auto' });
    assert(isKnown(loadWorld().events[1]), 'auto restores accumulated evidence');
    await setFactVisibility({ kind: 'event', id: 's', action: 'hide' });
    assert(!isFactVisible(loadWorld().events[1]) && isKnown(loadWorld().events[1]), 'hiding reader content does not erase protagonist knowledge');
    // Real pipeline must exclude worldbook text from accepted evidence.
    host.state.worldInfoEntries = [{ constant: true, content: '世界书独有的秘密证据', comment: '设定' }];
    host.state.chat.push(msg('主角没有获知新秘密'));
    host.generateViaBackend = async () => JSON.stringify({ events: [{ id: 'new-secret', title: '新秘密', kind: 'secret', body: '隐藏' }], knowledge: [{ kind: 'event', id: 'new-secret', known: true, evidenceQuote: '世界书独有的秘密证据' }] });
    await runImmediateEvolution();
    assert(!isKnown(loadWorld().events.find((item) => item.id === 'new-secret')), 'worldbook-only evidence cannot unlock a secret through the actual gate');
  }
  {
    const { host } = await fresh(); let w = loadWorld();
    w.events = Array.from({ length: 45 }, (_, i) => ({ id: `e${i}`, kind: 'macro', title: `事态${i}`, body: `原文${i}`, phase: '发展' }));
    applyEvolutionPatch(w, { events: [{ id: 'new', kind: 'macro', title: '新战争', body: '战事' }] });
    assert(w.events.length === 46 && w.events.some((item) => item.id === 'new'), 'more than 40 events never drops a new event');
    w.events[0].body = '完整历史'.repeat(300);
    applyEvolutionPatch(w, { events: [{ id: 'e0', lifecycle: 'archived', outcome: '边境已经重新划定' }, { id: 'e1', lifecycle: 'archived', outcome: '合并重复线索', mergedInto: 'new' }] });
    assert(w.events[0].body === '完整历史'.repeat(300) && w.facts.some((item) => item.text === '边境已经重新划定'), 'archival preserves full prose and persistent consequences');
    assert(w.events[1].mergedInto === 'new', 'merge retains the original-to-survivor relationship');
    assert(!rotationPool(w).includes('事态0'), 'archives leave focus rotation');
    await saveWorld(w);
    assert(!refreshInject().text.includes('事态0'), 'archives leave daily injection');
    let prompt;
    host.generateViaBackend = async (request) => { prompt = request.prompt; return '{}'; };
    await runEvolutionOnce({ world: w, purpose: 'immediate', incrementText: '新增正文' });
    assert(!prompt.includes('完整历史') && prompt.includes('边境已经重新划定') && prompt.includes('"id":"e0"'), 'archive detail stays out of model context while consequence and ID persist');
    const normal = renderPage({ page: 'events', world: w });
    const archived = renderPage({ page: 'events', world: w, archiveOpen: true, openDetails: {'event:e0':true} });
    assert(!normal.includes('完整历史') && archived.includes('完整历史'), 'archive is available only in the archive view');
    applyEvolutionPatch(w, { events: [{ title: '事态0', lifecycle: 'active', body: '重新发展' }] });
    assert(w.events.length === 46 && w.events[0].id === 'e0' && w.events[0].lifecycle === 'active', 'reactivation reuses original ID');
    const snapshot = minSubset(w); const restored = createEmptyWorld(); applySubset(restored, JSON.parse(JSON.stringify(snapshot)));
    assert(JSON.stringify(restored.events) === JSON.stringify(w.events), 'archive and knowledge fields survive snapshots');
    assert(JSON.stringify(restored.processedInput) === JSON.stringify(w.processedInput), 'increment boundary survives snapshots');
    const duplicateNames = createEmptyWorld();
    duplicateNames.events = [{ id: 'first', title: '同名事件', body: '第一条' }, { id: 'second', title: '同名事件', body: '第二条' }];
    applyEvolutionPatch(duplicateNames, { events: [{ id: 'second', title: '同名事件', body: '更新第二条' }] });
    assert(duplicateNames.events[0].body === '第一条' && duplicateNames.events[1].body === '更新第二条', 'exact ID takes priority over an earlier same-title event');
  }
  {
    const { host } = await fresh();
    const legacy = loadWorld(); delete legacy.processedInput;
    host.state.chat.push(msg('新剧情'));
    ensureInputBoundary(legacy, host.state.chat, 'shiju', '');
    assert(readIncrement(legacy, host.state.chat).text.includes('新剧情'), 'legacy ledger recovers bootstrap anchor and keeps subsequent increment');
    delete legacy.processedInput; delete legacy.meta.initialSnapshot; legacy.evolutionLog = [];
    ensureInputBoundary(legacy, host.state.chat, 'shiju', '');
    assert(!readIncrement(legacy, host.state.chat).items.length && legacy.meta.inputHint === 'baseline-established', 'unanchored legacy ledger safely establishes a baseline with notice');
    const clock = loadWorld();
    const contradictory = [msg('旧剧情'), msg('中间日期', 9), msg('末楼', 2)];
    assert(interpretStoryTime(clock, contradictory, 'shiju', '').status === 'conflict', 'initialized clock checks intermediate date order');
    contradictory[1] = msg('改回日期', 1);
    assert(interpretStoryTime(clock, contradictory, 'shiju', '').status === 'advance', 'fixing dates restores advancement');
    const timings = [];
    for (const size of [1000, 10000]) {
      const chat = Array.from({ length: size }, () => msg('普通正文'));
      const start = performance.now();
      const result = interpretStoryTime(clock, chat, 'shiju', '');
      timings.push(`${size} floors: ${(performance.now() - start).toFixed(1)}ms`);
      assert(result.status === 'same', 'long same-day history remains valid');
      const boundary = captureInputBoundary(chat);
      assert(!readIncrement({ processedInput: boundary }, chat).changed, 'long-history boundary is stable');
    }
    console.log(`shiju date parsing: ${timings.join(', ')}`);
  }
  return checks;
}
