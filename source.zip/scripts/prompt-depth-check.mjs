import { strict as nodeAssert } from 'node:assert';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { createEmptyWorld, saveSettings } from '../src/store/index.js';
import { clearInject, refreshInject } from '../src/modules/inject/index.js';
import { refreshTimeTag } from '../src/modules/timetag/index.js';

// Small host contract fixture, not a full SillyTavern request builder.
// Mirrors populationInjectionPrompts: only IN_CHAT participates, depth counts
// original messages from the end, and splice clamps beyond a short history.
// https://github.com/SillyTavern/SillyTavern/blob/release/public/scripts/openai.js
function assembleHistory(chat, prompts) {
  const messages = chat.map((message) => message.mes).reverse();
  const injections = Object.entries(prompts)
    .filter(([, prompt]) => prompt.position === 1 && prompt.value)
    .sort((a, b) => a[1].depth - b[1].depth);
  let inserted = 0;
  for (const [key, prompt] of injections) {
    messages.splice(prompt.depth + inserted, 0, key);
    inserted += 1;
  }
  return messages.reverse();
}

export function runPromptDepthChecks() {
  let checks = 0;
  const assert = (condition, message) => { checks += 1; nodeAssert.ok(condition, message); };
  for (const route of ['host', 'context', 'context-without-enums']) {
    const world = createEmptyWorld();
    world.plugin.enabled = true;
    world.meta.builtFingerprint = 'prompt-depth';
    world.events = [{ id: 'drought', kind: 'macro', title: '江左大旱', body: '河水见底', revealed: true }];
    const host = createMemoryHost({ chatMetadata: { shiju: world } });
    if (route !== 'host') delete host.setExtensionPrompt;
    if (route === 'context-without-enums') {
      delete host.extension_prompt_types;
      delete host.extension_prompt_roles;
    }
    setHost(host);
    saveSettings({ timeSource: { mode: 'shiju' } });
    const beforeWorld = JSON.stringify(host.state.chatMetadata);
    refreshInject();
    refreshTimeTag();
    const { shiju_macro: macro, shiju_timetag: tag } = host.state.prompts;
    assert(macro.position === 1 && macro.depth === 4 && macro.value.includes('江左大旱'), `${route}: macro uses IN_CHAT depth 4`);
    assert(tag.position === 1 && tag.depth === 0 && tag.value.includes('shiju_end'), `${route}: time tag uses IN_CHAT depth 0`);
    assert(macro.role === 0 && tag.role === 0 && macro.scan === false && tag.scan === false, `${route}: system role and scan flag are preserved`);

    for (const count of [6, 2, 0]) {
      host.state.chat = Array.from({ length: count }, (_, i) => ({ mes: `message-${i}` }));
      const original = JSON.stringify(host.state.chat);
      const expected = host.state.chat.map((message) => message.mes);
      expected.splice(Math.max(0, count - 4), 0, 'shiju_macro');
      expected.push('shiju_timetag');
      const ordered = assembleHistory(host.state.chat, host.state.prompts);
      assert(JSON.stringify(ordered) === JSON.stringify(expected), `${route}: both injections are placed correctly with ${count} messages`);
      assert(JSON.stringify(host.state.chat) === original, `${route}: assembling leaves ${count} stored messages intact`);
    }
    const legacy = { ...host.state.prompts, shiju_macro: { ...macro, position: 0 } };
    assert(!assembleHistory(host.state.chat, legacy).includes('shiju_macro'), `${route}: old IN_PROMPT configuration cannot pass depth placement`);
    assert(JSON.stringify(host.state.chatMetadata) === beforeWorld && host.state.savedMetadata === 0, `${route}: injection does not save or alter the world`);

    clearInject();
    assert(host.state.prompts.shiju_macro.value === '' && host.state.prompts.shiju_macro.position === 1, `${route}: macro clears through the same position`);
    assert(host.state.prompts.shiju_timetag === tag, `${route}: clearing macro leaves time tag alone`);
    saveSettings({ inject: { enabled: false }, timeSource: { mode: 'custom', customTag: 'clock' } });
    refreshTimeTag();
    assert(host.state.prompts.shiju_timetag.value === '' && host.state.prompts.shiju_timetag.position === 1, `${route}: time tag clears through the same position`);
    assert(assembleHistory(host.state.chat, host.state.prompts).length === 0, `${route}: cleared injections are absent`);
  }
  return checks;
}
