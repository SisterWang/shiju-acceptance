import { strict as nodeAssert } from 'node:assert';
import { cp, mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

/** Run the actual extension entry in a temporary SillyTavern directory layout. */
export async function runEntryWorldbookChecks() {
  const savedFetch = globalThis.fetch;
  let checks = 0;
  const assert = (condition, message) => { checks += 1; nodeAssert.ok(condition, message); };
  const root = fileURLToPath(new URL('..', import.meta.url));
  const fixture = await mkdtemp(join(tmpdir(), 'shiju-entry-worldbook-'));
  const scripts = join(fixture, 'public/scripts');
  const extension = join(scripts, 'extensions/third-party/shiju');
  const load = (path) => import(pathToFileURL(path).href);
  try {
    await mkdir(extension, { recursive: true });
    await cp(join(root, 'src'), join(extension, 'src'), { recursive: true });
    await cp(join(root, 'index.js'), join(extension, 'index.js'));
    await writeFile(join(fixture, 'package.json'), '{"type":"module"}');
    await writeFile(join(scripts, 'extensions.js'), `
      import { createMemoryHost } from './extensions/third-party/shiju/src/host/memory.js';
      export const memory = createMemoryHost();
      export const context = {};
      export const extension_settings = memory.state.extensionSettings;
      export const getContext = () => ({ ...memory.getContext(), ...context });
    `);
    await writeFile(join(fixture, 'public/script.js'), `
      import { memory } from './scripts/extensions.js';
      export const CLIENT_VERSION = 'SillyTavern:1.17.0:test';
      export const amount_gen = 128;
      export const eventSource = memory.eventSource;
      export const event_types = memory.event_types;
      export const extension_prompt_types = memory.extension_prompt_types;
      export const extension_prompt_roles = memory.extension_prompt_roles;
      export const saveSettingsDebounced = memory.saveSettingsDebounced;
    `);
    // Official API contract: loadWorldInfo(name), selected_world_info, world_names.
    // Deliberately do not supply the nonexistent getWorldInfo alias.
    await writeFile(join(scripts, 'world-info.js'), `
      export const books = {};
      export const world_info = { charLore: [] };
      export const METADATA_KEY = 'world_info';
      export const selected_world_info = [];
      export const world_names = [];
      export const calls = [];
      export async function loadWorldInfo(name) {
        calls.push(name);
        return books[name] ?? null;
      }
    `);
    const st = await load(join(scripts, 'extensions.js'));
    const wi = await load(join(scripts, 'world-info.js'));
    st.context.characterId = 0;
    const character = { data: { extensions: { world: '角色书' } } };
    st.context.characters = [character];
    wi.selected_world_info.push('全局书', '角色书');
    wi.world_names.push('角色书', '全局书', '未选择的书');
    wi.books['角色书'] = { uid: 'role-book', entries: {
      0: { comment: '角色蓝灯', constant: true, content: 'CHARACTER_BODY' },
      1: { comment: '禁用条目', constant: true, content: 'DISABLED_BODY', disable: true },
    } };
    wi.books['全局书'] = { entries: {
      0: { comment: '全局蓝灯', constant: true, content: 'GLOBAL_BODY' },
      1: { comment: '地区绿灯', key: ['江左'], content: 'GREEN_BODY' },
    } };
    wi.books['未选择的书'] = { entries: { 0: { comment: '不应加载', constant: true, content: 'UNSELECTED_BODY' } } };
    const modelCalls = [];
    st.context.mainApi = 'openai';
    st.context.chatCompletionSettings = {chat_completion_source:'openai',openai_model:'test-model',openai_max_tokens:1024};
    st.context.getRequestHeaders = () => ({'Content-Type':'application/json'});
    st.context.generateRaw = () => { throw new Error('generateRaw must not run'); };
    globalThis.fetch = async (path, options) => {
      assert(path === '/api/backends/chat-completions/generate', 'entry only uses same-origin generation backend');
      const request = JSON.parse(options.body);
      assert(Array.isArray(request.messages) && request.messages[0].role === 'system', 'entry passes ordered messages independently');
      assert(!('systemPrompt' in request), 'no duplicate system prompt');
      modelCalls.push({...request,prompt:request.messages.map(m=>m.content).join('\n')});
      return {ok:true,json:async()=>({choices:[{message:{content:JSON.stringify({regions:[{name:'江左'}],todayChanges:[]})}}]})};
    };

    await load(join(extension, 'index.js'));
    const { getHost } = await load(join(extension, 'src/host.js'));
    const host = getHost();
    assert(host.extension_prompt_types === st.memory.extension_prompt_types, 'entry forwards official prompt position enums');
    assert(host.extension_prompt_roles === st.memory.extension_prompt_roles, 'entry forwards official prompt role enums');
    const read = await host.readWorldbook();
    assert(wi.calls.join(',') === '角色书,全局书', 'entry loads linked and selected books once via the official API');
    assert(read.entries.some((entry) => entry.content === 'CHARACTER_BODY'), 'linked book body is loaded');
    assert(read.entries.some((entry) => entry.content === 'GLOBAL_BODY'), 'selected global book body is loaded');
    assert(!read.entries.some((entry) => entry.content === 'DISABLED_BODY'), 'disabled entry stays excluded');
    assert(!read.entries.some((entry) => entry.content === 'UNSELECTED_BODY'), 'available but unselected book stays excluded');
    assert(read.catalog.some((book) => book.name === '角色书' && book.uid === 'role-book'), 'catalog retains book name and UID');
    assert(read.entries.find((entry) => entry.content === 'CHARACTER_BODY').bookUid === 'role-book', 'entries retain their book identity');
    assert(read.catalog.length === 2, 'catalog deduplicates linked and globally selected book');

    const { readSourcePack } = await load(join(extension, 'src/modules/source/index.js'));
    const pack = await readSourcePack();
    assert(pack.worldbook.entries.some((entry) => entry.title === '全局蓝灯' && entry.content === 'GLOBAL_BODY'), 'source normalization preserves external body');
    const { bootstrapWorld } = await load(join(extension, 'src/modules/bootstrap/index.js'));
    const { runImmediateEvolution } = await load(join(extension, 'src/modules/timeGate/index.js'));
    const { saveSettings } = await load(join(extension, 'src/store/index.js'));
    assert((await bootstrapWorld()).created, 'entry-backed bootstrap succeeds');
    assert(st.memory.state.prompts.shiju_macro.position === 1 && st.memory.state.prompts.shiju_macro.depth === 4, 'entry forwards macro as IN_CHAT at depth 4');
    assert(st.memory.state.prompts.shiju_timetag.position === 1 && st.memory.state.prompts.shiju_timetag.depth === 0, 'entry forwards time tag as IN_CHAT at depth 0');
    assert(modelCalls[0].prompt.includes('CHARACTER_BODY') && modelCalls[0].prompt.includes('GLOBAL_BODY'), 'bootstrap model receives external blue-light bodies');
    assert(!modelCalls[0].prompt.includes('GREEN_BODY'), 'bootstrap retains green-light selection rules');
    st.memory.state.chat.push({ mes: '新增剧情' });
    assert((await runImmediateEvolution()).evolved, 'entry-backed evolution succeeds');
    assert(modelCalls[1].prompt.includes('GLOBAL_BODY') && modelCalls[1].prompt.includes('GREEN_BODY'), 'evolution receives blue-light and focus-matched green-light bodies');
    saveSettings({ worldbook: { exclude: ['全局书'] } });
    st.memory.state.chat.push({ mes: '再一段新增剧情' });
    await runImmediateEvolution();
    assert(!modelCalls[2].prompt.includes('GLOBAL_BODY') && !modelCalls[2].prompt.includes('GREEN_BODY'), 'book-level exclusion still filters loaded bodies');

    // Keep the existing embedded-card fallback and tolerate a missing named book.
    character.data.character_book = { name: '内嵌书', entries: [{ name: '内嵌条目', content: 'EMBEDDED_BODY', constant: true }] };
    character.data.extensions.world = '不存在的书';
    wi.books['不存在的书'] = { entries: {} }; // Real ST returns a dummy for a missing file.
    wi.selected_world_info.length = 0;
    wi.calls.length = 0;
    const fallback = await host.readWorldbook();
    assert(wi.calls.join(',') === '不存在的书', 'empty global selection does not load all available books');
    assert(fallback.entries.length === 1 && fallback.entries[0].content === 'EMBEDDED_BODY', 'missing external book leaves embedded card data available');
    assert(fallback.catalog.some((book) => book.name === '内嵌书'), 'embedded book remains in the catalog');
    // Full host source inventory; this is the real extension entry, not a selector stub.
    character.avatar = '角色卡.png';
    character.data.extensions.world = '角色书';
    character.data.character_book = { name: '角色书', entries: [{ name: '过期内嵌', content: 'STALE_INLINE', constant: true }] };
    wi.world_info.charLore.push({ name: '角色卡', extraBooks: ['附加书', '角色书', '缺失书'] });
    st.context.chatMetadata = { ...st.memory.state.chatMetadata, world_info: '聊天书' };
    st.context.powerUserSettings = { persona_description_lorebook: '用户角色书' };
    wi.selected_world_info.push('全局书', '附加书');
    wi.books['附加书'] = { entries: { 0: { comment: '附加', constant: true, content: 'EXTRA_BODY' } } };
    wi.books['聊天书'] = { entries: { 0: { comment: '聊天', constant: true, content: 'CHAT_BODY' } } };
    wi.books['用户角色书'] = { entries: { 0: { comment: '用户角色', constant: true, content: 'PERSONA_BODY' } } };
    wi.calls.length = 0;
    const full = await host.readWorldbook();
    for (const marker of ['CHARACTER_BODY', 'GLOBAL_BODY', 'EXTRA_BODY', 'CHAT_BODY', 'PERSONA_BODY']) {
      assert(full.entries.some((entry) => entry.content === marker), `source ${marker} is included`);
    }
    assert(!full.entries.some((entry) => entry.content === 'STALE_INLINE'), 'external linked book replaces stale embedded copy');
    assert(wi.calls.filter((name) => name === '附加书').length === 1 && wi.calls.filter((name) => name === '角色书').length === 1, 'duplicate bindings only load once');
    assert(full.catalog.some((book) => book.name === '聊天书') && full.catalog.some((book) => book.name === '用户角色书'), 'extra sources also reach settings catalog');
    const { selectWorldbook } = await load(join(extension, 'src/modules/worldbook/select.js'));
    const normalized = (await readSourcePack()).worldbook.entries;
    const selection = selectWorldbook({ entries: normalized, settings: { worldbook: { exclude: ['聊天书', '用户角色书'] } } });
    assert(!selection.text.includes('CHAT_BODY') && !selection.text.includes('PERSONA_BODY') && !selection.text.includes('用户角色书'), 'book exclusion applies to added sources and roster');
    character.data.extensions.world = '缺失书';
    character.data.character_book = { name: '缺失书', entries: [{ name: '回退', content: 'FALLBACK_BODY', constant: true }] };
    assert((await host.readWorldbook()).entries.some((entry) => entry.content === 'FALLBACK_BODY'), 'missing external book still falls back to its embedded copy');
    assert(modelCalls[0].max_tokens === 1024, 'follow length is read from captured host settings');
    const { generateViaST } = await load(join(extension, 'src/modules/model/index.js'));
    const calls = []; let release;
    const reply = text => ({ok:true,json:async()=>({choices:[{message:{content:text}}]})});
    globalThis.fetch = async (_path, options) => {
      calls.push(JSON.parse(options.body));
      if(calls.length === 1) await new Promise(resolve=>{release=resolve;});
      return reply('fixed reply');
    };
    const request = {purpose:'correct',systemPrompt:'fixed task',prompt:'input'};
    saveSettings({model:{responseLength:16384}});
    const first = generateViaST(request);
    for(let i=0;i<30 && !release;i++) await Promise.resolve();
    assert(typeof release === 'function','first independent request starts');
    saveSettings({model:{responseLength:8192}});
    const second = generateViaST(request);
    for(let i=0;i<30 && calls.length<2;i++) await Promise.resolve();
    assert(calls.length === 2,'independent requests do not wait for a shared-settings queue');
    release(); await Promise.all([first,second]);
    assert(calls.map(c=>c.max_tokens).join(',') === '16384,8192','concurrent lengths remain independent');
    assert(st.context.chatCompletionSettings.openai_max_tokens === 1024,'host length never changes');
    globalThis.fetch = async()=>({ok:false,status:503});
    let failed=false; try {await generateViaST(request);} catch(e){failed=e.code === 'SHIJU_MODEL_FAILED';}
    globalThis.fetch = async()=>reply('recovered');
    assert(failed && (await generateViaST(request)).text === 'recovered','failed request does not poison later calls');
    let aborted=0, sent=0;
    globalThis.fetch = async(_path,options)=>{
      sent++;
      return new Promise((_resolve,reject)=>options.signal.addEventListener('abort',()=>{aborted++;reject(new DOMException('cancelled','AbortError'));},{once:true}));
    };
    const oldFirst=generateViaST(request).catch(e=>e), oldSecond=generateViaST(request).catch(e=>e);
    for(let i=0;i<30 && sent<2;i++) await Promise.resolve();
    st.memory.eventSource.emit(st.memory.event_types.CHAT_CHANGED);
    const oldResults=await Promise.all([oldFirst,oldSecond]);
    assert(aborted === 2 && oldResults.every(e=>e.code === 'SHIJU_CHAT_CHANGED'),'chat switch cancels all and only plugin requests');
    return checks;
  } finally {
    globalThis.fetch = savedFetch;
    await rm(fixture, { recursive: true, force: true });
  }
}
