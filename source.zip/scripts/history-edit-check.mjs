import assert from 'node:assert/strict';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { loadWorld, loadSettings } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { register as registerReconcile } from '../src/modules/reconcile/index.js';
import { enqueueTurn } from '../src/modules/turn.js';
import { readIncrement } from '../src/modules/incremental.js';
import { observeHiddenFloors } from '../src/modules/visibility-observer.js';
import { runImmediateEvolution, runAutomaticGate, clearEvolutionHold } from '../src/modules/timeGate/index.js';
import { correctStoryDay, getLifecycleStatus } from '../src/modules/lifecycle/index.js';
import { renderPage } from '../src/ui/pages.js';

// Exercise the registered edit listener, not just the gate in isolation. Model
// responses are fixed in memory; no HTTP or real chats are involved.
async function fixture(mode='shiju') {
  const tag={shiju:'shiju_end',baibai:'bbs_end',custom:'clock'}[mode];
  const message=(body,i)=>({name:'验收',send_date:String(i),mes:`${body}<${tag}>2026/1/1</${tag}>`,swipe_id:0});
  const host=createMemoryHost({chat:[0,1,2].map(i=>message(`第${i}号桥未修复`,i)),hasBaibai:mode==='baibai',settings:{timeSource:{mode,customTag:'clock'}}});
  const control={calls:[],fail:false};
  host.generateViaBackend=async request=>{
    control.calls.push(request);
    if(control.fail) throw new Error('fixed failure');
    return JSON.stringify(request.purpose==='bootstrap'
      ? {regions:[{ name: '河谷', summary: '固定验收资料' }],events:[{id:'bridge',kind:'macro',title:'桥况',body:'未修复'}]}
      : request.purpose==='realign' ? {events:[{id:'bridge',kind:'macro',title:'桥况',body:'已通行'}],todayChanges:[]}
        : {todayChanges:[]});
  };
  setHost(host);clearEvolutionHold();await bootstrapWorld();
  host.state.chat[2].mes+='初次演进增量';await runImmediateEvolution();
  registerReconcile();
  const edit=async floor=>{
    host.eventSource.emit(host.event_types.MESSAGE_EDITED,floor);
    // Host rendering can send additional notifications after MESSAGE_EDITED.
    host.eventSource.emit(host.event_types.CHARACTER_MESSAGE_RENDERED,floor);
    await enqueueTurn(()=>({}));
  };
  return {host,control,edit,message};
}

export async function runHistoryEditChecks() {
  let count=0;
  const check=(value,label)=>{assert.ok(value,label);count++;};
  for(const mode of ['shiju','baibai','custom']) for(const floor of [0,1,2]) {
    const {host,control,edit}=await fixture(mode);
    const before=loadWorld(), calls=control.calls.length;
    host.state.chat[floor].mes=host.state.chat[floor].mes.replace('未修复','已通行');
    await edit(floor);
    const after=loadWorld(), life=getLifecycleStatus();
    check(JSON.stringify(after.processedInput)===JSON.stringify(before.processedInput),`${mode}/${floor}: edit preserves processed boundary`);
    check(after.meta.inputHint==='history-changed' && readIncrement(after,host.state.chat).changed,`${mode}/${floor}: edit is detected through registered events`);
    check(life.promptRequired && life.canRealign && life.choices.includes('realign'),`${mode}/${floor}: realign entry available`);
    const html=renderPage({page:'settings',world:after,lifecycle:life,settings:loadSettings()});
    check(html.includes('data-choice="realign"')&&html.includes('已处理的正文有修改'),`${mode}/${floor}: actual settings markup contains the entry`);
    check(JSON.stringify(after.evolutionLog)===JSON.stringify(before.evolutionLog)&&JSON.stringify(after.events)===JSON.stringify(before.events)&&JSON.stringify(after.storyClock)===JSON.stringify(before.storyClock),`${mode}/${floor}: no rollback, fact replacement or date advance`);
    check((await runImmediateEvolution()).reason==='history-changed'&&(await runAutomaticGate()).reason==='history-changed'&&control.calls.length===calls,`${mode}/${floor}: repeated gates neither consume nor call model`);
  }
  {
    const {host,control,edit}=await fixture();
    const before=loadWorld(),calls=control.calls.length,original=host.state.chat[0].mes;
    host.state.chat[0].mes=original.replace('未修复','已通行');await edit(0);
    for(const hidden of [true,false]) {
      host.state.chat[0].is_system=hidden;
      await observeHiddenFloors(host.state.chat,[0]);await edit(0);
      check(loadWorld().meta.inputHint==='history-changed'&&JSON.stringify(loadWorld().processedInput)===JSON.stringify(before.processedInput),'hide/unhide cannot acknowledge an unresolved prose edit');
    }
    host.state.chat[0].mes=original;await edit(0);
    check(!loadWorld().meta.inputHint&&!getLifecycleStatus().canRealign&&control.calls.length===calls,'undo back to processed text clears warning without model');
    for(const hidden of [true,false]) {
      host.state.chat[1].is_system=hidden;await observeHiddenFloors(host.state.chat,[1]);await edit(1);
      check(!loadWorld().meta.inputHint&&!readIncrement(loadWorld(),host.state.chat).changed,'visibility-only changes do not become history edits');
    }
    host.state.chat[0].mes=original.replace('未修复','已通行');await edit(0);
    await correctStoryDay({choice:'keep'});
    check(!loadWorld().meta.inputHint&&(await runImmediateEvolution()).evolved&&control.calls.length===calls+1,'explicit keep acknowledges prose without model');
    check(JSON.stringify(loadWorld().events)===JSON.stringify(before.events),'explicit keep preserves existing facts');
  }
  {
    const {host,control,edit}=await fixture();
    host.state.chat[1].mes=host.state.chat[1].mes.replace('未修复','已通行');await edit(1);
    const before=loadWorld();control.fail=true;
    check(!(await correctStoryDay({choice:'realign'})).ok,'failed realignment is reported');
    check(loadWorld().meta.inputHint==='history-changed'&&JSON.stringify(loadWorld().processedInput)===JSON.stringify(before.processedInput),'failure preserves pending edit and old boundary');
    control.fail=false;
    check((await correctStoryDay({choice:'realign'})).ok,'realignment can be retried');
    check(control.calls.at(-1).prompt.includes('第1号桥已通行'),'realignment receives the modified prose');
    check(!loadWorld().meta.inputHint&&!readIncrement(loadWorld(),host.state.chat).changed&&loadWorld().events[0].body==='已通行','successful realignment commits corrected facts and boundary');
    const calls=control.calls.length;
    check((await runImmediateEvolution()).evolved&&control.calls.length===calls+1,'successful realignment is not repeated');
  }
  {
    const {host,control,edit,message}=await fixture();
    const before=JSON.stringify(loadWorld().processedInput),calls=control.calls.length;
    host.state.chat[2].mes+='仅新增的修桥进展';await edit(2);
    check(!loadWorld().meta.inputHint&&JSON.stringify(loadWorld().processedInput)===before&&control.calls.length===calls,'tip append remains pending without being acknowledged by edit event');
    check(readIncrement(loadWorld(),host.state.chat).items[0].text==='仅新增的修桥进展','tip continuation contains only appended suffix');
    check((await runImmediateEvolution()).evolved&&(await runImmediateEvolution()).evolved&&control.calls.length===calls+2,'tip continuation processed once');
    host.state.chat.push(message('尚未处理的公告',3));
    host.state.chat[3].mes=host.state.chat[3].mes.replace('公告','贸易公告');await edit(3);
    check(!loadWorld().meta.inputHint&&readIncrement(loadWorld(),host.state.chat).text.includes('贸易公告'),'editing unprocessed floor retains new input');
  }
  {
    const {host,control,edit}=await fixture();
    const before=loadWorld(),original=host.state.chat[1].mes,calls=control.calls.length;
    host.state.chat[1].mes='矛盾<shiju_start>2026/1/9</shiju_start><shiju_end>2026/1/1</shiju_end>';await edit(1);
    check(loadWorld().meta.clockHint==='conflict'&&JSON.stringify(loadWorld().processedInput)===JSON.stringify(before.processedInput),'date contradiction does not consume edits');
    host.state.chat[1].mes=original.replace('未修复','已通行');await edit(1);
    check(loadWorld().meta.inputHint==='history-changed'&&getLifecycleStatus().canRealign&&control.calls.length===calls,'fixing date while keeping rewritten prose still requires alignment');
    host.state.chat[1].mes=original;await edit(1);
    check(!loadWorld().meta.clockHint&&!loadWorld().meta.inputHint&&control.calls.length===calls,'restoring both date and prose clears warnings without replay');
  }
  return count;
}
