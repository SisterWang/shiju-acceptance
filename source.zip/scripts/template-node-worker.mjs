import {parentPort} from 'node:worker_threads';
import {renderTemplate} from '../src/modules/template/runtime.js';
parentPort.on('message',async data=>parentPort.postMessage(await renderTemplate(data.entry,data.context,data.entries)));
