import assert from 'node:assert/strict';
import {setHost} from '../src/host.js';
import {createMemoryHost} from '../src/host/memory.js';
import {createEmptyWorld,saveWorld,loadWorld,saveSettings,loadSettings} from '../src/store/index.js';
import {captureInputBoundary,readIncrement} from '../src/modules/incremental.js';
import {runImmediateEvolution,rerunLastEvolution} from '../src/modules/timeGate/index.js';
import {beginEntityEdit,saveEntity,generateManagementPreview,adoptManagementPreview} from '../src/modules/management/index.js';
import {saveFactManual} from '../src/modules/intervene/index.js';
import {isSecret,isFactVisible,isKnown} from '../src/modules/events.js';
import {getInjectPreview} from '../src/modules/inject/index.js';
import {contextBinding} from '../src/modules/model/context.js';
import {createPromptSettings} from '../src/ui/promptSettings.js';

let checks=0;
const check=(value,label)=>{assert(value,label);checks++;};
const equal=(a,b,label)=>{assert.deepEqual(a,b,label);checks++;};
async function fresh() {
  const host=createMemoryHost({chat:[{mes:'河谷居民协商维护桥梁。',send_date:1}],worldInfoEntries:[{uid:1,title:'河谷',content:'河谷沿岸有商镇和丘陵。',constant:true}]});
  setHost(host);host.generateViaBackend=async()=> '{}';
  const world=createEmptyWorld();world.plugin.enabled=true;world.meta.builtFingerprint='review-fixture';
  world.regions=[{id:'r',name:'河谷',summary:'贸易地区',status:'active'}];
  world.events=[{id:'e',title:'维护桥梁',body:'居民协商维护桥梁。',kind:'macro'}];
  world.processedInput=captureInputBoundary(host.state.chat);await saveWorld(world);return host;
}

// Rerun may replace model output, but never a later manual edit or its referents.
{
  const host=await fresh();host.generateViaBackend=async()=>JSON.stringify({regions:[{id:'coast',name:'海岸',summary:'沿岸港口'}]});
  check((await runImmediateEvolution()).evolved,'create checkpoint and a model-only referent');
  let edit=beginEntityEdit('regions','r');await saveEntity(edit.token,{...edit.item,name:'新河谷',summary:'人工概况',secret:true});
  edit=beginEntityEdit('orgs');await saveEntity(edit.token,{...edit.item,name:'人工商会',summary:'人工新增组织',regionRef:'coast'});
  await saveFactManual({kind:'event',id:'e',patch:{title:'人工桥梁计划',body:'人工修正的事件全文'}});
  const before=loadWorld(),region=before.regions.find(r=>r.id==='r'),org=before.orgs[0],event=before.events[0];
  host.generateViaBackend=async()=> '{}';
  check((await rerunLastEvolution()).evolved,'empty rerun succeeds');
  equal(loadWorld().regions.find(r=>r.id==='r'),region,'rename, aliases, secrecy and manual body survive rerun');
  equal(loadWorld().orgs[0],org,'new manual organization survives');
  equal(loadWorld().events[0],event,'manual event survives');
  check(loadWorld().regions.some(r=>r.id===org.regionRef),'missing checkpoint referent restored');
  check(loadWorld().userCorrections.every(c=>c.consumed),'corrections consumed only with surviving records');
  equal(loadWorld().processedInput,before.processedInput,'rerun boundary unchanged');
  host.generateViaBackend=async()=>JSON.stringify({regions:[{id:'r',name:'河谷',summary:'旧模型概况'}],events:[{id:'e',title:'旧事件',body:'旧模型正文',lifecycle:'archived',outcome:'不应保存的归档后果'}]});
  check((await rerunLastEvolution()).evolved,'outdated model update reruns');
  equal(loadWorld().regions.find(r=>r.id==='r'),region,'outdated model cannot overwrite manual entity');
  equal(loadWorld().events[0],event,'outdated model cannot archive manual event');
  check(!loadWorld().facts.some(f=>f.text==='不应保存的归档后果'),'discarded archive produces no false fact');
  host.generateViaBackend=async()=>JSON.stringify({regions:[{id:'r',summary:'后续合理变化'}]});
  check((await runImmediateEvolution()).evolved,'subsequent normal evolution still works');
  check(loadWorld().regions.find(r=>r.id==='r').summary==='后续合理变化','manual records are not permanently frozen');
  edit=beginEntityEdit('orgs',org.id);await saveEntity(edit.token,{...edit.item,summary:'失败前的人工更新'});
  const protectedBefore=loadWorld();host.generateViaBackend=async()=>{throw Error('fixed failure');};
  check(!(await rerunLastEvolution()).ok,'failed rerun reported');
  equal(loadWorld().orgs,protectedBefore.orgs,'failed rerun leaves manual data intact');
  equal(loadWorld().userCorrections,protectedBefore.userCorrections,'failed rerun does not consume corrections');
}

// Both rebuilding and category updates must retain secrecy even when the model omits it.
{
  const host=await fresh(),world=loadWorld();
  world.regions[0].secret=true;world.regions[0].knowledgeOverride='unknown';
  world.events[0]={...world.events[0],kind:'secret',knowledgeOverride:'unknown',viewMode:'hidden',autoKnown:false};
  world.todayChanges=[{id:'c',title:'关联隐秘',body:'关联正文',kind:'secret',linkedEventId:'e',knowledgeOverride:'unknown'}];
  await saveWorld(world);
  host.generateViaBackend=async()=>JSON.stringify({regions:[{id:'r',name:'河谷',summary:'更新的地区概况'}],events:[{id:'e',title:'维护桥梁',body:'秘密计划正文'}]});
  const preview=await generateManagementPreview();await adoptManagementPreview(preview.token);
  const rebuilt=loadWorld();
  for(const item of [rebuilt.regions[0],rebuilt.events[0],rebuilt.todayChanges[0]]) {
    check(isSecret(item),'secret type preserved');check(!isKnown(item)&&!isFactVisible(item),'unknown remains hidden');
  }
  check(!getInjectPreview().text.includes('秘密计划正文'),'secret is not injected into prose');
  host.generateViaBackend=async()=>JSON.stringify({regions:[{id:'r',name:'河谷',summary:'分类补全的概况',secret:false}]});
  const category=await generateManagementPreview('regions');await adoptManagementPreview(category.token);
  check(isSecret(loadWorld().regions[0])&&!isFactVisible(loadWorld().regions[0]),'category generation cannot declassify');
  equal(loadWorld().todayChanges,rebuilt.todayChanges,'category update leaves other categories untouched');
}

// Full rebuild consumes all permitted background, while durable manual exclusions remain.
{
  const host=await fresh();
  host.state.chat.push({mes:'已由记忆提供的商队抵达。',send_date:2,is_system:true,extra:{bbs_hidden:true}});
  host.state.chat.push({mes:'手动隐藏且应排除的剧情。',send_date:3,is_system:true});
  host.state.chat.push({mes:'记忆缺失时提供的原文。',send_date:4,is_system:true,extra:{bbs_hidden:true}});
  const memory={floorStart:1,floorEnd:1,text:'商队已经抵达河谷。',valid:true};
  globalThis.STBaiBaiBook={getSnapshot:()=>({chat:{id:'preview'},revision:1}),getHistory:()=>({chat:{id:'preview'},revision:1,nodes:[memory]}),getFloor:floor=>({chat:{id:'preview'},revision:1,memory:floor===1?{valid:true,summary:memory.text}:{valid:false}})};
  try {
    let input='';host.generateViaBackend=async request=>{input=request.prompt;return JSON.stringify({regions:[{id:'r',name:'河谷',summary:'贸易地区'}]});};
    const boundaryBefore=loadWorld().processedInput,preview=await generateManagementPreview();
    equal(loadWorld().processedInput,boundaryBefore,'preview alone never consumes history');
    check(input.includes(memory.text)&&input.includes('记忆缺失时提供的原文')&&!input.includes('手动隐藏且应排除'),'full permitted background actually supplied');
    await adoptManagementPreview(preview.token);
    equal(loadWorld().processedInput.rows.map(r=>r.status),['processed','processed','excluded','processed'],'new baseline consumes summary and raw fallback only');
    const memoryPack={floorMemories:[memory]};
    check(readIncrement(loadWorld(),host.state.chat,memoryPack).items.length===0,'no replay after rebuild');
    host.state.chat[2].is_system=false;
    check(readIncrement(loadWorld(),host.state.chat,memoryPack).items.length===0,'unhide excluded floor does not replay');
    const again=await generateManagementPreview();await adoptManagementPreview(again.token);
    check(!input.includes('手动隐藏且应排除'),'excluded background stays excluded across another rebuild');
    check(loadWorld().processedInput.rows[2].status==='excluded','unhidden floor retains exclusion state');
    check(loadWorld().processedInput.excluded.some(row=>row.floor===2),'exclusion survives the next boundary capture');
    host.state.chat.push({mes:'重建后新增公告。',send_date:5});
    check(readIncrement(loadWorld(),host.state.chat,memoryPack).items.length===1,'new prose still pending');
    const boundary=loadWorld().processedInput;host.generateViaBackend=async()=>{throw Error('fixed failure');};
    await assert.rejects(()=>generateManagementPreview(),/fixed failure/);checks++;
    equal(loadWorld().processedInput,boundary,'failed rebuild does not advance baseline');
  } finally {delete globalThis.STBaiBaiBook;}
}

// Exercise the settings event handlers without a browser or any paid request.
{
  const host=await fresh();let model='A',address='https://one.example/v1';
  host.captureModelConnection=()=>({mode:'follow',api:'openai',model,settings:{chat_completion_source:'custom',custom_url:address}});
  const original={binding:contextBinding(host.captureModelConnection()),tokens:100000};
  saveSettings({model:{contextLimit:original}});
  const handlers={},fields={};
  const buttons=['model-edit','model-save','model-cancel'].map(action=>({dataset:{promptAction:action},addEventListener:(_,fn)=>handlers[action]=fn}));
  const body={querySelector:s=>fields[s] || null,querySelectorAll:s=>s==='[data-prompt-action]'?buttons:[]};
  let ui;ui=createPromptSettings({refresh:()=>ui.capture(body),getScope:()=>null,getSection:()=> 'model'});ui.bind(body);
  await handlers['model-edit']();model='B';await handlers['model-save']();
  equal(loadSettings().model.contextLimit,original,'stale model cap cannot be rebound on save');
  check(ui.render(null,false).model.includes('旧上下文上限已清除'),'connection mismatch explains cleared draft');
  const cap={value:'200000',addEventListener:(_,fn)=>cap.input=fn};fields['#sj-context-limit']=cap;ui.bind(body);cap.input();await handlers['model-save']();
  equal(loadSettings().model.contextLimit,{binding:contextBinding(host.captureModelConnection()),tokens:200000},'explicit reentry binds new model');
  check(!('contextBindingAtEdit' in loadSettings().model),'editor binding is not persisted');
  delete fields['#sj-context-limit'];await handlers['model-edit']();address='https://two.example/v1';await handlers['model-save']();
  check(loadSettings().model.contextLimit.binding!==contextBinding(host.captureModelConnection()),'same model different endpoint does not inherit cap');
  await handlers['model-save']();check(loadSettings().model.contextLimit===null,'explicit save after clearing permits no cap');
  await handlers['model-edit']();await handlers['model-cancel']();check(loadSettings().model.contextLimit===null,'cancel does not save draft');
}
console.log(`world management review checks ok: ${checks}`);
