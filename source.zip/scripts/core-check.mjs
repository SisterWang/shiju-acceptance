/**
 * Focused W1–W2 checks. Not a suite: the three gate APIs, the single commit, and the clock rules.
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { projectWorld } from '../src/ui/readout.js';
import {
  focusCount,
  keywordHit,
  selectWorldbook,
} from '../src/modules/worldbook/select.js';
import { createEmptyWorld, ensureSettings, loadSettings, loadWorld, saveSettings, saveWorld } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { commitEvolutionSuccess } from '../src/modules/commit/index.js';
import { applyHardBudget } from '../src/modules/evolve/budget.js';
import { setGeneratingTip, isGeneratingTip } from '../src/modules/generatingTip.js';
import * as model from '../src/modules/model/index.js';
import * as source from '../src/modules/source/index.js';
import * as bootstrap from '../src/modules/bootstrap/index.js';
import * as timetag from '../src/modules/timetag/index.js';
import * as timeGate from '../src/modules/timeGate/index.js';
import * as evolve from '../src/modules/evolve/index.js';
import * as commit from '../src/modules/commit/index.js';
import * as reconcile from '../src/modules/reconcile/index.js';
import * as inject from '../src/modules/inject/index.js';
import { clearEvolutionHold, rerunLastEvolution, runAutomaticGate, runImmediateEvolution } from '../src/modules/timeGate/index.js';
import { correctStoryDay, freezeWorld, inspectStoryDay, reopenWorld } from '../src/modules/lifecycle/index.js';
import { MACRO_DISCLAIMER, getInjectPreview } from '../src/modules/inject/index.js';
import * as lifecycle from '../src/modules/lifecycle/index.js';
import {
  AI_CORRECTION_CONFIRM,
  applyAiCorrection,
  previewAiCorrection,
  saveFactManual,
} from '../src/modules/intervene/index.js';
import * as intervene from '../src/modules/intervene/index.js';

const MODULES = [model, source, bootstrap, timetag, timeGate, evolve, commit, reconcile, inject, lifecycle, intervene];

export async function runCoreChecks() {
  let checks = 0;
  function assert(condition, message) {
    checks += 1;
    if (!condition) {
      console.error(`FAIL core #${checks}: ${message}`);
      process.exit(1);
    }
  }

  const previousFetch = globalThis.fetch;
  let fetches = 0;
  globalThis.fetch = async () => {
    fetches += 1;
    throw new Error('fetch blocked');
  };

  const calls = [];
  const control = { boom: false };
  const host = createMemoryHost();
  host.generateViaBackend = async (request) => {
    const recorded = {
      purpose: request.purpose,
      systemPrompt: request.systemPrompt,
      prompt: request.prompt,
    };
    calls.push(recorded);
    if (control.boom) {
      control.boom = false;
      throw new Error('模型炸了');
    }
    return canned(request);
  };

  try {
    delete globalThis.STBaiBaiBook;
    setHost(host);
    ensureSettings();
    for (const mod of MODULES) mod.register({});

    assertBudget(assert);

    await assertBootstrap(assert, host, calls);
    await assertOldChat(assert, host, calls);
    await assertSameDayAndCross(assert, host, calls);
    await assertConflictAndMissing(assert, host, calls);
    await assertFailure(assert, host, calls, control);
    await assertGenerating(assert, host, calls);
    await assertImmediateAndRerun(assert, host, calls, control);
    await assertLogCap(assert, host);
    await assertParallel(assert, host, calls);
    await assertSwipeAndTypo(assert, host, calls);
    await assertMiddleSwipe(assert, host, calls);
    await assertWorldbookSelect(assert, host, calls);
    await assertBaibai(assert, host, calls);
    await assertShijuAndCustom(assert, host, calls);
    await assertInjectAndLifecycle(assert, host, calls);
    await assertIntervene(assert, host, calls, control);
    await assertPreviewConcurrentWrites(assert, host);
    await assertTimeTagModes(assert, host);
    await assertGeneratingHardGate(assert, host, calls);
    await assertNoDoublePush(assert, host, calls);

    assert(fetches === 0, `A25 no upstream fetch (${fetches})`);
    assert(calls.length > 0, 'A25 model calls went through generateViaST');
    assert(calls.every((call) => typeof call.systemPrompt === 'string' && typeof call.prompt === 'string'), 'recorded prompts');
  } finally {
    delete globalThis.STBaiBaiBook;
    globalThis.fetch = previousFetch;
    setGeneratingTip(false);
    clearEvolutionHold();
  }

  return checks;
}

function canned(request) {
  if (request.purpose === 'correct') return '修订后的正文';
  if (request.purpose === 'bootstrap') {
    return JSON.stringify({
      regions: [{ name: '江左', summary: '水乡' }],
      todayChanges: [{ title: '不该留下', kind: 'macro', body:'验收正文' }],
    });
  }
  let title = '跨日变更';
  if (String(request.prompt).includes('重跑上次演进')) title = '重跑变更';
  else if (String(request.prompt).includes('立即演进')) title = '立即变更';
  return JSON.stringify({
    todayChanges: [{ title, kind: 'macro', body: '远方' }],
    regions: [{ name: '江左', summary: '水乡' }],
  });
}

function assertBudget(assert) {
  const marker = 'BUFFER_KEY_SENTENCE';
  const body = 'E'.repeat(8000);
  const fitted = applyHardBudget({
    summary: '概要',
    bufferText: `${marker} 当日一句`,
    p1: '楼'.repeat(8000),
    entries: [{ title: '巨书', content: body }],
    mvu: { blob: 'M'.repeat(5000) },
  });
  assert(fitted.text.includes(body), 'worldbook entry stays whole');
  assert(Array.from(fitted.text).length > 12000, 'no 12k hard ceiling');
  assert(fitted.truncated === false, 'complete inputs never mark truncation');
  assert(fitted.softWarn === false, 'no arbitrary size warning');
  assert(fitted.text.includes(marker) && fitted.p0.includes(marker), 'p0 keeps the buffer line');
  assert(fitted.text.includes('楼'.repeat(8000)) && fitted.text.includes('M'.repeat(5000)), 'complete background and MVU');
}

function shiju(start, end = start, body = '正文') {
  return `<shiju_start>${start}</shiju_start>${body}<shiju_end>${end}</shiju_end>`;
}

function evolveCount(calls) {
  return calls.filter((call) => call.purpose === 'evolve').length;
}

function reset(host, messages = []) {
  host.state.chat = messages.map((message) => ({ swipe_id: 0, ...message }));
  host.state.chatMetadata = {};
  host.state.extensionSettings = {};
  host.state.worldInfoEntries = [];
  host.state.mvu = null;
  host.state.prompts = {};
  host.state.hasBaibai = false;
  delete globalThis.STBaiBaiBook;
  clearEvolutionHold();
  setGeneratingTip(false);
  ensureSettings();
}

async function settle() {
  await new Promise((resolve) => setTimeout(resolve, 30));
}

async function assertBootstrap(assert, host, calls) {
  reset(host, []);
  host.state.worldInfoEntries = [{title:'初始地区',content:'江左水乡',constant:true}];
  const beforeMes = host.state.chat.map((message) => message.mes);
  const built = await bootstrapWorld();
  assert(built.ok === true && built.created === true && built.evolved === false, 'bootstrap creates');
  const world = loadWorld();
  assert(world.plugin.enabled === true, 'enabled');
  assert((world.regions.length + world.orgs.length + world.factions.length) >= 1, 'at least one entity');
  assert(world.todayChanges.length === 0, 'bootstrap clears today changes');
  assert(world.evolutionLog.length === 0 && world.lastEvolutionCheckpoint === null, 'bootstrap does not commit');
  assert(world.meta.evolutionCallCount === 0, 'bootstrap is not an evolution');
  assert(world.meta.usage && world.meta.usage.unit === 'token' && world.meta.usage.mvu === 0, 'bootstrap stores a usage split');
  assert(calls.filter((call) => call.purpose === 'bootstrap').length === 1, 'one bootstrap call');
  assert(evolveCount(calls) === 0, 'bootstrap does not evolve');
  assert(JSON.stringify(host.state.chat.map((message) => message.mes)) === JSON.stringify(beforeMes), 'mes untouched');

  const again = await bootstrapWorld();
  assert(again.created === false && again.evolved === false, 'second enable does not rebuild');
  assert(calls.filter((call) => call.purpose === 'bootstrap').length === 1, 'resume skips the model');

  world.plugin.enabled = false;
  world.plugin.frozenAt = 1;
  await saveWorld(world);
  const frozenCalls = calls.length;
  const resumed = await bootstrapWorld();
  assert(resumed.resumed === true && resumed.evolved === false, 'frozen ledger resumes');
  assert(calls.length === frozenCalls, 'resume makes no model call');
  assert(loadWorld().plugin.enabled === true && loadWorld().plugin.frozenAt == null, 'freeze cleared');
}

async function assertOldChat(assert, host, calls) {
  const messages = [
    { mes: shiju('2024/10/1', '2024/10/1', '甲') },
    { mes: shiju('2024/10/2', '2024/10/2', '乙') },
  ];
  reset(host, messages);
  const snapshot = host.state.chat.map((message) => message.mes).join('\n');
  const boots = calls.filter((call) => call.purpose === 'bootstrap').length;
  await bootstrapWorld();
  assert(host.state.chat.map((message) => message.mes).join('\n') === snapshot, 'old chat mes stays');
  assert(calls.filter((call) => call.purpose === 'bootstrap').length === boots + 1, 'old chat still one build');
  const world = loadWorld();
  assert(world.storyClock.dayIndex === 1, 'historical span is caught up');
  assert(world.meta.lastEvolvedDayIndex === 1, 'catch-up counts as already evolved');
  assert(world.evolutionLog.length === 0, 'catch-up writes no log');
  const before = evolveCount(calls);
  const gate = await runAutomaticGate();
  assert(gate.evolved === false, 'old chat gate does not evolve');
  assert(evolveCount(calls) === before, 'old chat gate makes no model call');
}

async function assertSameDayAndCross(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  assert(loadWorld().storyClock.dayIndex === 0, 'one date establishes day 0');
  const before = evolveCount(calls);
  const same = await runAutomaticGate();
  assert(same.evolved === false && same.reason === 'same-day', 'same-day gate');
  assert(evolveCount(calls) === before, 'same-day makes no evolve call');

  host.state.chat.push({ mes: shiju('1988/1/4', '1988/1/4', '后'), swipe_id: 0 });
  const gate = await runAutomaticGate();
  assert(gate.evolved === true, 'cross-day evolves once');
  const world = loadWorld();
  assert(world.storyClock.dayIndex === 3, 'three-day jump is one step');
  assert(world.evolutionLog.length === 1 && world.lastEvolutionCheckpoint, 'commit promoted both');
  const prompt = calls.filter((call) => call.purpose === 'evolve').at(-1).prompt;
  assert(prompt.includes('一次覆盖'), 'multi-day jump is one prompt');
}

async function assertConflictAndMissing(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/4', '1988/1/1', '倒退') }]);
  await bootstrapWorld();
  assert(loadWorld().meta.clockHint === 'conflict', 'backward range is a conflict');
  assert(loadWorld().evolutionLog.length === 0, 'conflict does not commit');
  const before = evolveCount(calls);
  const gate = await runAutomaticGate();
  assert(gate.evolved === false && gate.reason === 'conflict', 'conflict gate');
  assert(evolveCount(calls) === before, 'conflict makes no evolve call');

  reset(host, [{ mes: '没有时间标签' }]);
  await bootstrapWorld();
  assert(loadWorld().meta.clockHint === 'missing-tag', 'missing tag hint');
  const missingBefore = evolveCount(calls);
  const missing = await runAutomaticGate();
  assert(missing.evolved === false && missing.reason === 'missing-tag', 'missing tag stays put');
  assert(evolveCount(calls) === missingBefore, 'missing tag makes no evolve call');
}

async function assertFailure(assert, host, calls, control) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  host.state.chat.push({ mes: shiju('1988/1/4'), swipe_id: 0 });
  const errors = loadWorld().meta.errorCount;
  control.boom = true;
  const gate = await runAutomaticGate();
  assert(gate.ok === false && gate.evolved === false, 'failed evolve');
  const world = loadWorld();
  assert(world.evolutionLog.length === 0 && world.lastEvolutionCheckpoint === null, 'failure does not commit');
  assert(world.meta.errorCount === errors + 1, 'error counted');
  assert(world.storyClock.dayIndex === 0, 'failed auto does not move the clock');
  let refused = false;
  try {
    await commitEvolutionSuccess({ ok: false });
  } catch (error) {
    refused = error.code === 'SHIJU_COMMIT_REFUSED';
  }
  assert(refused, 'commit refuses a failure');
  assert(loadWorld().evolutionLog.length === 0, 'refused commit appends nothing');
}

async function assertGenerating(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'continue');
  assert(isGeneratingTip() === false, 'continue does not lock the tip');
  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'swipe', {}, true);
  assert(isGeneratingTip() === false, 'dry run does not lock the tip');
  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'swipe');
  assert(isGeneratingTip() === true, 'swipe generation locks the tip');
  const before = evolveCount(calls);
  const gate = await runAutomaticGate();
  assert(gate.evolved === false && gate.reason === 'generating', 'generating blocks the gate');
  assert(evolveCount(calls) === before, 'generating makes no model call');
  host.eventSource.emit(host.event_types.GENERATION_STOPPED);
  await settle();
  assert(isGeneratingTip() === false, 'stop clears the tip');
  assert(evolveCount(calls) === before, 'settling a same-day tip does not evolve');
}

async function assertImmediateAndRerun(assert, host, calls, control) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  const before = evolveCount(calls);
  const none = await rerunLastEvolution();
  assert(none.evolved === false && none.reason === 'no-checkpoint', 'rerun without a checkpoint');
  assert(evolveCount(calls) === before, 'empty rerun makes no model call');

  const day = loadWorld().storyClock.dayIndex;
  const idle = await runImmediateEvolution();
  assert(idle.evolved && evolveCount(calls) === before+1, 'explicit immediate permits autonomous evolution');
  host.state.chat.at(-1).mes += '新增剧情';
  const immediate = await runImmediateEvolution();
  assert(immediate.evolved === true, 'immediate evolves');
  assert(loadWorld().storyClock.dayIndex === day, 'immediate does not add a day');
  assert(loadWorld().evolutionLog.length === 2, 'immediate commits');
  assert(loadWorld().todayChanges[0].title === '立即变更', 'immediate changes');

  const digest = loadWorld().lastEvolutionCheckpoint.evolutionInputDigest;
  const rerun = await rerunLastEvolution();
  assert(rerun.evolved === true, 'rerun evolves');
  assert(loadWorld().storyClock.dayIndex === day, 'rerun keeps the day');
  assert(loadWorld().evolutionLog.length === 3, 'rerun appends another entry');
  assert(loadWorld().todayChanges[0].title === '重跑变更', 'rerun replaces today changes');
  assert(calls.at(-1).prompt.includes(digest), 'rerun reuses the checkpoint digest');

  const kept = loadWorld();
  const keptId = kept.evolutionLog.at(-1).id;
  const keptTitle = kept.todayChanges[0].title;
  const keptCheckpoint = kept.lastEvolutionCheckpoint.evolutionId;
  control.boom = true;
  const failed = await rerunLastEvolution();
  assert(failed.ok === false && failed.evolved === false, 'failed rerun');
  const after = loadWorld();
  assert(after.evolutionLog.at(-1).id === keptId, 'failed rerun keeps the log');
  assert(after.todayChanges[0].title === keptTitle, 'failed rerun keeps today changes');
  assert(after.lastEvolutionCheckpoint.evolutionId === keptCheckpoint, 'failed rerun keeps the checkpoint');
}

async function assertLogCap(assert, host) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  const ids = [];
  for (let index = 0; index < 9; index += 1) {
    host.state.chat.at(-1).mes += `新增剧情${index}`;
    await runImmediateEvolution();
    ids.push(loadWorld().evolutionLog.at(-1).id);
  }
  const log = loadWorld().evolutionLog;
  assert(log.length === 8, 'log keeps eight');
  assert(!log.some((entry) => entry.id === ids[0]), 'oldest entry dropped');
  assert(log.some((entry) => entry.id === ids[8]), 'newest entry kept');
}

async function assertParallel(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  host.state.chat.push({ mes: shiju('1988/1/4'), swipe_id: 0 });
  const before = evolveCount(calls);
  const [first, second] = await Promise.all([runAutomaticGate(), runAutomaticGate()]);
  assert(evolveCount(calls) === before + 1, 'parallel gates share one model call');
  assert(loadWorld().evolutionLog.length === 1, 'parallel gates append once');
  assert(first.evolved === true || second.evolved === true, 'one of the gates evolves');
}

async function assertSwipeAndTypo(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '原文') }]);
  await bootstrapWorld();
  host.state.chat.at(-1).mes += '新增剧情';
  await runImmediateEvolution();
  const before = evolveCount(calls);
  host.state.chat[0].swipe_id = 1;
  host.eventSource.emit(host.event_types.MESSAGE_SWIPED, 0);
  await settle();
  assert(loadWorld().evolutionLog.length === 0, 'swipe drops the anchor');
  assert(loadWorld().lastEvolutionCheckpoint === null, 'swipe clears a dangling checkpoint');
  assert(evolveCount(calls) === before, 'same-day swipe does not evolve again');

  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '原文') }]);
  await bootstrapWorld();
  host.state.chat.at(-1).mes += '新增剧情';
  await runImmediateEvolution();
  const id = loadWorld().evolutionLog[0].id;
  const evolveBefore = evolveCount(calls);
  host.state.chat[0].mes = host.state.chat[0].mes.replace('原文', '原文错字');
  host.eventSource.emit(host.event_types.MESSAGE_EDITED);
  await settle();
  assert(loadWorld().evolutionLog.length === 1 && loadWorld().evolutionLog[0].id === id, 'typo outside the tag keeps the log');
  assert(evolveCount(calls) === evolveBefore, 'typo makes no model call');
}

async function assertMiddleSwipe(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '开局') }]);
  await bootstrapWorld();
  host.state.chat.push({ mes: shiju('1988/1/2', '1988/1/2', '第二天'), swipe_id: 0 });
  await runAutomaticGate();
  const keptId = loadWorld().evolutionLog[0].id;
  host.state.chat.push({ mes: shiju('1988/1/2', '1988/1/2', '中间'), swipe_id: 0 });
  const mid = await runAutomaticGate();
  assert(mid.evolved === false, 'same-day middle floor does not evolve');
  host.state.chat.push({ mes: shiju('1988/1/4', '1988/1/4', '跳日'), swipe_id: 0 });
  await runAutomaticGate();
  const droppedId = loadWorld().evolutionLog[1].id;
  assert(loadWorld().evolutionLog[0].tipFloor === 1 && loadWorld().evolutionLog[1].tipFloor === 3, 'anchors sit on their tips');
  const before = evolveCount(calls);
  host.state.chat[2].swipe_id = 1;
  host.eventSource.emit(host.event_types.MESSAGE_SWIPED, 2);
  await settle();
  const log = loadWorld().evolutionLog;
  assert(log.some((entry) => entry.id === keptId), 'earlier anchor stays');
  assert(!log.some((entry) => entry.id === droppedId), 'later anchor drops');
  assert(evolveCount(calls) === before + 1, 'remaining cross-day tip evolves once');
}

function worldbookLedger() {
  return {
    worldbookRotateCursor: 0,
    regions: [
      { name: '北境', summary: '冷' },
      { name: '南泽', summary: '湿' },
      { name: '西山', summary: '高' },
    ],
    orgs: [{ name: '盐帮', summary: '盐' }],
    factions: [{ name: '水师', summary: '船' }],
    events: [
      { kind: 'macro', phase: '萌芽', title: '春潮', body: '起' },
      { kind: 'macro', phase: '发展', title: '夏汛', body: '涨' },
      { kind: 'macro', phase: '高潮', title: '秋决', body: '战' },
      { kind: 'macro', title: '未标阶段', body: '缺省' },
      { kind: 'macro', phase: '消退', title: '冬歇', body: '静' },
      { kind: 'macro', phase: '稳定', title: '平年', body: '稳' },
      { kind: 'news', phase: '高潮', title: '远报', body: '闻' },
      { kind: 'secret', phase: '高潮', title: '密约', body: '密' },
    ],
    dayBuffer: { items: [] },
    storyClock: { dayIndex: 0, dateLabel: '甲' },
  };
}

async function assertWorldbookSelect(assert, host, calls) {
  const root = fileURLToPath(new URL('..', import.meta.url));
  const budgetSrc = readFileSync(join(root, 'src/modules/evolve/budget.js'), 'utf8');
  const sourceSrc = readFileSync(join(root, 'src/modules/source/index.js'), 'utf8');
  const selectSrc = readFileSync(join(root, 'src/modules/worldbook/select.js'), 'utf8');
  assert(!budgetSrc.includes('12000'), 'A32 budget has no 12k hard total');
  assert(!sourceSrc.includes('slice(0, 8000)'), 'A32 normalize does not slice 8000');
  assert(!/readChat\s*\(/.test(selectSrc) && !/checkWorldInfo\s*\(/.test(selectSrc), 'A29 selector does not scan chat');

  const long = '甲'.repeat(9000);
  const normalized = source.normalizeEntries([
    { title: '长条', content: long, constant: true, key: ['北境'], enabled: true },
    { title: '禁用条', content: '不该留下', disable: true, constant: true },
  ]);
  assert(normalized.length === 1 && normalized[0].content === long, 'A32 normalize keeps the whole entry');
  assert(normalized[0].constant === true && normalized[0].keys.includes('北境'), 'constant and keys survive normalize');

  const originalRead = host.readWorldbook;
  host.readWorldbook = async () => ({
    name: '志',
    uid: 'book-1',
    entries: {
      1: { comment: '条', content: '文'.repeat(100), constant: false, key: '北境,南泽', keysecondary: ['副键'] },
      2: { comment: '关', content: '不进', disable: true },
    },
  });
  const mapped = await source.readSourcePack();
  host.readWorldbook = originalRead;
  assert(mapped.worldbook.entries.length === 1, 'object-map book drops disabled entries');
  const mappedEntry = mapped.worldbook.entries[0];
  assert(mappedEntry.content.length === 100 && mappedEntry.bookName === '志' && mappedEntry.bookUid === 'book-1', 'book uid and full text kept');
  assert(mappedEntry.keys.includes('北境') && mappedEntry.keys.includes('南泽') && mappedEntry.keys.includes('副键'), 'comma keys and keysecondary kept');

  assert(focusCount(1) === 3 && focusCount(2) === 5 && focusCount(4) === 7 && focusCount(32) === 12, 'A29 K widens with dayDelta');
  assert(keywordHit(['北境水师'], ['北境']) === true, 'A29 Chinese substring hits the key');
  assert(keywordHit(['南泽'], ['北境']) === false, 'unrelated key misses');

  const huge = `HEAD${'蓝'.repeat(9000)}TAIL`;
  const entries = [
    { title: '蓝灯条', content: huge, constant: true, bookName: '设定集' },
    { title: '焦点绿', content: '焦点绿全文应进', constant: false, keys: ['北境'], bookName: '设定集' },
    { title: '盐帮绿', content: '盐帮正文本轮不进', constant: false, keys: ['盐帮'], bookName: '设定集' },
    { title: '远报绿', content: '远报正文不应进', constant: false, keys: ['远报'], bookName: '设定集' },
    { title: '消退绿', content: '冬歇正文不应进', constant: false, keys: ['冬歇'], bookName: '设定集' },
    { title: '聊天绿', content: '聊天绿正文不应进', constant: false, keys: ['聊天专有词QQQ'], bookName: '设定集' },
    { title: '正文提焦点', content: '正文里有北境但不该因此整条进入', constant: false, keys: ['无关词ZZZ'], bookName: '设定集' },
    { title: '常驻绿', content: '常驻全文MARKER', constant: false, keys: ['绝不命中词'], bookName: '常驻书' },
    { title: '按号常驻', content: '按号全文MARKER', constant: false, keys: ['绝不命中词'], bookUid: 'wb-9', bookName: '有号书' },
    { title: '有号同名', content: '同名不应常驻MARKER', constant: false, keys: ['绝不命中词'], bookUid: 'wb-other', bookName: '常驻书' },
    { title: '排除标题', content: '排除正文MARKER', constant: true, bookName: '排除书' },
    { title: '排除优先条', content: '排除优先MARKER', constant: true, keys: ['北境'], bookName: '双名单' },
    { title: '禁用条', content: '禁用正文不应出现', disable: true, constant: true, bookName: '设定集' },
  ];
  const settings = {
    worldbook: {
    forceInclude: ['常驻书', { uid: 'wb-9' }, '双名单'],
    exclude: ['排除书', '双名单'],
    },
  };
  const narrowPick = selectWorldbook({ discoveryKeys:[],
    entries,
    world: worldbookLedger(),
    settings,
    dayDelta: 1,
    cursor: 0,
    chat: [{ mes: '聊天专有词QQQ' }],
    floorsTail: [{ text: '聊天专有词QQQ' }],
  });
  const widePick = selectWorldbook({ discoveryKeys:[],
    entries,
    world: worldbookLedger(),
    settings,
    dayDelta: 32,
    cursor: 0,
  });
  assert(narrowPick.k === 3 && widePick.k === 12, 'A29 narrow and wide K differ');
  assert(narrowPick.scanWords.join(',') === '北境,南泽,西山', 'A29 scan words are only this round of foci');
  assert(narrowPick.pool.includes('盐帮') && narrowPick.pool.includes('春潮') && narrowPick.pool.includes('未标阶段'), 'ongoing macro titles join the pool');
  assert(!narrowPick.pool.includes('冬歇') && !narrowPick.pool.includes('平年'), 'fading and stable phases stay out of the pool');
  assert(!narrowPick.pool.includes('远报') && !narrowPick.pool.includes('密约'), 'news and secret names stay out of the pool');
  assert(!narrowPick.scanWords.includes('盐帮') && widePick.scanWords.includes('盐帮'), 'A29 a large dayDelta covers foci the single day misses');
  assert(!widePick.scanWords.includes('远报') && !widePick.scanWords.includes('冬歇'), 'widening still does not scan the whole board');
  assert(widePick.focusNames.length === 12 && widePick.scanWords.length === narrowPick.pool.length, 'A29 wide K wraps the pool without using it as the scan list');
  assert(narrowPick.text.includes('世界书名册') && narrowPick.text.includes('设定集 · 盐帮绿'), 'A30 enabled titles stay on the roster');
  assert(narrowPick.text.includes(huge), 'A32 constant body is complete');
  assert(narrowPick.text.includes('常驻全文MARKER') && narrowPick.text.includes('按号全文MARKER'), 'A31 forceInclude keeps green bodies');
  assert(!narrowPick.text.includes('盐帮正文本轮不进'), 'A29 unfocused green body stays out');
  assert(widePick.text.includes('盐帮正文本轮不进'), 'A29 the same green body enters when the focus rotates onto it');
  assert(!narrowPick.text.includes('排除正文MARKER') && !narrowPick.text.includes('排除标题'), 'A31 exclude drops roster and body');
  assert(!narrowPick.text.includes('排除优先MARKER'), 'A31 exclude wins over forceInclude');
  assert(!narrowPick.text.includes('禁用正文不应出现'), 'disabled entries stay out');
  assert(!narrowPick.text.includes('聊天绿正文不应进'), 'A29 chat text does not open a green entry');
  assert(!narrowPick.text.includes('同名不应常驻MARKER'), 'uid wins over a shared book name');
  assert(!narrowPick.text.includes('正文里有北境但不该因此整条进入'), 'mentioning a focus in the body is not a key hit');
  assert(narrowPick.oversized === true, 'A32 a huge entry is flagged and kept');

  const pack = {
    worldbook: { entries },
    floorsTail: [{ floor: 0, text: '聊天专有词QQQ靠近文' }],
  };
  const narrowWorld = worldbookLedger();
  const beforeNarrow = calls.length;
  const narrowRun = await evolve.runEvolutionOnce({
    world: narrowWorld,
    pack,
    purpose: 'auto',
    span: { from: 0, to: 1 },
    settings,
  });
  const wideWorld = worldbookLedger();
  const wideRun = await evolve.runEvolutionOnce({
    world: wideWorld,
    pack,
    purpose: 'auto',
    span: { from: 0, to: 32 },
    settings,
  });
  const narrowPrompt = calls[beforeNarrow].prompt;
  const widePrompt = calls[beforeNarrow + 1].prompt;
  assert(narrowWorld.worldbookRotateCursor === 3 && wideWorld.worldbookRotateCursor === 12, 'cursor advances by K');
  assert(narrowPrompt.includes(huge) && widePrompt.includes(huge), 'A32 evolve prompts keep the whole constant entry');
  assert(narrowPrompt.includes('盐帮正文本轮不进') && widePrompt.includes('盐帮正文本轮不进'), 'A29 span dayDelta changes which green body is included');
  assert(!narrowPrompt.includes('聊天绿正文不应进') && widePrompt.includes('聊天绿正文不应进'), 'discovery count follows K independently of chat keywords');
  assert(narrowRun.usage && wideRun.usage, 'usage is returned with the evolve result');
  for (const key of ['worldbook', 'mvu', 'recent', 'total']) {
    assert(typeof narrowRun.usage[key] === 'number', `A30 usage.${key}`);
  }
  assert(narrowRun.usage.unit === 'token', 'A30 usage unit is token');
  assert(narrowRun.usage.mvu === 0, 'A30 missing MVU is zero');
  assert(narrowRun.usage.total === narrowRun.usage.worldbook + narrowRun.usage.mvu + narrowRun.usage.recent, 'A30 total sums the three blocks');
  assert(narrowRun.usage.worldbook > 8000 && narrowRun.usage.recent > 0, 'A30 worldbook and recent text are both counted');

  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  const ledger = loadWorld();
  const sample = worldbookLedger();
  ledger.regions = sample.regions;
  ledger.orgs = sample.orgs;
  ledger.factions = sample.factions;
  ledger.events = sample.events;
  ledger.worldbookRotateCursor = 0;
  await saveWorld(ledger);
  saveSettings({ worldbook: settings.worldbook });
  host.state.worldInfoEntries = entries;
  host.state.mvu = null;
  host.state.chat[0].mes += '聊天专有词QQQ';
  const done = await runImmediateEvolution();
  const prompt = calls.filter((call) => call.purpose === 'evolve').at(-1).prompt;
  assert(done.evolved === true && done.usage.mvu === 0, 'immediate evolve returns a zero MVU count');
  assert(prompt.includes(huge) && prompt.includes('常驻全文MARKER') && prompt.includes('世界书名册'), 'A28 constant and roster reach the live evolve prompt');
  assert(prompt.includes('焦点绿全文应进') && prompt.includes('盐帮正文本轮不进'), 'A29 live evolve scans only the first K foci');
  assert(!prompt.includes('排除正文MARKER') && !prompt.includes('聊天绿正文不应进'), 'A31 exclude and chat keywords stay out of the live prompt');
  const saved = loadWorld();
  assert(saved.worldbookRotateCursor === 3, 'cursor is stored on chatMetadata.shiju');
  const scan = saved.lastEvolutionCheckpoint.worldbookScan;
  assert(scan && scan.cursor === 0 && scan.scanWords.join(',') === '北境,南泽,西山', 'checkpoint stores the scan start, not the advanced cursor');
  const cursorAfter = saved.worldbookRotateCursor;
  const rerun = await rerunLastEvolution();
  const rerunPrompt = calls.filter((call) => call.purpose === 'evolve').at(-1).prompt;
  assert(rerun.evolved === true, 'rerun evolves on the same window');
  assert(rerunPrompt.includes('焦点绿全文应进') && rerunPrompt.includes('盐帮正文本轮不进'), 'rerun keeps the first round green entries');
  assert(loadWorld().worldbookRotateCursor === cursorAfter, 'rerun does not advance worldbookRotateCursor');
  const replay = loadWorld().lastEvolutionCheckpoint.worldbookScan;
  assert(replay && replay.cursor === 0 && replay.scanWords.join(',') === '北境,南泽,西山', 'rerun checkpoint keeps the same scan snapshot');
  assert(saved.meta.usage.worldbook === done.usage.worldbook && saved.meta.usage.total === done.usage.total, 'A30 usage is stored for the panel');
  assert(saved.meta.sources.softWarn === false && saved.meta.sources.truncated === false, 'A32 oversize is a soft warn, not a hard cut');
  const view = projectWorld(saved);
  assert(view.usage && view.usage.unit === 'token' && view.usage.mvu === 0 && view.softWarn === false, 'A30 readout exposes the usage contract');
  saveSettings({ ui: { theme: 'st' } });
  const kept = loadSettings().worldbook;
  assert(kept.exclude.includes('排除书') && kept.exclude.includes('双名单'), 'book exclude list survives an unrelated settings save');
  assert(kept.forceInclude.includes('常驻书') && kept.forceInclude.some((item) => item?.uid === 'wb-9'), 'book forceInclude list survives an unrelated settings save');
}

async function assertBaibai(assert, host, calls) {
  reset(host, [{ mes: '<bbs_start>1988/1/1</bbs_start>甲<bbs_end>1988/1/1</bbs_end>' }]);
  host.state.hasBaibai = true;
  globalThis.STBaiBaiBook = {
    getSnapshot() {
      return { state: { time: '三年前', location: '渡口' }, coverage: { complete: true } };
    },
    getHistory() {
      return { relativeText: '旧史' };
    },
    getInjectedHistory() {
      return { text: '旧史' };
    },
  };
  await bootstrapWorld();
  const boot = calls.filter((call) => call.purpose === 'bootstrap').at(-1);
  assert(boot.prompt.includes('旧史'), 'baibai history is in the build prompt');
  assert(!boot.prompt.includes('三年前'), 'snapshot time is not the clock');
  assert(loadWorld().storyClock.dayIndex === 0, 'bbs same day');
  assert(!String(loadWorld().storyClock.dateLabel).includes('三年前'), 'date label ignores state.time');
  const tagged = timetag.refreshTimeTag();
  assert(tagged.mode === 'baibai' && tagged.prompt === '', 'auto with the book clears shiju_timetag');
  const regex = host.getExtensionSettings().regex || [];
  assert(!regex.some((script) => script?.id === 'shiju-time-tag-hide'), 'baibai mode does not own the hide script');

  host.state.chat.push({ mes: '<bbs_start>1988/1/1</bbs_start>乙<bbs_end>1988/1/4</bbs_end>', swipe_id: 0 });
  const before = evolveCount(calls);
  const gate = await runAutomaticGate();
  assert(gate.evolved === true && loadWorld().storyClock.dayIndex === 3, 'bbs_end advances the clock');
  assert(evolveCount(calls) === before + 1, 'one baibai evolve');
  assert(!calls.at(-1).prompt.includes('三年前'), 'evolve prompt ignores state.time');

  reset(host, [{ mes: '无标签正文' }]);
  host.state.hasBaibai = true;
  globalThis.STBaiBaiBook = {
    getSnapshot() {
      return { state: { time: '三年前', location: '渡口' } };
    },
    getHistory() {
      return { text: '' };
    },
  };
  await bootstrapWorld();
  assert(loadWorld().storyClock.dayIndex === 0, 'state.time alone does not set a day');
  assert(loadWorld().meta.clockHint === 'missing-tag', 'no tag and no latestStoryTime is missing');
  assert(!String(loadWorld().storyClock.dateLabel).includes('三年'), 'label stays off state.time');
  const idle = evolveCount(calls);
  const skipped = await runAutomaticGate();
  assert(skipped.evolved === false && evolveCount(calls) === idle, 'state.time does not evolve');
}

async function assertShijuAndCustom(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  saveSettings({ timeSource: { mode: 'baibai' } });
  host.state.hasBaibai = false;
  await bootstrapWorld();
  const fallen = timetag.refreshTimeTag();
  assert(fallen.mode === 'shiju', 'stored baibai without the book falls back');
  assert(String(host.state.prompts.shiju_timetag?.value || '').includes('shiju_end'), 'fallback injects the shiju anchor');

  host.state.hasBaibai = true;
  globalThis.STBaiBaiBook = { getSnapshot() { return { state: { time: '三年前' } }; } };
  saveSettings({ timeSource: { mode: 'shiju' } });
  const stuck = timetag.refreshTimeTag();
  assert(stuck.mode === 'shiju', 'explicit shiju sticks while the book is present');
  const script = (host.getExtensionSettings().regex || []).find((item) => item?.id === 'shiju-time-tag-hide');
  assert(script && script.markdownOnly === true && script.promptOnly === false, 'hide regex is display-only');
  assert(String(script.findRegex).includes('shiju_end'), 'hide regex names the shiju tag');

  reset(host, [{
    mes: '<shiju_start>1999/1/1</shiju_start>忽略<shiju_end>1999/1/9</shiju_end><lore_time>1988/1/5</lore_time>',
  }]);
  saveSettings({ timeSource: { mode: 'custom', customTag: 'lore_time' } });
  await bootstrapWorld();
  const world = loadWorld();
  assert(String(world.storyClock.dateLabel).includes('1988/1/5'), 'custom tag is parsed');
  assert(!String(world.storyClock.dateLabel).includes('1999'), 'shiju tags are ignored in custom mode');
  assert(world.storyClock.dayIndex === 0, 'one custom date does not evolve');
  const customScript = (host.getExtensionSettings().regex || []).find((item) => item?.id === 'shiju-time-tag-hide');
  assert(customScript && String(customScript.findRegex).includes('lore_time'), 'custom hide regex');
  const before = evolveCount(calls);
  host.state.chat.push({ mes: '<shiju_end>1988/6/1</shiju_end>', swipe_id: 0 });
  const gate = await runAutomaticGate();
  assert(gate.evolved === false && evolveCount(calls) === before, 'a shiju-only floor does not move a custom clock');
}

function mesOf(host) {
  return host.state.chat.map((message) => message.mes);
}

async function assertInjectAndLifecycle(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '甲楼') }]);
  await bootstrapWorld();
  const world = loadWorld();
  world.events = [
    { id: 'm', kind: 'macro', title: '江左大旱', body: '河水见底', revealed: true },
    { id: 'n', kind: 'news', title: '北境粮草', body: '边镇缺粮', farAway: true },
    { id: 's', kind: 'secret', title: '密信', body: '不可见', revealed: false, knownMarked: false },
    { id: 'k', kind: 'secret', title: '已揭晓密约', body: '可以参考', revealed: true, knownMarked: true },
    { id: 'v', kind: 'macro', title: '帷幕内', body: '不该出现', veil: true },
  ];
  world.todayChanges = [
    { id: 'c', kind: 'news', title: '远方商路', body: '改道', farAway: true, revealed: true, updatedAtDay: 0 },
  ];
  const tagSlot = JSON.stringify(host.state.prompts.shiju_timetag);
  const floors = mesOf(host);
  await saveWorld(world);
  const macro = host.state.prompts.shiju_macro;
  assert(macro.depth === 4 && macro.position === 1, 'macro uses IN_CHAT at depth 4');
  assert(macro.value.includes(MACRO_DISCLAIMER), 'exact disclaimer');
  assert(macro.value.includes('勿强迫主角介入'), 'does not force the protagonist in');
  assert(macro.value.includes('发生于远方。北境粮草'), 'far event carries the marker');
  assert(macro.value.includes('发生于远方。远方商路'), 'far change carries the marker');
  assert(macro.value.includes('江左大旱') && macro.value.includes('已揭晓密约'), 'macro and revealed secret are in');
  assert(!macro.value.includes('密信') && !macro.value.includes('不可见') && !macro.value.includes('帷幕内'), 'veil stays out');
  assert(!macro.value.includes('必须写入') && !macro.value.includes('必须让主角介入'), 'no forced-prose instruction');
  assert(JSON.stringify(host.state.prompts.shiju_timetag) === tagSlot, 'world refresh preserves the time-tag prompt content');
  const refreshedTagSlot = host.state.prompts.shiju_timetag;
  inject.refreshInject();
  assert(host.state.prompts.shiju_timetag === refreshedTagSlot, 'inject itself does not touch the timetag key');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(floors), 'inject does not write mes');
  const preview = getInjectPreview();
  assert(preview.active === true && preview.omittedSecrets >= 2, 'preview counts omitted secrets');
  assert(preview.items.some((item) => item.title === '已揭晓密约' && item.kind === 'secret'), 'revealed secret keeps its kind');
  assert(!preview.items.some((item) => item.title === '密信'), 'preview hides veiled titles');

  saveSettings({ inject: { enabled: false } });
  assert(host.state.prompts.shiju_macro.value === '', 'inject switch clears the macro');
  assert(JSON.stringify(host.state.prompts.shiju_timetag) === tagSlot, 'inject switch leaves the time-tag prompt content unchanged');
  assert(getInjectPreview().active === false && getInjectPreview().previewText.includes('江左大旱'), 'preview remains while off');
  assert(loadWorld().plugin.enabled === true, 'inject switch does not freeze');
  host.state.chat.push({ mes: shiju('1988/1/3', '1988/1/3', '仍会推'), swipe_id: 0 });
  const offBefore = evolveCount(calls);
  const offGate = await runAutomaticGate();
  assert(offGate.evolved === true && evolveCount(calls) === offBefore + 1, 'inject off does not stop evolution');
  assert(host.state.prompts.shiju_macro.value === '', 'evolution does not turn injection back on');
  assert(host.state.chat[0].mes.includes('甲楼'), 'evolution does not delete floors');
  saveSettings({ inject: { enabled: true } });
  assert(String(host.state.prompts.shiju_macro.value).includes(MACRO_DISCLAIMER), 'inject switch restores the macro');

  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '甲楼') }]);
  await bootstrapWorld();
  const frozenFloor = host.state.chat[0].mes;
  await freezeWorld();
  const frozen = loadWorld();
  assert(frozen.plugin.enabled === false && typeof frozen.plugin.frozenAt === 'number', 'freeze stamps the ledger');
  assert(host.state.prompts.shiju_macro.value === '' && host.state.prompts.shiju_timetag.value === '', 'freeze clears both prompts');
  assert(host.state.chat[0].mes === frozenFloor, 'freeze keeps the floor');
  host.state.chat.push({ mes: shiju('1988/1/4', '1988/1/4', '乙楼'), swipe_id: 0 });
  const held = evolveCount(calls);
  const blocked = await runAutomaticGate();
  assert(blocked.evolved === false && blocked.reason === 'disabled', 'frozen gate does not evolve');
  assert(evolveCount(calls) === held, 'frozen gate makes no model call');
  assert(host.state.chat.length === 2 && host.state.chat[1].mes.includes('乙楼'), 'frozen chat keeps the new floor');
  const reopened = await reopenWorld();
  assert(reopened.evolved === false && evolveCount(calls) === held, 'reopen does not backfill');
  const resumed = loadWorld();
  assert(resumed.plugin.enabled === true && resumed.plugin.frozenAt == null, 'reopen clears the freeze');
  assert(resumed.storyClock.dayIndex === 3 && resumed.meta.lastEvolvedDayIndex === 3, 'reopen catches the clock without evolving');
  assert(resumed.evolutionLog.length === 0, 'reopen appends no log');
  assert(host.state.chat.length === 2 && host.state.chat[0].mes === frozenFloor, 'reopen does not delete floors');
  const idle = await runAutomaticGate();
  assert(idle.evolved === false && evolveCount(calls) === held, 'caught-up day does not evolve again');
  assert(String(host.state.prompts.shiju_macro.value).includes(MACRO_DISCLAIMER), 'reopen restores the macro');
  assert(String(host.state.prompts.shiju_timetag.value).includes('shiju_end'), 'reopen restores the timetag');

  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '留着') }]);
  await bootstrapWorld();
  const correcting = loadWorld();
  correcting.todayChanges = [{ id: 'old', kind: 'macro', title: '旧日', body: '昨天', updatedAtDay: 0, revealed: true }];
  correcting.events = [{ id: 'e2', kind: 'macro', title: '新日之事', body: '只在第二日', updatedAtDay: 2, revealed: true }];
  await saveWorld(correcting);
  const beforeCorrect = mesOf(host);
  const logBefore = loadWorld().evolutionLog.length;
  const fixed = await correctStoryDay({ choice: 'set', dayIndex: 2, dateLabel: '1988/1/3' });
  assert(fixed.ok === true && fixed.evolved === false, 'manual correction does not evolve');
  const corrected = loadWorld();
  assert(corrected.storyClock.dayIndex === 2 && corrected.storyClock.dateLabel.includes('1988/1/3'), 'correction writes the day');
  assert(corrected.meta.lastEvolvedDayIndex === 2, 'correction moves the evolved mark with the day');
  assert(corrected.evolutionLog.length === logBefore, 'correction does not append');
  assert(!corrected.todayChanges.some((item) => item.title === '旧日'), 'old day leaves today');
  assert(corrected.todayChanges.some((item) => item.title === '新日之事'), 'today is recalculated');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(beforeCorrect), 'correction does not edit floors');

  reset(host, [{ mes: shiju('1988/1/4', '1988/1/1', '倒退楼') }]);
  await bootstrapWorld();
  const conflicted = inspectStoryDay();
  assert(conflicted.promptRequired === true && conflicted.canRealign === false, 'fighting dates ask for a choice');
  assert(conflicted.prompt.includes('不能代为取值') && conflicted.choices.includes('keep'), 'conflict copy');
  const conflictDay = loadWorld().storyClock.dayIndex;
  const conflictCalls = calls.length;
  const kept = await correctStoryDay({ choice: 'keep' });
  assert(kept.ok === true && kept.dayIndex === conflictDay, 'keep leaves the plugin day');
  assert(loadWorld().evolutionLog.length === 0 && calls.length === conflictCalls, 'keep makes no model call');
  const refused = await correctStoryDay({ choice: 'realign' });
  assert(refused.ok === false && refused.reason === 'conflict' && calls.length === conflictCalls, 'realign refuses to guess');
  assert(inspectStoryDay().promptRequired === false, 'keep acknowledges the conflict');
  assert(host.state.chat[0].mes.includes('倒退楼'), 'conflict handling keeps the floor');

  reset(host, [{ mes: shiju('1988/1/5', '1988/1/5', '正文日') }]);
  await bootstrapWorld();
  const ahead = loadWorld();
  ahead.storyClock.dayIndex = 9;
  ahead.storyClock.dateLabel = '1988/1/20';
  ahead.meta.clockHint = 'conflict';
  await saveWorld(ahead);
  const drift = inspectStoryDay();
  assert(drift.canRealign === true && drift.prompt.includes('以正文为准重对齐'), 'prose can realign a drifted clock');
  const realignCalls = calls.length;
  const realignEvolve = evolveCount(calls);
  const realignFloors = mesOf(host);
  const aligned = await correctStoryDay({ choice: 'realign' });
  assert(aligned.ok === true && aligned.evolved === false && aligned.modelCalled === true, 'realign is one non-evolution call');
  assert(calls.length === realignCalls + 1 && calls.at(-1).purpose === 'realign', 'realign purpose');
  assert(evolveCount(calls) === realignEvolve, 'realign is not an evolve call');
  assert(loadWorld().storyClock.dayIndex === 0 && loadWorld().evolutionLog.length === 0, 'realign follows the prose and appends nothing');
  assert(loadWorld().todayChanges.some((item) => item.title === '跨日变更'), 'realign recalculates today');
  assert(JSON.stringify(mesOf(host)) === JSON.stringify(realignFloors), 'realign does not edit floors');

  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  const bulky = loadWorld();
  bulky.events = Array.from({ length: 40 }, (_, index) => ({
    id: `bulk-${index}`,
    kind: 'macro',
    title: `事态${index}`,
    body: '长'.repeat(80),
    revealed: true,
  }));
  await saveWorld(bulky);
  const fitted = host.state.prompts.shiju_macro.value;
  assert(Array.from(fitted).length <= 1500, 'macro stays within 1500');
  assert(fitted.includes(MACRO_DISCLAIMER) && getInjectPreview().truncated === true, 'budget keeps the disclaimer');
}

async function expectRefuse(assert, fn) {
  try {
    await fn();
  } catch (error) {
    assert(error.code === 'SHIJU_INTERVENE_REFUSED', `SHIJU_INTERVENE_REFUSED ≠ ${error.code}: ${error.message}`);
    return;
  }
  assert(false, 'expected SHIJU_INTERVENE_REFUSED');
}

async function assertIntervene(assert, host, calls, control) {
  const world = createEmptyWorld();
  world.plugin.enabled = true;
  world.meta.builtFingerprint = 'intervene';
  world.meta.modelCallCount = 2;
  world.storyClock = { dateLabel: '甲辰春', dayIndex: 4, source: 'test', lastConfirmedAtFloor: 1 };
  world.events = [
    { id: 'e1', kind: 'macro', title: '大旱', body: '河水见底', revealed: true },
    { id: 'e2', kind: 'macro', title: '边镇', body: '另一条', revealed: true },
    { id: 'sec', kind: 'secret', title: '密信', body: '不可改', revealed: false },
    { id: 'known', kind: 'secret', title: '已揭晓密约', body: '原密文', revealed: true, knownMarked: true },
  ];
  world.todayChanges = [
    { id: 'c1', kind: 'news', title: '商路', body: '改道', revealed: true, farAway: true, producedByEvolutionId: 'evo-keep' },
    { id: 'csec', kind: 'secret', title: '暗线', body: '不能改', revealed: false, secret: true },
  ];
  world.evolutionLog = [{ id: 'already' }];
  world.lastEvolutionCheckpoint = { evolutionId: 'already', marker: 'keep' };
  await saveWorld(world);

  const callsBefore = calls.length;
  const savedManual = await saveFactManual({
    kind: 'event',
    id: 'e1',
    patch: { title: '大旱已解', body: '河已复流', revealed: true, kind: 'secret' },
  });
  assert(savedManual.modelCalls === 0 && savedManual.title === '大旱已解' && savedManual.body === '河已复流', 'manual save returns the row');
  assert(calls.length === callsBefore, 'manual save makes no model call');
  let ledger = loadWorld();
  const edited = ledger.events.find((item) => item.id === 'e1');
  assert(edited.title === '大旱已解' && edited.body === '河已复流' && edited.kind === 'macro', 'manual write keeps kind');
  assert(edited.evidence === '用户修正', 'manual save records evidence');
  assert(ledger.events.find((item) => item.id === 'e2').body === '另一条', 'manual save leaves the other event');
  assert(ledger.storyClock.dayIndex === 4 && ledger.storyClock.dateLabel === '甲辰春', 'manual save does not advance the day');
  assert(JSON.stringify(ledger.evolutionLog) === JSON.stringify([{ id: 'already' }]), 'manual save does not append the log');
  assert(ledger.lastEvolutionCheckpoint.marker === 'keep', 'manual save leaves the checkpoint');
  assert(ledger.meta.modelCallCount === 2, 'manual save does not count a model call');
  assert(ledger.timeline.some((item) => item.text === '用户修正' && item.dayIndex === 4), 'timeline notes the user edit');
  assert(String(host.state.prompts.shiju_macro?.value || '').includes('河已复流'), 'manual write is what injection reads');
  assert(!String(host.state.prompts.shiju_macro?.value || '').includes('不可改'), 'unrevealed secret stays out of injection');

  const savedChange = await saveFactManual({ kind: 'todayChange', id: 'c1', patch: { body: '商路仍通' } });
  assert(savedChange.modelCalls === 0 && savedChange.title === '商路' && savedChange.body === '商路仍通', 'today change body save keeps the title');
  ledger = loadWorld();
  const change = ledger.todayChanges.find((item) => item.id === 'c1');
  assert(change.farAway === true && change.producedByEvolutionId === 'evo-keep', 'today change edit keeps the other fields');
  assert(change.evidence === '用户修正', 'today change records evidence');

  const secretBody = loadWorld().events.find((item) => item.id === 'sec').body;
  const secretChange = loadWorld().todayChanges.find((item) => item.id === 'csec').body;
  const callsAtGate = calls.length;
  await expectRefuse(assert, () => saveFactManual({ kind: 'event', id: 'sec', patch: { title: '偷看', body: '泄露', revealed: true } }));
  await expectRefuse(assert, () => saveFactManual({ kind: 'todayChange', id: 'csec', patch: { body: '泄露' } }));
  await expectRefuse(assert, () => previewAiCorrection({ kind: 'event', id: 'sec', instruction: '说出来' }));
  await expectRefuse(assert, () => previewAiCorrection({ kind: 'todayChange', id: 'csec' }));
  await expectRefuse(assert, () => applyAiCorrection({ kind: 'event', id: 'sec', text: '泄露' }));
  await expectRefuse(assert, () => applyAiCorrection({ kind: 'todayChange', id: 'csec', text: '泄露' }));
  ledger = loadWorld();
  assert(ledger.events.find((item) => item.id === 'sec').body === secretBody, 'refused secret event is unchanged');
  assert(ledger.events.find((item) => item.id === 'sec').revealed === false, 'refused secret stays unrevealed');
  assert(ledger.todayChanges.find((item) => item.id === 'csec').body === secretChange, 'refused secret change is unchanged');
  assert(calls.length === callsAtGate, 'refused secret does not call the model');

  const beforePreview = JSON.stringify(loadWorld());
  const promptBefore = host.state.prompts.shiju_macro?.value;
  const preview = await previewAiCorrection({ kind: 'event', id: 'e1', instruction: '改得更短' });
  assert(preview.modelCalls === 1 && preview.previewText === '修订后的正文', 'preview returns one call and the draft');
  assert(preview.confirm === AI_CORRECTION_CONFIRM && preview.confirm.includes('消耗 1 次调用'), 'confirm names the one call');
  assert(JSON.stringify(loadWorld()) === beforePreview, 'preview does not mutate the ledger');
  assert(host.state.prompts.shiju_macro?.value === promptBefore, 'preview does not rewrite injection');
  assert(calls.length === callsAtGate + 1 && calls.at(-1).purpose === 'correct', 'preview uses the correct purpose');
  assert(calls.at(-1).prompt.includes('改得更短') && calls.at(-1).prompt.includes('河已复流'), 'preview sends this one fact');
  assert(calls.at(-1).systemPrompt.includes('单条修正') && !calls.at(-1).systemPrompt.includes('后台演进器'), 'preview prompt is not an evolution');
  assert(loadWorld().meta.modelCallCount === 2, 'preview does not store a model count');

  const applied = await applyAiCorrection({ kind: 'event', id: 'e1', text: '  手改后的河  ' });
  assert(applied.modelCalls === 0 && applied.body === '  手改后的河  ' && applied.title === '大旱已解', 'apply writes the edited draft and spends nothing');
  assert(calls.length === callsAtGate + 1, 'apply makes no model call');
  ledger = loadWorld();
  assert(ledger.events.find((item) => item.id === 'e1').body === '  手改后的河  ', 'apply hard-writes the body');
  assert(ledger.events.find((item) => item.id === 'e2').body === '另一条', 'apply leaves the other event');
  assert(ledger.storyClock.dayIndex === 4, 'apply does not advance the day');
  assert(JSON.stringify(ledger.evolutionLog) === JSON.stringify([{ id: 'already' }]), 'apply does not append the log');
  assert(ledger.lastEvolutionCheckpoint.marker === 'keep', 'apply leaves the checkpoint');
  assert(ledger.meta.modelCallCount === 2, 'apply does not count a model call');
  assert(String(host.state.prompts.shiju_macro?.value || '').includes('手改后的河'), 'applied text is what injection reads');

  const beforeBoom = JSON.stringify(loadWorld());
  control.boom = true;
  let boomCode = '';
  try {
    await previewAiCorrection({ kind: 'todayChange', id: 'c1' });
  } catch (error) {
    boomCode = error.code;
  }
  assert(boomCode === 'SHIJU_MODEL_FAILED' && control.boom === false, 'failed preview surfaces the model error');
  assert(JSON.stringify(loadWorld()) === beforeBoom, 'failed preview leaves the ledger');

  const known = await saveFactManual({ kind: 'event', id: 'known', patch: { body: '可以改的密约' } });
  assert(known.body === '可以改的密约' && known.modelCalls === 0, 'revealed secret can be saved');
  await expectRefuse(assert, () => applyAiCorrection({ kind: 'event', id: 'e1', text: '   ' }));
  assert(loadWorld().events.find((item) => item.id === 'e1').body === '  手改后的河  ', 'empty adopt does not wipe the body');
  await expectRefuse(assert, () => saveFactManual({ kind: 'fact', id: 'e1', patch: { body: '不行' } }));
  await expectRefuse(assert, () => saveFactManual({ kind: 'event', id: 'missing', patch: { body: '没有' } }));

  host.state.chatMetadata.shiju = null;
  await expectRefuse(assert, () => previewAiCorrection({ kind: 'event', id: 'e1' }));
  assert(calls.filter((call) => call.purpose === 'correct').length === 2, 'only the real preview and the failed one called');
}

async function assertPreviewConcurrentWrites(assert, host) {
  const backend = host.generateViaBackend;
  const changes = [
    { name: 'freeze', run: () => freezeWorld() },
    { name: 'manual edit', run: () => saveFactManual({ kind: 'event', id: 'preview-event', patch: { body: '用户刚保存的新正文' } }) },
    { name: 'automatic evolution', run: () => {
      host.state.chat.push({ mes: shiju('1988/1/2'), swipe_id: 0 });
      return runAutomaticGate();
    } },
  ];
  for (const change of changes) {
    for (const failModel of [false, true]) {
      reset(host, [{ mes: shiju('1988/1/1') }]);
      await bootstrapWorld();
      const world = loadWorld();
      world.events = [{ id: 'preview-event', kind: 'macro', title: '待修正事件', body: '旧正文' }];
      await saveWorld(world);
      let finish;
      let reject;
      let started;
      let previewCalls = 0;
      const ready = new Promise((resolve) => { started = resolve; });
      host.generateViaBackend = (request) => {
        if (request.purpose !== 'correct') return backend(request);
        previewCalls += 1;
        started();
        return new Promise((resolve, fail) => { finish = resolve; reject = fail; });
      };
      try {
        const pending = previewAiCorrection({ kind: 'event', id: 'preview-event' })
          .then((result) => ({ result }), (error) => ({ error }));
        await ready;
        const changed = await change.run();
        assert(changed.ok, `${change.name}: concurrent operation succeeds`);
        const afterChange = JSON.stringify(loadWorld());
        const promptsAfterChange = JSON.stringify(host.state.prompts);
        const savesAfterChange = host.state.savedMetadata;
        if (failModel) reject(new Error('模型失败'));
        else finish('基于旧正文生成的修订稿');
        const outcome = await pending;
        assert(JSON.stringify(loadWorld()) === afterChange, `${change.name}: preview preserves concurrent changes (model failure=${failModel})`);
        assert(host.state.savedMetadata === savesAfterChange, `${change.name}: preview never saves a snapshot`);
        assert(JSON.stringify(host.state.prompts) === promptsAfterChange, `${change.name}: preview preserves current injection`);
        assert(previewCalls === 1 && !outcome.result, `${change.name}: no stale draft returned or automatic retry`);
        assert(outcome.error?.code === (failModel ? 'SHIJU_MODEL_FAILED' : 'SHIJU_INTERVENE_REFUSED'), `${change.name}: expected preview rejection`);
        if (!failModel) assert(outcome.error.message.includes('重新生成'), `${change.name}: stale preview explains how to retry`);
      } finally {
        host.generateViaBackend = backend;
      }
    }
  }
}

function hideScript(host) {
  return (host.getExtensionSettings().regex || []).find((script) => script?.id === 'shiju-time-tag-hide');
}

/** A26: shiju writes depth 0, custom and baibai clear that key, auto follows the book. */
async function assertTimeTagModes(assert, host) {
  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '甲') }]);
  saveSettings({ timeSource: { mode: 'shiju' } });
  await bootstrapWorld();
  const shijuSlot = host.state.prompts.shiju_timetag;
  assert(shijuSlot?.depth === 0 && String(shijuSlot.value).includes('shiju_start') && String(shijuSlot.value).includes('shiju_end'), 'A26 shiju mode writes the anchor at depth 0');
  const shijuHide = hideScript(host);
  assert(shijuHide && shijuHide.markdownOnly === true && shijuHide.promptOnly === false && String(shijuHide.findRegex).includes('shiju_end'), 'A26 shiju hide regex is display-only');

  saveSettings({ timeSource: { mode: 'custom', customTag: 'lore_time' } });
  const custom = timetag.refreshTimeTag();
  assert(custom.mode === 'custom' && custom.prompt === '' && custom.hidden === true, 'A26 custom clears shiju_timetag and hides its own tag');
  assert(host.state.prompts.shiju_timetag.value === '' && host.state.prompts.shiju_timetag.depth === 0, 'A26 custom prompt value is empty at depth 0');
  const customHide = hideScript(host);
  assert(customHide && String(customHide.findRegex).includes('lore_time') && !String(customHide.findRegex).includes('shiju_'), 'A26 custom hide regex is not the shiju tag');

  host.state.hasBaibai = true;
  globalThis.STBaiBaiBook = { getSnapshot() { return { state: { time: '三年前' } }; } };
  saveSettings({ timeSource: { mode: 'baibai' } });
  const book = timetag.refreshTimeTag();
  assert(book.mode === 'baibai' && book.prompt === '' && book.hidden === false, 'A26 baibai clears the timetag and does not own the hide regex');
  assert(host.state.prompts.shiju_timetag.value === '', 'A26 baibai prompt value stays empty');
  assert(!hideScript(host), 'A26 baibai hide script is gone');

  saveSettings({ timeSource: { mode: 'auto' } });
  const autoBook = timetag.refreshTimeTag();
  assert(autoBook.mode === 'baibai' && autoBook.prompt === '' && autoBook.hidden === false, 'A26 auto with the book stays on baibai');

  host.state.hasBaibai = false;
  delete globalThis.STBaiBaiBook;
  const restored = timetag.refreshTimeTag();
  assert(restored.mode === 'shiju' && restored.hidden === true, 'A26 auto without the book returns to shiju');
  assert(host.state.prompts.shiju_timetag.depth === 0 && String(host.state.prompts.shiju_timetag.value).includes('shiju_end'), 'A26 restored shiju timetag is depth 0');
}

/** A27: regenerate / regen lock every evolution entry. */
async function assertGeneratingHardGate(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1') }]);
  await bootstrapWorld();
  host.state.chat.at(-1).mes += '新增剧情';
  await runImmediateEvolution();
  const before = evolveCount(calls);
  const logId = loadWorld().evolutionLog.at(-1).id;

  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'regenerate');
  assert(isGeneratingTip() === true, 'A27 regenerate locks the tip');
  const gate = await runAutomaticGate();
  const immediate = await runImmediateEvolution();
  const rerun = await rerunLastEvolution();
  assert(gate.evolved === false && gate.reason === 'generating', 'A27 generating tip blocks the automatic gate');
  assert(immediate.evolved === false && immediate.reason === 'generating', 'A27 generating tip blocks immediate evolution');
  assert(rerun.evolved === false && rerun.reason === 'generating', 'A27 generating tip blocks rerun');
  assert(evolveCount(calls) === before && loadWorld().evolutionLog.at(-1).id === logId, 'A27 locked tip does not push');

  host.eventSource.emit(host.event_types.GENERATION_STOPPED);
  await settle();
  assert(isGeneratingTip() === false, 'A27 stop clears a regenerate lock');
  assert(evolveCount(calls) === before && loadWorld().evolutionLog.at(-1).id === logId, 'A27 settling regenerate on the same day does not push');

  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'regen');
  assert(isGeneratingTip() === true, 'A27 regen alias locks the tip');
  const during = await runAutomaticGate();
  assert(during.reason === 'generating' && evolveCount(calls) === before, 'A27 regen alias blocks the gate');
  host.eventSource.emit(host.event_types.GENERATION_ENDED);
  await settle();
  assert(isGeneratingTip() === false, 'A27 generation end clears the tip');
  assert(evolveCount(calls) === before && loadWorld().evolutionLog.at(-1).id === logId, 'A27 regen settle on the same day does not push');
}

/** A27: reroll, swipe, and delete each push at most once. Reconcile does not append. */
async function assertNoDoublePush(assert, host, calls) {
  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '开局') }]);
  await bootstrapWorld();
  host.state.chat.push({ mes: shiju('1988/1/4', '1988/1/4', '后'), swipe_id: 0 });
  await runAutomaticGate();
  const anchored = evolveCount(calls);
  const beforeId = loadWorld().evolutionLog.at(-1).id;
  assert(loadWorld().evolutionLog.length === 1, 'A27 one anchor before reroll');

  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'regenerate');
  host.state.chat[1].mes = shiju('1988/1/8', '1988/1/8', '重写');
  host.eventSource.emit(host.event_types.GENERATION_ENDED);
  host.eventSource.emit(host.event_types.CHARACTER_MESSAGE_RENDERED);
  await settle();
  assert(evolveCount(calls) === anchored + 1, 'A27 reroll evolves once');
  assert(loadWorld().evolutionLog.length === 1 && loadWorld().evolutionLog.at(-1).id !== beforeId, 'A27 reroll replaces the anchor');
  const rolledId = loadWorld().evolutionLog.at(-1).id;
  host.eventSource.emit(host.event_types.GENERATION_ENDED);
  host.eventSource.emit(host.event_types.CHARACTER_MESSAGE_RENDERED);
  await settle();
  assert(evolveCount(calls) === anchored + 1 && loadWorld().evolutionLog.at(-1).id === rolledId, 'A27 reroll settle does not push twice');

  const swipeAt = evolveCount(calls);
  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'swipe');
  host.state.chat[1].swipe_id = 1;
  host.state.chat[1].mes = shiju('1988/1/12', '1988/1/12', '另一刷');
  host.eventSource.emit(host.event_types.MESSAGE_SWIPED, 1);
  await settle();
  assert(isGeneratingTip() === true && evolveCount(calls) === swipeAt && loadWorld().evolutionLog.at(-1).id === rolledId, 'A27 swipe during generation does not push');
  host.eventSource.emit(host.event_types.GENERATION_ENDED);
  host.eventSource.emit(host.event_types.MESSAGE_SWIPED, 1);
  await settle();
  assert(evolveCount(calls) === swipeAt + 1 && loadWorld().evolutionLog.length === 1, 'A27 swipe evolves once');
  const swipedId = loadWorld().evolutionLog.at(-1).id;
  host.eventSource.emit(host.event_types.MESSAGE_SWIPED, 1);
  await settle();
  assert(evolveCount(calls) === swipeAt + 1 && loadWorld().evolutionLog.at(-1).id === swipedId, 'A27 a second swipe notice does not push again');

  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '开局') }]);
  await bootstrapWorld();
  host.state.chat.push({ mes: shiju('1988/1/2', '1988/1/2', '次日'), swipe_id: 0 });
  await runAutomaticGate();
  host.state.chat.push({ mes: shiju('1988/1/4', '1988/1/4', '再后'), swipe_id: 0 });
  await runAutomaticGate();
  assert(loadWorld().evolutionLog.length === 2, 'A27 two anchors before delete');
  const keptId = loadWorld().evolutionLog[0].id;
  const deleteAt = evolveCount(calls);
  host.state.chat.pop();
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  await settle();
  const dropped = loadWorld().evolutionLog;
  assert(dropped.length === 1 && dropped[0].id === keptId, 'A27 delete drops the later anchor and does not append');
  assert(evolveCount(calls) === deleteAt, 'A27 delete of the tip does not evolve again');

  host.state.chat.push({ mes: shiju('1988/1/6', '1988/1/6', '删后再来'), swipe_id: 0 });
  await runAutomaticGate();
  const midAt = evolveCount(calls);
  host.state.chat.splice(1, 1);
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  await settle();
  assert(evolveCount(calls) === midAt + 1 && loadWorld().evolutionLog.length === 1, 'A27 deleting an earlier floor evolves once');
  const onceId = loadWorld().evolutionLog[0].id;
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  await settle();
  assert(evolveCount(calls) === midAt + 1 && loadWorld().evolutionLog[0].id === onceId, 'A27 a repeated delete does not push again');

  reset(host, [{ mes: shiju('1988/1/1', '1988/1/1', '留着') }]);
  await bootstrapWorld();
  host.state.chat.at(-1).mes += '新增剧情';
  await runImmediateEvolution();
  const quietId = loadWorld().evolutionLog[0].id;
  const quietAt = evolveCount(calls);
  host.state.chat.push({ mes: shiju('1988/1/1', '1988/1/1', '同日'), swipe_id: 0 });
  host.state.chat.pop();
  host.eventSource.emit(host.event_types.MESSAGE_DELETED);
  await settle();
  assert(loadWorld().evolutionLog.length === 1 && loadWorld().evolutionLog[0].id === quietId, 'A27 reconcile does not append when the anchor still holds');
  assert(evolveCount(calls) === quietAt, 'A27 a no-op delete makes no model call');
}
