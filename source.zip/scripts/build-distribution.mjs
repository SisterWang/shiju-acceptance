import { build } from 'esbuild';
import { readFile, mkdir, copyFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const out=resolve(process.argv[2] || 'dist');
await mkdir(out,{recursive:true});
await build({entryPoints:['index.js'],outfile:resolve(out,'index.js'),bundle:true,format:'esm',platform:'browser',target:'es2022',minify:false,plugins:[{name:'host-and-worker-paths',setup(b){
 b.onResolve({filter:/^(\.\.\/){3,}/},args=>({path:args.path,external:true}));
 b.onLoad({filter:/src\/modules\/template\/index\.js$/},async args=>({contents:(await readFile(args.path,'utf8')).replace("../../../vendor/template-worker.js","./template-worker.js"),loader:'js'}));
}}]});
for(const name of ['style.css','manifest.json','LICENSE']) await copyFile(name,resolve(out,name));
await copyFile('vendor/template-worker.js',resolve(out,'template-worker.js'));
