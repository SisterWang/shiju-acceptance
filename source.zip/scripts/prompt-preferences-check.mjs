import { strict as nodeAssert } from 'node:assert';
import { createHash } from 'node:crypto';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { captureChatScope } from '../src/chatScope.js';
import { loadSettings, saveSettings, loadWorld, saveWorld, loadPreferences, migrateWorld } from '../src/store/index.js';
import { BAIBAI_JAILBREAK, BAIBAI_SOURCE } from '../src/prompts/baibai-jailbreak.js';
import { EVOLUTION_PRESETS, effectivePreferences, preferencesPending } from '../src/preferences.js';
import { saveEvolutionPreferences } from '../src/modules/preferences/index.js';
import { captureModelConfig, generateViaST } from '../src/modules/model/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { runImmediateEvolution, runAutomaticGate, rerunLastEvolution, clearEvolutionHold } from '../src/modules/timeGate/index.js';
import { correctStoryDay, freezeWorld, reopenWorld } from '../src/modules/lifecycle/index.js';
import { previewAiCorrection } from '../src/modules/intervene/index.js';
import { minSubset, applySubset } from '../src/modules/commit/subset.js';
import { refreshInject } from '../src/modules/inject/index.js';

const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return { promise, resolve }; };
const msg = day => ({ mes: `剧情<shiju_end>2026/1/${day}</shiju_end>` });
const pref = (mode, customText) => saveEvolutionPreferences({ preferences: { mode, ...(customText == null ? {} : { customText }) } });
const pending = () => preferencesPending(loadWorld(), effectivePreferences(loadPreferences()));
async function setup(build = true) {
  const host = createMemoryHost({ chat: [msg(1)], chatMetadata: { other: { untouched: true } }, settings: { timeSource: { mode: 'shiju' } } });
  const calls = [];
  host.generateViaBackend = async request => { calls.push(request); return request.purpose === 'correct' ? '单条修正' : JSON.stringify({ regions: [{ name: '边境' }], events: [{ id: 'e', title: '商贸', kind: 'macro', body: '商贸原文' }], todayChanges: [] }); };
  setHost(host); clearEvolutionHold();
  if (build) await bootstrapWorld();
  return { host, calls };
}
export async function runPromptPreferencesChecks() {
  let checks = 0;
  const assert = (ok, label) => { checks++; nodeAssert.ok(ok, label); };
  const rejects = async (task, code, label) => { let error; try { await task(); } catch (caught) { error = caught; } assert(error?.code === code, label); };
  const hash = text => createHash('sha256').update(text, 'utf8').digest('hex');
  const fixedHash = 'a542ee60ae52efa1605e7e4594de635c4750c4ed69f1c351ad46e0f71e55299d';
  assert(Buffer.byteLength(BAIBAI_JAILBREAK) === 3299 && hash(BAIBAI_JAILBREAK) === fixedHash && BAIBAI_SOURCE.sha256 === fixedHash, 'vendored runtime prompt matches pinned upstream bytes');
  {
    const { calls } = await setup(false);
    assert(loadSettings().model.jailbreakMode === 'builtin' && loadSettings().model.responseLength === null, 'global defaults preserve ST response length');
    for (const purpose of ['bootstrap', 'evolve', 'realign', 'correct']) {
      await generateViaST({ purpose, prompt: 'DATA', systemPrompt: 'FIXED' });
      const request = calls.at(-1);
      assert(request.messages[0].content === BAIBAI_JAILBREAK && request.messages[0].role === 'system', `${purpose} sends verbatim first system message`);
      assert(request.messages.filter(m => m.content === BAIBAI_JAILBREAK).length === 1, 'builtin included exactly once');
      assert(request.messages[1].content === 'FIXED' && request.messages.at(-1).role === 'user', 'fixed task and user data retain order');
      assert(request.messages.length === (purpose === 'correct' ? 3 : 4), 'single correction does not inherit evolution preference');
      assert(!('responseLength' in request), 'follow mode omits responseLength');
    }
    const literal = '  自定义原样文本\r\n第二行\n  ';
    saveSettings({ model: { jailbreakMode: 'custom', customText: literal, responseLength: 16384 } });
    await generateViaST({ purpose: 'evolve', prompt: 'DATA', systemPrompt: 'FIXED' });
    assert(calls.at(-1).messages[0].content === literal && calls.at(-1).responseLength === 16384, 'custom text preserves all whitespace and requested response limit');
    saveSettings({ model: { jailbreakMode: 'off' } });
    await generateViaST({ purpose: 'correct', prompt: 'DATA', systemPrompt: 'FIXED' });
    assert(calls.at(-1).messages.length === 2 && calls.at(-1).messages[0].content === 'FIXED', 'off omits wrapper');
    assert(loadSettings().model.customText === literal, 'switching off retains custom text');
    saveSettings({ model: { jailbreakMode: 'builtin' } });
    await generateViaST({ purpose: 'correct', prompt: 'DATA' });
    assert(hash(calls.at(-1).messages[0].content) === fixedHash, 'return to default restores exact original');
    const before = JSON.stringify(loadSettings());
    await rejects(() => saveSettings({ model: { jailbreakMode: 'custom', customText: ' \n' } }), 'SHIJU_MODEL_SETTINGS', 'blank custom wrapper is rejected');
    for (const value of [0, -1, 1.2, Infinity, Number.MAX_SAFE_INTEGER + 1, '16384']) await rejects(() => saveSettings({ model: { responseLength: value } }), 'SHIJU_MODEL_SETTINGS', 'invalid length is rejected without coercion');
    assert(JSON.stringify(loadSettings()) === before, 'validation never overwrites saved settings');
    const snapshot = captureModelConfig('evolve'); saveSettings({ model: { jailbreakMode: 'off', responseLength: null } });
    await generateViaST({ purpose: 'evolve', prompt: 'DATA', modelConfig: snapshot });
    assert(calls.at(-1).messages[0].content === BAIBAI_JAILBREAK && calls.at(-1).responseLength === 16384, 'captured config survives later global changes');
  }
  {
    const { host, calls } = await setup(false);
    await pref('custom', '只发展生态和水利，不安排王朝战争');
    assert(loadWorld() === null && calls.length === 0, 'prebuild preference does not create ledger or call model');
    assert(host.state.chatMetadata.other.untouched, 'preference save merges unrelated metadata');
    await bootstrapWorld();
    const message = calls[0].messages[2].content;
    assert(message.includes('只发展生态和水利'), 'bootstrap uses configured preference');
    assert(EVOLUTION_PRESETS.every(item => !message.includes(item.text)), 'custom preference fully replaces every builtin style');
    assert(message.includes('事件 ID') && calls[0].messages[1].content.includes('只输出一个 JSON'), 'custom mode retains fixed rules and task protocol');
    assert(!pending() && (await runImmediateEvolution()).reason === 'no-increment', 'bootstrap consumes the supplied preference');
    await pref('steady');
    assert(loadPreferences().customText.includes('生态和水利'), 'preset selection preserves inactive custom text');
    const beforeCalls = calls.length;
    await runAutomaticGate();
    assert(calls.length === beforeCalls && pending(), 'preference change does not bypass automatic day gate');
    assert((await runImmediateEvolution()).evolved, 'preference alone can drive immediate evolution');
    assert(calls.at(-1).prompt.includes('本轮只有演进偏好变化') && !pending(), 'preference-only operation is explicit and consumed on success');
    assert((await runImmediateEvolution()).reason === 'no-increment', 'unchanged preference does not call again');
    await pref('steady', '修改未启用的文本');
    assert(!pending(), 'inactive custom text is ignored by pending comparison');
    await pref('steady'); assert(!pending(), 'saving identical preferences is inert');
    await rejects(() => pref('custom', '\n '), 'SHIJU_PREFERENCES_INVALID', 'empty custom preference never falls back');
    await pref('custom', '自定义替换模式');
    await previewAiCorrection({ kind: 'event', id: 'e' });
    assert(pending() && !calls.at(-1).messages.some(m => m.content.includes('自定义替换模式')), 'AI correction neither injects nor consumes preference');
    await correctStoryDay({ choice: 'set', dayIndex: 0, dateLabel: '2026/1/1' });
    await freezeWorld(); await reopenWorld();
    assert(pending(), 'manual day correction and reopen do not consume preference');
    const applied = loadWorld().appliedPreferences;
    let failures = 0; host.generateViaBackend = async () => { failures++; throw new Error('模拟接口拒绝'); };
    assert(!(await runImmediateEvolution()).ok && failures === 1 && pending(), 'failed call does not consume or automatically retry');
    assert(JSON.stringify(loadWorld().appliedPreferences) === JSON.stringify(applied), 'failed call preserves applied snapshot');
    host.generateViaBackend = async request => { calls.push(request); return '{}'; };
    assert((await runImmediateEvolution()).evolved && !pending(), 'failed preference can be retried');
    await pref('intrigue'); await rerunLastEvolution();
    assert(!pending() && calls.at(-1).messages[2].content.includes(EVOLUTION_PRESETS[2].text), 'rerun uses and consumes current preference');
    const savedSnapshot = minSubset(loadWorld());
    await pref('upheaval'); host.state.chat.push(msg(2));
    assert((await correctStoryDay({ choice: 'realign' })).ok && !pending(), 'realignment consumes current preference');
    const world = loadWorld(); applySubset(world, savedSnapshot); await saveWorld(world);
    assert(loadPreferences().mode === 'upheaval' && pending(), 'rollback restores consumed snapshot but keeps current user choice');
    const injected = refreshInject().text;
    assert(!injected.includes('nvwa_standalone_core') && !injected.includes('【当前演进偏好】'), 'wrappers and preferences never enter macro injection');
    const exported = JSON.parse(JSON.stringify(host.state.chatMetadata));
    setHost(createMemoryHost({ chatMetadata: exported }));
    assert(loadPreferences().mode === 'upheaval' && pending(), 'export and reload preserve preference and consumption state');
    const legacy = { ...loadWorld() }; delete legacy.appliedPreferences;
    assert(!preferencesPending(migrateWorld(legacy), effectivePreferences()), 'legacy default is already consumed');
  }
  {
    const { host, calls } = await setup();
    for (const item of EVOLUTION_PRESETS) {
      await pref(item.id);
      await generateViaST({ purpose: 'evolve', prompt: 'DATA', systemPrompt: 'FIXED' });
      const text = calls.at(-1).messages[2].content;
      assert(text.includes(item.text) && EVOLUTION_PRESETS.filter(other => other !== item).every(other => !text.includes(other.text)), `${item.id} only injects its own direction`);
    }
    await pref('custom', 'A聊天的方向');
    const scope = captureChatScope(), a = host.state.chatMetadata;
    host.state.chatId = 'B'; host.state.chatMetadata = {}; host.eventSource.emit(host.event_types.CHAT_CHANGED);
    assert(loadPreferences().mode === 'natural', 'new chat does not inherit previous chat preference');
    await rejects(() => saveEvolutionPreferences({ chatScope: scope, preferences: { mode: 'steady' } }), 'SHIJU_CHAT_CHANGED', 'stale preference editor cannot write B');
    await pref('intrigue'); const b = host.state.chatMetadata;
    host.state.chatId = 'preview'; host.state.chatMetadata = a; host.eventSource.emit(host.event_types.CHAT_CHANGED);
    await rejects(() => saveEvolutionPreferences({ chatScope: scope, preferences: { mode: 'steady' } }), 'SHIJU_CHAT_CHANGED', 'return to A does not revive old editor');
    assert(loadPreferences().customText === 'A聊天的方向' && b.shijuPreferences.mode === 'intrigue', 'chat metadata remains isolated');
    const started = deferred(), response = deferred();
    host.generateViaBackend = request => { calls.push(request); started.resolve(); return response.promise; };
    const operation = runImmediateEvolution(); await started.promise;
    await rejects(() => pref('steady'), 'SHIJU_WORLD_BUSY', 'direct preference save is blocked during world turn');
    saveSettings({ model: { jailbreakMode: 'off' } });
    response.resolve('{}'); await operation;
    assert(calls.at(-1).messages[0].content === BAIBAI_JAILBREAK, 'global changes while waiting do not change sent request');
    assert(!pending(), 'successful waiting operation consumes its snapshot');
  }
  // Snapshot must precede an asynchronous worldbook read, too.
  for (const task of ['bootstrap', 'evolve', 'realign']) {
    const { host, calls } = await setup(task !== 'bootstrap');
    const started = deferred(), source = deferred();
    host.readWorldbook = () => { started.resolve(); return source.promise; };
    if (task !== 'bootstrap') host.state.chat.push(msg(2));
    const operation = task === 'bootstrap' ? bootstrapWorld() : task === 'realign' ? correctStoryDay({ choice: 'realign' }) : runImmediateEvolution();
    await started.promise; saveSettings({ model: { jailbreakMode: 'off' } }); source.resolve({ entries: [] });
    await operation;
    assert(calls.at(-1).messages[0].content === BAIBAI_JAILBREAK, `${task} captures global configuration before source wait`);
  }
  return checks;
}
