import assert from 'node:assert/strict';
import { readChatStream } from '../src/host/stream.js';
import { fetchCustomModels, sendRequest } from '../src/host/transport.js';

function responseFrom(text, split = 1) {
  const bytes = new TextEncoder().encode(text);
  return new Response(new ReadableStream({ start(controller) { for (let i=0;i<bytes.length;i+=split) controller.enqueue(bytes.slice(i,i+split)); controller.close(); } }));
}
const sse = ': ping\r\n\r\ndata: {"choices":[{"delta":{"content":"你好","reasoning_content":"private"},"finish_reason":null}]}\r\n\r\ndata: {"choices":[{"delta":{"content":"世界"},"finish_reason":"stop"}],"usage":{"completion_tokens":4}}\r\n\r\ndata: [DONE]\r\n\r\n';
let progress = 0;
const result = await readChatStream(responseFrom(sse), value => { progress = value.characters; });
assert.equal(result.text,'你好世界'); assert.equal(result.usage.completion_tokens,4); assert.equal(progress,4);
await assert.rejects(readChatStream(responseFrom('data: {"choices":[{"delta":{"content":"partial"}}]}\n\n')), /结束标记/);
await assert.rejects(readChatStream(responseFrom('data: {"choices":[{"delta":{"content":"x"},"finish_reason":"length"}]}\n\ndata: [DONE]\n\n')), /不完整/);
const fallback = await readChatStream(responseFrom('{"choices":[{"message":{"content":"ok"},"finish_reason":"stop"}]}'));
assert.equal(fallback.text,'ok'); assert.equal(fallback.actualStream,false);
let requests = [];
const models = await fetchCustomModels({endpoint:'http://localhost:8889/v1/chat/completions',apiKey:'secret'}, {fetchImpl:async (path,options) => {requests.push([path,JSON.parse(options.body)]);return Response.json({data:[{id:'b'},{id:'a'},{id:'b'},{}]});}});
assert.deepEqual(models,['a','b']); assert.equal(requests[0][0],'/api/backends/chat-completions/status'); assert.equal(requests[0][1].reverse_proxy,'http://localhost:8889/v1');
const request = {connection:{mode:'custom',endpoint:'http://localhost:8889/v1',customModel:'test',apiKey:'',stream:true,responseLength:1024},messages:[{role:'user',content:'hi'}]};
const text = await sendRequest(request,{fetchImpl:async(path,options) => { assert.equal(JSON.parse(options.body).stream,true); return responseFrom(sse,3); }});
assert.equal(text,'你好世界');
await assert.rejects(sendRequest({...request,connection:{...request.connection,stream:false}},{detailed:true,fetchImpl:async()=>Response.json({choices:[{message:{content:'partial'},finish_reason:'length'}]})}), /不完整/);
await assert.rejects(readChatStream(responseFrom('data: {"error":{"message":"offline"}}\n\n')), /offline/);
let attempts=0;
await assert.rejects(sendRequest(request,{detailed:true,fetchImpl:async()=>{attempts++;return new Response('broken',{status:503});}}), /HTTP 503/);
assert.equal(attempts,1);
// A DONE event completes a response even if a proxy leaves the socket open.
let cancelled=false;
const hanging = new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n'));},cancel(){cancelled=true;}}));
assert.equal((await readChatStream(hanging)).text,'ok');assert.equal(cancelled,true);
await assert.rejects(readChatStream(responseFrom('event: error\ndata: {"message":"proxy failed"}\n\n')),/错误事件/);
const broken=new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"部分"}}]}\n\n'));},pull(c){c.error(new Error('connection reset'));}}));
await assert.rejects(readChatStream(broken),error=>error.partialText==='部分' && /reset/.test(error.message));
assert.deepEqual(await fetchCustomModels({endpoint:'http://localhost/v1'}, {fetchImpl:async()=>Response.json({data:[]})}),[]);
await assert.rejects(fetchCustomModels({endpoint:'http://localhost/v1'}, {fetchImpl:async()=>new Response('',{status:401})}),/401/);
await assert.rejects(fetchCustomModels({endpoint:'http://localhost/v1'}, {fetchImpl:async()=>Response.json({models:[]})}),/不支持/);
let consumed=0, errorCancelled=false;
await assert.rejects(sendRequest(request,{detailed:true,fetchImpl:async()=>new Response(new ReadableStream({pull(c){consumed++;c.enqueue(new TextEncoder().encode('x'.repeat(5000)));},cancel(){errorCancelled=true;}}),{status:502})}),error=>error.httpStatus===502 && error.message.length<2200);
assert.ok(consumed<=2 && errorCancelled);
console.log('shiju custom-api-check ok');
