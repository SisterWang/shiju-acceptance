import { observeHiddenFloors } from '../src/modules/visibility-observer.js';
import assert from 'node:assert/strict';
import { Worker } from 'node:worker_threads';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { createEmptyWorld, saveWorld, loadWorld, saveSettings } from '../src/store/index.js';
import { captureInputBoundary, ensureInputBoundary, readIncrement } from '../src/modules/incremental.js';
import { interpretStoryTime, applyClock } from '../src/modules/timetag/read.js';
import { readSourcePack, narrativeText } from '../src/modules/source/index.js';
import { runImmediateEvolution } from '../src/modules/timeGate/index.js';
import { selectWorldbook } from '../src/modules/worldbook/select.js';
import { renderSelected, runWorker } from '../src/modules/template/index.js';
import { buildRequest, sendRequest, normalizeEndpoint, textPrompt } from '../src/host/transport.js';
import { captureConnection } from '../src/host/connection.js';
import { minSubset, applySubset } from '../src/modules/commit/subset.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';

export async function runCompatibilityChecks() {
  let count=0; const check=(ok,label)=>{assert.ok(ok,label);count++;};
  const host=createMemoryHost({chatId:'compat'}); setHost(host);
  const msg=(mes,extra={})=>({mes,send_date:mes,swipe_id:0,...extra});
  const world=createEmptyWorld(); world.meta.builtFingerprint='compat';world.plugin.enabled=true;
  const chat=[msg('<shiju_end>2026/1/1</shiju_end>old'),msg('<shiju_end>2026/1/2</shiju_end>tip')];
  world.processedInput=captureInputBoundary(chat); applyClock(world,interpretStoryTime(world,chat,'shiju',''));
  for(const hidden of [true,false,true,false]) {
    chat[1].is_system=hidden;
    check(!readIncrement(world,chat).changed && !readIncrement(world,chat).items.length,'visibility never changes processed identity');
    check(interpretStoryTime(world,chat,'shiju','').status === 'same','hidden date anchor stays valid');
  }
  chat.push(msg('<shiju_end>2026/1/3</shiju_end>private',{is_system:true}));
  check(!readIncrement(world,chat).items.length,'new manual hidden prose excluded');
  chat[2].is_system=false;
  check(!readIncrement(world,chat).items.length,'unhide does not restore pending history');
  check(interpretStoryTime(world,chat,'shiju','').status === 'same','unhide excluded date cannot advance time');
  chat.push(msg('new visible'));
  check(readIncrement(world,chat).items.length === 1,'mixed new content only includes allowed floor');
  const checkpoint=minSubset(world); const restored=createEmptyWorld();applySubset(restored,checkpoint);
  check(restored.processedInput.excluded.length === 1,'exclusions in checkpoints');
  host.state.chat=chat;await saveWorld(world);
  let calls=[];host.generateViaBackend=async r=>{calls.push(r);throw Error('fixed failure');};
  check(!(await runImmediateEvolution()).evolved,'failed call is not committed');
  check(readIncrement(loadWorld(),chat).items.length === 1,'failure retains real increment');
  check(!calls.at(-1).prompt.includes('private'),'excluded new content absent even in background');
  host.generateViaBackend=async r=>{calls.push(r);return '{}';};
  check((await runImmediateEvolution()).evolved,'retry processes increment once');
  check((await runImmediateEvolution()).reason === 'no-increment','no repeat after commit');
  const newly=msg('hidden then unhidden');chat.push(newly);newly.is_system=true;
  await observeHiddenFloors(chat,[chat.length-1]);newly.is_system=false;
  check(!readIncrement(loadWorld(),chat).items.length,'visibility observation persists exclusion without an evolution');
  chat.pop(); // the excluded floor was never part of the committed physical prefix
  for(const mutate of [c=>c[0].mes+='edit',c=>c[0].swipe_id++,c=>c.shift(),c=>c.reverse()]) {
    const changed=structuredClone(chat);mutate(changed);check(readIncrement(loadWorld(),changed).changed,'real history changes remain detectable');
  }
  const memoryChat=[msg('old'),msg('unseen',{is_system:true,extra:{bbs_hidden:true}})];
  const mw=createEmptyWorld();mw.processedInput=captureInputBoundary(memoryChat,0);
  const baibai={injectedHistory:{nodes:[{floorStart:1,floorEnd:1,text:'a valid memory'}]}};
  const increment=readIncrement(mw,memoryChat,baibai);
  check(increment.text.includes('a valid memory') && increment.accepted[0] === 1,'Baibai hidden floor delivered through summary');
  const without=readIncrement(mw,memoryChat);check(!without.items.length,'hidden prose never substituted for a missing memory');
  mw.processedInput=captureInputBoundary(memoryChat,Infinity,mw.processedInput,[]);
  check(mw.processedInput.rows[1].status === 'pending' && readIncrement(mw,memoryChat,baibai).items.length === 1,'other successful turns do not consume pending memory');
  mw.processedInput=captureInputBoundary(memoryChat,Infinity,mw.processedInput,increment.accepted);
  check(!readIncrement(mw,memoryChat,baibai).items.length,'summary accepted exactly once');
  const legacy={meta:{},processedInput:{rows:[{floor:0,swipeId:0,hash:mw.processedInput.rows[0].hash}],tipText:'old'}};
  check(ensureInputBoundary(legacy,memoryChat,'shiju','') && legacy.processedInput.version === 2,'verifiable legacy migration');
  const uncertain={meta:{},processedInput:{rows:[{floor:3,hash:'bad'}]}};ensureInputBoundary(uncertain,memoryChat,'shiju','');
  check(!readIncrement(uncertain,memoryChat,baibai).items.length && uncertain.meta.inputHint === 'baseline-established','uncertain migration establishes baseline without replay');
  const big=Array.from({length:10000},(_,i)=>msg(`floor ${i}`));const start=performance.now();const bw=createEmptyWorld();bw.processedInput=captureInputBoundary(big);big.forEach(m=>m.is_system=true);readIncrement(bw,big);
  check(performance.now()-start<1000,'10k physical boundary remains linear');

  const pack={floorsTail:[{floor:9,text:'recent'}],baibai:{coverage:{complete:true},injectedHistory:{nodes:[{floorStart:0,floorEnd:8,text:'compressed'},{floorStart:9,floorEnd:9,text:'duplicate'}]}}};
  const text=narrativeText(pack);check(text.includes('recent')&&text.includes('compressed')&&!text.includes('duplicate'),'complete memory still includes recent prose with overlap removed');
  check(!narrativeText({...pack,baibai:{history:{nodes:[]},injectedText:'excluded raw memory'}}).includes('excluded raw memory'),'known empty structured history does not fall back to excluded raw text');
  let revision=1,loads=0;
  host.state.chat=[msg('recent')];host.state.chatMetadata={};
  globalThis.STBaiBaiBook={getSnapshot:()=>({chat:{id:'compat'},revision}),getHistory:()=>({chat:{id:'compat'},revision,text:'history'}),getInjectedHistory:()=>({chat:{id:'compat'},revision,text:'injected'})};
  host.readWorldbook=async()=>{if(loads++ === 0) revision++;return {entries:[]};};
  check((await readSourcePack()).baibai.snapshot.revision === 2 && loads === 2,'revision change rereads once');
  host.readWorldbook=async()=>{revision++;return {entries:[]};};
  await assert.rejects(readSourcePack(),e=>e.code==='SHIJU_SOURCE_CHANGED');count++;
  globalThis.STBaiBaiBook.getSnapshot=()=>{throw Error('unavailable');};globalThis.STBaiBaiBook.getHistory=()=>{throw Error();};globalThis.STBaiBaiBook.getInjectedHistory=()=>{throw Error();};
  host.readWorldbook=async()=>({entries:[]});
  const fallback=await readSourcePack();check(narrativeText(fallback).includes('recent')&&fallback.diagnostics.length,'API failure falls back with diagnostic');delete globalThis.STBaiBaiBook;

  host.createTemplateWorker=()=>{
    const worker=new Worker(new URL('./template-node-worker.mjs',import.meta.url),{execArgv:[]});
    const proxy={postMessage:v=>worker.postMessage(v),terminate:()=>worker.terminate()};
    worker.on('message',data=>proxy.onmessage?.({data}));worker.on('error',error=>proxy.onerror?.(error));return proxy;
  };
  const data={global:{x:1,g:2},initial:{x:2},local:{x:3},chat:[{variables:[{x:4,arr:[1,2]}]}]};const original=JSON.stringify(data);
  const render=async(content,entries=[])=>runWorker({title:'main',content},data,entries);
  check((await render('<%= getvar("x") %>/<%= getGlobalVar("x") %>/<%= getLocalVar("x") %>')).text === '4/1/3','variable precedence and scopes');
  check((await render('<% let n=0; for(const v of variables.arr){n+=v}; %><%= await Promise.resolve(n) %>')).text === '3','loops, locals and async calculation');
  const writes=await render('<% setvar("x",9); variables.x=8; delete variables.g; variables.arr.push(3); %><%= getvar("x") %>:<%= variables.arr.join(",") %>');
  check(writes.text === '4:1,2' && writes.diagnostics.length >= 4,'setters and object/array writes are noops and diagnosed');
  check(JSON.stringify(data)===original,'host data unchanged');
  check((await render('<%= _.sumBy([{v:2},{v:3}],"v") %>')).text === '5','bundled lodash pure subset');
  for(const content of ['<%= await fetch("https://example.com") %>','<%= missingHelper() %>','<%= ({}).constructor.constructor("return this")() %>','<%= await import("https://example.com/a.js") %>']) {
    check((await render(content)).text === null,'unsupported or escaping template discarded');
  }
  const entries=[{bookName:'B',title:'child',content:'<%= getvar("x") %>'}];
  check((await render('<%- await getwi("B","child") %>',entries)).text === '4','explicit read/render dependency');
  check((await render('<%- await include("child") %>',entries)).text === '4','explicit EJS include');
  check((await render('<%- await getwi("main") %>',[{title:'main',content:'<%- await getwi("main") %>'}])).text === null,'cycles discarded');
  check((await render('<%= world_info.uid %>')).text === '', 'missing metadata reads as undefined');
  const timed=await runWorker({title:'loop',content:'<% while(true){} %>'},data,[],100);
  check(timed.timeout,'worker terminated on timeout');
  const entries2=[{title:'bad',content:'<%= unknown() %>',constant:true},{title:'good',content:'safe',constant:true},{title:'[GENERATE:AFTER]',content:'bad lifecycle',constant:true}];
  const rendered=await renderSelected(selectWorldbook({entries:entries2}),{worldbook:{entries:entries2},templateData:data},{});
  check(rendered.text.includes('safe')&&!rendered.text.includes('<%')&&!rendered.text.includes('bad lifecycle'),'per-entry failure preserves static input and skips lifecycle');
  host.state.chat=[];host.state.chatMetadata={};host.readWorldbook=async()=>({entries:[entries2[0]]});let invoked=0;host.generateViaBackend=async()=>{invoked++;return '{}';};
  check((await bootstrapWorld()).reason === 'source' && invoked === 0,'empty effective data avoids model call');

  const base={mode:'follow',api:'openai',responseLength:555,model:'gpt-4o',settings:{chat_completion_source:'openai',temp_openai:0.7,openai_max_tokens:555},name1:'User',name2:'Char'};
  const request={messages:[{role:'system',content:'protocol'},{role:'user',content:'body'}],connection:base,responseLength:16000};
  const originalConnection=JSON.stringify(base);
  let built=await buildRequest(request);check(built.body.max_tokens === 16000 && built.body.stream === false,'OpenAI length mapped only into request');
  check(JSON.stringify(base)===originalConnection,'builder does not mutate snapshot');
  for(const source of ['claude','openrouter','makersuite','vertexai','mistralai','custom','cohere','perplexity','groq','deepseek','xai','zai','nanogpt','moonshot','azure_openai']) {
    built=await buildRequest({...request,connection:{...base,settings:{...base.settings,chat_completion_source:source}}});
    check(built.body.max_tokens === 16000 && built.body.type === 'quiet',`provider ${source} request is independent`);
  }
  built=await buildRequest({...request,connection:{...base,model:'gpt-5'}});check(built.body.max_completion_tokens === 16000 && !('max_tokens' in built.body),'reasoning model length alias');
  for(const type of ['ooba','koboldcpp','llamacpp','ollama','vllm','aphrodite','tabby','mancer','huggingface']) {
    built=await buildRequest({...request,connection:{...base,api:'textgenerationwebui',server:'http://test',maxContext:32000,settings:{type},instruct:{enabled:true,input_sequence:'[U]',output_sequence:'[A]',system_sequence:'[S]'}}});
    check(built.body.max_tokens===16000 && built.body.max_new_tokens===16000 && built.body.prompt.includes('[S]protocol'),`text ${type} length and instruct mapping`);
  }
  for(const api of ['kobold','novel']) {
    built=await buildRequest({...request,connection:{...base,api,settings:{model_novel:'kayra'}}});check(built.body.max_length===16000,`${api} does not clamp length`);
  }
  check(textPrompt(request.messages,{...base,instruct:{enabled:true,macro:true,wrap:true,names_behavior:'always',system_sequence:'[{{name}}]',input_sequence:'[{{name}}]',first_input_sequence:'UNUSED',last_system_sequence:'[reply]'}})==='[System]\nprotocol\n[User]\nUser: body\n[reply]\n','quiet instruct formatting follows role names and configured sequences');
  built=await buildRequest({...request,connection:{...base,api:'kobold',settings:{preset_settings:'gui',api_server:'http://fixture'}}});
  check(built.body.gui_settings===true && built.body.max_length===16000,'Kobold GUI mode keeps server sampler settings with independent length');
  check(normalizeEndpoint('https://example.com/v1/chat/completions/')==='https://example.com/v1','custom complete URL normalized once');
  built=await buildRequest({...request,connection:{...base,mode:'custom',endpoint:'https://example.com/v1',customModel:'mine',apiKey:'test-secret'}});
  check(built.body.proxy_password === 'test-secret' && built.body.reverse_proxy==='https://example.com/v1'&&built.body.tool_choice==='none','custom routed through ST backend with independent credentials');
  let seen=[];const ok=data=>({ok:true,json:async()=>data});
  check(await sendRequest(request,{fetchImpl:async(path,options)=>{seen.push([path,JSON.parse(options.body)]);return ok({choices:[{message:{content:'fixed'}}]});}})==='fixed' && seen.length===1,'nonstream parse through one same-origin request');
  seen=[];await assert.rejects(sendRequest(request,{fetchImpl:async()=>{seen.push(1);return {ok:false,status:500};}}));check(seen.length===1,'failure is not retried');
  const horde={...request,connection:{...base,api:'koboldhorde',settings:{},horde:{models:['test'],trusted_workers_only:true}}};
  seen=[];let polls=0;
  const hresult=await sendRequest(horde,{pollDelay:1,fetchImpl:async(path)=>{seen.push(path);return ok(path.endsWith('generate-text')?{id:'task'}:++polls===1?{done:false}:{done:true,generations:[{text:'horde reply'}]});}});
  check(hresult==='horde reply' && seen.filter(p=>p.endsWith('generate-text')).length===1 && polls===2,'Horde poll is not generation retry');
  const ctrl=new AbortController();seen=[];
  await assert.rejects(sendRequest(horde,{signal:ctrl.signal,fetchImpl:async(path)=>{seen.push(path);if(path.endsWith('generate-text'))ctrl.abort();return ok({id:'task'});}}));
  check(seen.some(p=>p.endsWith('cancel-task')),'Horde cancellation explicitly cancels allocated job');
  const ctx={mainApi:'openai',chatCompletionSettings:base.settings,powerUserSettings:{},name1:'U'};
  const snap=captureConnection(ctx,{amount_gen:80,CLIENT_VERSION:'SillyTavern:1.16.0:test'},{},{channelMode:'follow'});ctx.chatCompletionSettings.openai_max_tokens=999;
  check(snap.responseLength===555,'connection snapshot precedes later host settings changes');
  const yamlSettings={...base.settings,chat_completion_source:'custom',custom_include_body:JSON.stringify({stream:true,max_tokens:1,messages:[],tools:[{}],temperature:0.3}),custom_exclude_body:JSON.stringify(['max_tokens','messages','stop'])};
  const nativeCustom=captureConnection({...ctx,chatCompletionSettings:yamlSettings},{CLIENT_VERSION:'SillyTavern:1.17.0:test'},{lib:{yaml:{parse:JSON.parse}}},{channelMode:'follow'});
  check(nativeCustom.settings.custom_include_body==='{"temperature":0.3}' && nativeCustom.settings.custom_exclude_body==='["stop"]','native custom YAML cannot override per-request protocol or length');
  check(JSON.parse(yamlSettings.custom_include_body).stream===true,'native custom sanitization never mutates host configuration');
  saveSettings({model:{channelMode:'custom',endpoint:'https://example.com/v1',customModel:'mine',apiKey:'secret'}});
  check(!JSON.stringify(loadWorld()).includes('secret'),'custom credentials stay outside chat ledger');
  return count;
}
