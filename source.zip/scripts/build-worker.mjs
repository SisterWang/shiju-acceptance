import { build } from 'esbuild';
await build({ entryPoints: ['src/modules/template/worker.js'], bundle: true, outfile: 'vendor/template-worker.js', platform:'browser', format:'iife', banner:{js:'"use strict";'}, minify:true, legalComments:'eof' });
