import { strict as nodeAssert } from 'node:assert';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { createEmptyWorld, loadWorld, saveSettings, saveWorld } from '../src/store/index.js';
import { HIDE_REGEX_ID, register } from '../src/modules/timetag/index.js';

export async function runTimeTagRefreshChecks() {
  let checks = 0;
  const assert = (condition, message) => { checks += 1; nodeAssert.ok(condition, message); };
  const enabled = createEmptyWorld();
  enabled.plugin.enabled = true;
  enabled.meta.builtFingerprint = 'timetag-refresh';
  const host = createMemoryHost({
    chatMetadata: { shiju: enabled },
    chat: [{ mes: '<shiju_end>1988/1/1</shiju_end>' }],
  });
  setHost(host);
  const otherRegex = { id: 'other-plugin', findRegex: '/other/', disabled: true };
  host.state.extensionSettings.regex = [otherRegex];
  let promptWrites = 0;
  let modelCalls = 0;
  const writePrompt = host.setExtensionPrompt;
  host.setExtensionPrompt = (...args) => {
    if (args[0] === 'shiju_timetag') promptWrites += 1;
    writePrompt(...args);
  };
  host.generateViaBackend = async () => { modelCalls += 1; throw new Error('refresh must not generate'); };
  const prompt = () => host.state.prompts.shiju_timetag?.value;
  const hide = () => host.state.extensionSettings.regex.find((script) => script.id === HIDE_REGEX_ID);
  const beforeWorld = JSON.stringify(loadWorld());
  const beforeChat = JSON.stringify(host.state.chat);
  register();
  assert(prompt()?.includes('shiju_end') && hide(), 'registration restores the active chat time tag');
  const settingsSaves = host.state.savedSettings;
  register();
  register();
  promptWrites = 0;

  // Only use the public setting/event paths; never explicitly refreshTimeTag here.
  saveSettings({ timeSource: { mode: 'custom', customTag: 'lore_time' } });
  assert(prompt() === '', 'changing to custom mode clears the shiju prompt immediately');
  assert(hide()?.findRegex.includes('lore_time') && !hide().findRegex.includes('shiju_end'), 'custom mode replaces the hide regex');
  assert(promptWrites === 1, 'repeated registration does not duplicate the settings subscription');
  assert(host.state.savedSettings === settingsSaves + 2, 'unchanged registrations do not resave regex; custom mode saves setting and changed regex');
  saveSettings({ timeSource: { customTag: 'new_clock' } });
  assert(hide()?.findRegex.includes('new_clock') && !hide().findRegex.includes('lore_time'), 'editing the custom tag updates its regex');
  saveSettings({ timeSource: { customTag: '' } });
  assert(!hide() && prompt() === '', 'empty custom tag removes the previous hide regex');
  saveSettings({ timeSource: { mode: 'shiju' } });
  assert(prompt()?.includes('shiju_end') && hide()?.findRegex.includes('shiju_end'), 'switching back restores the shiju prompt and regex');

  host.state.hasBaibai = true;
  saveSettings({ timeSource: { mode: 'baibai' } });
  assert(prompt() === '' && !hide(), 'baibai mode removes shiju prompt and regex');
  saveSettings({ timeSource: { mode: 'auto' } });
  assert(prompt() === '' && !hide(), 'auto follows detected baibai');
  host.state.hasBaibai = false;
  host.eventSource.emit(host.event_types.CHAT_CHANGED);
  assert(prompt()?.includes('shiju_end') && hide(), 'chat switch rechecks auto source availability');
  assert(JSON.stringify(loadWorld()) === beforeWorld && JSON.stringify(host.state.chat) === beforeChat, 'settings and refresh events do not alter ledger or messages');
  assert(host.state.savedMetadata === 0 && modelCalls === 0, 'settings and refresh events neither save a world nor call a model');

  const switchTo = (id, world) => {
    host.state.chatId = id;
    host.state.chatMetadata = world ? { shiju: structuredClone(world) } : {};
    // SillyTavern clears extension prompts when changing chats.
    host.state.prompts = { shiju_macro: { value: 'macro sentinel' } };
    promptWrites = 0;
    host.eventSource.emit(host.event_types.CHAT_CHANGED);
  };
  switchTo('enabled-B', enabled);
  assert(prompt()?.includes('shiju_end') && hide(), 'switching to an enabled chat restores its cleared prompt');
  assert(promptWrites === 1, 'chat event has one listener despite repeated registration');
  assert(host.state.prompts.shiju_macro.value === 'macro sentinel', 'time-tag chat handler leaves macro prompt alone');
  const savedBeforeRefresh = host.state.savedSettings;
  host.eventSource.emit(host.event_types.CHAT_CHANGED);
  assert(host.state.savedSettings === savedBeforeRefresh, 'unchanged chat refresh does not resave regex');
  switchTo('disabled-C', { ...enabled, plugin: { ...enabled.plugin, enabled: false } });
  assert(prompt() === '' && !hide(), 'switching to a disabled chat clears time-tag state');
  switchTo('enabled-D', enabled);
  switchTo('frozen-E', { ...enabled, plugin: { ...enabled.plugin, frozenAt: 1 } });
  assert(prompt() === '' && !hide(), 'switching to a frozen chat clears time-tag state');
  switchTo('enabled-F', enabled);
  switchTo('no-world-G', null);
  assert(prompt() === '' && !hide(), 'switching to a chat without a world clears time-tag state');
  assert(host.state.extensionSettings.regex.length === 1 && host.state.extensionSettings.regex[0] === otherRegex, 'all switches preserve other plugins regexes');

  await saveWorld(enabled);
  assert(prompt()?.includes('shiju_end') && hide(), 'world save enabling the current chat refreshes time tags');
  const disabled = loadWorld();
  disabled.plugin.enabled = false;
  await saveWorld(disabled);
  assert(prompt() === '' && !hide(), 'world save disabling the current chat clears time tags');
  assert(modelCalls === 0, 'world-driven refresh never calls the model');

  // Rebinding a test/preview host must not duplicate handlers or allow stale events.
  const other = createMemoryHost({ chatMetadata: { shiju: enabled } });
  setHost(other);
  register();
  other.state.prompts = {};
  host.eventSource.emit(host.event_types.CHAT_CHANGED);
  assert(other.state.prompts.shiju_timetag === undefined, 'an old host event does not refresh the current host');
  setHost(host);
  register();
  promptWrites = 0;
  host.eventSource.emit(host.event_types.CHAT_CHANGED);
  assert(promptWrites === 1, 'rebinding the original host does not duplicate chat handlers');
  return checks;
}
