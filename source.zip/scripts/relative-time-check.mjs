import { strict as nodeAssert } from 'node:assert';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { loadWorld } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { freezeWorld, reopenWorld } from '../src/modules/lifecycle/index.js';
import { reconcileOnChatMutation, register as registerReconcile } from '../src/modules/reconcile/index.js';
import { clearEvolutionHold, runAutomaticGate, rerunLastEvolution } from '../src/modules/timeGate/index.js';
import { interpretStoryTime } from '../src/modules/timetag/index.js';
import { enqueueTurn } from '../src/modules/turn.js';

const message = (label, tag = 'shiju_end') => ({ mes: `<${tag}>${label}</${tag}>`, swipe_id: 0 });

export async function runRelativeTimeChecks() {
  let checks = 0;
  const assert = (condition, message) => { checks += 1; nodeAssert.ok(condition, message); };
  async function setup(chat = [message('1988/1/1')], mode = 'shiju') {
    const host = createMemoryHost({ chat, settings: { timeSource: { mode, customTag: 'clock' } }, hasBaibai: mode === 'baibai' });
    const control = { calls: 0, fail: false };
    host.generateViaBackend = async (request) => {
      if (request.purpose === 'evolve') {
        control.calls += 1;
        if (control.fail) throw new Error('model failed');
      }
      return '{"regions":[{"name":"江左","summary":"固定验收资料"}],"todayChanges":[]}';
    };
    setHost(host);
    clearEvolutionHold();
    await bootstrapWorld();
    return { host, control };
  }

  for (const [mode, tag] of [['shiju', 'shiju_end'], ['custom', 'clock'], ['baibai', 'bbs_end']]) {
    const { host, control } = await setup([message('1988/1/1', tag)], mode);
    host.state.chat.push(message('次日', tag));
    const results = await Promise.all([runAutomaticGate(), runAutomaticGate(), runAutomaticGate()]);
    assert(results.filter((result) => result.evolved).length === 1, `${mode}: repeated gates evolve only once`);
    assert(control.calls === 1 && loadWorld().storyClock.dayIndex === 1, `${mode}: one relative tag costs one call and one day`);
    assert(loadWorld().evolutionLog.length === 1, `${mode}: one log entry`);
    const before = JSON.stringify(loadWorld());
    const reading = interpretStoryTime(loadWorld(), host.state.chat, mode, 'clock');
    assert(reading.status === 'same' && reading.dayIndex === 1, `${mode}: repeated read reports same day`);
    assert(JSON.stringify(loadWorld()) === before, `${mode}: time reader is pure`);
    host.state.chat.push({ mes: '没有新时间标签的回复', swipe_id: 0 });
    assert(!(await runAutomaticGate()).evolved && control.calls === 1, `${mode}: an untagged tail does not reuse the old relative tag`);
    host.state.chat.push(message('次日', tag));
    assert((await runAutomaticGate()).evolved && loadWorld().storyClock.dayIndex === 2, `${mode}: identical label on a new floor advances again`);
    assert(!(await runAutomaticGate()).evolved && control.calls === 2, `${mode}: new floor is also consumed once`);

    const exported = JSON.parse(JSON.stringify(host.state.chatMetadata));
    const restored = createMemoryHost({ chat: structuredClone(host.state.chat), chatMetadata: exported, settings: host.state.extensionSettings.shiju, hasBaibai: mode === 'baibai' });
    restored.generateViaBackend = host.generateViaBackend;
    setHost(restored);
    clearEvolutionHold();
    assert(!(await runAutomaticGate()).evolved && control.calls === 2, `${mode}: exported and reopened chat retains the consumed anchor`);
  }

  // A consumed anchor is part of clock snapshots, so rerun and rollback preserve it.
  {
    const { host, control } = await setup();
    registerReconcile();
    host.state.chat.push(message('次日'));
    host.eventSource.emit(host.event_types.GENERATION_ENDED);
    host.eventSource.emit(host.event_types.CHARACTER_MESSAGE_RENDERED);
    host.eventSource.emit(host.event_types.GENERATION_STOPPED);
    await enqueueTurn(() => ({}));
    assert(control.calls === 1 && loadWorld().storyClock.dayIndex === 1, 'duplicate generation notifications do not repeat relative evolution');
    await rerunLastEvolution();
    assert(!(await runAutomaticGate()).evolved && control.calls === 2 && loadWorld().storyClock.dayIndex === 1, 'explicit rerun keeps relative tag consumed and day unchanged');
    host.state.chat[1].mes += '只改正文错字';
    await reconcileOnChatMutation({ cause: 'edit' });
    assert(control.calls === 2 && loadWorld().storyClock.dayIndex === 1, 'editing outside the tag does not advance again');
    host.state.chat.push(message('两天后'));
    await runAutomaticGate();
    assert(loadWorld().storyClock.dayIndex === 3, 'a new two-day tag advances by two');
    host.state.chat.pop();
    const deleted = await reconcileOnChatMutation({ cause: 'delete' });
    assert(deleted.dropped === 1 && !deleted.evolved && control.calls === 3 && loadWorld().storyClock.dayIndex === 1, 'deletion restores the previous consumed relative anchor');
    host.state.chat[1].swipe_id = 1;
    host.state.chat[1].mes = '<shiju_end>三天后</shiju_end>';
    const swiped = await reconcileOnChatMutation({ cause: 'swipe', floor: 1 });
    assert(swiped.evolved && loadWorld().storyClock.dayIndex === 3 && control.calls === 4, 'changed swipe recomputes from the restored pre-evolution clock');
    assert(!(await reconcileOnChatMutation({ cause: 'swipe', floor: 1 })).evolved && control.calls === 4, 'duplicate swipe notification does not evolve twice');
    host.state.chat[1].mes = '<shiju_end>两天后</shiju_end>';
    await reconcileOnChatMutation({ cause: 'edit' });
    assert(loadWorld().storyClock.dayIndex === 2 && control.calls === 5, 'edited time fingerprint is not mistaken for the old consumed tag');
    assert(!(await runAutomaticGate()).evolved && control.calls === 5, 'edited relative tag is consumed once');
  }

  // Failed evolution must not consume the date; a deliberate retry can still commit.
  {
    const { host, control } = await setup();
    host.state.chat.push(message('次日'));
    control.fail = true;
    assert(!(await runAutomaticGate()).ok && loadWorld().storyClock.dayIndex === 0, 'failed relative evolution leaves clock unchanged');
    assert((await runAutomaticGate()).reason === 'held' && control.calls === 1, 'duplicate failure notification does not retry');
    control.fail = false;
    clearEvolutionHold();
    assert((await runAutomaticGate()).evolved && loadWorld().storyClock.dayIndex === 1, 'retry can consume the failed relative tag');
    assert(!(await runAutomaticGate()).evolved && control.calls === 2, 'successful retry consumes it only once');
  }

  // Bootstrap and reopening intentionally align the clock without evolving history.
  {
    const { control } = await setup([message('次日')]);
    assert(loadWorld().storyClock.dayIndex === 1, 'bootstrap aligns a relative-only clock');
    assert(!(await runAutomaticGate()).evolved && control.calls === 0, 'bootstrap-consumed relative tag is not evolved again');
  }
  {
    const { control } = await setup([message('1988/1/1'), message('1988/1/3'), message('次日')]);
    assert(loadWorld().storyClock.dayIndex === 3, 'bootstrap aligns an absolute history ending in a relative tag');
    assert(!(await runAutomaticGate()).evolved && control.calls === 0, 'mixed-history bootstrap consumes its final relative tag');
  }
  {
    const { host, control } = await setup();
    await freezeWorld();
    host.state.chat.push(message('三天后'));
    await reopenWorld();
    assert(loadWorld().storyClock.dayIndex === 3, 'reopen skips the frozen relative-time gap');
    assert(!(await runAutomaticGate()).evolved && control.calls === 0, 'reopening does not backfill the consumed frozen gap');
  }
  return checks;
}
