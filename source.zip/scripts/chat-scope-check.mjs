import { strict as nodeAssert } from 'node:assert';
import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { captureChatScope } from '../src/chatScope.js';
import { createEmptyWorld, loadWorld, saveWorld } from '../src/store/index.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import { commitEvolutionSuccess } from '../src/modules/commit/index.js';
import { minSubset } from '../src/modules/commit/subset.js';
import { previewAiCorrection } from '../src/modules/intervene/index.js';
import { correctStoryDay, freezeWorld, reopenWorld } from '../src/modules/lifecycle/index.js';
import { register as registerReconcile } from '../src/modules/reconcile/index.js';
import { clearEvolutionHold, runAutomaticGate, runImmediateEvolution, rerunLastEvolution } from '../src/modules/timeGate/index.js';
import { applyClock, interpretStoryTime } from '../src/modules/timetag/index.js';
import { enqueueTurn } from '../src/modules/turn.js';

function deferred() {
  let resolve;
  let reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

function message(day) {
  return { mes: `<shiju_end>2026/1/${day} 12:00</shiju_end>`, swipe_id: 0 };
}

function world(name) {
  const value = createEmptyWorld();
  value.processedInput = { rows: [], tipText: '' };
  value.plugin.enabled = true;
  value.meta.builtFingerprint = name;
  value.meta.lastEvolvedDayIndex = 0;
  value.regions = [{ id: name, name }];
  value.events = [{ id: 'event', kind: 'macro', title: `${name}事件`, body: `${name}正文` }];
  applyClock(value, interpretStoryTime(value, [message(1)], 'shiju', ''));
  value.lastEvolutionCheckpoint = minSubset(value);
  return value;
}

const reply = JSON.stringify({ regions: [{ name: 'A的新地区', summary: '固定验收资料' }], todayChanges: [{ title: 'A的演进结果' }] });
const operations = [
  { name: 'immediate', run: runImmediateEvolution },
  { name: 'automatic', run: runAutomaticGate },
  { name: 'rerun', run: rerunLastEvolution },
  { name: 'bootstrap', run: bootstrapWorld, empty: true },
  { name: 'reopen', run: reopenWorld, empty: true },
  { name: 'realign', run: () => correctStoryDay({ choice: 'realign' }) },
  { name: 'preview', run: () => previewAiCorrection({ kind: 'event', id: 'event' }) },
];

function setup(empty = false) {
  const host = createMemoryHost({
    chatId: 'A',
    chatMetadata: empty ? {} : { shiju: world('A') },
    chat: [message(1), message(2)],
  });
  setHost(host);
  clearEvolutionHold();
  return host;
}

function switchChat(host, id, metadata, notify = false) {
  host.state.chatId = id;
  host.state.chatMetadata = metadata;
  host.state.chat = [message(1)];
  if (notify) host.eventSource.emit(host.event_types.CHAT_CHANGED);
}

function cancelled(result) {
  return result?.reason === 'chat-changed' || result?.code === 'SHIJU_CHAT_CHANGED';
}

function observe(promise) {
  return promise.catch((error) => ({ code: error.code, message: error.message }));
}

async function waitForCall(started, pending, name) {
  await Promise.race([
    started.promise,
    pending.then((result) => { throw new Error(`${name} finished without the expected call: ${JSON.stringify(result)}`); }),
  ]);
}

export async function runChatScopeChecks() {
  let checks = 0;
  const assert = (condition, message) => { checks += 1; nodeAssert.ok(condition, message); };

  // Success, invalid JSON and backend rejection must all leave both chats intact.
  // Include a destination with no world: bootstrap and preview used to overwrite it too.
  for (const operation of operations) {
    for (const outcome of ['success', 'parse-failure', 'backend-failure']) {
      for (const emptyDestination of [false, true]) {
        const host = setup(operation.empty);
        const origin = host.state.chatMetadata;
        const destination = emptyDestination ? { scenario: 'B' } : { shiju: world('B'), scenario: 'B' };
        const beforeA = JSON.stringify(origin);
        const beforeB = JSON.stringify(destination);
        const started = deferred();
        const backend = deferred();
        host.generateViaBackend = () => { started.resolve(); return backend.promise; };
        const pending = observe(operation.run());
        await waitForCall(started, pending, operation.name);
        switchChat(host, 'B', destination);
        if (outcome === 'backend-failure') backend.reject(new Error('model unavailable'));
        else backend.resolve(outcome === 'parse-failure' ? 'not JSON' : reply);
        const result = await pending;
        const label = `${operation.name}/${outcome}/emptyB=${emptyDestination}`;
        assert(cancelled(result), `${label}: cancelled as stale`);
        assert(JSON.stringify(host.state.chatMetadata) === beforeB, `${label}: B unchanged`);
        assert(JSON.stringify(origin) === beforeA, `${label}: A unchanged`);
        assert(host.state.savedMetadata === 0, `${label}: no persistence from stale request`);
      }
    }
  }

  // Changing chat while loading sources must stop before spending a model call.
  for (const operation of operations.filter((item) => item.name !== 'preview')) {
    const host = setup(operation.empty);
    const started = deferred();
    const source = deferred();
    let calls = 0;
    host.readWorldbook = () => { started.resolve(); return source.promise; };
    host.generateViaBackend = async () => { calls += 1; return reply; };
    const pending = observe(operation.run());
    await waitForCall(started, pending, operation.name);
    const destination = { shiju: world('B') };
    const before = JSON.stringify(destination);
    switchChat(host, 'B', destination);
    source.resolve({ entries: [] });
    assert(cancelled(await pending), `${operation.name}: source-stage switch cancels`);
    assert(calls === 0, `${operation.name}: no model call with mixed-chat sources`);
    assert(host.state.savedMetadata === 0 && JSON.stringify(host.state.chatMetadata) === before, `${operation.name}: source-stage switch does not write`);
  }

  // A -> B -> A is a new session, even if the original objects are restored.
  {
    const host = setup();
    const origin = host.state.chatMetadata;
    const before = JSON.stringify(origin);
    const started = deferred();
    const backend = deferred();
    host.generateViaBackend = () => { started.resolve(); return backend.promise; };
    const pending = runImmediateEvolution();
    await waitForCall(started, pending, 'round trip');
    switchChat(host, 'B', { shiju: world('B') }, true);
    switchChat(host, 'A', origin, true);
    backend.resolve(reply);
    assert(cancelled(await pending), 'returning to A does not revive its old request');
    assert(JSON.stringify(host.state.chatMetadata) === before && host.state.savedMetadata === 0, 'round trip leaves A intact');
  }

  // Work queued in A must not start against B; newly queued B work still runs.
  {
    const host = setup();
    const started = deferred();
    const backend = deferred();
    let calls = 0;
    host.generateViaBackend = () => {
      calls += 1;
      if (calls === 1) { started.resolve(); return backend.promise; }
      return Promise.resolve('{"todayChanges":[{"title":"B的新结果","body":"固定验收正文"}]}');
    };
    const active = runImmediateEvolution();
    await waitForCall(started, active, 'queued work');
    const oldQueued = runImmediateEvolution();
    const oldFreeze = freezeWorld();
    switchChat(host, 'B', { shiju: world('B') }, true);
    const newQueued = runImmediateEvolution();
    backend.resolve(reply);
    assert(cancelled(await active) && (await oldQueued).reason==='busy' && cancelled(await oldFreeze), 'active and queued A work is cancelled');
    assert((await newQueued).evolved, 'new B work runs after cancellation');
    assert(calls === 2 && host.state.savedMetadata === 1, 'only active A and fresh B spend calls; only B saves');
    assert(loadWorld().regions[0].name === 'B' && loadWorld().plugin.enabled, 'B retains its world and enabled state');
    assert(loadWorld().todayChanges[0].title === 'B的新结果' && loadWorld().evolutionLog.length === 1, 'B receives only its own result');
  }

  // Chat names can collide across characters/groups; host replacement also invalidates work.
  for (const change of ['character', 'group', 'host']) {
    const host = setup();
    const identity = { characterId: 'character-A', groupId: null };
    const getContext = host.getContext;
    host.getContext = () => ({ ...getContext(), ...identity });
    const started = deferred();
    const backend = deferred();
    host.generateViaBackend = () => { started.resolve(); return backend.promise; };
    const pending = runImmediateEvolution();
    await waitForCall(started, pending, change);
    let destination = host;
    if (change === 'character') identity.characterId = 'character-B';
    else if (change === 'group') identity.groupId = 'group-B';
    else { destination = createMemoryHost({ chatId: 'A', chatMetadata: { shiju: world('B') } }); setHost(destination); }
    const before = JSON.stringify(destination.state.chatMetadata);
    backend.resolve(reply);
    assert(cancelled(await pending), `${change}: identity change cancels`);
    assert(JSON.stringify(destination.state.chatMetadata) === before && destination.state.savedMetadata === 0, `${change}: destination untouched`);
  }

  // Defence at the final write boundary, including direct commit callers.
  {
    const host = setup();
    const chatScope = captureChatScope();
    const baseWorld = loadWorld();
    switchChat(host, 'B', { shiju: world('B') });
    const before = JSON.stringify(host.state.chatMetadata);
    const committed = await observe(commitEvolutionSuccess({
      ok: true, chatScope, baseWorld, checkpoint: minSubset(baseWorld), entry: { id: 'old-A' },
    }));
    assert(cancelled(committed), 'commit refuses an old chat scope');
    assert(cancelled(await observe(saveWorld(baseWorld, chatScope))), 'store refuses an old chat scope');
    assert(JSON.stringify(host.state.chatMetadata) === before && host.state.savedMetadata === 0, 'write boundaries leave B intact');
  }

  // A metadata replacement is a normal save, even on hosts without chat IDs.
  {
    const host = setup();
    const getContext = host.getContext;
    host.getContext = () => {
      const ctx = getContext();
      delete ctx.chatId;
      delete ctx.getCurrentChatId;
      return ctx;
    };
    const scope = captureChatScope();
    await saveWorld(loadWorld(), scope);
    assert(host.state.savedMetadata === 1, 'ID-less host permits ordinary metadata replacement');
    host.state.chat = [message(3)];
    assert(cancelled(await observe(saveWorld(world('A'), scope))), 'ID-less host rejects a changed chat reference');
    assert(host.state.savedMetadata === 1, 'ID-less stale write does not persist');
  }

  // If an asynchronous metadata update crosses chats, do not invoke the current-chat saver.
  {
    const host = setup();
    const getContext = host.getContext;
    const updated = deferred();
    let saves = 0;
    host.getContext = () => {
      const ctx = getContext();
      return {
        ...ctx,
        updateChatMetadata: (patch, reset) => {
          ctx.updateChatMetadata(patch, reset);
          return updated.promise;
        },
        saveMetadata: async () => { saves += 1; },
      };
    };
    const saving = observe(saveWorld(world('A')));
    const destination = { shiju: world('B') };
    const before = JSON.stringify(destination);
    switchChat(host, 'B', destination);
    updated.resolve();
    assert(cancelled(await saving), 'save detects a switch during async metadata update');
    assert(saves === 0 && JSON.stringify(host.state.chatMetadata) === before, 'save does not persist the destination after a switch');
  }

  // Reconcile must capture the new epoch, not invalidate the CHAT_CHANGED work itself.
  {
    const host = setup();
    registerReconcile();
    switchChat(host, 'B', { shiju: world('B') }, true);
    await enqueueTurn(() => ({ ok: true }));
    assert(host.state.savedMetadata === 1, 'new-chat reconcile runs in the new session');
    assert(loadWorld().regions[0].name === 'B', 'new-chat reconcile preserves B');
  }

  return checks;
}
