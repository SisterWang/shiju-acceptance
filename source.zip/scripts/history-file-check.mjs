import assert from 'node:assert/strict';
import {createHistoryFileStore, HISTORY_FILE_NAME, HISTORY_FILE_PATH} from '../src/host/history-file.js';
import {setHost} from '../src/host.js';
import {createMemoryHost} from '../src/host/memory.js';

let file=null, requests=[], mode='', settings={otherPlugin:{length:123}};
const store=createHistoryFileStore({getHeaders:()=>({'X-CSRF-Token':'fixture'}),fetchImpl:async(path,options)=>{
  requests.push({path,options});
  assert.equal(options.cache,'no-store');
  assert.equal(options.headers['X-CSRF-Token'],'fixture');
  if(path==='/api/files/upload') {
    if(mode==='offline')return new Response('',{status:503});
    const body=JSON.parse(options.body); assert.equal(body.name,HISTORY_FILE_NAME);
    file=atob(body.data);
    // An unrelated writer updates settings during the history write.
    settings.otherPlugin.length++;
    return Response.json({path:mode==='wrong-path'?'/user/files/unexpected.json':HISTORY_FILE_PATH});
  }
  assert.equal(path,HISTORY_FILE_PATH);
  if(mode==='mismatch')return Response.json({format:'shiju-request-history',version:1,data:'wrong'});
  if(mode==='denied')return new Response('',{status:403});
  return file === null ? new Response('',{status:404}) : new Response(file);
}});
assert.equal(await store.loadRequestHistory(),null);
await store.persistRequestHistory('fixture');assert.equal(await store.loadRequestHistory(),'fixture');
assert.equal(settings.otherPlugin.length,124);
assert.ok(requests.every(r=>!r.path.includes('/settings/')));
mode='offline';await assert.rejects(store.persistRequestHistory('no'),/503/);
mode='wrong-path';await assert.rejects(store.persistRequestHistory('no'),/位置/);
mode='mismatch';await assert.rejects(store.persistRequestHistory('no'),/未确认/);
mode='denied';await assert.rejects(store.loadRequestHistory(),/403/);
mode='';file='{"version":1}';await assert.rejects(store.loadRequestHistory(),/格式/);
file='x'.repeat(2*1024*1024+257);await assert.rejects(store.loadRequestHistory(),/容量/);
const timed=createHistoryFileStore({getHeaders:()=>({}),timeoutMs:5,fetchImpl:(_,options)=>new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(new DOMException('timeout','AbortError'))))});
await assert.rejects(timed.loadRequestHistory(),{name:'AbortError'});

// A read failure must never overwrite the unread file. Retrying merges old
// records and new in-page requests, without replaying a model request.
const old=[{id:'previous-page',status:'running',startedAt:'2026-01-01T00:00:00Z',messages:[]}];
const zipped=new Uint8Array(await new Response(new Blob([JSON.stringify(old)]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
const encoded=Buffer.from(zipped).toString('base64');
const host=createMemoryHost();let failRead=true,saves=0,warnings=0;
host.loadRequestHistory=async()=>{if(failRead)throw Error('offline');return encoded;};
host.persistRequestHistory=async()=>{saves++;};
host.notifyHistoryFailure=()=>{warnings++;};setHost(host);
const history=await import('../src/modules/model/history.js?read-failure-test');
await history.initHistory();assert.match(history.historyStatus(),/读取失败/);
const ref=await history.beginHistory({purpose:'connection-test',messages:[]},null);history.finishHistory(ref,'ok');
await history.retryHistory();assert.equal(saves,0);assert.equal(warnings,1);
failRead=false;await history.retryHistory();assert.equal(saves,1);assert.equal(history.historyStatus(),'');
assert.equal(history.getHistory().length,2);assert.equal(history.getHistory()[1].status,'interrupted');
assert.equal(host.state.savedSettings,0);assert.deepEqual(host.state.extensionSettings,{});
console.log('shiju history-file-check ok');
