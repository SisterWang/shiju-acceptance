# 界面合约（W4）

给小杰。面板只读世界账、只写下面列出的设置。演进、提交、注入、时间门归核心。W4 把「立即演进」「重跑」接到已有入口，不在界面里重做时间门。单条修正用下面三条，不要自己写账。

## 界面可以调用

只使用这些名字。世界账用 `loadWorld()` 的副本，不要改完再存回去。

| 名字 | 用途 |
| --- | --- |
| `loadWorld` | 读当前聊天的世界账。没有账时是 `null`，不会建世界。 |
| `loadSettings` | 读 `extension_settings.shiju`。 |
| `saveSettings` | 只写文末列出的设置键。可只传改过的那一层。 |
| `subscribe` | 账或设置变了再重绘。 |
| `detectBaibaiBook` | 运行时是否挂着柏宝书。不扫楼，不写正则。 |
| `watchBaibaiReady` | 书挂上时刷新同一次探测。 |

W4 按钮只调用这两条。调用点保持薄：状态栏和设置页的点击都进同一个处理，分别落到下面的函数。界面不调用 `runAutomaticGate`。单条修正不要调用这两条。

| 名字 | 按钮 |
| --- | --- |
| `runImmediateEvolution` | 「立即演进」。不等跨日，故事日不加一。 |
| `rerunLastEvolution` | 「重跑」。用上次记下的输入覆盖该次结果，故事日不加一。没有 checkpoint 时核心不调模型。 |

W3 可以调用：

| 名字 | 用途 |
| --- | --- |
| `getInjectPreview` | 只读本轮宏观注入。不要自己拼提示词。 |
| `getLifecycleStatus` | `enabled` / `frozen` / 故事日冲突提示。 |
| `setPluginEnabled` | `true` 重开或建世界，`false` 冻结。冻结停演进并清空两把注入 key。 |
| `correctStoryDay` | `{ choice: 'keep' \| 'realign' \| 'set', dayIndex?, dateLabel? }`。不删楼层。 |

`bootstrapWorld` 和 `runAutomaticGate` 由核心自己跑。界面不调用。

## 单条修正（W4）

从 `src/modules/intervene/index.js` 调用。只改一条事件或一条今日变更。不要调用 `runImmediateEvolution`、`rerunLastEvolution`、`commitEvolutionSuccess`，不要给 `evolutionLog` 追加条目，不要前进故事日。取消预览是界面丢掉稿子，不要再调接口。

| 名字 | 用途 |
| --- | --- |
| `saveFactManual({ kind, id, patch })` | 手动保存。`kind` 是 `'event'` 或 `'todayChange'`。`patch` 只认 `title`、`body`。马上写入世界账。模型调用是 0。 |
| `previewAiCorrection({ kind, id, instruction? })` | AI 修订稿。`instruction` 可空。只经 `generateViaST`。返回 `{ previewText, modelCalls: 1, confirm }`。不写账。 |
| `applyAiCorrection({ kind, id, text })` | 采用修订。`text` 可以是模型稿，也可以是用户改过的预览。写入该条 `body`。这次模型调用是 0。 |

点「AI 修正」之前，确认文案必须含「消耗 1 次调用」，并写明只改这一条，不是重跑，也不是立即演进。直接用导出的 `AI_CORRECTION_CONFIRM`。

等待修订稿期间若世界账发生变化，接口会拒绝过期稿件，提示「生成修订稿期间世界账已更新，请重新生成」。界面展示错误并留在指令步骤，由用户决定是否重新生成；不要自动重试或恢复旧账本。

门禁：

- `kind === 'secret'` 或 `secret === true`，且 `revealed !== true`：三条都拒绝，错误码 `SHIJU_INTERVENE_REFUSED`，账不变。这种条目预览也不会调模型。不要做修正入口，也不要把正文放进输入框。
- 已经揭晓的隐秘可以修正。
- 没有世界账、找不到这一条、标题被改成空的、采用的正文是空的，同样拒绝。
- 列表可以继续只列标题。修正框从 `loadWorld()` 读这一条的 `title` 和 `body`。不要改那份副本再存回去。
- 标题超过 40 字、正文超过 500 字会被截断。
- 写成功后这一条带 `evidence: '用户修正'`，`timeline` 多一句「用户修正」。那不是演进日志，不用画出来。

## 只读、可以显示

| 字段 | 面板上怎么用 |
| --- | --- |
| `storyClock` | `dateLabel`、`dayIndex`（故事日）。 |
| `todayChanges` | 列表只显示条数和 `title`，不显示 `body`。`kind === 'secret'` 且未显示时用通用标题“未揭晓的隐秘”。修正框按「单条修正」从 `loadWorld()` 读这一条正文。 |
| `regions` / `orgs` / `factions` | 只显示 `name`。隐秘实体不摊开正文。 |
| `events` | 按帷幕分桶：`kind` 为 `macro` 宏观事态、`news` 远方见闻、`secret` 隐秘。列表可计数、列公开标题；隐秘未显示时不包含真实标题或正文。归档历史默认折叠，每页 10 条。修正框规则与今日变更相同。 |
| `plugin.enabled` / `plugin.frozenAt` | 是否启用。`frozenAt != null` 表示冻结。 |
| `meta.sources.truncated` | 为真时可标「资料被截断」。这只表示摘要、近期正文或 MVU 碰到建议长度。世界书正文不再因此被砍。 |
| `meta.sources.softWarn` | 为真时可软标红。P0 / P1 / P3 超建议长度，或某条世界书正文特别大（仍整条保留）时为真。 |
| `meta.usage` | 最近一次建世界或演进组装的估算 token。`worldbook` 世界书、`mvu` MVU、`recent` 近期正文、`total` 三者之和、`unit` 固定 `"token"`。没有 MVU 时 `mvu` 是 `0`。没有组装过是 `null`。`projectWorld().usage` 是同一份。动态页在「今日变更」上方展示：单位写「估算 token」；`mvu` 为 0 时该块显示「无」；没有这份数据时显示「尚无 · 演进结束后可见」。 |
| 演进入口返回值 `usage` | `runImmediateEvolution` / `rerunLastEvolution`（以及自动门）在真正组装之后带上面这个对象。面板可以读返回值，也可以等账本上的 `meta.usage`。 |

不要展示或改写 `evolutionLog`、`lastEvolutionCheckpoint`、`dayBuffer`。`lastEvolutionCheckpoint` 只允许用来判断「重跑」能不能点，不把内容画出来。

## 两颗按钮何时可点

和 `src/modules/timeGate` 的演进入口同一套门槛。不满足时 `disabled`，`title` 写原因。进行中两颗都不可点，状态栏写「正在立即演进…」或「正在重跑…」。

| 条件 | 「立即演进」 | 「重跑」 |
| --- | --- | --- |
| 没有世界账，或没有 `meta.builtFingerprint` | 不可点 | 不可点 |
| `plugin.frozenAt != null` | 不可点 | 不可点 |
| 有账但 `plugin.enabled` 为假 | 不可点 | 不可点 |
| 末楼正在 regenerate / swipe / regen（`isGeneratingTip()`） | 不可点 | 不可点 |
| 面板操作或核心世界更新仍在进行 | 不可点 | 不可点 |
| 已启用，且上面都不是 | 可点 | 还要已有 checkpoint 才可点 |

同日、缺标签、日期冲突、注入开关、柏宝书档都不额外禁用这两颗。那些只约束自动演进。点下去之后看返回值：`ok && evolved` 时状态栏报告完成；`reason` 为 `generating` / `no-world` / `no-checkpoint` 时写对应原因；其余失败写「演进没有完成」，并 `console.error`。抛错同样写「演进没有完成」。

## 禁止

- 不要直接写 `chatMetadata.shiju`，也不要从界面调用 `saveWorld`。
- 不要调用 `commitEvolutionSuccess`。
- 不要给 `evolutionLog` 追加条目。
- 不要 `fetch` 上游模型。模型只走核心的 `generateViaST`。
- 不要在界面里实现 TimeGate、提交或注入。时间门在 `src/modules/timeGate`，按钮只调用已导出的 `runImmediateEvolution` / `rerunLastEvolution`。
- 不要用单条修正去代替「立即演进」或「重跑」。

界面改 `src/ui/**` 和样式即可。不要为了挂按钮去改 `src/modules/**`。

## 设置键

只经 `saveSettings` 写入 `extension_settings.shiju`。

- `timeSource.mode`：`auto` | `shiju` | `custom` | `baibai`
  - `auto` 表示还没手选。无柏宝书时界面看起来是世局标签，有则看起来是柏宝书。手选后写成明确档，不再跟着探测跳。
  - `baibai` 没探测到就灰显，文案「未检测到柏宝书」。
- `timeSource.customTag`：只在 `custom` 档露出并写入。
- `ui.theme`：`day` | `night` | `pastel` | `green` | `st`
- `ui.fab`：`{ x, y }`。没拖过是 `null`。
- `inject.enabled`：布尔。缺省为开。关掉只停 `shiju_macro`，不停演进。
- `worldbook.forceInclude` / `worldbook.exclude`：书级名单，默认空数组。元素是书名字符串，或 `{ uid?, name? }`。有 uid 的书只认 uid，没有 uid 才认 name。`exclude` 优先于 `forceInclude`。不配就走蓝灯全文 + 绿灯轮转。设置页「高级设置」按已加载的书做三态：默认两边都不写，常驻写入 `forceInclude`，排除写入 `exclude`。只做书级，不做条目勾选。名单来自宿主已加载的世界书，不在界面里重做筛选。
- `worldbookRotateCursor` 在世界账上，归核心。界面不要写。

## 注入 key（界面不要写）

| key | 归属 |
| --- | --- |
| `shiju_timetag` | 核心 `src/modules/timetag`，IN_CHAT / system / depth 0。世局标签档且世界已启用时由核心写入。 |
| `shiju_macro` | 核心 `src/modules/inject`，IN_CHAT / system / depth 4。世界已启用且 `inject.enabled` 开着时写入。冻结或关掉开关时清空。 |

面板不要调用 `setExtensionPrompt`，也不要自己写这两把 key。预览用 `getInjectPreview()`。冻结后演进和两把注入都停；重开不补演关闭期间。


## 编辑归属与隐秘控制

编辑会话捕获聊天归属，切换聊天立即关闭确认框、清除手动草稿和 AI 稿件；切回不恢复旧会话。保存、预览、采用均携带归属给核心检查。任何演进/重跑/重对齐等待期间禁用保存、采用和知情修改，显示“正在演进，完成后可修改”，保留未保存草稿，失败后恢复操作。

隐秘提供“查看内容／收起内容”和“知情状态：自动／主角已知／主角未知”。未查看且主角未知时统一显示“未揭晓的隐秘”，真实标题/正文不进入 DOM、提示或无障碍标签。查看不改变主角知情，正文注入只接受主角已知。关联今日变更共享状态。

“查看归档”默认收起，历史分页保留全文与长期后果。立即演进返回 no-increment 时显示“暂无新的变化可演进”；处理过的正文非追加变动需要对账时提示重新对齐或保持当前账本。


## 提示词与演进偏好编辑

设置页由 `src/ui/promptSettings.js` 管理独立草稿，显示「演进偏好 · 当前聊天」与「模型高级设置 · 全局」。偏好使用五项单选；内置模式展示说明，自定义展示编辑器，并明确「完全替换内置方向」。保存调用核心 `saveEvolutionPreferences`，不能直接写聊天元数据。建世界前可用；演进锁禁用保存但保留草稿，聊天切换清空会话，切回不恢复。

全局编辑器通过 `saveSettings({ model })` 保存。内置原文只读；自定义保存不修剪空白；关闭不删除已保存文本。恢复默认只修改草稿，取消不改变已保存设置。回复长度在跟随酒馆与独立设置之间切换，首次独立值 16384，非法值显示错误并保持编辑状态。全局草稿不随聊天切换丢弃。

保存偏好不会调用模型。有效配置尚未承接时在状态栏和设置区提示「演进偏好已修改，可立即演进一次」，成功后清除。错误使用可聚焦的 alert，操作结果使用 status；所有输入均有显式标签。

## 兼容设置与资料诊断

全局模型草稿增加 `channelMode`（follow/custom）、`endpoint`、`customModel`、`apiKey`。自定义时显示地址、模型、密码输入框；非法地址或空模型在保存时提示并保留草稿。取消不改配置，切换模式不删除已保存地址/模型/密钥。长度设置对两种模式统一适用，界面说明「仅作用于本次世局请求」。

`readDiagnostics()` 返回当前聊天最近一次资料读取/渲染诊断；设置页使用可展开的「资料诊断」列出书名、条目名和拦截/跳过原因。`subscribeDiagnostics()` 负责刷新；聊天归属失效后不展示旧诊断。它不保存宿主变量或密钥，不把未执行的 EJS 放进模型请求。

独立请求与聊天切换、编辑草稿的绑定规则不变。全局模型设置可在等待期间修改，只影响后续请求；聊天偏好仍在演进期间禁用保存。资料不足、快照变化与不兼容接口必须显示具体原因。
