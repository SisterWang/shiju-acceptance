# 世局

只管宏观，不碰记忆与眼前戏。

这是 SillyTavern 的第三方扩展，包名 `shiju`。支持建世界、增量演进、世界账修正、隐秘知情管理与事件归档。演进期间会锁定编辑，草稿只属于当前聊天；没有新增正文、未承接修正或时间推进时，立即演进不会调用模型。模型只经酒馆后端转发，浏览器不 `fetch` 上游。核心行为见 [CORE.md](CORE.md)。

仓库根目录就是扩展目录。不要再套一层 `public/scripts/...`。

## 装进酒馆

目录名必须是 `shiju`。酒馆用文件夹名当扩展 id，设置才会落在 `extension_settings.shiju`。

```bash
cd SillyTavern/public/scripts/extensions/third-party
git clone <仓库地址> shiju
```

刷新酒馆，在扩展列表里启用「世局」。入口是聊天区右下角偏上的圆钮（约 46px，细环、中心点、短刻度，平时半透明）。点开才出现面板，面板开着时圆钮隐藏。

若用酒馆的「从网址安装」，装完确认文件夹名叫 `shiju`，而不是仓库的其它名字。建议酒馆 1.12 及以上。`manifest.json` 里 `auto_update` 为 `false`。

## 本地看壳

不需要把酒馆跑起来。预览用内存里的假宿主，不写聊天文件。

```bash
npm run preview
```

打开 [世局预览](http://127.0.0.1:43123/dev/preview.html)。

冒烟（不启动浏览器）：

```bash
npm run smoke
```

预览已经开着时，可以再跑一轮真正点过四页、换主题、拖圆钮的检查。同一轮还会打开 `?fixture=1`，在没有柏宝书、没有 MVU 的路径上点启用、看实体、冻结再重开，并导出再打开这则聊天：

```bash
npm run browser-smoke
```

`dev/` 只有本地预览会加载。酒馆只认 `manifest.json` 里的 `index.js` 和 `style.css`。

## 降级夹具（A5 / A24）

夹具默认关闭。`index.js` 不加载它，不带 `?fixture=1` 的预览也不装。它只证明一条原生路径：没有柏宝书、没有 MVU，仍能走完启用、注入、旧档不改楼、关闭再开。世界账写在 `chatMetadata.shiju`。导出的聊天 JSON 同时带酒馆文件头 `chat_metadata.shiju` 和 `chatMetadata.shiju`。设置留在 `extension_settings.shiju`。夹具旁边放了一份诱饵账，冒烟确认续读时不用它。

`npm run smoke` 覆盖上面这条，包括卸掉内存里的扩展、用导出的聊天和新宿主再装回去。

仍要在真实酒馆里手测的只有两步：聊天菜单的导出 / 打开，以及扩展面板里卸载再安装。自动夹具模拟这两步留下的聊天文件和设置；真实宿主验证应使用隔离数据目录。注入槽对得上 §5.2；主模型随后写进眼前戏的正文不在这一轮里（那是 A12）。建世界用的是夹具里的固定回复，不是连着的模型。

## 分支

两个人从 `main` 拉分支，合回去之前各自待在自己的前缀里。

| 分支 | 谁 | 含义 |
| --- | --- | --- |
| `main` | 一起合 | 可集成。只有这支当成能装进酒馆的结果。 |
| `feat/core-*` | 核心 | TimeGate、model、commit，以及演进、对账、注入、时间标签、建世界。 |
| `feat/ui-*` | 界面 / 存取壳 | 面板、主题、Store、悬浮球。 |

例子：`feat/core-timegate`，`feat/ui-feed-cards`。分支名用小写。

W1–W3 的行为、三条入口和唯一的 `evolutionLog` 追加点写在 [CORE.md](CORE.md)。不要在面板上另开一条追加日志的路。

## 谁改哪里

界面主改：

- `src/store/**`
- `src/ui/**`
- `style.css`
- `dev/**`

核心主改：

- `src/modules/model`
- `src/modules/bootstrap`
- `src/modules/timetag`
- `src/modules/timeGate`
- `src/modules/evolve`
- `src/modules/commit`
- `src/modules/reconcile`
- `src/modules/inject`
- `src/modules/lifecycle`

两边都会碰到、尽量少改：

- `index.js` — 只负责接上酒馆的 `getContext` / `extension_settings`
- `src/main.js` — 启动，并调用各模块的 `register()`
- `manifest.json`

界面不要直接改 `chatMetadata` 或 `extension_settings`，只走 Store。核心不要为了挂按钮去改 `src/ui`。酒馆事件写在模块自己的 `register()` 里。时间标签和对账会在那里挂监听。设置里的「立即演进」「重跑」只调用 `runImmediateEvolution` / `rerunLastEvolution`。界面不调用 `runAutomaticGate`。

`index.js` 里的相对路径按这个位置算：

`SillyTavern/public/scripts/extensions/third-party/shiju/index.js`

## Store

| 函数 | 落点 |
| --- | --- |
| `loadWorld()` / `saveWorld(world)` | `chatMetadata.shiju`，跟这则聊天走 |
| `loadSettings()` / `saveSettings(patch)` | `extension_settings.shiju`，跟酒馆后端的 `settings.json` 走 |

约定：

- 每次都重新拿宿主上下文，不把 `chatMetadata` 的引用存下来。
- `loadWorld()` 在这则聊天还没有账时返回 `null`，不会擅自建世界。
- `saveWorld` 写入副本。调用方改自己的对象不会悄悄改到账上，要再存一次。
- `saveSettings` 可以只传改过的那一层，例如 `{ ui: { theme: 'night' } }`，不会把悬浮球位置抹掉。
- 世界状态 `schemaVersion` 为 7，高于 7 的版本会保留。旧世界账默认将自然演进视为已承接；当前聊天的演进偏好独立保存在 `chatMetadata.shijuPreferences`。
- **不用 IndexedDB 当主账。** 设置走酒馆后端，世界账走聊天存档。导出聊天会夹带世局的账。

主题存在 `extension_settings.shiju.ui.theme`。

| id | 面板上的名字 |
| --- | --- |
| `day` | 日间 |
| `night` | 夜间 |
| `pastel` | 粉彩 |
| `green` | 木白 |
| `st` | 跟随ST（默认） |

面板根节点是 `#shiju-chrome`，用 `data-theme` 挂 `--sj-*`。`st` 读取 `--SmartTheme*`，缺变量时有回退色。悬浮球位置在 `ui.fab`（`{ x, y }`，没拖过是 `null`）。

时间源在 `extension_settings.shiju.timeSource`。`mode` 没手选过是 `auto`。设置页三档互斥，只通过 `saveSettings` 写入：

| 界面 | 存进去的 `mode` | 什么时候能选 |
| --- | --- | --- |
| 世局标签 | `shiju` | 始终 |
| 自定义标签 | `custom` | 始终。只有这一档露出「标签名」输入，写进 `customTag` |
| 柏宝书 | `baibai` | 探测到柏宝书才可点，否则灰显，文案「未检测到柏宝书」 |

`auto` 在界面上的默认：没有柏宝书时看起来是世局标签，有则看起来是柏宝书。手点某一档之后写成明确的 `mode`，不再跟着探测结果跳。探测到柏宝书时，时间源下面固定写「检测到柏宝书 · 可选手改」。

探测只看运行时标记：`STBaiBaiBook`、`bbs_generateInterceptor`，或页面上的 `#bbs-app-host`。不扫楼，不写隐藏正则，不注入 `shiju_timetag`。本地预览可以点「柏宝书：未检测到」切换这个结果，也可以打开 `?baibai=1`。

## 四页

动态、世界、事件、设置。宽屏分页在顶上，窄屏改成底栏。内容区自己滚动，分页在文档流里，不固定盖住最后一行。

动态以「今日变更」为主，旁边能看到地区、势力、组织的数目。世界页用这三档切换，只显示名字。事件页是全部 / 宏观事态 / 远方见闻 / 隐秘。隐秘和今日变更都不摊开正文。

这一版没有场景页、位置纠偏；演进方向可在设置页选择。状态栏和设置里的「立即演进」「重跑」走核心的立即演进和重跑：不等跨日，故事日不加一。没有已启用的世界、世界冻结、末楼正在生成时按钮不可点；重跑还要已有检查点。

主题五档仍是日间、夜间、粉彩、木白、跟随ST，色值对齐 UI v4.2。

## 先钉死、先不写内容的 key

| key | 模块 | depth |
| --- | --- | --- |
| `shiju_timetag` | `src/modules/timetag` | 0 |
| `shiju_macro` | `src/modules/inject` | 4 |

`shiju_timetag` 在世界已启用、且有效时间源是世局标签时写到 depth 0，并同步显示层隐藏正则 `shiju-time-tag-hide`（`markdownOnly: true`，`promptOnly: false`，标签留在 `mes` 里）。自定义标签只解析、并按该标签藏显示层，不写这把 key。柏宝书档清掉这把 key，隐藏正则仍交给柏宝书。

`shiju_macro` 在世界已启用且 `inject.enabled` 开着时写到 depth 4。宏观和远方进入短摘要，远方带「发生于远方」，隐秘默认不进。固定句是「背景参考，不必强行写入正文」。冻结或关掉注入开关时这把 key 清空；冻结同时清掉时间标签。两把 key 不混写，也不改历史楼层。

## 这一版还不做

- 不在浏览器里 `fetch` 上游。模型只走 `generateViaST` → 宿主 `generateViaBackend`（独立同源后端请求）
- 面板上的 AI 单条修正、「立即演进」「重跑」只转调核心，不在界面里另写一套演进
- 不用 IndexedDB，也不用 localStorage 当主账


## 提示词与演进偏好

设置页分为两种保存范围：

- **演进偏好 · 当前聊天**：自然演进、平稳经营、暗流博弈、动荡变局、自定义，五选一。自定义完全替换内置方向，事实一致性、隐秘证据和输出结构等固定规则仍保留。切换模式保留已保存的自定义文本；空白自定义不能保存。建世界前也能配置，不会因此创建世界账。
- **模型高级设置 · 全局**：破限提示词默认内置，也可自定义或关闭。自定义逐字保存，切换模式及升级不覆盖文本。「恢复默认提示词」只替换草稿，保存后生效，取消不改变原设置。后台建世界、演进、重跑、重对齐和 AI 单条修正均使用此设置，不加入主聊天注入槽。

保存偏好不调用模型。已有世界的有效偏好发生变化后，显示「演进偏好已修改，可立即演进一次」；即使没有新正文，也可以点击立即演进承接一次。成功后不会重复调用，失败可以重试；自动演进仍需跨日。演进期间禁止保存聊天偏好并保留草稿，切换聊天清除旧草稿。全局设置可在等待期间修改，仅影响后续请求。

回复长度默认「跟随酒馆」。选择「独立设置」时初始编辑值为 16384，可改为接口支持的正安全整数；不会自动缩减，也不会因失败自动重试。长度只写入本次独立请求体，不修改宿主设置，不需要全局模型串行队列。

内置原文来自 [ST-BaiBai-Book 固定版本的导出实现](https://github.com/baibai-git/ST-BaiBai-Book/blob/0a3a1cdfe92bf5ff1b822b6b6588cb694090d0da/src/memory/prompts.ts#L369)：取同目录 `prompts/tasks.txt` 开头至 `</nvwa_standalone_core>`，按上游规则去除首尾空白，不包含后续任务模板。本地文件为 `src/prompts/baibai-jailbreak.js`，运行时不联网下载。

- 提交：`0a3a1cdfe92bf5ff1b822b6b6588cb694090d0da`
- 实际内置字符串 UTF-8：3299 字节
- SHA-256：`a542ee60ae52efa1605e7e4594de635c4750c4ed69f1c351ad46e0f71e55299d`

`npm run smoke` 验证原文字节与校验值、模型消息、偏好迁移和一次性承接；`npm run browser-smoke` 在预览服务启动后验证设置编辑、取消、重置与聊天隔离。真实宿主验收使用隔离的 SillyTavern 1.16 / 1.17 和固定模型回复，检查独立请求消息及并发长度隔离，不以模型是否拒答判断迁移一致性。

## 隐藏楼层与插件兼容（schema 7）

隐藏和取消隐藏只改变可见性，不再触发历史修改提示，也不会倒退世界日期。已处理正文不重复处理；新正文被观察到手动隐藏后，会记录为排除，之后取消隐藏也不会自动补演。真正修改正文、删除、重排和切换 swipe 仍需对账。处理边界与排除记录随世界账、检查点保存；旧边界无法验证时，从当前末楼建立基线并提示。

已处理楼层的正文被改写后，即使日期标签没变，也会保留原处理记录并提示“已处理的正文有修改”。可选择“以正文为准重对齐”，或“保持插件状态”；检测和提示本身不调用模型。日期未变不会重复推进时间，但不再据此自动认可正文改写。撤销到原正文会清除提示；末楼纯追加仍作为新增正文处理。旧版已经覆盖的处理记录不会因升级自动重建，需要单独核对，不能据旧检查点盲目回退。

柏宝书压缩历史与最近有效正文一起作为背景。优先按公开 API 的楼层范围去重，最近正文优先；摘要失败时保留正文并提示。柏宝书接管隐藏的未处理楼层可通过有效记忆承接一次；手动排除的内容不会借摘要重新进入。读取期间聊天或记忆 revision 变化时最多重读一次，仍不一致就提示重试，不消耗增量。

### 只读世界书 EJS

世界书先按原有规则选条目，再展开常用宏和 EJS。计算在本地打包的独立 Worker 与 SES 隔离环境内进行，不调用提示词模板的执行器或生命周期任务。

支持表达式、条件、循环、异步文本计算、普通局部变量；`variables`、`getvar`、`getGlobalVar`、`getLocalVar`、`getMessageVar`；用户/角色资料、当前 swipe 的变量副本；`getwi` / `getWorldInfo` 和显式 `include`。变量合并顺序为全局、初始、聊天、当前楼层（无变量时向前寻找）。可使用 JSON、Math 和打包的 Lodash 计算子集。依赖读取继续遵守书级排除。

HTML 注释、`-->` 文本及普通字符串中的相同内容可以与 EJS 混用；编译后的代码在 Worker 内进行兼容转换，实际输出的文字、空白和换行保留，不改世界书原文。Lodash 子集包含 `_.omit(object, ...paths)`，支持字段列表、嵌套字段和数组下标路径；先复制输入再省略字段，返回值可以继续修改，不影响变量快照。

写变量及直接赋值、删除、数组修改不改变快照，记录拦截原因。宿主指令、发消息、保存、注入、网络和动态模块加载不可用。错误、不支持的宏/辅助函数或循环依赖会跳过该条，不发送原始 EJS。每条最多 2 秒，整轮最多 10 秒；超时后跳过剩余动态条目，静态条目保留。设置页的「资料诊断」可展开查看书名、条目和原因。全部有效资料为空时不调用模型。

诊断区分代码转换、执行、依赖失败和超时；引用失败时展示父条目至失败条目的路径，不记录完整模板或异常中携带的变量内容。两秒限时包含 Worker 加载、编译、转换和执行，不为兼容转换另加时间。

这不是提示词模板完整运行环境：例如 DOM、faker、自定义可写函数、自动 `[GENERATE:*]` / `[RENDER:*]` / `@INJECT` 不在支持范围。包含 HTML 注释序列或 `import(` 文本的带标签模板（例如 `String.raw` 后接模板字符串）暂不支持，会明确提示并跳过；普通模板字符串不受此限制。Lodash 支持清单与第三方许可证见 [vendor/NOTICE.md](vendor/NOTICE.md)。

### 独立请求与自定义渠道

模型高级设置提供「跟随酒馆／自定义渠道」。自定义只保存一组 API 地址、模型和密钥，切换模式保留配置，保存和取消分开。地址接受基址或完整 `/chat/completions`；密钥遮罩，配置仅保存在全局 `extension_settings.shiju.model`，不进入聊天导出。

两种模式都经酒馆同源后端转发。跟随模式适配 SillyTavern 1.16 / 1.17 的 Chat Completion、Text Completion、Kobold、NovelAI、AI Horde；未知版本或接口报错。请求使用操作开始时捕获的连接、格式、采样和长度副本，不触发正文生成或提示词处理事件，不使用 `generateRaw`，不改全局连接、流式开关或回复长度。与其他插件并发时不相互恢复或覆盖设置。

跟随长度读取当前接口的设置；独立上限只覆盖本次请求的对应字段，不自动缩减。请求非流式、无工具调用；失败不自动重试。Horde 只轮询已创建的任务，聊天切换会取消世局请求及对应 Horde 任务。主聊天提示词、时间标签槽、世界写入锁和重跑历史策略保持原有行为。

开发时 `npm ci && npm run build` 重建 Worker；插件安装无需 npm 或运行时联网下载依赖。自动回归用 `npm run smoke`，浏览器回归用 `npm run browser-smoke`。真实宿主测试只使用临时目录、虚构聊天和固定回复，详见 [COMPATIBILITY-VALIDATION.md](COMPATIBILITY-VALIDATION.md)。
