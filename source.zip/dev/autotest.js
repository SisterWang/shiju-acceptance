import { runCompatibilityAutotest } from './compatibility-autotest.js';
import { runPromptSettingsAutotest } from './prompt-settings-autotest.js';
import { createEmptyWorld } from '../src/store/schema.js';
import { loadSettings, loadWorld, saveWorld } from '../src/store/index.js';
import { runImmediateEvolution } from '../src/modules/timeGate/index.js';
import { isWorldBusy } from '../src/modules/turn.js';
import { captureInputBoundary } from '../src/modules/incremental.js';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const FORBIDDEN = ['调方向', '位置纠偏', '可参与', '场景'];

export async function runAutotest() {
  const node = document.createElement('p');
  node.id = 'sj-autotest';
  node.textContent = '自检中';
  document.body.appendChild(node);
  try {
    await steps();
    await runPromptSettingsAutotest();
    await runCompatibilityAutotest();
    node.dataset.state = 'ok';
    node.textContent = '自检通过';
    document.documentElement.dataset.sjAutotest = 'ok';
  } catch (error) {
    node.dataset.state = 'fail';
    node.textContent = error instanceof Error ? error.message : String(error);
    document.documentElement.dataset.sjAutotest = 'fail';
    document.documentElement.dataset.sjAutotestError = node.textContent;
    console.error(error);
  }
}

async function steps() {
  const root = document.getElementById('shiju-chrome');
  const fab = root?.querySelector('.sj-fab');
  const panel = document.getElementById('shiju-panel');
  assert(root && fab && panel, 'chrome missing');
  assert(panel.hidden, 'panel should start closed');
  assert(!fab.hidden, 'fab should start visible');
  assert(fab.querySelector('svg'), 'fab needs an icon');
  assert(fab.textContent.trim() === '', 'fab must not use the two characters as its label');
  assert(fab.getAttribute('aria-label') === '世局', 'fab name');

  const box = fab.getBoundingClientRect();
  assert(box.width >= 44 && box.width <= 48, `fab width ${box.width}`);
  const body = document.getElementById('shiju-page');

  fab.click();
  assert(!panel.hidden, 'panel did not open');
  assert(body.textContent.includes('本轮用量（估算 token）'), 'usage label on the feed');
  assert(body.textContent.includes('尚无 · 演进结束后可见'), 'empty usage before a round');
  assert(fab.hidden, 'fab should hide while the panel is open');
  assert(getComputedStyle(panel).display === 'flex', 'panel display');
  assert(getComputedStyle(body).overflowY === 'auto', 'body should scroll on its own');
  const tabs = root.querySelector('.sj-tabs');
  assert(getComputedStyle(tabs).position !== 'fixed', 'tabs must stay in flow');

  const seen = new Set();
  for (const id of ['feed', 'world', 'events', 'settings']) {
    root.querySelector(`[role="tab"][data-page="${id}"]`).click();
    assert(body.dataset.page === id, `page ${id}`);
    seen.add(id);
  }
  assert(seen.size === 4, 'four pages');

  const html = root.innerHTML;
  for (const word of FORBIDDEN) assert(!html.includes(word), `forbidden copy: ${word}`);
  for (const label of ['日间', '夜间', '粉彩', '木白', '跟随ST']) {
    assert(html.includes(label), `missing theme ${label}`);
  }
  for (const label of ['世局标签', '自定义标签', '柏宝书']) {
    assert(html.includes(label), `missing time source ${label}`);
  }
  assert(html.includes('未检测到柏宝书'), 'missing-book copy');
  assert(!html.includes('可选手改'), 'hand-edit hint without the book');
  const baibai = root.querySelector('input[name="sj-time-source"][value="baibai"]');
  assert(baibai?.disabled, 'baibai stays gray without the book');
  assert(root.querySelector('input[name="sj-time-source"][value="shiju"]')?.checked, 'default mode is shiju');
  assert(!root.querySelector('#sj-custom-tag'), 'custom tag stays hidden');
  const placeholders = [...root.querySelectorAll('[data-action="evolve"], [data-action="rerun"]')];
  assert(placeholders.length >= 2, 'evolution placeholders');
  for (const button of placeholders) assert(button.disabled, 'evolution placeholder must stay disabled');

  const before = getComputedStyle(panel).backgroundColor;
  root.querySelector('input[value="night"]').click();
  assert(root.dataset.theme === 'night', 'night token');
  assert(loadSettings().ui.theme === 'night', 'night persisted');
  const after = getComputedStyle(panel).backgroundColor;
  assert(before !== after, 'theme tokens did not change the panel');

  root.querySelector('input[value="pastel"]').click();
  const accent = getComputedStyle(root).getPropertyValue('--sj-accent').trim().toLowerCase();
  assert(accent.includes('c4486d'), `pastel accent ${accent}`);

  for (const id of ['day', 'green', 'st']) {
    root.querySelector(`input[value="${id}"]`).click();
    assert(root.dataset.theme === id, id);
  }

  root.querySelector('input[name="sj-time-source"][value="custom"]').click();
  const tag = root.querySelector('#sj-custom-tag');
  assert(tag, 'custom tag input');
  tag.value = 'story_end';
  tag.dispatchEvent(new Event('input', { bubbles: true }));
  assert(loadSettings().timeSource.mode === 'custom', 'custom mode saved');
  assert(loadSettings().timeSource.customTag === 'story_end', 'custom tag saved');
  root.querySelector('input[name="sj-time-source"][value="shiju"]').click();
  assert(loadSettings().timeSource.mode === 'shiju', 'shiju mode saved');
  assert(!root.querySelector('#sj-custom-tag'), 'tag input hides off custom');

  const injectBtn = root.querySelector('[data-action="toggle-inject"]');
  assert(injectBtn?.textContent === '注入开', 'inject starts on');
  injectBtn.click();
  assert(loadSettings().inject.enabled === false, 'inject switch saved');
  assert(root.querySelector('[data-action="toggle-inject"]')?.textContent === '注入关', 'inject label');
  root.querySelector('[data-action="toggle-inject"]').click();
  assert(loadSettings().inject.enabled === true, 'inject switch restored');
  assert(root.dataset.inject === '0' || root.dataset.inject === '1', 'inject status is on the shell');
  assert(root.dataset.frozen === '0', 'not frozen without a ledger');
  const enable = root.querySelector('[data-action="toggle-plugin"]');
  assert(enable?.textContent === '启用', 'enable when there is no ledger');
  enable.click();
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert(loadWorld() == null, 'enable without a backend does not write a ledger');
  assert(root.querySelector('[data-action="evolve"]').disabled, 'evolve stays disabled after enable');
  assert(root.querySelector('[data-action="rerun"]').disabled, 'rerun stays disabled after enable');

  root.querySelector('.sj-close').click();
  assert(panel.hidden, 'panel did not close');
  assert(!fab.hidden, 'fab should return');

  const start = fab.getBoundingClientRect();
  const down = { clientX: start.left + 10, clientY: start.top + 10, button: 0, pointerId: 1, bubbles: true };
  fab.dispatchEvent(new PointerEvent('pointerdown', down));
  window.dispatchEvent(new PointerEvent('pointermove', {
    clientX: start.left + 70,
    clientY: start.top - 40,
    pointerId: 1,
    bubbles: true,
  }));
  window.dispatchEvent(new PointerEvent('pointerup', {
    clientX: start.left + 70,
    clientY: start.top - 40,
    pointerId: 1,
    bubbles: true,
  }));
  fab.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  assert(panel.hidden, 'a drag must not open the panel');
  assert(!fab.classList.contains('is-default'), 'drag should leave the default corner');
  const saved = loadSettings().ui.fab;
  assert(typeof saved.x === 'number' && typeof saved.y === 'number', 'fab position was not saved');

  fab.click();
  assert(!panel.hidden, 'fab click should open after a drag');
  root.querySelector('[data-page="world"]').click();
  assert(body.textContent.includes('还没有世局记录'), 'empty world copy');

  const world = createEmptyWorld();
  world.plugin.enabled = true;
  world.storyClock.dateLabel = '甲辰春';
  world.storyClock.dayIndex = 4;
  world.meta.sources.truncated = true;
  world.meta.usage = { worldbook: 300000, mvu: 0, recent: 2000, total: 302000, unit: 'token' };
  world.regions.push({ id: 'r1', name: '江左', summary: '不该出现的地区正文' });
  world.todayChanges.push(
    { id: 'a', title: '江潮', kind: 'macro', body: '不该出现的变更正文' },
    { id: 'b', title: '暗线', kind: 'secret', body: '不该出现的隐秘正文' },
  );
  world.events.push(
    { id: 'e1', kind: 'news', title: '远讯', body: '不该出现的见闻正文' },
    { id: 'e2', kind: 'secret', title: '密室', body: '不该出现的事件正文' },
  );
  await saveWorld(world);
  const loaded = loadWorld();
  assert(loaded.storyClock.dateLabel === '甲辰春', 'world round trip');
  assert(loaded.regions.length === 1, 'region kept');
  assert(body.textContent.includes('数目读自这则聊天的世界账'), 'world page did not refresh');
  assert(body.textContent.includes('1'), 'region count');
  assert(body.textContent.includes('江左'), 'region name');
  assert(!body.textContent.includes('不该出现的地区正文'), 'region body stays hidden');
  assert(body.textContent.includes('资料被截断'), 'truncated hint on the open page');
  assert(document.getElementById('sj-status').textContent === '已启用', 'enabled status');
  assert(document.getElementById('sj-day').textContent.includes('甲辰春'), 'date label');
  assert(document.getElementById('sj-day').textContent.includes('D4'), 'day index');
  assert(!document.getElementById('sj-trunc').hidden, 'truncated chip');

  root.querySelector('[role="tab"][data-page="feed"]').click();
  assert(body.textContent.includes('江潮'), 'public change title');
  assert(!body.textContent.includes('暗线'), 'unrevealed change title stays hidden');
  assert(!body.textContent.includes('不该出现的变更正文'), 'change body stays hidden');
  assert(body.textContent.includes('未揭晓前不列标题'), 'secret changes are count only');
  assert(body.textContent.includes('30万'), 'usage shows worldbook tokens');
  assert(body.textContent.includes('2千'), 'usage shows recent tokens');
  assert(body.textContent.includes('30.2万'), 'usage shows the total');
  const mvuLabel = [...body.querySelectorAll('.sj-ub-k')].find((el) => el.textContent === 'MVU');
  assert(mvuLabel?.nextElementSibling?.textContent === '无', 'missing mvu reads 无');
  assert(body.querySelector('.sj-usage') && body.querySelector('.sj-tl-head'), 'usage bar and today changes both render');
  const usageNode = body.querySelector('.sj-usage');
  const todayNode = body.querySelector('.sj-tl-head');
  assert(usageNode.compareDocumentPosition(todayNode) & Node.DOCUMENT_POSITION_FOLLOWING, 'usage bar is above today changes');

  root.querySelector('[role="tab"][data-page="events"]').click();
  assert(body.textContent.includes('远讯') && body.textContent.includes('未揭晓的隐秘'), 'public and concealed event titles');
  assert(!body.innerHTML.includes('密室'), 'secret title stays out of visible text and attributes');
  assert(!body.textContent.includes('不该出现的见闻正文'), 'event body stays hidden');
  assert(!body.textContent.includes('不该出现的事件正文'), 'secret event body stays hidden');
  assert(!body.querySelector('[data-fix-open="event:e2"]'), 'unrevealed event has no correction entry');
  assert(body.querySelector('[data-fix-open="event:e1"]'), 'news event can be corrected');

  const hostPreview = globalThis.__SHIJU_PREVIEW_HOST__;
  hostPreview.state.modelCalls = 0;
  hostPreview.generateViaBackend = async (request) => {
    hostPreview.state.modelCalls += 1;
    hostPreview.state.lastPurpose = request?.purpose || '';
    return '模型修订稿';
  };
  const waitFor = async (predicate, message) => {
    for (let i = 0; i < 40; i += 1) {
      if (predicate()) return;
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    assert(predicate(), message);
  };

  root.querySelector('[role="tab"][data-page="feed"]').click();
  assert(!body.querySelector('[data-fix-open="todayChange:b"]'), 'unrevealed change has no correction entry');
  body.querySelector('[data-fix-open="todayChange:a"]').click();
  assert(body.querySelector('.sj-fix')?.dataset.fixMode === 'manual', 'editor opens on manual');
  assert(body.textContent.includes('手动') && body.textContent.includes('AI'), 'manual and ai segments');
  body.querySelector('#sj-fix-title').value = '江潮改';
  body.querySelector('#sj-fix-body').value = '手改正文';
  body.querySelector('[data-fix-save]').click();
  await waitFor(
    () => loadWorld().todayChanges.find((item) => item.id === 'a')?.body === '手改正文'
      && body.textContent.includes('已保存')
      && !body.querySelector('[data-fix-mode="ai"]')?.disabled,
    'manual save did not write',
  );
  const edited = loadWorld();
  const editedChange = edited.todayChanges.find((item) => item.id === 'a');
  assert(editedChange.title === '江潮改', 'manual save writes the title');
  assert(editedChange.evidence === '用户修正', 'manual save records evidence');
  assert(edited.todayChanges.find((item) => item.id === 'b').body === '不该出现的隐秘正文', 'manual save leaves the secret');
  assert(edited.events.find((item) => item.id === 'e1').body === '不该出现的见闻正文', 'manual save leaves the other fact');
  assert(edited.storyClock.dayIndex === 4, 'manual save does not advance the day');
  assert(edited.evolutionLog.length === 0, 'manual save does not append a log');
  assert(hostPreview.state.modelCalls === 0, 'manual save does not call the model');

  body.querySelector('[data-fix-mode="ai"]').click();
  assert(body.textContent.includes('只改这一条 · 先出修订稿 · 采用后才写入'), 'ai explains preview then adopt');
  const beforeConfirm = JSON.stringify(loadWorld());
  body.querySelector('[data-fix-generate]').click();
  const confirm = document.getElementById('sj-confirm');
  assert(confirm && !confirm.hidden, 'preview asks before calling');
  const confirmCopy = document.getElementById('sj-confirm-body').textContent;
  assert(confirmCopy.includes('消耗 1 次调用'), 'confirm names the one call');
  assert(confirmCopy.includes('不是重跑上次演进') && confirmCopy.includes('也不是立即演进'), 'confirm is not an evolution');
  confirm.querySelector('[data-confirm="cancel"]').click();
  await new Promise((resolve) => setTimeout(resolve, 30));
  assert(confirm.hidden, 'confirm cancel closes the dialog');
  assert(hostPreview.state.modelCalls === 0, 'confirm cancel does not call the model');
  assert(JSON.stringify(loadWorld()) === beforeConfirm, 'confirm cancel does not write');
  assert(!body.querySelector('#sj-fix-draft') && !body.querySelector('[data-fix-apply]'), 'confirm cancel never reaches adopt');

  body.querySelector('[data-fix-generate]').click();
  confirm.querySelector('[data-confirm="ok"]').click();
  await waitFor(() => Boolean(body.querySelector('#sj-fix-draft')), 'preview draft did not appear');
  assert(body.querySelector('#sj-fix-draft').value === '模型修订稿', 'preview stays in the editor');
  assert(loadWorld().todayChanges.find((item) => item.id === 'a').body === '手改正文', 'preview does not write');
  assert(hostPreview.state.modelCalls === 1 && hostPreview.state.lastPurpose === 'correct', 'preview spends one correction call');
  body.querySelector('#sj-fix-draft').value = '用户改过的修订';
  const beforeCancel = JSON.stringify(loadWorld());
  body.querySelector('.sj-fix [data-fix-dismiss="cancel"]').click();
  await new Promise((resolve) => setTimeout(resolve, 30));
  assert(!body.querySelector('.sj-fix'), 'cancel closes the editor');
  assert(!body.querySelector('[data-fix-apply]'), 'cancel removes adopt');
  assert(JSON.stringify(loadWorld()) === beforeCancel, 'cancel does not call apply');
  assert(hostPreview.state.modelCalls === 1, 'cancel does not spend another call');
  assert(loadWorld().todayChanges.find((item) => item.id === 'a').title === '江潮改', 'cancel keeps the manual title');
  assert(loadWorld().todayChanges.find((item) => item.id === 'a').body === '手改正文', 'cancel keeps the manual body');

  body.querySelector('[data-fix-open="todayChange:a"]').click();
  body.querySelector('[data-fix-mode="ai"]').click();
  body.querySelector('[data-fix-generate]').click();
  confirm.querySelector('[data-confirm="ok"]').click();
  await waitFor(() => Boolean(body.querySelector('#sj-fix-draft')), 'second preview did not appear');
  body.querySelector('.sj-fix [data-fix-dismiss="discard"]').click();
  assert(body.querySelector('#sj-fix-instr'), 'discard returns to the instruction step');
  assert(!body.querySelector('[data-fix-apply]'), 'discard removes adopt');
  assert(loadWorld().todayChanges.find((item) => item.id === 'a').body === '手改正文', 'discard does not call apply');
  assert(hostPreview.state.modelCalls === 2, 'discard does not spend another call');

  body.querySelector('[data-fix-generate]').click();
  confirm.querySelector('[data-confirm="ok"]').click();
  await waitFor(() => Boolean(body.querySelector('#sj-fix-draft')), 'adopt preview did not appear');
  body.querySelector('#sj-fix-draft').value = '采用后的正文';
  body.querySelector('[data-fix-apply]').click();
  await waitFor(
    () => loadWorld().todayChanges.find((item) => item.id === 'a')?.body === '采用后的正文',
    'adopt did not write',
  );
  const adopted = loadWorld().todayChanges.find((item) => item.id === 'a');
  assert(adopted.title === '江潮改', 'adopt keeps the earlier manual title');
  assert(hostPreview.state.modelCalls === 3, 'adopt does not spend a call');
  assert(loadWorld().evolutionLog.length === 0, 'adopt does not append a log');
  assert(loadWorld().storyClock.dayIndex === 4, 'adopt does not advance the day');
  assert(loadWorld().events.find((item) => item.id === 'e2').body === '不该出现的事件正文', 'adopt leaves the secret event');
  delete hostPreview.generateViaBackend;

  root.querySelector('[role="tab"][data-page="events"]').click();
  assert(!body.querySelector('.sj-fix'), 'leaving the page drops the local draft');
  assert(!body.querySelector('[data-fix-open="event:e2"]'), 'unrevealed event still has no entry');
  assert(!body.textContent.includes('不该出现的事件正文'), 'secret event body stays out');

  world.meta.builtFingerprint = 'preview-built';
  await saveWorld(world);
  hostPreview.state.worldInfoEntries = [
    { bookName: '北境纪年', bookUid: 'wb-north', comment: '纪年', content: '北境全文' },
    { bookName: '东湾通商志', comment: '通商', content: '东湾全文' },
  ];
  root.querySelector('[role="tab"][data-page="settings"]').click();
  await waitFor(
    () => body.textContent.includes('北境纪年') && body.textContent.includes('东湾通商志'),
    'loaded world books did not appear',
  );
  assert(body.textContent.includes('不是只蓝灯'), 'pin legend');
  assert(body.textContent.includes('名册 + 正文都不进'), 'exclude legend');
  const modeButton = (name, mode) => [...body.querySelectorAll('[data-wb-mode]')].find((btn) => btn.dataset.wbName === name && btn.dataset.wbMode === mode);
  modeButton('北境纪年', 'pin').click();
  assert(loadSettings().worldbook.forceInclude.some((item) => item?.uid === 'wb-north'), 'pin writes the uid');
  assert(body.querySelector('details.sj-adv')?.open, 'advanced stays open after a choice');
  modeButton('东湾通商志', 'exclude').click();
  assert(loadSettings().worldbook.exclude.includes('东湾通商志'), 'exclude writes the name');
  assert(!loadSettings().worldbook.forceInclude.some((item) => item === '东湾通商志' || item?.name === '东湾通商志'), 'exclude is not also pinned');
  assert(modeButton('北境纪年', 'pin')?.classList.contains('is-on'), 'pin stays selected');
  assert(modeButton('东湾通商志', 'exclude')?.classList.contains('is-on'), 'exclude stays selected');
  modeButton('北境纪年', 'default').click();
  assert(!loadSettings().worldbook.forceInclude.some((item) => item?.uid === 'wb-north'), 'default drops the pin');
  assert(!loadSettings().worldbook.exclude.some((item) => item?.uid === 'wb-north'), 'default does not exclude');
  assert(loadSettings().worldbook.exclude.includes('东湾通商志'), 'the other book stays excluded');
  assert(!body.querySelector('input[type="checkbox"]'), 'no entry checkboxes');
  const allEvolve = () => [...root.querySelectorAll('[data-action="evolve"]')];
  const allRerun = () => [...root.querySelectorAll('[data-action="rerun"]')];
  assert(allEvolve().length >= 2 && allRerun().length >= 2, 'header and settings both expose the actions');
  assert(allEvolve().every((button) => button.disabled === false), 'immediate evolve does not wait for a new day');
  assert(allRerun().every((button) => button.disabled), 'rerun waits for a checkpoint');
  assert(allRerun().every((button) => button.title.includes('还没有可重跑')), 'rerun says why it is off');

  const host = globalThis.__SHIJU_PREVIEW_HOST__;
  host.eventSource.emit(host.event_types.GENERATION_STARTED, 'swipe');
  await new Promise((resolve) => setTimeout(resolve, 20));
  assert(allEvolve().every((button) => button.disabled && button.title.includes('末楼正在生成')), 'generating tip disables evolve');
  assert(allRerun().every((button) => button.disabled), 'generating tip disables rerun');
  const marked = host.state.savedMetadata;
  host.eventSource.emit(host.event_types.GENERATION_STOPPED);
  for (let i = 0; i < 40; i += 1) {
    const settled = host.state.savedMetadata > marked && allEvolve().every((button) => !button.disabled);
    if (settled) break;
    await new Promise((resolve) => setTimeout(resolve, 15));
  }
  assert(allEvolve().every((button) => !button.disabled), 'evolve returns after the tip settles');

  const armed = loadWorld();
  armed.lastEvolutionCheckpoint = { evolutionId: 'preview-checkpoint' };
  await saveWorld(armed);
  assert(!root.innerHTML.includes('preview-checkpoint'), 'checkpoint is not rendered');
  assert(!root.innerHTML.includes('lastEvolutionCheckpoint'), 'checkpoint field is not rendered');
  assert(allRerun().every((button) => !button.disabled), 'rerun enables when a checkpoint exists');
  assert(allRerun().every((button) => button.title.includes('故事日不加一')), 'rerun title keeps the day put');

  const frozenLedger = loadWorld();
  await waitFor(() => !isWorldBusy(), 'settled operation must release its lock');
  frozenLedger.plugin.frozenAt = 3;
  await saveWorld(frozenLedger);
  assert(document.getElementById('sj-status').textContent.startsWith('已冻结'), 'freeze status follows the ledger');
  assert(loadWorld().plugin.frozenAt === 3, 'freeze is only a stored field');
  assert(allEvolve().every((button) => button.disabled), 'freeze disables evolve');
  assert(allRerun().every((button) => button.disabled), 'freeze disables rerun');

  root.querySelector('[data-action="evolve"]').click();
  root.querySelector('[data-action="rerun"]').click();
  assert(loadWorld().evolutionLog.length === 0, 'disabled clicks do not append a log');
  assert(loadWorld().todayChanges.length === 2, 'disabled clicks do not rewrite today changes');

  const live = loadWorld();
  live.plugin.enabled = true;
  live.plugin.frozenAt = null;
  live.processedInput = captureInputBoundary(hostPreview.state.chat);
  const dayBefore = live.storyClock.dayIndex;
  await saveWorld(live);
  assert(allEvolve().some((button) => !button.disabled), 'evolve is available again after unfreeze');
  hostPreview.state.chat.push({ mes: '本轮新增的剧情' });
  root.querySelector('[data-action="evolve"]').click();
  let reported = '';
  for (let i = 0; i < 40; i += 1) {
    reported = document.getElementById('sj-status').textContent || '';
    if (reported.includes('演进没有完成') || reported.includes('没有接到酒馆后端转发') || reported.includes('已立即演进')) break;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  assert(reported.includes('演进没有完成') || reported.includes('没有接到酒馆后端转发'), 'a failed evolve is visible');
  const afterClick = loadWorld();
  assert(afterClick.evolutionLog.length === 0, 'failed evolve does not append a log');
  assert(afterClick.storyClock.dayIndex === dayBefore, 'failed evolve does not advance the day');
  assert(afterClick.todayChanges.length === 2, 'failed evolve keeps today changes');

  // Drafts survive a failed automatic/shared turn, but never a chat switch.
  await waitFor(() => !isWorldBusy(), 'failed turn releases its lock');
  root.querySelector('[role="tab"][data-page="events"]').click();
  body.querySelector('[data-fix-open="event:e1"]').click();
  body.querySelector('#sj-fix-body').value = '还没有保存的手动草稿';
  let releaseModel;
  hostPreview.generateViaBackend = () => new Promise((resolve) => { releaseModel = resolve; });
  const lockedTurn = runImmediateEvolution();
  await waitFor(() => Boolean(releaseModel), 'delayed evolution starts');
  assert(body.querySelector('[data-fix-save]').disabled, 'evolution disables manual save');
  assert(body.textContent.includes('正在演进，完成后可修改'), 'edit lock is explained');
  assert(body.querySelector('#sj-fix-body').value === '还没有保存的手动草稿', 'lock preserves unsaved draft');
  releaseModel('invalid');
  await lockedTurn;
  assert(!body.querySelector('[data-fix-save]').disabled, 'failure restores editing');
  assert(body.querySelector('#sj-fix-body').value === '还没有保存的手动草稿', 'failure preserves draft');
  body.querySelector('[data-fix-mode="ai"]').click();
  body.querySelector('[data-fix-generate]').click();
  assert(!confirm.hidden, 'confirmation is open before switching');
  const chatA = hostPreview.state.chatMetadata;
  hostPreview.state.chatId = 'another-chat-with-same-fact-id';
  hostPreview.state.chatMetadata = structuredClone(chatA);
  hostPreview.eventSource.emit(hostPreview.event_types.CHAT_CHANGED);
  await waitFor(() => confirm.hidden && !body.querySelector('.sj-fix') && !isWorldBusy(), 'switch closes dialog and editor');
  hostPreview.state.chatId = 'preview';
  hostPreview.state.chatMetadata = chatA;
  hostPreview.eventSource.emit(hostPreview.event_types.CHAT_CHANGED);
  await waitFor(() => !isWorldBusy(), 'returning chat settles');
  assert(!body.querySelector('.sj-fix'), 'returning to original chat does not revive draft');
  hostPreview.generateViaBackend = async () => '界面测试修订稿';
  body.querySelector('[data-fix-open="event:e1"]').click();
  body.querySelector('[data-fix-mode="ai"]').click();
  body.querySelector('[data-fix-generate]').click();
  confirm.querySelector('[data-confirm="ok"]').click();
  await waitFor(() => Boolean(body.querySelector('#sj-fix-draft')), 'AI draft appears before switching');
  hostPreview.state.chatId = 'another-chat-with-same-fact-id';
  hostPreview.state.chatMetadata = structuredClone(chatA);
  hostPreview.eventSource.emit(hostPreview.event_types.CHAT_CHANGED);
  await waitFor(() => !isWorldBusy(), 'second switch settles');
  assert(!body.querySelector('#sj-fix-draft') && !body.querySelector('[data-fix-apply]'), 'switch clears AI draft and adoption action');
}
