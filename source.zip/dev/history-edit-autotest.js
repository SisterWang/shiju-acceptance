import { createEmptyWorld, saveWorld, loadWorld, saveSettings, loadSettings, loadPreferences } from '../src/store/index.js';
import { effectivePreferences } from '../src/preferences.js';
import { captureInputBoundary } from '../src/modules/incremental.js';
import { applyClock, interpretStoryTime } from '../src/modules/timetag/read.js';
import { runImmediateEvolution } from '../src/modules/timeGate/index.js';
import { enqueueTurn } from '../src/modules/turn.js';

// Called only by the guarded disposable-host harness. Use the actual host
// editor/save buttons so MESSAGE_EDITED and MESSAGE_UPDATED have real timing.
export async function runHistoryEditAutotest({st,host,check,until,requestCount}) {
  if (!['43125','43126'].includes(location.port) || !new URLSearchParams(location.search).has('compat')) throw new Error('Only disposable hosts');
  const oldTime=structuredClone(loadSettings().timeSource);
  const world=createEmptyWorld();world.meta.builtFingerprint='history-event-fixture';
  await saveWorld(world);
  saveSettings({timeSource:{mode:'shiju'}});
  const floor=host.getContext().chat.length;
  for(const body of ['桥梁尚未修复','集市照常开放']) {
    const message={name:'世局验收A',mes:`${body}<shiju_end>2026/1/1</shiju_end>`,send_date:new Date().toISOString(),is_user:false,is_system:false,swipe_id:0,extra:{}};
    host.getContext().chat.push(message);st.addOneMessage(message);
  }
  world.plugin.enabled=true;
  world.events=[{id:'bridge-check',kind:'macro',title:'桥况',body:'桥梁尚未修复'}];
  applyClock(world,interpretStoryTime(null,host.getContext().chat,'shiju',''));
  world.meta.lastEvolvedDayIndex=world.storyClock.dayIndex;
  // This fixture stands in for a successfully built world: current chat
  // preferences must already be acknowledged, as in a real bootstrap.
  world.appliedPreferences=effectivePreferences(loadPreferences());
  world.processedInput=captureInputBoundary(host.getContext().chat);
  await saveWorld(world);
  const before=loadWorld(), calls=requestCount();
  try {
    const element=document.querySelector(`.mes[mesid="${floor}"]`);
    check(!!element?.querySelector('.mes_edit'),'找到真实楼层编辑按钮');
    element.querySelector('.mes_edit').click();
    await until(()=>element.querySelector('.edit_textarea'),'host edit textarea');
    element.querySelector('.edit_textarea').value='桥梁已修复并恢复通行<shiju_end>2026/1/1</shiju_end>';
    element.querySelector('.mes_edit_done').click();
    await until(()=>loadWorld()?.meta?.inputHint==='history-changed','history warning after actual save');
    await enqueueTurn(()=>({}));
    check(host.getContext().chat[floor].mes.includes('已修复并恢复通行'),'酒馆编辑保存确实修改了虚构正文');
    check(JSON.stringify(loadWorld().processedInput)===JSON.stringify(before.processedInput),'编辑保存不覆盖原处理边界');
    check(JSON.stringify(loadWorld().events)===JSON.stringify(before.events)&&loadWorld().storyClock.dayIndex===before.storyClock.dayIndex,'编辑保存不更改世界事实或推进日期');
    document.querySelector('.sj-fab').click();
    document.querySelector('[role="tab"][data-page="settings"]').click();
    const panel=()=>document.getElementById('shiju-page');
    check(!!panel().querySelector('[data-choice="realign"]')&&panel().textContent.includes('已处理的正文有修改'),'实际设置面板显示历史修改与重对齐入口');
    check((await runImmediateEvolution()).reason==='history-changed'&&requestCount()===calls,'立即演进保持提示且不调用模型');
    panel().querySelector('[data-choice="keep"]').click();
    await until(()=>!loadWorld()?.meta?.inputHint,'explicit keep');
    await enqueueTurn(()=>({}));
    const keepResult=await runImmediateEvolution();
    check(!panel().querySelector('[data-choice="realign"]')&&keepResult.evolved&&requestCount()===calls+1,`明确保持世界账后消除提示并承接基线：${JSON.stringify({reason:keepResult.reason,entry:!!panel().querySelector('[data-choice="realign"]'),calls:requestCount()-calls})}`);
    check(JSON.stringify(loadWorld().events)===JSON.stringify(before.events),'保持世界账不改写原事实');
    document.querySelector('.sj-close').click();
  } finally {
    const latest=loadWorld();latest.plugin.enabled=false;await saveWorld(latest);
    saveSettings({timeSource:oldTime});
  }
}
