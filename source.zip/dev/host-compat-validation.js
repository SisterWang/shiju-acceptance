// Deploy ONLY into disposable SillyTavern copies with the fixture roles.
// It cannot run on the user's mapped port or without the explicit query flag.
if (['43125','43126'].includes(location.port) && new URLSearchParams(location.search).has('compat')) {
  // Run without holding module evaluation open during asynchronous fixture work.
  void (async () => {
  const output=document.createElement('pre');output.id='sj-autotest';output.style='position:fixed;top:60px;left:10px;z-index:999999;background:#fff;color:#111;max-width:600px;white-space:pre-wrap;padding:16px';document.body.append(output);
  let n=0;const check=(ok,label)=>{if(!ok)throw Error(label);n++;output.textContent=`通过 ${n}: ${label}`;};
  const until=async(fn,label)=>{for(let i=0;i<600;i++){if(fn())return;await new Promise(r=>setTimeout(r,50));}throw Error('等待超时：'+label);};
  const load=p=>import('/scripts/extensions/third-party/shiju/'+p);
  const nativeFetch=window.fetch;const requests=[];let hold=false,release,fail=false;
  // Fixed responses installed before selecting any fictional chat. Never forward
  // model calls; no real credentials or provider requests are needed here.
  window.fetch=async(url,options={})=>{
    const path=String(url);
    if(/\/api\/(backends\/[^/]+\/generate|novelai\/generate|horde\/generate-text)/.test(path)) {
      const body=JSON.parse(options.body);requests.push({path,body});
      if(hold){hold=false;await new Promise((resolve,reject)=>{release=resolve;options.signal?.addEventListener('abort',()=>reject(new DOMException('cancelled','AbortError')),{once:true});});}
      if(fail){fail=false;return new Response('{}',{status:503});}
      return new Response(JSON.stringify({choices:[{message:{content:'{}'}}],output:'{}',results:[{text:'{}'}],id:'fixture-horde'}),{headers:{'Content-Type':'application/json'}});
    }
    if(path.includes('/api/horde/task-status'))return new Response(JSON.stringify({done:true,generations:[{text:'{}'}]}),{headers:{'Content-Type':'application/json'}});
    if(path.includes('/api/horde/cancel-task'))return new Response('{}');
    return nativeFetch(url,options);
  };
  try {
    await until(()=>window.TavernHelper && window.STBaiBaiBook && window.EjsTemplate && window.__baiBaiToolkitExtensionInstalled,'four plugins initialized');
    const st=await import('/script.js'),oai=await import('/scripts/openai.js');
    const {getHost}=await load('src/host.js');const host=getHost();
    await new Promise(resolve=>st.eventSource.once(st.event_types.APP_READY,resolve));
    const {saveSettings,loadSettings,createEmptyWorld,saveWorld,loadWorld}=await load('src/store/index.js');
    const {generateViaST,captureModelConfig}=await load('src/modules/model/index.js');
    const {captureInputBoundary,readIncrement}=await load('src/modules/incremental.js');
    const {runWorker}=await load('src/modules/template/index.js');
    const {runImmediateEvolution}=await load('src/modules/timeGate/index.js');
    const {isWorldBusy}=await load('src/modules/turn.js');
    const {BAIBAI_JAILBREAK}=await load('src/prompts/baibai-jailbreak.js');
    check(true,'酒馆助手、柏宝书、提示词模板、柏宝箱均已加载');
    await st.getCharacters();await until(()=>host.getContext().characters.some(c=>c.name==='世局验收A')&&host.getContext().characters.some(c=>c.name==='世局验收B'),'fake characters populated');const chars=host.getContext().characters;
    const a=chars.findIndex(c=>c.name==='世局验收A'),b=chars.findIndex(c=>c.name==='世局验收B');check(a>=0&&b>=0,'仅使用隔离角色');
    await st.selectCharacterById(a);await until(()=>!isWorldBusy()&&host.getContext().chatMetadata.timedWorldInfo,'initial chat and host worldbook preview');
    // APP_READY and selectCharacterById can precede delayed companion/host
    // initialization. Do not attribute those events to the request under test.
    let prior=JSON.stringify(host.getContext().chatMetadata),stableSince=performance.now();
    await until(()=>{const current=JSON.stringify(host.getContext().chatMetadata);if(current!==prior){prior=current;stableSince=performance.now();}return performance.now()-stableSince>=1000;},'stable fixture metadata');
    st.changeMainAPI('openai');Object.assign(oai.oai_settings,{chat_completion_source:'openai',openai_model:'gpt-4o',openai_max_tokens:777,stream_openai:false,bias_preset_selected:''});
    saveSettings({model:{channelMode:'follow',jailbreakMode:'builtin',responseLength:16384}});
    // Run the actual TSE script through the actual helper, in the fake chat.
    const tse=await (await nativeFetch('/shiju-tse-fixture.js')).text();
    window.TavernHelper.replaceScriptTrees([{type:'script',id:'shiju-compat-tse',name:'TSE isolated compatibility fixture',enabled:true,content:tse}],{type:'global'});
    await until(()=>[...document.querySelectorAll('iframe')].some(f=>f.id.includes('shiju-compat-tse')),'TSE iframe');
    await new Promise(r=>setTimeout(r,1500));
    await until(()=>[...document.querySelectorAll('iframe')].some(f=>f.id.includes('shiju-compat-tse')&&f.contentWindow?.__tse_engine_instance__),'TSE initialized');
    check(true,'TSE 通过真实酒馆助手加载并初始化');
    const events=[];const names=['GENERATION_AFTER_COMMANDS','GENERATE_BEFORE_COMBINE_PROMPTS','CHAT_COMPLETION_PROMPT_READY','CHAT_COMPLETION_SETTINGS_READY','TEXT_COMPLETION_SETTINGS_READY','MESSAGE_SENT','MESSAGE_RECEIVED'];
    const callbacks=names.map(name=>{const fn=()=>events.push(name);if(st.event_types[name])st.eventSource.on(st.event_types[name],fn);return [name,fn];});
    const variables=JSON.stringify({chat:host.getContext().chatMetadata.variables,tse:host.getContext().chatMetadata.tse_engine,global:host.getExtensionSettings().variables});
    const chatBefore=JSON.stringify(host.getContext().chat);
    const settingsBefore=JSON.stringify(oai.oai_settings);
    const request={purpose:'correct',systemPrompt:'隔离固定协议',prompt:'仅测试虚构资料'};
    await generateViaST(request);
    check(requests.at(-1).body.messages[0].content===BAIBAI_JAILBREAK,'实际后端首条消息原文一致');
    check(requests.at(-1).body.max_tokens===16384 && JSON.stringify(oai.oai_settings)===settingsBefore,'请求长度独立且宿主设置完全不变');
    check(events.length===0,'不触发模板、抽牌或正文生成事件');
    check(JSON.stringify(host.getContext().chat)===chatBefore,'正文与楼层完全不变');
    check(JSON.stringify({chat:host.getContext().chatMetadata.variables,tse:host.getContext().chatMetadata.tse_engine,global:host.getExtensionSettings().variables})===variables,'聊天变量和 TSE 状态不变');
    const nativeCustom=structuredClone(oai.oai_settings);
    Object.assign(oai.oai_settings,{chat_completion_source:'custom',custom_url:'https://example.invalid/v1',custom_model:'fixture-model',custom_include_body:'stream: true\nmax_tokens: 1\ntools: [{}]\ntemperature: 0.3',custom_exclude_body:'- max_tokens\n- messages\n- stop'});
    await generateViaST(request);
    const customBody=requests.at(-1).body;
    check(customBody.max_tokens===16384&&customBody.custom_include_body==='{"temperature":0.3}'&&customBody.custom_exclude_body==='["stop"]','宿主自定义参数无法覆盖世局协议和长度');
    Object.assign(oai.oai_settings,nativeCustom);
    const ejs=await runWorker({title:'隔离条目',content:'<% setvar("x",8);variables.x=9; %><%= getvar("x") %>'},{global:{x:1}},[]);
    check(ejs.text==='1'&&ejs.diagnostics.length===2,'真实宿主 Worker 只读计算');
    const {runHistoryEditAutotest}=await load('dev/history-edit-autotest.js');
    await runHistoryEditAutotest({st,host,check,until,requestCount:()=>requests.length});
    const fixtureWorld=createEmptyWorld();fixtureWorld.meta.builtFingerprint='visibility-fixture';fixtureWorld.plugin.enabled=false;
    fixtureWorld.processedInput=captureInputBoundary(host.getContext().chat);await saveWorld(fixtureWorld);
    const floor=host.getContext().chat.length;
    const hiddenFixture={name:'世局验收A',mes:`只供隐藏验收的虚构正文 ${Date.now()}`,send_date:new Date().toISOString(),is_user:false,is_system:false,extra:{}};
    host.getContext().chat.push(hiddenFixture);st.addOneMessage(hiddenFixture);
    const {hideChatMessageRange}=await import('/scripts/chats.js');
    await hideChatMessageRange(floor,floor,false);
    await until(()=>loadWorld().processedInput.excluded.some(row=>row.floor===floor),'manual hide persisted');
    await hideChatMessageRange(floor,floor,true);
    check(!readIncrement(loadWorld(),host.getContext().chat).items.length,'真实隐藏／取消隐藏保留排除状态且不重演');
    const {readSourcePack,narrativeText}=await load('src/modules/source/index.js');
    const source=await readSourcePack();
    check(!narrativeText(source).includes(hiddenFixture.mes),'真实柏宝书背景读取不重新引入排除正文');
    // Concurrent native generation deliberately owns its temporary length. Our
    // request must neither restore it early nor replace it with our own length.
    release=null;const pauseNative=async()=>{st.eventSource.removeListener(st.event_types.CHAT_COMPLETION_PROMPT_READY,pauseNative);await new Promise(resolve=>{release=resolve;});};st.eventSource.on(st.event_types.CHAT_COMPLETION_PROMPT_READY,pauseNative);
    const companion=host.getContext().generateRaw({prompt:'虚构的并发记忆任务',responseLength:333});
    await until(()=>!!release,'companion held');
    check(oai.oai_settings.openai_max_tokens===333,'并发宿主任务拥有自己的临时长度: '+JSON.stringify({length:oai.oai_settings.openai_max_tokens,api:st.main_api,last:requests.at(-1).body.max_tokens}));
    await generateViaST(request);
    check(requests.at(-1).body.max_tokens===16384&&oai.oai_settings.openai_max_tokens===333,'世局并发不干扰宿主任务');
    release();release=null;await companion;
    check(oai.oai_settings.openai_max_tokens===777,'宿主自行恢复长度，世局没有介入');
    events.length=0;fail=true;let failed=false,before=requests.length;
    try{await generateViaST(request);}catch{failed=true;}
    check(failed&&requests.length===before+1&&oai.oai_settings.openai_max_tokens===777,'失败不重试、不修改长度');
    const textgen=await import('/scripts/textgen-settings.js'), kobold=await import('/scripts/kai-settings.js'), novel=await import('/scripts/nai-settings.js'), horde=await import('/scripts/horde.js');
    const power=host.getContext().powerUserSettings;const oldInstruct=structuredClone(power.instruct),oldStops=power.custom_stopping_strings;
    power.instruct.enabled=false;power.custom_stopping_strings='[]';
    const configs=[['textgenerationwebui',textgen.textgenerationwebui_settings],['kobold',kobold.kai_settings],['novel',novel.nai_settings],['koboldhorde',horde.horde_settings]];
    for(const [api,settings] of configs) {
      const original=structuredClone(settings);
      try {
        if(api==='textgenerationwebui') {
          settings.type='ooba';settings.server_urls={...settings.server_urls,ooba:'http://127.0.0.1:1'};settings.logit_bias=[];settings.send_banned_tokens=false;
          Object.assign(power.instruct,{enabled:true,macro:true,wrap:true,names_behavior:'always',system_same_as_user:false,system_sequence:'[{{name}}]',system_suffix:'',input_sequence:'[{{name}}]',input_suffix:'',first_input_sequence:'UNUSED',last_system_sequence:'[reply]',stop_sequence:'STOP',sequences_as_stop_strings:true});
        } else power.instruct.enabled=false;
        if(api==='novel') {settings.model_novel='kayra-v1';settings.banned_tokens='';settings.logit_bias=[];}
        if(api==='koboldhorde') settings.models=['fixture-model'];
        await st.changeMainAPI(api);const beforeSettings=JSON.stringify(settings),beforeLength=st.amount_gen;
        await generateViaST(request);const sent=requests.at(-1);
        check(api==='koboldhorde' ? sent.body.params.max_length===16384 : api==='textgenerationwebui' ? sent.body.max_tokens===16384 : sent.body.max_length===16384,`真实 ${api} 后端长度映射`);
        check(JSON.stringify(settings)===beforeSettings&&st.amount_gen===beforeLength,`真实 ${api} 设置不变`);
        if(api==='textgenerationwebui') {
          const expected=st.createRawPrompt([{role:'system',content:BAIBAI_JAILBREAK},{role:'system',content:request.systemPrompt},{role:'user',content:request.prompt}],api,false,false,'','');
          check(sent.body.prompt===expected,'文本请求格式与当前宿主 instruct 一致');
          const {getInstructStoppingSequences}=await import('/scripts/instruct-mode.js');
          check(getInstructStoppingSequences().every(stop=>sent.body.stopping_strings.includes(stop)),'文本请求沿用 instruct 停止串');
        }
      } finally {for(const k of Object.keys(settings))delete settings[k];Object.assign(settings,original);}
    }
    power.instruct=oldInstruct;power.custom_stopping_strings=oldStops;await st.changeMainAPI('openai');
    saveSettings({model:{channelMode:'custom',endpoint:'https://example.invalid/v1/chat/completions',customModel:'fixture-model',apiKey:'fixture-key',responseLength:9999}});
    await generateViaST(request);
    check(requests.at(-1).body.reverse_proxy==='https://example.invalid/v1'&&requests.at(-1).body.model==='fixture-model'&&requests.at(-1).body.max_tokens===9999,'自定义渠道使用独立同源请求');
    check(events.length===0,'自定义渠道也不触发生成事件');
    const snap=captureModelConfig('correct');saveSettings({model:{customModel:'later-model'}});
    await generateViaST({...request,modelConfig:snap});check(requests.at(-1).body.model==='fixture-model','等待期间修改配置只影响后续调用');
    hold=true;const old=generateViaST(request).catch(e=>e);await until(()=>!!release,'old chat request');
    await st.selectCharacterById(b);const cancelled=await old;
    check(cancelled.code==='SHIJU_CHAT_CHANGED','切换聊天取消世局请求');release=null;await until(()=>!isWorldBusy(),'B ready');
    // UI and draft checks use the existing real panel.
    document.querySelector('.sj-fab').click();document.querySelector('[role="tab"][data-page="settings"]').click();
    const get=s=>document.getElementById('shiju-page').querySelector(s),click=a=>get(`[data-prompt-action="${a}"]`).click();
    get('[data-settings-section="model"]').click();click('model-edit');
    check(get('#sj-channel-key').type==='password','真实界面密钥遮罩');
    get('#sj-channel-model').value='cancelled-edit';click('model-cancel');check(loadSettings().model.customModel==='later-model','取消编辑保留已保存配置');
    click('model-edit');click('model-reset');click('model-save');check(loadSettings().model.jailbreakMode==='builtin','恢复内置原文可保存');
    for(const [name,fn] of callbacks)if(st.event_types[name])st.eventSource.removeListener(st.event_types[name],fn);
    output.textContent=`隔离 SillyTavern ${st.CLIENT_VERSION}：${n} 项通过\n四插件 + TSE 已加载，固定回复，零上游模型调用。`;
    document.documentElement.dataset.sjAutotest='ok';
  } catch(error) {output.textContent=`${output.textContent}\n${error.stack}`;document.documentElement.dataset.sjAutotest='fail';document.documentElement.dataset.sjAutotestError=output.textContent;console.error(error);}
  // Leave the model interceptor installed until this disposable page closes.
  })();
}
