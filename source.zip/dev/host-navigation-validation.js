// Disposable installations only; never imported by the production entry.
if (['43125','43126'].includes(location.port) && new URLSearchParams(location.search).has('navigationcompat')) void (async () => {
  const output=document.createElement('pre');output.id='sj-autotest';document.body.append(output);
  const until=async(fn,label)=>{for(let i=0;i<500;i++){if(fn())return;await new Promise(resolve=>setTimeout(resolve,50));}throw Error('等待超时 '+label);};
  const originalFetch=window.fetch;let attempts=0;
  window.fetch=async(url,options)=>{
    if(/\/api\/(backends\/[^/]+\/generate|novelai\/generate|horde\/generate-text)/.test(String(url))){attempts++;throw Error('验收禁止模型请求');}
    return originalFetch(url,options);
  };
  try {
    const st=await import('/script.js');
    await until(()=>st.settingsReady&&document.getElementById('shiju-wand-entry'),'真实宿主与扩展入口');
    const host=(await import('../src/host.js')).getHost();
    await new Promise(resolve=>st.eventSource.once(st.event_types.APP_READY,resolve));
    await st.getCharacters();const index=host.getContext().characters.findIndex(character=>character.name==='世局验收A');
    if(index<0)throw Error('仅允许隔离验收角色');await st.selectCharacterById(index);
    const {isWorldBusy}=await import('../src/modules/turn.js');await until(()=>!isWorldBusy(),'任务结束');
    await until(()=>document.getElementById('extensionsMenuButton')?.getClientRects().length,'魔法棒可见');
    const {runNavigationTimeAutotest}=await import('./navigation-time-autotest.js');
    const count=await runNavigationTimeAutotest(host);
    const {loadWorld,saveWorld}=await import('../src/store/index.js');const world=loadWorld();world.plugin.enabled=false;await saveWorld(world);
    if(attempts)throw Error(`出现 ${attempts} 次非预期请求（已阻止）`);
    output.textContent=`真实酒馆入口与日期通过 ${count} 项；模型请求 0 次`;
    document.documentElement.dataset.sjAutotest='ok';
  } catch(error) {
    output.textContent=error.stack;document.documentElement.dataset.sjAutotest='fail';document.documentElement.dataset.sjAutotestError=error.stack;
  } finally {window.fetch=originalFetch;}
})();
