import { createEmptyWorld, loadWorld, saveWorld, loadSettings, saveSettings } from '../src/store/index.js';
import { enqueueTurn } from '../src/modules/turn.js';

export async function runRecordDetailsAutotest() {
  const host=globalThis.__SHIJU_PREVIEW_HOST__, body=document.getElementById('shiju-page');
  const backup=structuredClone(host.state.chatMetadata), chatId=host.state.chatId;
  const assert=(ok,message)=>{if(!ok)throw Error(message);};
  const get=s=>body.querySelector(s);
  const tab=id=>document.querySelector(`[role="tab"][data-page="${id}"]`).click();
  const toggle=key=>[...body.querySelectorAll('[data-detail-toggle]')].find(el=>el.dataset.detailToggle===key);
  const flush=()=>new Promise(r=>setTimeout(r,20));
  const world=createEmptyWorld();
  world.regions=[{id:'r',name:'北岸平原',summary:'河道贯穿平原，粮仓沿岸分布。\n春汛将至，沿河村镇正在加固堤岸。',status:'active',evidence:'地方志',updatedAtDay:12}];
  world.factions=[{id:'f',name:'北岸商盟',summary:'由沿河商户组成，正协商共同承担修桥费用。',regionRef:'r',status:'active'}];
  world.orgs=[{id:'o',name:'渡口工务所',summary:'负责桥梁检修与渡运调度。',regionRef:'r',status:'dormant'}, {id:'s',name:'密会机构',summary:'密会正文',secret:true}];
  world.events=[{id:'e',kind:'macro',title:'商盟协商修桥计划',body:'商盟已完成费用初步核算，等待各镇确认分担比例。\n工务所将在三日内提交通行保障方案。',phase:'发展',relatedRefs:['f','s'],updatedAtDay:12},
    {id:'empty',kind:'news',title:'远方来讯'},
    {id:'secret',kind:'secret',title:'秘密标题',body:'秘密事件正文'},
    {id:'arch',kind:'macro',title:'旧桥抢修完成',body:'工务所替换了损坏桥板，恢复双向通行。',lifecycle:'archived',outcome:'运输时间缩短，渡运压力下降。'}];
  world.todayChanges=[{id:'c',kind:'macro',title:'修桥协商开始',body:'各镇代表已抵达会场。',linkedEventId:'e'}];
  try {
    await saveWorld(world);
    const before=JSON.stringify(loadWorld()), settings=JSON.stringify(loadSettings()), saves=host.state.savedMetadata;
    for (const [kind,key,text] of [['region','r','粮仓'],['faction','f','共同承担'],['org','o','检修']]) {
      tab('world'); get(`[data-world-kind="${kind}"]`).click();
      const button=toggle(`entity:${kind}:${key}`);
      assert(button && !button.disabled && button.getAttribute('aria-expanded')==='false','entity has collapsed read entry');
      assert(document.getElementById(button.getAttribute('aria-controls')),'detail control target exists');
      button.click(); assert(body.textContent.includes(text),'entity detail opens');
      assert(document.activeElement===toggle(`entity:${kind}:${key}`),'toggle keeps keyboard focus');
      assert(!get('[data-fix-open]'),'entity reading does not expose unsupported editing');
    }
    assert(!body.innerHTML.includes('密会机构') && !body.innerHTML.includes('密会正文'),'hidden entity stays out of DOM');
    toggle('entity:org:s').click(); assert(body.textContent.includes('密会正文'),'explicit entity peek works');
    toggle('entity:org:s').click(); assert(!body.innerHTML.includes('密会正文'),'collapse conceals secret entity');
    tab('events');
    assert(!body.innerHTML.includes('秘密标题') && !body.innerHTML.includes('秘密事件正文'),'secret event is concealed');
    toggle('event:e').click();
    assert(body.textContent.includes('费用初步核算') && body.textContent.includes('北岸商盟'),'event body and references visible');
    assert(!body.innerHTML.includes('密会机构'),'references do not leak secret names');
    toggle('event:empty').click(); assert(body.textContent.includes('暂无详情'),'empty body has honest fallback');
    tab('feed'); toggle('todayChange:c').click();
    assert(body.textContent.includes('代表已抵达') && body.textContent.includes('商盟协商'),'today detail and linked event');
    tab('events'); assert(toggle('event:e').getAttribute('aria-expanded')==='true','navigation retains detail state');
    let release; const busy=enqueueTurn(()=>new Promise(r=>release=r)); await flush();
    assert(get('[data-fix-open="event:e"]').disabled && !toggle('event:e').disabled,'reading remains available while edits locked');
    toggle('event:e').click(); toggle('event:e').click(); release(); await busy;
    get('[data-archive-toggle]').click(); toggle('event:arch').click();
    assert(body.textContent.includes('运输时间缩短') && body.textContent.includes('替换了损坏桥板'),'archive detail retains history and consequences');
    assert(JSON.stringify(loadWorld())===before && host.state.savedMetadata===saves && JSON.stringify(loadSettings())===settings,'reading never writes world or settings');
    host.state.chatId='details-B';host.state.chatMetadata=structuredClone(host.state.chatMetadata);host.eventSource.emit(host.event_types.CHAT_CHANGED);await flush();
    assert(toggle('event:e')?.getAttribute('aria-expanded')==='false','same IDs in another chat do not inherit detail state');
    host.state.chatId=chatId;host.eventSource.emit(host.event_types.CHAT_CHANGED);await flush();
    assert(toggle('event:e')?.getAttribute('aria-expanded')==='false','returning chat does not revive detail state');
    // Leave a neutral, expanded demo for local visual QA when explicitly requested.
    if(new URLSearchParams(location.search).has('detailsdemo')) {
      saveSettings({ui:{theme:'day'}}); toggle('event:e').click(); return;
    }
  } finally {
    if(!new URLSearchParams(location.search).has('detailsdemo')) {
      host.state.chatId=chatId;host.state.chatMetadata=backup;host.eventSource.emit(host.event_types.CHAT_CHANGED);await flush();
    }
  }
}
