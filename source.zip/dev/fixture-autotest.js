import { setHost } from '../src/host.js';
import { bootstrapWorld } from '../src/modules/bootstrap/index.js';
import * as inject from '../src/modules/inject/index.js';
import * as reconcile from '../src/modules/reconcile/index.js';
import * as timetag from '../src/modules/timetag/index.js';
import { readSourcePack } from '../src/modules/source/index.js';
import { runAutomaticGate } from '../src/modules/timeGate/index.js';
import { loadSettings, loadWorld } from '../src/store/index.js';
import {
  DECOY_REGION,
  NATIVE_MACRO,
  NATIVE_NEWS,
  NATIVE_ORG,
  NATIVE_REGION,
  NATIVE_SECRET,
  NATIVE_SECRET_BODY,
  exportChatFile,
  floorHash,
  nativeLaterFloor,
  nativeNewChat,
  nativeOldFloors,
  reinstallNativeHost,
  uninstallKeepingChat,
} from '../src/fixture/native.js';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function waitFor(read, message) {
  return new Promise((resolve, reject) => {
    let left = 40;
    const tick = () => {
      let value = false;
      try {
        value = Boolean(read());
      } catch (error) {
        reject(error);
        return;
      }
      if (value) {
        resolve();
        return;
      }
      left -= 1;
      if (left <= 0) {
        reject(new Error(message));
        return;
      }
      setTimeout(tick, 50);
    };
    tick();
  });
}

function pageText() {
  return document.getElementById('shiju-page')?.textContent || '';
}

export async function runFixtureAutotest(api) {
  const node = document.createElement('p');
  node.id = 'sj-autotest';
  node.textContent = '夹具自检中';
  document.body.appendChild(node);
  try {
    await steps(api);
    node.dataset.state = 'ok';
    node.textContent = '夹具自检通过';
    document.documentElement.dataset.sjAutotest = 'ok';
  } catch (error) {
    node.dataset.state = 'fail';
    node.textContent = error instanceof Error ? error.message : String(error);
    document.documentElement.dataset.sjAutotest = 'fail';
    document.documentElement.dataset.sjAutotestError = node.textContent;
    console.error(error);
  }
}

async function steps(api) {
  const host = globalThis.__SHIJU_PREVIEW_HOST__;
  const root = document.getElementById('shiju-chrome');
  const fab = root?.querySelector('.sj-fab');
  assert(host && root && fab && typeof api?.refresh === 'function', 'fixture chrome missing');
  globalThis.STBaiBaiBook = {
    getSnapshot() {
      return { state: { time: '三年前' } };
    },
    getHistory() {
      return { text: '旧史' };
    },
  };
  host.state.mvu = { hp: 1 };
  host.state.hasBaibai = true;
  const pack = await readSourcePack();
  assert(pack.baibai === undefined && pack.mvu === undefined, 'A5 pack has no book and no MVU');
  assert(host.hasBaibaiBook() === false && host.readMvu() === null, 'A5 hooks stay native');

  fab.click();
  api.refresh();
  assert(root.dataset.baibai === '0', 'panel stays native while a book marker is assigned');
  root.querySelector('[data-page="settings"]').click();
  assert(pageText().includes('未检测到柏宝书'), 'settings stay on the native default');

  host.state.chat = nativeNewChat();
  host.state.chatMetadata = {};
  host.state.chatId = 'native-new';
  const freshMes = host.state.chat.map((message) => message.mes);
  const freshHash = floorHash(host.state.chat);
  api.refresh();
  const enable = root.querySelector('[data-action="toggle-plugin"]');
  assert(enable?.textContent === '启用', 'A1 enable button');
  enable.click();
  await waitFor(() => loadWorld()?.regions?.some((item) => item.name === NATIVE_REGION), 'A1 entity did not appear');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'bootstrap').length === 1, 'A1 one bootstrap');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length === 0, 'A1 does not evolve');
  assert(JSON.stringify(host.state.chat.map((message) => message.mes)) === JSON.stringify(freshMes), 'A1 floors stay');
  assert(floorHash(host.state.chat) === freshHash, 'A1 floor hash');
  assert(host.state.chatMetadata.shiju.regions.some((item) => item.name === NATIVE_REGION), 'A1 ledger is on the chat');
  assert(!loadWorld().regions.some((item) => item.name === DECOY_REGION), 'A1 ignores the decoy');
  root.querySelector('[data-page="world"]').click();
  assert(pageText().includes(NATIVE_REGION), 'A1 panel lists the region');
  document.querySelector('#shiju-page [data-world-kind="org"]').click();
  assert(pageText().includes(NATIVE_ORG), 'A1 panel lists the org');
  root.querySelector('[data-page="events"]').click();
  assert(pageText().includes(NATIVE_MACRO), 'A1 panel lists the macro event');
  assert(!pageText().includes(NATIVE_SECRET_BODY), 'secret body stays off the events page');

  host.eventSource.emit(host.event_types.GENERATION_STARTED);
  const macro = String(host.state.prompts.shiju_macro?.value || '');
  assert(macro.includes(`发生于远方。${NATIVE_NEWS}`), 'A2 far news is marked');
  assert(macro.includes(NATIVE_MACRO), 'A2 macro is injected');
  assert(!macro.includes(NATIVE_SECRET) && !macro.includes(NATIVE_SECRET_BODY), 'A2 secret stays out');
  root.querySelector('[data-page="feed"]').click();
  const preview = document.querySelector('[data-inject-preview="1"]');
  assert(preview?.textContent.includes('背景参考，不必强行写入正文'), 'A2 preview keeps the disclaimer');
  assert(preview?.textContent.includes('隐秘默认不注入'), 'A2 preview omits the secret');

  host.state.chat = nativeOldFloors();
  host.state.chatMetadata = {};
  host.state.chatId = 'native-old';
  host.state.prompts = {};
  const oldMes = host.state.chat.map((message) => message.mes);
  const oldHash = floorHash(host.state.chat);
  const bootsBefore = host.state.fixtureCalls.filter((call) => call.purpose === 'bootstrap').length;
  api.refresh();
  root.querySelector('[data-page="settings"]').click();
  const again = root.querySelector('[data-action="toggle-plugin"]');
  assert(again?.textContent === '启用', 'A3 enable on the old chat');
  again.click();
  await waitFor(() => root.querySelector('[data-action="toggle-plugin"]')?.textContent === '冻结', 'A3 enable did not finish');
  assert(loadWorld()?.regions?.some((item) => item.name === NATIVE_REGION), 'A3 entity did not appear');
  assert(host.state.chat.map((message) => message.mes).join('\n') === oldMes.join('\n'), 'A3 historical floors stay');
  assert(floorHash(host.state.chat) === oldHash, 'A3 floor hash');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'bootstrap').length === bootsBefore + 1, 'A3 one more build');
  assert(host.state.chat[0].mes.includes('甲楼原文'), 'A3 original sentence');

  const frozenMes = host.state.chat.map((message) => message.mes);
  const frozenHash = floorHash(host.state.chat);
  const freeze = root.querySelector('[data-action="toggle-plugin"]');
  assert(freeze?.textContent === '冻结', 'A4 freeze button');
  freeze.click();
  await waitFor(() => root.querySelector('[data-action="toggle-plugin"]')?.textContent === '重开', 'A4 did not freeze');
  assert(loadWorld()?.plugin?.enabled === false, 'A4 ledger is frozen');
  assert(host.state.chatMetadata.shiju.plugin.enabled === false, 'A4 freeze is stored on the chat');
  assert(host.state.prompts.shiju_macro?.value === '', 'A4 injection cleared');
  assert(document.getElementById('sj-status')?.textContent.includes('已冻结'), 'A4 panel says frozen');
  host.state.chat.push(nativeLaterFloor());
  const evolveBefore = host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length;
  const held = await runAutomaticGate();
  assert(held.evolved === false, 'A4 no evolution while closed');
  assert(host.state.fixtureCalls.filter((call) => call.purpose === 'evolve').length === evolveBefore, 'A4 no evolve call');
  root.querySelector('[data-page="settings"]').click();
  const reopen = root.querySelector('[data-action="toggle-plugin"]');
  assert(reopen?.textContent === '重开', 'A4 reopen button');
  reopen.click();
  await waitFor(() => root.querySelector('[data-action="toggle-plugin"]')?.textContent === '冻结', 'A4 did not reopen');
  assert(loadWorld()?.plugin?.enabled === true && loadWorld()?.plugin?.frozenAt == null, 'A4 state restored');
  assert(host.state.chat.map((message) => message.mes).slice(0, frozenMes.length).join('\n') === frozenMes.join('\n'), 'A4 historical floors');
  assert(floorHash(host.state.chat.slice(0, frozenMes.length)) === frozenHash, 'A4 original floor hash');
  root.querySelector('[data-page="world"]').click();
  document.querySelector('#shiju-page [data-world-kind="region"]').click();
  assert(pageText().includes(NATIVE_REGION), 'A4 region is back on the panel');

  root.querySelector('[data-page="settings"]').click();
  root.querySelector('input[value="night"]').click();
  assert(loadSettings().ui.theme === 'night', 'A24 theme saved');
  assert(host.getExtensionSettings().shiju.ui.theme === 'night', 'A24 theme is on extension_settings.shiju');
  const exported = JSON.parse(JSON.stringify(exportChatFile(host)));
  assert(exported[0].chatMetadata?.shiju?.regions?.some((item) => item.name === NATIVE_REGION), 'A24 export includes chatMetadata.shiju');
  assert(exported[0].chat_metadata?.shiju?.regions?.some((item) => item.name === NATIVE_REGION), 'A24 export keeps chat_metadata.shiju');

  const packed = uninstallKeepingChat(host);
  const next = reinstallNativeHost(packed.chatFile, packed.settings);
  setHost(next);
  inject.register();
  timetag.register();
  reconcile.register();
  api.refresh();
  assert(loadWorld()?.regions?.some((item) => item.name === NATIVE_REGION), 'A24 reinstall resumes the ledger');
  assert(!loadWorld().regions.some((item) => item.name === DECOY_REGION), 'A24 reinstall ignores the decoy');
  assert(next.state.localVault.shiju.regions[0].name === DECOY_REGION, 'A24 decoy stays unused');
  assert(loadSettings().ui.theme === 'night', 'A24 settings survived reinstall');
  root.querySelector('[data-page="world"]').click();
  document.querySelector('#shiju-page [data-world-kind="region"]').click();
  assert(pageText().includes(NATIVE_REGION), 'A24 panel reads the reopened chat');
  assert(!pageText().includes(DECOY_REGION), 'A24 panel does not read the decoy');
  const beforeResume = next.state.fixtureCalls.length;
  const resumed = await bootstrapWorld();
  assert(resumed.created === false && resumed.evolved === false, 'A24 resume does not rebuild');
  assert(next.state.fixtureCalls.length === beforeResume, 'A24 resume makes no model call');
}
