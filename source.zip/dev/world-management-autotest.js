import { createEmptyWorld,saveWorld,loadWorld } from '../src/store/index.js';
import { captureInputBoundary } from '../src/modules/incremental.js';
import { enqueueTurn } from '../src/modules/turn.js';
export async function runWorldManagementAutotest() {
  const host=globalThis.__SHIJU_PREVIEW_HOST__,backup=structuredClone(host.state.chatMetadata),backend=host.generateViaBackend;
  const body=document.getElementById('shiju-page'),assert=(ok,message)=>{if(!ok)throw Error(message);};
  const get=s=>body.querySelector(s),click=s=>{const el=get(s);assert(el,`Missing ${s}`);el.click();};
  const flush=()=>new Promise(r=>setTimeout(r,40));
  const fill=(field,value)=>{const el=get(`[data-entity-field="${field}"]`);el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));};
  const tab=id=>document.querySelector(`[role="tab"][data-page="${id}"]`).click();
  const checkSize=()=>assert(get('[data-manage="new:regions"]').getBoundingClientRect().height>=44,'management controls meet touch size');
  const world=createEmptyWorld();world.plugin.enabled=true;world.meta.builtFingerprint='management-fixture';world.processedInput=captureInputBoundary(host.state.chat);
  world.regions=[{id:'r:legacy',name:'北岸平原',summary:'河道贯穿平原，各镇协商维修桥梁。',status:'active'}];
  let calls=0;
  host.generateViaBackend=async()=>{calls++;return JSON.stringify({regions:[{name:'北岸平原',summary:'模型整理资料'},{name:'南岸丘陵',summary:'丘陵间分布着果园和驿道。'}]});};
  try {
    await saveWorld(world);tab('world');click('[data-world-kind="region"]');
    checkSize();click('[data-manage="new:regions"]');assert(document.activeElement===get('#sj-entity-name'),'entity editor receives keyboard focus');
    fill('name','西港');fill('summary','港务所协调船运。\n'+'完整资料'.repeat(400));
    let release;const running=enqueueTurn(()=>new Promise(r=>release=r));await flush();
    assert(get('[data-manage="save"]').disabled && get('#sj-entity-summary').value.includes('完整资料'),'busy disables save and keeps draft');
    release();await running;await flush();click('[data-manage="save"]');await flush();
    assert(loadWorld().regions.some(r=>r.name==='西港'&&r.manualMaintained)&&calls===0,'manual add no call');
    click('[data-detail-toggle="entity:region:r:legacy"]');click('[data-manage="edit:regions:r:legacy"]');fill('name','北岸河谷');click('[data-manage="save"]');await flush();
    assert(loadWorld().regions.find(r=>r.id==='r:legacy').aliases.includes('北岸平原'),'rename alias');
    click('[data-manage="new:regions"]');fill('name','北岸平原');fill('summary','重复名称测试');click('[data-manage="save"]');await flush();
    click('[data-manage="locate:regions:r:legacy"]');assert(document.activeElement?.dataset.detailToggle==='entity:region:r:legacy','duplicate locates existing record without opening it');
    click('[data-manage="edit-cancel"]');
    click('[data-manage="generate:regions"]');await flush();await flush();
    assert(get('[data-manage="adopt"]')&&body.textContent.includes('保留'),'preview shown');
    assert(body.scrollWidth<=body.clientWidth+1,'management preview has no horizontal overflow');
    assert(!loadWorld().regions.some(r=>r.name==='南岸丘陵'),'not adopted yet');
    click('[data-manage="reveal"]');assert(body.textContent.includes('采用后')&&body.textContent.includes('南岸丘陵'),'review changes');
    click('[data-manage="adopt"]');await flush();
    assert(loadWorld().regions.some(r=>r.name==='南岸丘陵')&&loadWorld().regions.some(r=>r.name==='西港'),'adoption supplements and preserves');
    tab('settings');click('[data-settings-section="world"]');click('[data-manage="generate:all"]');await flush();await flush();
    click('[data-manage="adopt"]');await flush();assert(get('[data-manage="backup-export"]'),'rebuild backup export');
    click('[data-manage="restore"]');assert(get('[role="alertdialog"]'),'restore explicit confirmation');click('[data-manage="restore-cancel"]');
    tab('world');click('[data-manage="new:regions"]');fill('name','切换会清除的草稿');
    host.eventSource.emit(host.event_types.CHAT_CHANGED);await flush();assert(!get('#sj-entity-name'),'chat switch discards editor');
    if(new URLSearchParams(location.search).has('managementdemo')) {
      click('[data-manage="generate:regions"]');await flush();await flush();click('[data-manage="reveal"]');return;
    }
  } finally {host.generateViaBackend=backend;if(!new URLSearchParams(location.search).has('managementdemo')){host.state.chatMetadata=backup;host.eventSource.emit(host.event_types.CHAT_CHANGED);await flush();}}
}
