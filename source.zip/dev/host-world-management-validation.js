// Fixed responses and fictional data, restricted to disposable local hosts.
if(['43125','43126'].includes(location.port)&&new URLSearchParams(location.search).has('worldcompat'))void(async()=>{
  const output=document.createElement('pre');output.id='sj-autotest';document.body.append(output);
  let count=0;const check=(ok,label)=>{if(!ok)throw Error(label);count++;output.textContent=`通过 ${count}：${label}`;};
  const until=async(fn,label)=>{for(let i=0;i<500;i++){if(fn())return;await new Promise(r=>setTimeout(r,50));}throw Error('等待超时 '+label);};
  const load=path=>import('/scripts/extensions/third-party/shiju/'+path);
  const originalFetch=window.fetch;let requests=[],reply={regions:[{id:'r',name:'河谷',summary:'地区资料'.repeat(1500)}],events:[{id:'e',title:'修桥计划',body:'各镇筹资维护桥梁，不涉及主角行动。'}]};
  window.fetch=async(url,options={})=>{
    if(/\/api\/(backends\/[^/]+\/generate|novelai\/generate|horde\/generate-text)/.test(String(url))){requests.push(JSON.parse(options.body));return Response.json({choices:[{message:{content:JSON.stringify(reply)},finish_reason:'stop'}]});}
    return originalFetch(url,options);
  };
  let host,oldRead;
  try {
    await until(()=>window.TavernHelper&&window.STBaiBaiBook&&window.EjsTemplate&&window.__baiBaiToolkitExtensionInstalled,'伴随插件加载');
    const st=await import('/script.js');await until(()=>st.settingsReady,'酒馆设置就绪');
    host=(await load('src/host.js')).getHost();await new Promise(resolve=>st.eventSource.once(st.event_types.APP_READY,resolve));
    await st.getCharacters();const id=host.getContext().characters.findIndex(c=>c.name==='世局验收A');check(id>=0,'仅使用隔离角色');await st.selectCharacterById(id);
    const {isWorldBusy}=await load('src/modules/turn.js');await until(()=>!isWorldBusy(),'原任务结束');
    let prior=JSON.stringify(host.getContext().chatMetadata), stable=Date.now();await until(()=>{const now=JSON.stringify(host.getContext().chatMetadata);if(now!==prior){prior=now;stable=Date.now();}return Date.now()-stable>2000;},'后台初始化稳定');
    const store=await load('src/store/index.js'),manage=await load('src/modules/management/index.js');
    store.saveSettings({model:{channelMode:'custom',endpoint:'http://fixture.invalid/v1',customModel:'fixture-model',apiKey:'',stream:false,jailbreakMode:'off',contextLimit:null}});
    await store.saveChatMetadata({shiju:null});
    oldRead=host.readWorldbook;host.readWorldbook=()=>({entries:[{uid:1,title:'合法绿灯 EJS',keys:['未被发现'],bookName:'虚构资料',content:'<% const x=_.omit({a:1,b:2},"a"); %><!-- 原样 --> <%= x.b %>'},{uid:2,title:'宏观资料',keys:['未知区域'],content:'全量绿灯尾部'+'完整背景'.repeat(3000),bookName:'虚构资料'}]});
    const {bootstrapWorld}=await load('src/modules/bootstrap/index.js');const {runImmediateEvolution,rerunLastEvolution}=await load('src/modules/timeGate/index.js');
    const {getHistory}=await load('src/modules/model/history.js');
    check((await bootstrapWorld()).created,'真实宿主初始化');
    check(requests[0].messages.at(-1).content.includes('<!-- 原样 --> 2')&&requests[0].messages.at(-1).content.includes('完整背景'.repeat(3000)),'打包 Worker 渲染且完整传递绿灯正文');
    const day=store.loadWorld().storyClock.dayIndex;reply={};
    check((await runImmediateEvolution()).evolved&&store.loadWorld().storyClock.dayIndex===day,'初始化后无新增正文可主动演进');
    check((await rerunLastEvolution()).evolved,'主动演进可重跑');
    const editor=manage.beginEntityEdit('regions','r');await manage.saveEntity(editor.token,{...editor.item,name:'新河谷',summary:'人工保留资料'});
    reply={regions:[{name:'河谷',summary:'模型新概况'},{name:'海岸',summary:'沿岸有港口'}]};
    const preview=await manage.generateManagementPreview('regions');check(!!preview.token,'分类预览返回会话 '+JSON.stringify(preview.ok===false?preview:{}));await manage.adoptManagementPreview(preview.token);
    check(store.loadWorld().regions.some(r=>r.name==='新河谷'&&r.summary==='人工保留资料')&&store.loadWorld().regions.some(r=>r.name==='海岸'),'分类补全与人工内容保护');
    const rebuild=await manage.generateManagementPreview();check(!!rebuild.token,'重建预览返回会话 '+JSON.stringify(rebuild.ok===false?rebuild:{}));await manage.adoptManagementPreview(rebuild.token);
    check(manage.readRebuildBackup()?.world&&store.loadWorld().evolutionLog.length===0,'重建独立备份与新基线');
    await manage.restoreRebuildBackup(manage.beginBackupRestore());check(store.loadWorld().lastEvolutionCheckpoint,'备份恢复原检查点');
    check(getHistory().some(r=>r.purpose==='reinitialize'&&r.business==='重新初始化已采用'),'实际历史区分生成与采用');
    const world=store.loadWorld();world.plugin.enabled=false;await store.saveWorld(world);
    output.textContent=`全部通过 ${count} 项；${requests.length} 次固定回复；真实模型 0 次`;document.documentElement.dataset.sjAutotest='ok';
  }catch(error){document.documentElement.dataset.sjAutotest='fail';document.documentElement.dataset.sjAutotestError=error.stack || String(error);output.textContent=document.documentElement.dataset.sjAutotestError;}
  finally{window.fetch=originalFetch;if(host&&oldRead)host.readWorldbook=oldRead;}
})();
