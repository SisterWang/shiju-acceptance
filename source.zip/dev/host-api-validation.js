// Runs only on the two disposable local test instances.
if (['43125','43126'].includes(location.port) && new URLSearchParams(location.search).has('apicompat')) void (async()=>{
  const output=document.createElement('pre');output.id='sj-autotest';document.body.append(output);
  let n=0; const check=(x,label)=>{if(!x)throw Error(label);n++;output.textContent=`通过 ${n}: ${label}`;};
  const until=async (fn,label)=>{for(let i=0;i<400;i++){if(fn())return;await new Promise(r=>setTimeout(r,50));}throw Error('等待超时：'+label);};
  const nativeFetch=window.fetch; let calls=[],failSave=false, holdModels=false, modelRelease=null, historyUploads=0, historySettingsWrites=0, generationEvents=0, holdStream=false, streamController=null;
  window.fetch=async(url,options={})=>{
    const path=String(url);
    if(path==='/api/backends/chat-completions/status') {calls.push(path);if(holdModels){holdModels=false;return new Promise(resolve=>{modelRelease=()=>resolve(Response.json({data:[{id:'stale-model'}]}));});}return Response.json({data:[{id:'fixture-b'},{id:'fixture-a'},{id:'fixture-a'}]});}
    if(path==='/api/backends/chat-completions/generate') {const body=JSON.parse(options.body);calls.push({path,body});
      if(body.stream){if(holdStream){holdStream=false;return new Response(new ReadableStream({start(c){streamController=c;}}));}
        const bytes=new TextEncoder().encode('data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n');return new Response(new ReadableStream({start(c){c.enqueue(bytes.slice(0,11));c.enqueue(bytes.slice(11));c.close();}}));}
      return Response.json({choices:[{message:{content:'ok'},finish_reason:'stop'}],usage:{prompt_tokens:3,completion_tokens:1}});
    }
    if(path==='/api/files/upload') { historyUploads++; if(failSave)return new Response('{}',{status:503}); }
    if(path==='/api/settings/save') historySettingsWrites++;
    return nativeFetch(url,options);
  };
  try {
    await until(()=>document.getElementById('shiju-chrome'),'世局初始化');
    const st=await import('/script.js');await until(()=>st.settingsReady,'酒馆设置加载');
    const load=p=>import('/scripts/extensions/third-party/shiju/'+p);
    const {getHost}=await load('src/host.js');const host=getHost();
    const {testCustomConnection}=await load('src/modules/model/index.js');
    const history=await load('src/modules/model/history.js'); await history.initHistory();
    if (new URLSearchParams(location.search).get('phase') === 'read') {
      check(history.getHistory().some(r=>r.purpose==='connection-test' && r.response==='ok'),'另一个浏览器读取前次保存的历史');
      output.textContent=`全部通过：${n}`;document.documentElement.dataset.sjAutotest='ok';return;
    }
    st.eventSource.on(st.event_types.GENERATION_STARTED,()=>generationEvents++);
    const models=await host.fetchCustomModels({endpoint:'http://127.0.0.1:8889/v1',apiKey:''});
    check(models.join(',')==='fixture-a,fixture-b','模型列表去重排序');
    const model={channelMode:'custom',endpoint:'http://127.0.0.1:8889/v1',apiKey:'fixture-secret',customModel:'fixture-model',responseLength:1024,jailbreakMode:'off',stream:true};
    let prior=JSON.stringify(host.getContext().chatMetadata || {}),stable=Date.now();
    await until(()=>{const now=JSON.stringify(host.getContext().chatMetadata || {});if(now!==prior){prior=now;stable=Date.now();}return Date.now()-stable>1500;},'聊天元数据初始化稳定');
    const before=JSON.stringify(host.getContext().chatMetadata || {});
    const reply=await testCustomConnection(model);check(reply==='ok','真实宿主转发路径解析流式响应');
    check(calls.at(-1).body.stream===true && calls.at(-1).body.messages.length===1,'测试请求仅带固定消息及独立流式参数');
    const saveStart=performance.now();await history.retryHistory();const saveMs=performance.now()-saveStart;
    check(!history.historyStatus() && saveMs < 5000,`历史保存已回读确认（${Math.round(saveMs)} ms）`);
    const item=history.getHistory()[0];check(item.purpose==='connection-test' && item.actualStream && item.response==='ok','历史保存内容正确');
    check(!JSON.stringify(item).includes('fixture-secret'),'历史不包含密钥');
    document.querySelector('.sj-fab').click();document.querySelector('[data-page="settings"][role="tab"]').click();
    document.querySelector('[data-settings-section="model"]').click();
    const edit=document.querySelector('[data-prompt-action="model-edit"]');if(edit)edit.click();
    let custom=document.querySelector('[name="sj-channel-mode"][value="custom"]');custom.checked=true;custom.dispatchEvent(new Event('change',{bubbles:true}));
    const put=(selector,value)=>{const el=document.querySelector(selector);el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));};
    put('#sj-channel-url','http://127.0.0.1:8889/v1');put('#sj-channel-key','fixture-secret');put('#sj-channel-model','fixture-model');
    document.querySelector('[data-prompt-action="model-list"]').click();
    await until(()=>document.querySelectorAll('#sj-model-options option').length===2,'界面模型列表');check(true,'界面可以获取模型列表');
    const selected=document.querySelector('#sj-model-filter');selected.value='fixture-a';selected.dispatchEvent(new Event('change',{bubbles:true}));
    check(document.querySelector('#sj-channel-model').value==='fixture-a','模型列表可选择模型');
    holdModels=true;document.querySelector('[data-prompt-action="model-list"]').click();await until(()=>modelRelease,'暂停模型列表');
    put('#sj-channel-url','http://127.0.0.1:8889/new-v1');modelRelease();
    await until(()=>!document.querySelector('[data-prompt-action="model-list"]').disabled,'旧模型响应结束');
    check(!document.querySelector('#sj-model-options'),'修改地址后迟到的模型列表不重新出现');
    put('#sj-channel-url','http://127.0.0.1:8889/v1');
    document.querySelector('[data-prompt-action="model-test"]').click();
    await until(()=>document.querySelector('#sj-test-feedback')?.textContent.includes('连接测试通过'),'界面连接测试');check(true,'界面测试草稿渠道并报告成功');
    document.querySelector('[data-prompt-action="model-cancel"]').click();
    holdStream=true;
    const pending=testCustomConnection(model);await until(()=>streamController,'流式请求开始');
    document.querySelector('[data-history-action="open"]').click();
    const focused=document.querySelector('[data-history-filter="purpose"]');focused.focus();
    streamController.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"测"}}]}\n\n'));
    await until(()=>document.querySelector('[data-history-progress]')?.textContent.includes('已接收 1 字'),'流式进度');
    check(true,'历史视图显示实时接收字数');
    check(document.activeElement===focused,'流式进度不重建视图或抢占焦点');
    streamController.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"试"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n'));streamController.close();
    check(await pending==='测试','流式完整后返回正文');
    document.querySelector('[data-history-action="back"]').click();
    historySettingsWrites=0;
    await history.retryHistory();
    const file=await nativeFetch('/user/files/shiju-request-history-v1.json',{cache:'no-store'});
    check(file.ok && (await file.json()).format==='shiju-request-history','历史保存到账号独立文件');
    check(historyUploads>0 && historySettingsWrites===0,'历史不调用全量设置保存接口');
    const beforeObj=JSON.parse(before), afterObj=host.getContext().chatMetadata || {};
    const changedKeys=[...new Set([...Object.keys(beforeObj),...Object.keys(afterObj)])].filter(k=>JSON.stringify(beforeObj[k])!==JSON.stringify(afterObj[k]));
    check(!changedKeys.length,'测试连接不修改聊天元数据（变化字段：'+changedKeys.join(',')+'）');
    check(generationEvents===0,'没有触发正文生成事件');
    failSave=true;check(await testCustomConnection(model)==='ok','历史保存失败不改变模型请求成功结果'); const ref=await history.beginHistory({purpose:'test',connection:{},messages:[]},null);history.finishHistory(ref,'ok');await history.retryHistory();
    check(!!history.historyStatus(),'服务器保存失败显示错误');
    check(document.querySelector('[data-history-save-status]')?.textContent.includes('历史未保存'),'设置入口显示历史保存失败');
    document.querySelector('[data-history-action="open"]').click();
    check(document.querySelector('.sj-request-history [role="alert"]')?.textContent.includes('历史未保存'),'历史视图显示保存失败及恢复入口');
    failSave=false;document.querySelector('[data-history-action="retry"]').click();
    await until(()=>!history.historyStatus(),'手动重试保存');check(!history.historyStatus(),'恢复连接后通过界面重试保存');
    check(document.querySelector('.sj-request-history').textContent.includes('请勿清理'),'展示独立文件清理风险说明');
    const headers=host.getContext().getRequestHeaders();
    const savedEnvelope=await (await nativeFetch('/api/settings/get',{method:'POST',headers,body:'{}'})).json();
    const savedSettings=JSON.parse(savedEnvelope.settings);savedSettings.shijuIsolationFixture='concurrent-writer';
    await Promise.all([history.retryHistory(),nativeFetch('/api/settings/save',{method:'POST',headers,body:JSON.stringify(savedSettings)})]);
    const verified=await (await nativeFetch('/api/settings/get',{method:'POST',headers,body:'{}'})).json();
    check(JSON.parse(verified.settings).shijuIsolationFixture==='concurrent-writer','同时保存的其他设置不被历史覆盖');
    const oai=await import('/scripts/openai.js');st.changeMainAPI('openai');
    Object.assign(oai.oai_settings,{chat_completion_source:'openai',openai_model:'fixture-model',openai_max_tokens:777});
    let release=null;const pause=async()=>{st.eventSource.removeListener(st.event_types.CHAT_COMPLETION_PROMPT_READY,pause);await new Promise(resolve=>{release=resolve;});};
    st.eventSource.on(st.event_types.CHAT_COMPLETION_PROMPT_READY,pause);
    const companion=host.getContext().generateRaw({prompt:'虚构的并发请求',responseLength:333});
    await until(()=>!!release,'并发请求暂停');await history.retryHistory();await new Promise(resolve=>setTimeout(resolve,4200));
    check(oai.oai_settings.openai_max_tokens===333,'历史保存不提前恢复其他插件的回复长度');
    release();await companion;check(oai.oai_settings.openai_max_tokens===777,'其他插件自行恢复原长度');
    output.textContent=`全部通过：${n}；历史保存并回读 ${Math.round(saveMs)} ms`;document.documentElement.dataset.sjAutotest='ok';
  } catch(error){document.documentElement.dataset.sjAutotest='fail';document.documentElement.dataset.sjAutotestError=error.stack||String(error);output.textContent=document.documentElement.dataset.sjAutotestError;}
  finally {window.fetch=nativeFetch;}
})();
