// Only disposable SillyTavern instances; no model requests or chat writes.
if (['43125','43126'].includes(location.port) && new URLSearchParams(location.search).has('templatecompat')) {
  void (async () => {
    const output = document.createElement('pre');
    output.id = 'sj-autotest'; document.body.append(output);
    let count = 0;
    const check = (ok, label) => {
      if (!ok) throw new Error(label);
      count++; output.textContent = `通过 ${count}：${label}`;
    };
    try {
      const root = '/scripts/extensions/third-party/shiju/';
      const {getHost} = await import(root+'src/host.js');
      const {runWorker,renderSelected} = await import(root+'src/modules/template/index.js');
      const {selectWorldbook} = await import(root+'src/modules/worldbook/select.js');
      const {checkTemplateCompatibility,templateData} = await import(root+'scripts/template-fixtures.js');
      for (let i=0; i<600 && !(window.TavernHelper && window.STBaiBaiBook && window.EjsTemplate && window.__baiBaiToolkitExtensionInstalled); i++) await new Promise(r=>setTimeout(r,50));
      check(window.TavernHelper && window.STBaiBaiBook && window.EjsTemplate && window.__baiBaiToolkitExtensionInstalled, '四插件均已加载');
      const host = getHost();
      // Plugin globals appear before the host finishes loading its chat. Take
      // the baseline only after the replayable APP_READY event has completed.
      await new Promise(resolve=>host.eventSource.once(host.event_types.APP_READY,resolve));
      const st = await import('/script.js');
      const character = host.getContext().characters.findIndex(row=>row.name==='世局验收A');
      check(character >= 0, '使用隔离实例中的虚构验收角色');
      await st.selectCharacterById(character);
      // The host's delayed prompt/token preview initializes timedWorldInfo
      // after CHAT_CHANGED/APP_READY. Observe completion; do not initialize or
      // omit this metadata ourselves, so the full equality check stays useful.
      for (let i=0;i<100 && !host.getContext().chatMetadata.timedWorldInfo;i++) await new Promise(resolve=>setTimeout(resolve,100));
      check(!!host.getContext().chatMetadata.timedWorldInfo, '宿主世界书计时状态初始化完成');
      const snapshot = () => JSON.stringify({chat:host.getContext().chat,metadata:host.getContext().chatMetadata,variables:host.getExtensionSettings().variables});
      // Character selection can return before companion plugins finish their
      // asynchronous chat initialization. Require a stable baseline first.
      let stableSince=performance.now(), previous=snapshot();
      const settleStart=stableSince;
      while (performance.now()-stableSince < 1000) {
        if (performance.now()-settleStart > 10000) throw new Error('隔离聊天初始化未稳定');
        await new Promise(resolve=>setTimeout(resolve,100));
        const current=snapshot();
        if (current!==previous) {previous=current;stableSince=performance.now();}
      }
      const before = snapshot(), dataBefore = JSON.stringify(templateData);
      const elapsed = [];
      function differences(a,b,prefix='') {
        if (JSON.stringify(a)===JSON.stringify(b)) return [];
        if (!a || !b || typeof a!=='object' || typeof b!=='object') return [prefix];
        return [...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(key=>differences(a[key],b[key],`${prefix}.${key}`)).slice(0,20);
      }
      const changes = [];
      let lastSnapshot = before;
      function observe(label) {
        const current=snapshot();
        if (current!==lastSnapshot) changes.push({label,paths:differences(JSON.parse(lastSnapshot),JSON.parse(current))});
        lastSnapshot=current;
      }
      const render = async (content,entries=[]) => {
        const start = performance.now();
        const result = await runWorker({title:'main',content},templateData,entries);
        elapsed.push(performance.now()-start);
        observe('worker '+elapsed.length);
        return result;
      };
      await checkTemplateCompatibility(render, check);
      const entries = Array.from({length:12},(_,i)=>({bookName:'测试书',title:`条目${i}`,uid:i,constant:true,content:'<!-- 注释 -->状态：<%= getvar("status") %>'}));
      const start = performance.now();
      const batch = await renderSelected(selectWorldbook({entries}), {templateData,worldbook:{entries}}, {});
      const batchMs = performance.now()-start;
      observe('renderSelected batch');
      check(batch.bodies.length === 12 && batch.diagnostics.length === 0, '12 条动态资料在原有整轮预算内完整保留');
      const bad = [
        {title:'失败父条目',constant:true,content:'<%- await include("失败子条目") %>'},
        {title:'失败子条目',content:'<%= unknown() %>'},
        {title:'静态资料',constant:true,content:'桥梁已修复'},
      ];
      const partial = await renderSelected(selectWorldbook({entries:bad}), {templateData,worldbook:{entries:bad}}, {});
      observe('renderSelected partial');
      check(partial.bodies.some(e=>e.title==='静态资料') && !partial.text.includes('<%'), '失败条目不影响静态资料且不发送源码');
      check(partial.diagnostics.some(d=>d.reason.includes('失败父条目') && d.reason.includes('失败子条目')), '诊断包含引用链');
      const timeoutStart = performance.now();
      const timed = await runWorker({title:'无限循环',content:'<% while(true){} %>'},templateData,[]);
      check(timed.timeout && timed.diagnostics[0].code === 'EJS_TIMEOUT' && performance.now()-timeoutStart < 3000, '原有两秒预算终止无限循环');
      const after = snapshot();
      observe('timeout');
      check(after === before && JSON.stringify(templateData) === dataBefore, `宿主聊天、元数据及变量完全不变（差异字段：${JSON.stringify(changes)}）`);
      // Optional old bundle served only from the disposable test server.
      const baseline = [];
      if (new URLSearchParams(location.search).has('baseline')) {
        for (let i=0; i<5; i++) {
          const start = performance.now();
          const result = await new Promise((resolve,reject)=>{
            const worker = new Worker('/shiju-template-before.js');
            const timer = setTimeout(()=>{worker.terminate();reject(new Error('baseline timeout'));},2000);
            worker.onmessage = event=>{clearTimeout(timer);worker.terminate();resolve(event.data);};
            worker.onerror = ()=>{clearTimeout(timer);worker.terminate();reject(new Error('baseline worker error'));};
            worker.postMessage({entry:{title:'baseline',content:'状态：<%= getvar("status") %>'},context:templateData,entries:[]});
          });
          check(result.text === '状态：已验收', '旧版冷启动基准');
          baseline.push(performance.now()-start);
        }
      }
      const simple = [];
      for (let i=0;i<5;i++) {
        const start = performance.now();
        check((await render('状态：<%= getvar("status") %>')).text === '状态：已验收', '新版冷启动基准');
        simple.push(performance.now()-start);
      }
      const stats = values => values.length ? {min:Math.round(Math.min(...values)),max:Math.round(Math.max(...values)),median:Math.round([...values].sort((a,b)=>a-b)[Math.floor(values.length/2)])} : null;
      output.textContent = `${count} 项通过；零模型调用、零聊天写入。\n耗时 ms：${JSON.stringify({oldCold:stats(baseline),newCold:stats(simple),allCases:stats(elapsed),batch12:Math.round(batchMs)})}`;
      document.documentElement.dataset.sjAutotest='ok';
    } catch (error) {
      output.textContent += `\n${error.stack}`;
      document.documentElement.dataset.sjAutotest='fail';
      document.documentElement.dataset.sjAutotestError=output.textContent;
    }
  })();
}
