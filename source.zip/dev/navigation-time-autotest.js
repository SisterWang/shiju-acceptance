import { historySaving } from '../src/modules/model/history.js';
import { start } from '../src/main.js';
import { createEmptyWorld, saveWorld, saveSettings, loadSettings, loadWorld } from '../src/store/index.js';
import { absoluteSerial } from '../src/modules/timetag/read.js';
import { captureInputBoundary } from '../src/modules/incremental.js';
import { inspectStoryDay } from '../src/modules/lifecycle/index.js';
import { enqueueTurn, isWorldBusy } from '../src/modules/turn.js';
import { onExtensionUpdate, createUpdateTracker, updates } from '../src/update.js';
import { mountUpdateNotice } from '../src/ui/updateNotice.js';
import { mountWandEntry } from '../src/ui/wand.js';

export async function runNavigationTimeAutotest(host) {
  let count=0;
  const check=(ok,message)=>{if(!ok)throw Error(message);count++;};
  const until=async(fn,label)=>{for(let i=0;i<100;i++){if(fn())return;await new Promise(r=>setTimeout(r,30));}throw Error('等待超时 '+label);};
  const root=document.getElementById('shiju-chrome'), body=root.querySelector('.sj-body');
  const click=selector=>{const el=root.querySelector(selector);if(!el)throw Error('找不到 '+selector);el.click();};
  // Late-created menu and idempotent startup use the same code as real hosts.
  let menu=document.getElementById('extensionsMenu');
  if(!menu){menu=document.createElement('div');menu.id='extensionsMenu';document.body.append(menu);}
  let wand=document.getElementById('extensionsMenuButton');
  if(!wand){wand=document.createElement('button');wand.id='extensionsMenuButton';wand.textContent='魔法棒';document.body.append(wand);}
  await until(()=>document.getElementById('shiju-wand-entry'),'延迟菜单入口');
  start();check(document.querySelectorAll('#shiju-wand-entry').length===1,'重复启动只有一个入口');
  saveSettings({ui:{showFab:true}});
  document.getElementById('shiju-wand-entry').click();
  check(!root.querySelector('.sj-panel').hidden,'魔法棒打开面板');
  click('[role="tab"][data-page="settings"]');click('[data-settings-section="appearance"]');
  click('[data-action="toggle-fab"]');click('.sj-close');
  check(root.querySelector('.sj-fab').hidden && !loadSettings().ui.showFab,'关闭面板不会复活已关闭的球');
  check(document.activeElement===document.getElementById('shiju-wand-entry') || document.activeElement===wand,`焦点返回可见入口：${document.activeElement?.outerHTML?.slice(0,250)}；wand=${wand.outerHTML.slice(0,400)}；entry=${document.getElementById('shiju-wand-entry').getClientRects().length}`);
  document.getElementById('shiju-wand-entry').click();
  check(!root.querySelector('.sj-panel').hidden,'球关闭后仍可打开');
  click('[data-action="toggle-fab"]');check(loadSettings().ui.showFab,'重新开启球');

  const oldRead=host.readChat, oldModel=host.generateViaBackend;
  const date='复兴纪元488年1月4日 22:15';
  const chat=[{mes:`公告<shiju_end>${date}</shiju_end>`,swipe_id:0},{mes:'天气公告<shiju_end>复兴纪元488年1月3日 12:00</shiju_end>',swipe_id:0}];
  host.readChat=()=>chat;host.generateViaBackend=()=>{throw Error('验收不允许模型调用');};
  try {
    saveSettings({timeSource:{mode:'shiju'}});
    const world=createEmptyWorld(),serial=absoluteSerial(date);
    world.plugin.enabled=true;world.meta.builtFingerprint='navigation-fixture';
    world.storyClock={dateLabel:date,dayIndex:27,serial,originSerial:serial-27,source:'shiju',lastConfirmedAtFloor:0};
    world.processedInput=captureInputBoundary(chat);await saveWorld(world);
    check(root.querySelector('[data-action="time-diagnosis"]').textContent.includes('日期冲突'),'顶部显示真实日期问题');
    check(root.querySelector('[data-action="evolve"]').disabled,'真实冲突禁用立即演进');
    click('[data-action="time-diagnosis"]');
    check(body.querySelector('[data-settings-fold="date"]').open && document.activeElement.id==='sj-time-diagnosis','点击状态直达并聚焦校正区');
    check(body.querySelector('#sj-time-diagnosis').textContent.includes('楼层 #1') && body.querySelector('#sj-time-diagnosis').textContent.includes(date),'展示冲突双方与楼层');
    check(body.querySelector('[data-action="correct-day"]').disabled&&!body.querySelector('[data-choice="realign"]'),'来源内部矛盾不能靠重对齐或改账日期掩盖');
    chat[1].mes='天气公告<shiju_end>复兴纪元488年1月4日 23:00</shiju_end>';
    click('[data-action="recheck-time"]');check(!inspectStoryDay().blocked&&!root.querySelector('[data-action="evolve"]').disabled,'日期修复即恢复按钮');
    let latest=loadWorld();latest.meta.inputHint='history-changed';await saveWorld(latest);
    check(root.querySelector('[data-action="time-diagnosis"]').textContent.includes('历史正文'),'历史修改不会标为日期冲突');
    latest.meta.inputHint='';latest.processedInput=captureInputBoundary(chat);await saveWorld(latest);
    const day=body.querySelector('#sj-day-index');day.value='99';day.dispatchEvent(new Event('input',{bubbles:true}));
    click('[data-action="correct-day"]');
    check(!root.querySelector('#sj-confirm').hidden && root.querySelector('#sj-confirm-body').textContent.includes('第 99 日'),'校正前展示前后日期');
    click('[data-confirm="ok"]');await until(()=>loadWorld().storyClock.dayIndex===99&&!isWorldBusy(),'日期保存');
    check(inspectStoryDay().status==='aligned','校正后保持统一基准');

    onExtensionUpdate();check(!root.querySelector('.sj-update-notice').hidden,'更新回调展示刷新与稍后');
    click('[data-update-later]');check(root.querySelector('.sj-update-notice').hidden&&body.querySelector('[data-refresh-app]'),'稍后隐藏浮动提醒但保留设置入口');
    onExtensionUpdate();check(root.querySelector('.sj-update-notice').hidden,'重复更新回调不重复打扰');
    let release;
    const running=enqueueTurn(()=>new Promise(resolve=>{release=resolve;}));
    await until(()=>release,'模拟运行锁');
    click('[data-refresh-app]');
    check(root.querySelector('.sj-reload-dialog').open&&root.querySelector('[data-reload-confirm]').disabled,'运行中不允许刷新取消任务');
    click('[data-reload-cancel]');release({});await running;
    await until(()=>!host.hasPendingSettingsSave?.(), '宿主设置保存完成');
    // Dirty model settings remain in their draft; refresh asks before discarding.
    click('[data-settings-section="model"]');click('[data-prompt-action="model-edit"]');
    await until(()=>!host.hasPendingSettingsSave?.()&&!historySaving()&&!isWorldBusy(), '设置与历史写入完成');
    click('[data-refresh-app]');
    check(root.querySelector('[data-reload-risk]').textContent.includes('尚未保存'),`未保存设置提示明确：${root.querySelector('[data-reload-risk]').textContent}`);
    click('[data-reload-cancel]');
    check(!!body.querySelector('[data-prompt-action="model-save"]'),'取消刷新保留草稿');
    click('[data-prompt-action="model-cancel"]');

    // Test actual refresh dispatch without navigating the test runner.
    const isolated=document.createElement('div');document.body.append(isolated);
    let reloaded=0,busy=false;
    const tracker=createUpdateTracker('a',async()=>({version:'b'}));
    mountUpdateNotice(isolated,{tracker,risks:()=>({busy,draft:false}),reload:()=>reloaded++});
    await tracker.check();isolated.querySelector('[data-refresh-app]').click();
    busy=true;isolated.querySelector('[data-reload-confirm]').click();check(reloaded===0,'确认前重新检查运行状态');
    busy=false;isolated.querySelector('[data-reload-cancel]').click();isolated.querySelector('[data-refresh-app]').click();isolated.querySelector('[data-reload-confirm]').click();
    check(reloaded===1,'仅明确确认后执行刷新');isolated.querySelector('dialog').close();isolated.remove();
    latest=loadWorld();latest.meta.inputHint='history-changed';await saveWorld(latest);
    click('[data-action="time-diagnosis"]');
  } finally { host.readChat=oldRead;host.generateViaBackend=oldModel; }
  // A replaceable menu cannot duplicate the existing entry.
  const dispose=mountWandEntry(()=>{});check(document.querySelectorAll('#shiju-wand-entry').length===1,'菜单绑定幂等');
  dispose();check(!!document.getElementById('shiju-wand-entry'),'释放重复绑定不删除原入口');
  check(root.querySelector('.sj-panel').getBoundingClientRect().right<=innerWidth+1,'面板适配屏幕宽度');
  check(body.scrollWidth<=body.clientWidth+1,'诊断无横向溢出');
  return count;
}
