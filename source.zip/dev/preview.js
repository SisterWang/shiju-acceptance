import { setHost } from '../src/host.js';
import { createMemoryHost } from '../src/host/memory.js';
import { installNativeFixture } from '../src/fixture/native.js';
import { start } from '../src/main.js';
import { createEmptyWorld, saveWorld } from '../src/store/index.js';
import { runAutotest } from './autotest.js';
import { runFixtureAutotest } from './fixture-autotest.js';

const params = new URLSearchParams(location.search);
const host = createMemoryHost({ hasBaibai: params.has('baibai') });
setHost(host);
globalThis.__SHIJU_PREVIEW_HOST__ = host;

const fixtureOn = params.get('fixture') === '1';
if (fixtureOn) installNativeFixture(host, { enabled: true });
else if (params.has('intervene')) {
  host.generateViaBackend = async () => '东湾税卡临时放宽半日，商队得以通过。';
  const world = createEmptyWorld();
  world.plugin.enabled = true;
  world.storyClock = { dateLabel: '甲辰春', dayIndex: 12, source: 'shiju', lastConfirmedAtFloor: null };
  world.meta.builtFingerprint = 'preview-intervene';
  world.todayChanges = [
    { id: 'c1', kind: 'macro', title: '东湾商会加设税卡', body: '商路通行费上调。' },
    { id: 'c2', kind: 'secret', title: '某伯爵私下联络佣兵团', body: '伯爵通过密使接触北方佣兵团。', revealed: false },
  ];
  world.events = [
    { id: 'e1', kind: 'macro', title: '东湾商会加设税卡', body: '东湾至西原商路通行费上调，商会影响力向西延伸。' },
    { id: 'e3', kind: 'news', title: '西原商路通行变慢', body: '护商队遇袭后西原段通行变慢。' },
    { id: 'e2', kind: 'secret', title: '某伯爵私下联络佣兵团', body: '伯爵通过密使接触北方佣兵团，商议未公开的调动。', revealed: false },
  ];
  await saveWorld(world);
}

const api = start();
if (!document.getElementById('shiju-chrome')) {
  throw new Error('世局面板没有挂上');
}

const toggle = document.getElementById('sj-baibai-toggle');
if (toggle) {
  const paintToggle = () => {
    const on = Boolean(host.state.hasBaibai);
    toggle.textContent = on ? '柏宝书：已检测到' : '柏宝书：未检测到';
    toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
  };
  paintToggle();
  toggle.addEventListener('click', () => {
    host.state.hasBaibai = !host.state.hasBaibai;
    paintToggle();
    api?.refresh();
  });
}

if (fixtureOn) {
  const hint = document.querySelector('.hint');
  if (hint) {
    hint.textContent = '降级夹具已打开：没有柏宝书，没有 MVU。只有带 ?fixture=1 的预览会装上它，酒馆入口不会。';
  }
}

if (params.has('autotest')) {
  if (fixtureOn) await runFixtureAutotest(api);
  else await runAutotest(api);
}
