import { loadSettings, saveSettings } from '../src/store/index.js';
import { beginHistory, finishHistory, updateHistory, getHistory, retryHistory, clearHistory, historyStatus } from '../src/modules/model/history.js';

/** Fixed-response browser regression tests; no real model/network calls. */
export async function runReviewRegressionAutotest() {
  const host = globalThis.__SHIJU_PREVIEW_HOST__;
  const original = {model:loadSettings().model, backend:host.generateViaBackend, capture:host.captureModelConnection, persist:host.persistRequestHistory};
  const body = document.getElementById('shiju-page');
  const get = selector => body.querySelector(selector);
  const assert = (ok, message) => { if (!ok) throw Error(message); };
  const until = async (predicate, label) => { for(let i=0;i<100;i++) { if(predicate()) return; await new Promise(r=>setTimeout(r,10)); } throw Error(label); };
  const click = action => get(`[data-prompt-action="${action}"]`).click();
  const input = (selector, value) => { const el=get(selector); el.value=value; el.dispatchEvent(new Event('input',{bubbles:true})); };
  const select = (selector, value) => { const el=get(selector); el.value=value; el.dispatchEvent(new Event('change',{bubbles:true})); };
  let release, reject, sent;
  try {
    host.captureModelConnection = model => ({...model,mode:'custom',responseLength:model.responseLength ?? 100});
    host.generateViaBackend = request => { sent=request; return new Promise((resolve,fail)=>{release=resolve;reject=fail;}); };
    saveSettings({model:{...original.model,channelMode:'custom',endpoint:'https://a.example/v1',customModel:'fixture',apiKey:'',responseLength:100}});
    document.querySelector('[role="tab"][data-page="settings"]').click();
    get('[data-settings-section="model"]').click(); click('model-edit');
    const start = async () => { release=null; click('model-test'); await until(()=>release,'mock connection test starts'); };
    const finish = async () => { release({text:'ok'}); await until(()=>get('[data-prompt-action="model-test"]'),'mock connection test ends'); };
    const changes = [
      ()=>input('#sj-channel-url','https://b.example/v1'),
      ()=>input('#sj-channel-key','replacement-key'),
      ()=>input('#sj-channel-model','another-model'),
      ()=>get('#sj-channel-stream').click(),
      ()=>input('#sj-response-length','200'),
      ()=>select('#sj-response-mode','follow'),
    ];
    for (const change of changes) {
      await start(); change(); await finish();
      assert(get('#sj-test-feedback')?.textContent==='配置已修改，请重新测试连接','changed draft never inherits old test success');
      assert(getHistory()[0].business==='连接测试通过','old test remains available in history');
    }
    await start(); await finish();
    assert(get('#sj-test-feedback').textContent==='连接测试通过','unchanged draft displays success');
    input('#sj-channel-model','new-after-success');
    assert(get('#sj-test-feedback').textContent.includes('配置已修改'),'editing invalidates completed success immediately');
    await start(); input('#sj-channel-url','https://c.example/v1'); reject(new Error('old failure'));
    await until(()=>get('[data-prompt-action="model-test"]'),'failed test ends');
    assert(!get('#sj-test-feedback').textContent.includes('old failure'),'old failure does not overwrite changed draft notice');
    await start(); const oldEndpoint=sent.connection.endpoint; click('model-cancel'); click('model-edit'); await finish();
    assert(!get('#sj-test-feedback'),'cancel and reopen cannot inherit an old session result');
    assert(getHistory()[0].endpoint===oldEndpoint,'history keeps tested endpoint');
    click('model-cancel');

    await clearHistory();
    const reading=await beginHistory({purpose:'correct',messages:[{role:'user',content:'可选择的测试文本\n'.repeat(200)}],connection:{}},null);
    finishHistory(reading,{text:'完整修订稿'});
    const running=await beginHistory({purpose:'connection-test',messages:[{role:'user',content:'ok'}],connection:{}},null);
    await retryHistory();
    get('[data-settings-section="history"]').click();
    const row = () => [...body.querySelectorAll('[data-history-record]')].find(el=>el.dataset.historyRecord===reading.id);
    row().open=true; row().querySelector('details').open=true;
    const copy = row().querySelector('[data-history-copy]'); copy.focus({preventScroll:true});
    const focusKey=copy.dataset.historyView;
    const pre=row().querySelector('pre'); pre.scrollTop=130; body.scrollTop=180;
    const expectedScroll=body.scrollTop, expectedTextScroll=pre.scrollTop;
    const selection=document.getSelection(); selection.setBaseAndExtent(pre.firstChild,2,pre.firstChild,8);
    const selectedText=selection.toString();
    const verifyReading = label => {
      assert(row().open && row().querySelector('details').open,`${label}: folds stay open`);
      assert(document.activeElement.dataset.historyView===focusKey,`${label}: focus preserved`);
      assert(body.scrollTop===expectedScroll && row().querySelector('pre').scrollTop===expectedTextScroll,`${label}: scroll preserved`);
      assert(document.getSelection().toString()===selectedText,`${label}: text selection preserved`);
    };
    finishHistory(running,{text:'ok'}); verifyReading('response completion');
    updateHistory(running.id,{business:'连接测试通过'}); verifyReading('business completion');
    await retryHistory(); verifyReading('persist completion');
    host.persistRequestHistory=async()=>{throw Error('fixture offline');};
    await retryHistory(); assert(historyStatus(),'save failure is reported'); verifyReading('save failure banner');
    host.persistRequestHistory=original.persist; await retryHistory(); verifyReading('save retry');
    get('[data-settings-section="model"]').click();
    assert(!body.querySelector('.sj-request-history'),'navigation still leaves history normally');
  } finally {
    host.generateViaBackend=original.backend; host.captureModelConnection=original.capture;
    host.persistRequestHistory=original.persist; saveSettings({model:original.model});
    await clearHistory();
  }
}
