# 世局核心（W1–W2）

面板在 W4 把「立即演进」「重跑」接到下面两条入口。按钮只调用它们，不自己提交，也不自己注入。

## 三条入口

都从 `src/modules/timeGate/index.js` 导出。成功时只经 `commitEvolutionSuccess`。失败不调用它。

| 函数 | 做什么 |
| --- | --- |
| `runAutomaticGate()` | 末楼时间比已演进日更晚才推演一次。同一天、缺标签、时间对不上，模型调用是 0。末楼正在 regenerate / swipe 时直接返回，不动账。 |
| `runImmediateEvolution()` | 不等跨日；有新正文、未承接修正、未承接偏好或故事时间推进才调用模型。故事日仅跟随正文时间，不人为加一。没有已启用的世界就返回。 |
| `rerunLastEvolution()` | 没有 checkpoint 时不调模型。有的话用那次记下的输入重算，替换该次今日变更，再追加一条日志。故事日不加一。 |

建世界是 `bootstrapWorld()`（`src/modules/bootstrap`）。启用时最多一次建世界模型调用，然后把时钟拨到聊天里已经走过的日子，**不推演**。再启用已有的账不会再调模型，也不改历史楼的 `mes`。

## 唯一提交

`commitEvolutionSuccess(pending)` 在 `src/modules/commit/index.js`。

全插件只有这一处 `evolutionLog.push`。同一次调用里晋升 `lastEvolutionCheckpoint`。`pending.ok !== true` 时抛 `SHIJU_COMMIT_REFUSED`，日志和 checkpoint 都不变。对账只丢失效锚点并回滚，不追加。

日志最多留 8 条，多出来的从最旧丢掉。

异步操作在入队时绑定宿主、角色 / 群组、聊天 ID 和聊天切换序号。读取资料、调用模型、提交或写失败计数时都沿用这一份归属；切走再切回也会使旧操作失效。过期操作不写当前聊天的世界账、日志或计数，排队入口返回 `reason: 'chat-changed'`，底层接口抛 `SHIJU_CHAT_CHANGED`。归属信息只留在内存，不进入聊天存档或模型输入。

## 模型

只有 `src/modules/model/index.js` 的 `generateViaST` 会找宿主的 `generateViaBackend`。酒馆入口把它接到独立同源后端请求。浏览器里不 `fetch` 上游。

## 时间

有效时间源和设置页同一规则：手选的世局标签、自定义标签不动；`auto` 以及存着的柏宝书，要探测到书才走柏宝书，否则是世局标签。探测用 `detectBaibaiBook()`，不从 `src/ui` 引用。

柏宝书的钟看 `bbs_end` / `bbs_start`（其次叶子时间、再其次 `latestStoryTime`）。不看 `snapshot.state.time`。

`shiju_timetag` 只在世局标签档、且世界已启用时写到 depth 0。隐藏正则 id 是 `shiju-time-tag-hide`，只藏显示层。柏宝书档清掉这把 key，正则仍交给柏宝书。

时间源设置、自定义标签名、世界账变更和 `CHAT_CHANGED` 都会同步刷新时间提示词与隐藏正则。切入已启用聊天时恢复提示词；切入未启用、冻结或没有世界账的聊天时清空。重复注册不会叠加监听，未变化的隐藏正则不会重复保存。

相对时间（如「次日」「三天后」）把最近已应用的时间源、自定义标签名、楼层、swipe 和时间指纹记在 `storyClock.relativeTimeAnchor`。重复读取同一锚点返回同日，不再次调用演进模型；新楼层的同名标签仍可推进。锚点随故事时钟保存、导出和回滚，建世界与重开时的对齐也会记录；演进失败不消耗锚点，仍沿用失败暂停与重试规则。

## 注入（W3）

`shiju_macro` 在 `src/modules/inject`，**depth 4**。`shiju_timetag` 仍是另一把 key，注入模块不写它，也不改 `mes`。

两把 key 都通过 `src/host.js` 的 `writeInChatPrompt()` 使用酒馆 `IN_CHAT` 模式，以 system 角色按聊天深度注入；`IN_PROMPT` 不按传入的 depth 定位。深度从聊天末尾按消息条数计算，宏观背景为 4，时间标签规则为 0；不改写已存聊天。`scripts/prompt-depth-check.mjs` 覆盖两种写入路径、长/短/空历史中的排列与清空，入口检查同时验证酒馆枚举的传递。

会写进宏观注入的：宏观事态、远方见闻。远方每一条都带「发生于远方」。隐秘和 veil 默认不进；只有主角已知（手动覆盖优先，否则读自动知情状态）才进；用户查看不授予主角知情，kind 仍是 `secret`。正文固定带 D17 原话：**「背景参考，不必强行写入正文」**，并写明勿强迫主角介入、远方不当眼前戏。短摘要默认不超过 1500 字。

`extension_settings.shiju.inject.enabled` 默认开。关掉只清 `shiju_macro`，不停演进，时间标签照旧。`getInjectPreview()` 给面板只读预览；关掉时预览还在，提示词是空的。

生成开始、世界账或设置变更时会 `refreshInject()`。

## 启停与故事日（W3）

`src/modules/lifecycle`。

| 动作 | 行为 |
| --- | --- |
| 冻结 `freezeWorld()` / `setPluginEnabled(false)` | `enabled=false`，写下 `frozenAt`。演进入口直接返回。`shiju_macro` 和 `shiju_timetag` 都清空。不删楼层，不追加 `evolutionLog`。 |
| 重开 `reopenWorld()` / `setPluginEnabled(true)` | 没有账就建世界一次，不推演。已有账则解冻，把时钟拨到当前正文，`lastEvolvedDayIndex` 跟着拨过去。**关闭期间不补演**。注入和时间标签恢复。 |
| 正文日期互相打架 | 不猜、不取平均。提示二选一：保持插件状态，或手动校正。这种打架不能「以正文为准重对齐」。 |
| 插件日和正文日不一致，正文本身没有打架 | 可以「以正文为准重对齐」（1 次模型，不走 `commitEvolutionSuccess`），或保持插件状态。 |
| 手动校正 `correctStoryDay({ choice: 'set', dayIndex, dateLabel })` | 写入故事日，按该日重算今日变更。不删楼层，不追加日志。 |

缺标签不强制弹窗。校正和冻结都不写用户楼的 `mes`。

## 单条修正（W4）

`src/modules/intervene`。跟立即演进、重跑分开：不调用 `commitEvolutionSuccess`，不追加 `evolutionLog`，故事日不前进。

| 函数 | 做什么 |
| --- | --- |
| `saveFactManual({ kind, id, patch })` | 硬改一条事件或今日变更的 `title` / `body`，马上 `saveWorld`。模型调用是 0。 |
| `previewAiCorrection({ kind, id, instruction? })` | 只经 `generateViaST` 出修订稿。返回 `previewText` 和 `modelCalls: 1`。不写账。 |
| `applyAiCorrection({ kind, id, text })` | 把确认过的正文写进这一条。稿子可以先被用户改过。这次调用是 0。 |

隐秘未向用户显示时三条都拒绝（`SHIJU_INTERVENE_REFUSED`），账本不动。确认文案用 `AI_CORRECTION_CONFIRM`，里面有「消耗 1 次调用」。取消预览只发生在界面。

生成修订稿期间若世界账已更新，预览拒绝返回过期稿件（`SHIJU_INTERVENE_REFUSED`），提示重新生成；保留冻结、手动修改和自动演进等操作的结果，不回写旧快照，也不自动重试模型调用。

写下去的那一条带 `evidence: '用户修正'`，`timeline` 追加一句「用户修正」。这不是演进日志。

## 演进世界书（D18′ / D23）

建世界、跨日推演、立即演进、重跑组装世界书时走 `selectWorldbook`。启用且未排除的标题进名册。正文整条进或整条不进：蓝灯 `constant`、书级 `forceInclude`（含绿灯，不经轮转）、以及本轮 K 个焦点名子串命中 `key` / `keysecondary`。`exclude` 整本不进名册也不进正文。扫描词只是这 K 个名字，不扫聊天，也不把轮转池全部名字当扫词。

轮转池是地区、组织、势力的 `name`，加上 `kind === "macro"` 且阶段为萌芽 / 发展 / 高潮（阶段缺省视为进行中）的事件标题。已归档、消退、稳定、远方见闻、隐秘不进池。游标在 `chatMetadata.shiju.worldbookRotateCursor`。`dayDelta = max(1, 本轮前进故事日数)`，`K = min(12, 3 + floor(log2(dayDelta)) * 2)`。成功提交时把本轮扫描起点、`dayDelta`、`k` 和 `scanWords` 记在 `lastEvolutionCheckpoint.worldbookScan`。重跑按这份快照重选同一批绿灯，不再推进游标。

世界书不再做 12k 总硬顶，也不再默认 `slice(8000)`。P0 / P1 / P3 仍按建议长度软截，并可以打 `meta.sources.softWarn`。单条极大整条保留。每次组装把估算 token 放在返回值 `usage`（`worldbook` / `mvu` / `recent` / `total`，单位 `token`；没有 MVU 则 `mvu` 为 0），提交成功后写到 `meta.usage`，面板读 `projectWorld().usage`。

## 检查

```bash
npm run smoke
```


## 编辑、增量和事件生命周期（schema 5）

- `turn` 统一串行协调手动写入和世界更新，演进从入队到持久化完成占用按聊天绑定的内存运行锁。手动保存、采用修订、隐秘操作在界面禁用，核心拒绝 `SHIJU_WORLD_BUSY`。成功、失败均释放；切换聊天使旧锁和编辑归属失效。
- `processedInput` 保存楼层、swipe、内容哈希、时间指纹和已处理末楼正文（schema 7 起使用物理楼层）。建世界/解冻建立基线，演进成功推进，失败不推进。末楼续写只送新增后缀；中间非追加修改走对账或提示。旧档优先恢复有效日志/建世界锚点，无可信锚点则当前末楼建立基线并提示。
- `userCorrections` 按 kind/id 去重，记录手动和采用 AI 稿件后的当前事实。未承接修正以单独优先段落进入下一轮，不受普通摘要截断；成功后 consumed，失败保留。修正不冻结后续剧情。
- 日期顺序在解析遍历中检查。明确矛盾在对账回滚前拦截，保留世界账、暂停自动演进；修正后恢复。普通正文编辑不触发日期矛盾提示。
- 隐秘的用户查看（viewMode/revealed）与主角知情（autoKnown、knowledgeOverride、knowledgeEvidence）分离。覆盖为 auto/known/unknown；模型自动知情必须引用本轮提供的剧情或记忆原句，世界书不能作为唯一证据。关联今日变更共享事件状态。
- 事件 `lifecycle` 为 active/archived，缺省 active；phase 仍描述阶段。8～12 是模型软目标，不截断、不因数量自动删除或归档。ID 优先匹配；归档保留原文和关联关系，outcome 写入带 sourceEventId 的事实；mergedInto 指向合并后的事件。归档全文不参与常规提示词、注入和轮转，只提供 ID/标题索引供旧事复发识别。
- 世界书入口汇总全局、角色主书、角色附加书、聊天绑定书、人设绑定书和内嵌书。绑定去重，外部最新书优先，缺失时内嵌回退；缺失单本不影响其他书。蓝绿灯/常驻/排除逻辑保持不变。

以上持久字段纳入聊天保存和检查点/回滚；运行锁、编辑归属不持久化。旧档保留全部事件和原有揭晓状态。重跑的历史输入窗口和日志追加行为本轮不调整。


## 模型设置与演进偏好（schema 6）

`src/preferences.js` 定义预设、校验与有效快照。全局 `extension_settings.shiju.model` 包含 `jailbreakMode: builtin | custom | off`、`customText: string`、`responseLength: null | 正安全整数`。`null` 表示使用操作开始时捕获的宿主回复长度。保存校验拒绝空白自定义或非法长度；保留自定义原始空白。

`captureModelConfig(purpose)` 在异步资料读取前复制全局配置和当前有效偏好。任务仍传 `systemPrompt`、`prompt`，统一出口生成 `messages: Array<{role, content}>`：可选破限 system → 固定任务 system → 可选偏好 system → 任务资料 user。`bootstrap` / `evolve` / `realign` 带偏好，`correct` 不带。重跑沿用 evolve。关闭破限时省略第一段；自定义偏好只用其自身文本，不拼任何内置方向。

宿主接口为 `generateViaBackend(request, assertCurrent?, options?)`，options 可包含 `signal`、`onProgress` 和 `detailed`；详细返回包含 `text`、`httpStatus`、`elapsedMs`、`firstTextMs`、`finishReason`、`usage` 及 `actualStream`，缺失的上游字段保持未知。request 保留任务参数，并包含 `messages`、可选 `responseLength` 与连接快照 `connection`。适配器直接请求同源后端；没有模型串行队列，不调用 `generateRaw`，不触发宿主生成事件。聊天写入队列继续独立生效。

聊天偏好接口：

- `loadPreferences()`：读取 `chatMetadata.shijuPreferences`，缺省 `{ mode: 'natural', customText: '' }`。
- `saveEvolutionPreferences({ preferences, chatScope? })`：复用 `enqueueEdit`、归属检查和元数据合并保存，不需要世界账；演进中拒绝写入，其他元数据保留。
- 有效快照 `{ mode, text }` 只取当前生效内容，未启用的 customText 不影响待承接比较。模式 ID 为 natural / steady / intrigue / upheaval / custom。

世界账 `appliedPreferences` 记录最近成功提供给模型的快照，纳入 minSubset、建世界快照、检查点和回滚。建世界、演进（含重跑）、重对齐成功提交该快照；失败、跨聊天取消、单条修正、手动改日期和解冻不消耗。回滚不修改用户的 `shijuPreferences`；重跑使用当前选择，历史窗口和日志策略保持原样。旧档缺字段时视为自然演进已承接。

立即演进新增偏好待承接条件；只有偏好变化时，输入明确要求调整未来方向、不重演历史、不改写既有事实、不强制新增事件。保存不触发模型，自动时间门仍要求跨日。成功承接后若无其他增量，返回 `reason: 'no-increment'`。

## 兼容输入与请求（schema 7）

- `processedInput.version = 2`。`rows` 使用 `floor / identity / swipeId / hash / timeFingerprint / status`，`status` 为 processed、excluded、pending；`excluded` 另记观察到但未承接的手动隐藏楼层。物理列表不因可见性变化而缩短。末楼追加只取后缀，其他修改仍走对账。`processedInput` 整体纳入 `minSubset` / `applySubset`。
- 编辑事件不更新已处理正文的 `hash` 或 `tipText`，也不清空待对齐提示。时间锚点有效仅说明无需因时间回滚，随后仍由 `readIncrement()` 与既有边界比较正文；非追加改写设置 `inputHint: history-changed`，界面提供重对齐/保持选择。成功重对齐或明确保持后才承接改写；撤销回原正文则由正常检测清除提示。可见性与正文校验继续独立，无新增存档字段。
- `readSourcePack()` 捕获聊天归属、正文、变量和柏宝书快照。检查 snapshot/history/injectedHistory/getFloor 的聊天 ID 与 revision，并在异步世界书读取后复核；最多重读一次。公开 `getHistory({before})` 提供最近窗口前的压缩历史，`getFloor` 的 valid memory 为未承接的隐藏楼层提供一次性增量。排除范围不会重新经过摘要进入请求。
- `assembleRenderedInput()` 先执行原有选择器，再 `renderSelected()`，最后复用同步预算组装。`vendor/template-worker.js` 是本地 EJS/SES/Lodash 子集及 Endo 兼容转换产物；`runtime.js` 不接受宿主对象。EJS 生成代码经 `evadeCensorSync` 转换后才交给 SES，引用条目使用同一路径。`_.omit` 先深拷贝输入再调用锁定版本的实现。超时由主线程终止 Worker，包含加载与转换时间；单条错误返回诊断，其他条目继续。诊断仅在当前聊天的内存中保存，切换后失效。
- EJS 跳过诊断保留 `kind/reason`，增加 `code`（`EJS_TRANSFORM`、`EJS_TAGGED_TEMPLATE`、`EJS_EXECUTION`、`EJS_DEPENDENCY`、`EJS_CYCLE`、`EJS_LIFECYCLE`、`EJS_WORKER`、`EJS_TIMEOUT`）及适用时的 `chain: [{id,bookName,title}]`。外层书名/标题仍指被选中的父条目，用于从目录移除失败资料；`reason` 包含实际失败引用链。不要把解析器原始错误或模板抛出的异常消息传给界面，它们可能包含源码或变量内容。无持久字段或存档迁移。
- `captureModelConnection(model)` 同步复制当前连接、采样、格式和长度，`captureModelConfig()` 在资料读取之前调用。`src/host/native-builders.js` 是去除全局副作用后的参数构造；`tokens.js` 对捕获的 bias / ban / stop 使用独立分词请求，不读写宿主缓存。采样请求类型 quiet、没有工具；跟随酒馆保持非流式，自定义按捕获的开关选择流式。
- 宿主 Custom 服务商的附加 YAML 使用酒馆的纯解析器读取副本，保留采样附加项，过滤会覆盖或删除消息、模型、流式、长度和工具字段的设置；不修改宿主原配置。无可用解析器或格式错误时明确报错。
- `sendRequest()` 只请求固定的酒馆同源路径。自定义地址规范化后放入 `reverse_proxy`，密钥放入 `proxy_password`，不改酒馆密钥库。HTTP 错误仅保留有界的响应摘录，存储与展示前脱敏已知密钥；不保存认证头或完整连接配置。酒馆隐藏的上游状态、结束原因和用量保持未知，不推测。Horde 创建一次、轮询、失败或取消后取消任务；不把轮询算作重试。
- 全局 `model` 增加 `channelMode: follow | custom`、`endpoint`、`customModel`、`apiKey`。旧配置默认 follow。未启用的配置仍保留，聊天保存/导出不包含这些字段。
- 未支持的版本/接口报 `SHIJU_UNSUPPORTED_API`；快照持续变化报 `SHIJU_SOURCE_CHANGED`。失败不提交新边界、用户修正和偏好快照；观察到的排除记录可单独保存，防止重试重新纳入隐藏内容。


## 模型请求历史接口

模型统一出口在请求发起时捕获聊天身份、消息及连接摘要，通过 `beginHistory` / `finishHistory` 更新请求记录；流式进度只保存在内存，不逐块写服务器。业务校验将对应记录更新为失败、修订稿生成或世界账提交完成；`transportStatus` 与业务结果分开记录。连接测试不附加业务协议，并在 120 秒后取消。

历史宿主接口为 `loadRequestHistory(): Promise<string|null>` 和 `persistRequestHistory(gzipBase64): Promise<void>`。`src/host/history-file.js` 使用同源 `/api/files/upload` 与 `/user/files/shiju-request-history-v1.json`，固定文件名、账号隔离、禁止缓存、每次操作 15 秒上限、保存后回读确认。不调用全量设置接口或宿主 `saveSettings()`，不改变其他插件临时长度；无需服务器插件。文件封装为 `{format:'shiju-request-history',version:1,data:<gzipBase64>}`。gzip 编码不超过 2 MiB，解压不超过 16 MiB，最多 30 条；超大单条仅落盘摘要，本页保留全文。开始时落盘请求摘要，结束及业务结果确定后落盘完整记录。

读取失败会阻止后续覆盖；手动重试先读取并合并本页新记录。保存失败只影响历史，显示轻提示及设置内的重试入口，用户可导出本页记录。密钥和反向代理口令在内容、错误及复制导出前脱敏。历史文件不注册为聊天附件或知识库资料，因此酒馆数据清理工具可能将它视为未引用文件，界面明确提示勿清理。跨设备需轮流使用并刷新；不保证多设备同时写入。首次读取文件不存在视为空历史，损坏或权限错误不会视为空文件覆盖。
